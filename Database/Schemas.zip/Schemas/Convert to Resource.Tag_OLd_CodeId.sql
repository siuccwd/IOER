USE [Isle_IOER]
GO

CREATE PROCEDURE [dbo].[ResourceTab.Convert] 
AS
BEGIN
	SET NOCOUNT ON;
	
--==> may need some cleanup ex with audience type
/*
SELECT     TOP (200) RowID, ResourceId, AudienceId, OriginalAudience, CreatedById, Created, ResourceIntId
FROM         [Resource.IntendedAudience]
WHERE     (AudienceId IS NOT NULL) AND (ResourceIntId NOT IN
                          (SELECT     Id
                            FROM          Resource))
ORDER BY Created DESC

*/
--  ========== Access Rights??? --> store with RV, only one value =================
-- if used, need to ensure only one record is created
--INSERT INTO [dbo].[Resource.Tag]
--           ([ResourceIntId]
--           ,[CategoryId]
--           ,[TagValueId]
--           ,[Created]
--           ,[CreatedById]
--           ,[OriginalValue])

--SELECT 
--top 1000
--		rv.[ResourceIntId]
--		,1		--Access Rights
--		,rv.AccessRightsId
--		,res.[Created]
--		,NULL		--[CreatedById]
--		,rv.AccessRights
      
--  FROM [dbo].[Resource.Version] rv
--  inner join [Resource] res on rv.resourceIntId = res.id
--where rv.IsActive = 1 AND AccessRightsId is not null 

--GO
--  ========== audienceType =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,7		--Audience Type
		,[AudienceId]
		,[Created]
		,[CreatedById]
		,[OriginalAudience]
      
  FROM [dbo].[Resource.IntendedAudience]
where [AudienceId] is not null 

--GO

--  ========== Career Cluster =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,8		--Career Cluster
		,ClusterId
		,[Created]
		,[CreatedById]
		,''
      
  FROM [dbo].[Resource.Cluster]
where ClusterId is not null 

--GO
--  ========== Educational Use =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,11		--Educational Use
		,EducationUseId
		,[Created]
		,[CreatedById]
		,OriginalType
      
  FROM [dbo].[Resource.EducationUse]
where EducationUseId is not null 

--GO

--  ========== Grade Level =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,13		--Grade Level
		,GradeLevelId
		,[Created]
		,[CreatedById]
		,OriginalLevel
      
  FROM [dbo].[Resource.GradeLevel]
where GradeLevelId is not null 

--GO

--  ========== Group Type =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,14	--Group Type
		,GroupTypeId
		,[Created]
		,[CreatedById]
		,''	--OriginalLevel
      
  FROM [dbo].[Resource.GroupType]
where GroupTypeId is not null 

--GO


--  ========== Item Type =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,15	--Item Type
		,ItemTypeId
		,[Created]
		,[CreatedById]
		,''	--OriginalLevel
      
  FROM [dbo].[Resource.ItemType]
where ItemTypeId is not null 

--GO

--  ========== Language =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,17			--Language
		,LanguageId
		,[Created]
		,[CreatedById]
		,OriginalLanguage
      
  FROM [dbo].[Resource.Language]
where LanguageId is not null 

--GO

--  ========== Resource Format =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,18			--Resource Format
		,CodeId
		,[Created]
		,[CreatedById]
		,OriginalValue
      
  FROM [dbo].[Resource.Format]
where CodeId is not null 

--GO

--  ========== Subject ????????????????????????? =================
-- not sure we want to use as tab or .Text
--INSERT INTO [dbo].[Resource.Tag]
--           ([ResourceIntId]
--           ,[CategoryId]
--           ,[TagValueId]
--           ,[Created]
--           ,[CreatedById]
--           ,[OriginalValue])

--SELECT 
--top 1000
--		[ResourceIntId]
--		,20			--Subject
--		,CodeId
--		,[Created]
--		,[CreatedById]
--		,[Subject]
      
--  FROM [dbo].[Resource.Subject]
--where CodeId is not null 

--GO

--  ========== Resource Type =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[CategoryId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		,19			--Resource Type
		,ResourceTypeId
		,[Created]
		,[CreatedById]
		,OriginalType
      
  FROM [dbo].[Resource.ResourceType]
where ResourceTypeId is not null 


END
go