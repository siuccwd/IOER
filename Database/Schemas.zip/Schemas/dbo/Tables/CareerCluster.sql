USE [LearningRegistryCache_Dev]
GO

/****** Object:  Table [dbo].[CareerCluster]    Script Date: 07/17/2012 15:08:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CareerCluster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CareerCluster](
	[Id] [int] NOT NULL,
	[CareerCluster] [nvarchar](255) NOT NULL,
	[CisFileNum] [char](6) NULL,
	[IsHighGrowth] [bit] NULL,
	[IsActive] [bit] NULL,
	[NaicSect] [char](2) NULL,
	[ShortName] [varchar](25) NULL,
	[HighGrowthName] [varchar](75) NULL,
	[IsIlPathway] [bit] NULL,
	[IlPathwayName] [varchar](75) NULL,
	[prefix] [varchar](15) NULL,
	[Description] [nvarchar](255) NULL,
	[IlPathwayChannel] [varchar](75) NULL,
	[IlPathwayReportOrder] [int] NULL,
 CONSTRAINT [PK_CareerCluster] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_CareerCluster_IsHighGrowth]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CareerCluster] ADD  CONSTRAINT [DF_CareerCluster_IsHighGrowth]  DEFAULT ((0)) FOR [IsHighGrowth]
END

GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_CareerCluster_IsActive]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CareerCluster] ADD  CONSTRAINT [DF_CareerCluster_IsActive]  DEFAULT ((1)) FOR [IsActive]
END

GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_CareerCluster_IsHighGrowth1]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CareerCluster] ADD  CONSTRAINT [DF_CareerCluster_IsHighGrowth1]  DEFAULT ((0)) FOR [IsIlPathway]
END

GO


