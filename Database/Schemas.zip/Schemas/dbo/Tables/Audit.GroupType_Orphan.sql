USE [LearningRegistryCache_DEV_20121005]
GO

/****** Object:  Table [dbo].[Audit.GroupType_Orphan]    Script Date: 03/20/2013 08:40:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Audit.GroupType_Orphan](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ResourceIntId] [int] NULL,
	[OriginalValue] [varchar](200) NULL,
	[FoundMapping] [bit] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[LastRerunDate] [datetime] NULL,
	[ResourceRowId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Audit.GroupType_Orphan] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Audit.GroupType_Orphan] ADD  CONSTRAINT [DF_Audit.GroupType_Orphan_FoundMapping]  DEFAULT ((0)) FOR [FoundMapping]
GO

ALTER TABLE [dbo].[Audit.GroupType_Orphan] ADD  CONSTRAINT [DF_Audit.GroupType_Orphan_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Audit.GroupType_Orphan] ADD  CONSTRAINT [DF_Audit.GroupType_Orphan_Created]  DEFAULT (getdate()) FOR [Created]
GO


