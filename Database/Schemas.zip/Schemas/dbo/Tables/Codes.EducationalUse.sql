USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  Table [dbo].[Codes.EducationalUse]    Script Date: 03/13/2013 12:37:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.EducationalUse](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[Description] [varchar](500) NULL,
	[EdUseCategoryId] [int] NULL,
	[SortOrder] [int] NULL,
	[IsActive] [bit] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.EducationalUse] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.EducationalUse]  WITH CHECK ADD  CONSTRAINT [FK_Codes.EducationalUse_Codes.EducationalUse] FOREIGN KEY([Id])
REFERENCES [dbo].[Codes.EducationalUse] ([Id])
GO

ALTER TABLE [dbo].[Codes.EducationalUse] CHECK CONSTRAINT [FK_Codes.EducationalUse_Codes.EducationalUse]
GO

ALTER TABLE [dbo].[Codes.EducationalUse]  WITH CHECK ADD  CONSTRAINT [FK_Codes.EducationalUse_Codes.EducationalUseCategory] FOREIGN KEY([EdUseCategoryId])
REFERENCES [dbo].[Codes.EducationalUseCategory] ([Id])
GO

ALTER TABLE [dbo].[Codes.EducationalUse] CHECK CONSTRAINT [FK_Codes.EducationalUse_Codes.EducationalUseCategory]
GO

ALTER TABLE [dbo].[Codes.EducationalUse] ADD  CONSTRAINT [DF_Codes.EducationalUse_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO

ALTER TABLE [dbo].[Codes.EducationalUse] ADD  CONSTRAINT [DF_Codes.EducationalUse_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO


