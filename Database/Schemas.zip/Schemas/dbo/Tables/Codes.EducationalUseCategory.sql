USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  Table [dbo].[Codes.EducationalUseCategory]    Script Date: 03/13/2013 12:37:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.EducationalUseCategory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Category] [varchar](50) NULL,
	[Description] [varchar](200) NULL,
	[SortOrder] [int] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.EducationalUseCategory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.EducationalUseCategory] ADD  CONSTRAINT [DF_Codes.EducationalUseCategory_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO


