USE [LearningRegistryCache_Dev]
GO

/****** Object:  Table [dbo].[Codes.AlignmentType]    Script Date: 08/01/2012 09:56:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Codes.AlignmentType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Codes.AlignmentType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](50) NULL,
	[Title] [varchar](50) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.AlignmentType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Codes.AlignmentType_WarehouseTotal]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Codes.AlignmentType] ADD  CONSTRAINT [DF_Codes.AlignmentType_WarehouseTotal]  DEFAULT ((0)) FOR [WarehouseTotal]
END

GO


