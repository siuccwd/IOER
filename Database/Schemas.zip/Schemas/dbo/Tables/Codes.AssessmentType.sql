USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  Table [dbo].[Codes.AssessmentType]    Script Date: 03/19/2013 17:50:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.AssessmentType](
	[Id] [int] NOT NULL,
	[Title] [varchar](50) NULL,
	[Description] [varchar](500) NULL,
	[IsActive] [bit] NULL,
	[WarehouseTotal] [int] NULL,
	[SortOrder] [int] NULL,
 CONSTRAINT [PK_Codes.AssessmentType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.AssessmentType] ADD  CONSTRAINT [DF_Codes.AssessmentType_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Codes.AssessmentType] ADD  CONSTRAINT [DF_Codes.AssessmentType_WarehouseTotal]  DEFAULT ((0)) FOR [WarehouseTotal]
GO

ALTER TABLE [dbo].[Codes.AssessmentType] ADD  CONSTRAINT [DF_Codes.AssessmentType_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO


