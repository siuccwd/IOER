USE [Isle_IOER]
GO

/****** Object:  Table [dbo].[Blacklist.Hosts]    Script Date: 3/11/2014 2:51:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Blacklist.Hosts](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Hostname] [varchar](100) NULL,
	[RecordSource] [varchar](50) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedId] [int] NULL,
 CONSTRAINT [PK_Blacklist.Hosts] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Blacklist.Hosts] ADD  CONSTRAINT [DF_Blacklist.Hosts_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Blacklist.Hosts] ADD  CONSTRAINT [DF_Blacklist.Hosts_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


