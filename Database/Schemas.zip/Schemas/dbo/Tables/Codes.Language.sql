USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  Table [dbo].[Codes.Language]    Script Date: 03/13/2013 12:38:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.Language](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[IsPathwaysLanguage] [bit] NULL,
	[IsActive] [bit] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.Language] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.Language] ADD  CONSTRAINT [DF_Codes.Language_IsPathwaysLanguage]  DEFAULT ((0)) FOR [IsPathwaysLanguage]
GO

ALTER TABLE [dbo].[Codes.Language] ADD  CONSTRAINT [DF_Codes.Language_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO


