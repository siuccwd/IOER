USE Isle_IOER
GO

/****** Object:  Table [dbo].[AuditReport.Detail]    Script Date: 08/30/2012 10:04:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[AuditReport.Detail](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReportId] [int] NOT NULL,
	[Filename] [varchar](100) NULL,
	[DocID] [varchar](100) NULL,
	[URI] [varchar](500) NULL,
	[MessageType] [char](1) NULL,
	[MessageRouting] [varchar](2) NULL,
	[Message] [varchar](500) NULL,
 CONSTRAINT [PK_AuditReport.Detail] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

