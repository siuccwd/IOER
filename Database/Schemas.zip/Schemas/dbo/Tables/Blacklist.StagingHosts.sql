USE [Isle_IOER]
GO

/****** Object:  Table [dbo].[Blacklist.StagingHosts]    Script Date: 3/11/2014 2:51:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Blacklist.StagingHosts](
	[Line] [varchar](500) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


