USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  Table [dbo].[Codes.GradeLevel]    Script Date: 03/13/2013 12:35:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.GradeLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[NsdlTitle] [varchar](50) NULL,
	[AgeLevel] [int] NULL,
	[Description] [varchar](500) NULL,
	[IsPathwaysLevel] [bit] NULL,
	[IsK12Level] [bit] NULL,
	[IsActive] [bit] NULL,
	[AlignmentUrl] [varchar](150) NULL,
	[SortOrder] [int] NULL,
	[WarehouseTotal] [int] NULL,
	[GradeRange] [varchar](50) NULL,
	[GradeGroup] [varchar](50) NULL,
	[PathwaysEducationLevelId] [int] NULL,
 CONSTRAINT [PK_Codes.GradeLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.GradeLevel] ADD  CONSTRAINT [DF_Codes.GradeLevel_IsPathwaysLevel]  DEFAULT ((1)) FOR [IsPathwaysLevel]
GO

ALTER TABLE [dbo].[Codes.GradeLevel] ADD  CONSTRAINT [DF_Codes.GradeLevel_IsK12Level]  DEFAULT ((0)) FOR [IsK12Level]
GO

ALTER TABLE [dbo].[Codes.GradeLevel] ADD  CONSTRAINT [DF_Codes.GradeLevel_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO


