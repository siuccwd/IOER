USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[CodeTables_UpdateWarehouseTotals]    Script Date: 01/11/2013 10:48:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
UPDATE [dbo].[Resource.Subject]
   SET [CodeId] = code.Id
--		select [ResourceIntId] ,[Subject], code.Id
from [Resource.Subject] base
inner join [Codes.subject] code on base.Subject = code.Title
 

*/


/*
Exec CodeTables_UpdateWarehouseTotals 5
*/
-- =========================================================================
-- 13/03/04 mparsons - was taking too long, so split up
-- 14/05/28 mparsons - added Codes.TagValue. Leaving others for now
-- =========================================================================
ALTER  Procedure [dbo].[CodeTables_UpdateWarehouseTotals]
    @debugLevel int = 0

AS
--declare @debugLevel int
-- ==========================================================
print 'updating all Codes.TagValue ...'
UPDATE [dbo].[Codes.TagValue]
   SET [WarehouseTotal] = base.WarehouseTotal
from [Codes.TagValue] codes      
Inner join ( 
SELECT [TagValueId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Tag] base
  inner join [Resource] rvs on base.ResourceIntId = rvs.Id
  where rvs.IsActive = 1
  group by [TagValueId]
    ) base on codes.Id = base.[TagValueId]
-- ==========================================================
print 'updating StandardBody.Node ...'
UPDATE [dbo].[StandardBody.Node]
   SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal      
FROM [dbo].[StandardBody.Node] codes
Inner join ( 
SELECT StandardId ,count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Standard] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
    group by StandardId
    ) base on codes.Id = base.StandardId
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0)) 

-- *** TODO - remove the follwing after convertion ***
-- ==========================================================
print 'updating Codes.ResourceType ...'
UPDATE [dbo].[Codes.ResourceType]
   SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal      
FROM [dbo].[Codes.ResourceType] codes
Inner join ( 
SELECT [ResourceTypeId] ,count(*) AS wareHouseTotal
  FROM [dbo].[Resource.ResourceType] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
    group by [ResourceTypeId]
    ) base on codes.Id = base.[ResourceTypeId]
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0)) 

-- ==========================================================
print 'updating [Codes.ResourceTypeCategory] ...'
UPDATE [dbo].[Codes.ResourceTypeCategory]
   SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.[Category], base.WarehouseTotal      
FROM [dbo].[Codes.ResourceTypeCategory] codes
Inner join ( 
SELECT [CategoryId] ,sum(wareHouseTotal) As wareHouseTotal
  FROM [dbo].[Codes.ResourceType]
    group by [CategoryId]
    ) base on codes.Id = base.[CategoryId]
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0)) 

-- ==========================================================
print 'updating Codes.GradeLevel ...'
UPDATE [dbo].[Codes.GradeLevel]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.GradeLevel] codes
Inner join ( 
SELECT [GradeLevelId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.GradeLevel] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
  group by [GradeLevelId]
    ) base on codes.Id = base.[GradeLevelId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
if @debugLevel > 8  begin  
  select * from [dbo].[Codes.GradeLevel]
  end
-- ==========================================================
--print 'updating Codes.PathwaysEducationLevel ...'
--UPDATE [dbo].[Codes.PathwaysEducationLevel]
--SET [WarehouseTotal] = base.WarehouseTotal
---- select codes.Title, base.WarehouseTotal  
--FROM [dbo].[Codes.PathwaysEducationLevel] codes
--Inner join ( 
--SELECT [PathwaysEducationLevelId],count(*) AS wareHouseTotal
--  FROM [dbo].[Resource.EducationLevel] base
--  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
--  group by [PathwaysEducationLevelId]
--    ) base on codes.Id = base.PathwaysEducationLevelId

--print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
--if @debugLevel > 8  begin  
--  select * from [dbo].[Codes.PathwaysEducationLevel]
--  end  
-- ==========================================================
print 'updating Codes.IntendedAudience ...'
UPDATE [dbo].[Codes.AudienceType]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.AudienceType] codes
Inner join ( 
SELECT [AudienceId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.IntendedAudience] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
  group by [AudienceId]
    ) base on codes.Id = base.[AudienceId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
-- ==========================================================
print 'updating Codes.Language  ...'
UPDATE [dbo].[Codes.Language]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.Language] codes
Inner join ( 
SELECT [LanguageId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Language] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
  group by [LanguageId]
    ) base on codes.Id = base.[LanguageId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
    
-- ==========================================================
print 'updating Codes.ResourceFormat ...'
UPDATE [dbo].[Codes.ResourceFormat]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.ResourceFormat] codes
Inner join ( 
SELECT [CodeId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Format] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
  group by [CodeId]
    ) base on codes.Id = base.[CodeId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
/*    
SELECT [Value],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Property]
    where [PropertyTypeId]= 3
      group by [Value]

SELECT [Id]
      ,[Title]
      ,[WarehouseTotal]
  FROM [.[dbo].[Codes.ResourceFormat]
GO


*/
-- ==========================================================
print 'updating CareerClusters ...'
UPDATE [dbo].CareerCluster
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.IlPathwayName, base.WarehouseTotal  
FROM [dbo].CareerCluster codes
Inner join ( 
SELECT ClusterId,count(*) AS WarehouseTotal
  FROM [dbo].[Resource.Cluster] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
  group by ClusterId
    ) base on codes.Id = base.ClusterId

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
-- ==========================================================
print 'updating Access rights ...'
-- updates
UPDATE [dbo].[Codes.AccessRights]
   SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal      
FROM [dbo].[Codes.AccessRights] codes
inner join (
 SELECT AccessRightsId, count(*) As WarehouseTotal
  FROM [dbo].[Resource.Version_Summary] base
  group by base.AccessRightsId
  --Order by 2 desc
  ) base on codes.Id = base.AccessRightsId
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))

-- ======
--OLD via text
--print 'updating Access rights ...'
---- updates
--UPDATE [dbo].[Codes.AccessRights]
--   SET [WarehouseTotal] = base.WarehouseTotal
---- select codes.Title, base.WarehouseTotal      
--FROM [dbo].[Codes.AccessRights] codes
--inner join (
-- SELECT isnull(base.AccessRights,'Unknown') As AccessRights, count(*) As WarehouseTotal
--  FROM [dbo].[Resource.Version_Summary] base
--  group by base.AccessRights
--  --Order by 2 desc
--  ) base on codes.Title = base.AccessRights
--print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
-- ==========================================================
print 'updating Codes.EducationUse ...'
UPDATE [dbo].[Codes.EducationalUse]
   SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal      
FROM [dbo].[Codes.EducationalUse] codes
Inner join ( 
SELECT EducationUseId ,count(*) AS wareHouseTotal
  FROM [dbo].[Resource.EducationUse] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
    group by EducationUseId
    ) base on codes.Id = base.EducationUseId
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0)) 
-- ==========================================================
print 'updating Subjects ...'
UPDATE [dbo].[Codes.Subject]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.Subject] codes
Inner join ( 
SELECT [CodeId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Subject] base
  inner join [Resource.Version_Summary] rvs on base.ResourceIntId = rvs.ResourceIntId
  group by [CodeId]
    ) base on codes.Id = base.[CodeId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))

-- ==========================================================

