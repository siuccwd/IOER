USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceUpdate]    Script Date: 08/29/2012 14:19:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Resource.IntendedAudienceUpdate]
	@RowId uniqueidentifier,
	@AudienceId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [Resource.IntendedAudience]
    SET AudienceId = @AudienceId
    WHERE RowID = @RowId
END

GO


grant execute on [Resource.IntendedAudienceUpdate] to public
go