USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.AccessibilityFeature_SelectedCodes]    Script Date: 9/24/2014 5:50:36 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.AccessibilityFeature_SelectedCodes] 448010
*/
Create PROCEDURE [dbo].[Resource.AccessibilityFeature_SelectedCodes]
    @ResourceIntId int
As
SELECT distinct
	code.Id, code.Title, code.[Description]
   -- ,ResourceIntId
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.AccessibilityFeature] code
Left Join [Resource.AccessibilityFeature] rpw on code.Id = rpw.AccessibilityFeatureId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsActive = 1
go
grant execute on [Resource.AccessibilityFeature_SelectedCodes] to public
go
