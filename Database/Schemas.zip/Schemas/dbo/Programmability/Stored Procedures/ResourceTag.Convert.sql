USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[ResourceTag.Convert]    Script Date: 8/25/2014 1:19:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
May 22 - 

select count(*) from [Resource.Tag]

--2014-05-22 22:00:47.963
--2014-07-01 17:23:56.447
--2014-06-18 18:47:57.417
--2014-10-16 08:30:07.613
select max(created) from [Resource.Tag]


SELECT 
      [CategoryId]     ,[CategoryTitle]
	  ,[TagTitle]	        ,[TagValueId]
			,count(*)

  FROM [Isle_IOER].[dbo].[Resource_TagSummary]
    group by 
	 [CategoryId]	 ,[CategoryTitle]
	  ,[TagTitle]	        ,[TagValueId]
*/

--==> may need some cleanup ex with audience type
/*
SELECT     TOP (200) RowID, ResourceId, AudienceId, OriginalAudience, CreatedById, Created, ResourceIntId
FROM         [Resource.IntendedAudience]
WHERE     (AudienceId IS NOT NULL) AND (ResourceIntId NOT IN
                          (SELECT     Id
                            FROM          Resource))
ORDER BY Created DESC


DECLARE @StartDate datetime
set @StartDate = '2014-11-04' 
exec [dbo].[ResourceTag.Convert]  @StartDate

*/


-- =========================================================================
-- Create date: 4/25/2014
-- Description:	Populate the resource tag table from the resource child tables
--
-- Mods
-- 14-05-21 mparsons - update to check for existing - for reruns
--					 - to do - will be useful to include a date option, for ex to run after the import until latter is converted		
-- =========================================================================
ALTER PROCEDURE [dbo].[ResourceTag.Convert] 
		@StartDate datetime
AS
BEGIN
	--SET NOCOUNT ON;
	
--DECLARE @StartDate datetime
--set @StartDate = '2010-06-18'

--  ========== Access Rights??? --> store with RV, only one value =================
-- if used, need to ensure only one record is created
--INSERT INTO [dbo].[Resource.Tag]
--           ([ResourceIntId]
--           ,[TagValueId]
--           ,[Created]
--           ,[CreatedById]
--           ,[OriginalValue])

--SELECT 
--top 1000
--		rv.[ResourceIntId]
--		,1		--Access Rights
--		,rv.AccessRightsId
--		,res.[Created]
--		,NULL		--[CreatedById]
--		,rv.AccessRights
      
--  FROM [dbo].[Resource.Version] rv
--  inner join [Resource] res on rv.resourceIntId = res.id
--where rv.IsActive = 1 AND AccessRightsId is not null 

--GO
print 'audience type'
--  ========== audienceType =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,7		--Audience Type		,[AudienceId]
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,[OriginalAudience]
      
  FROM [dbo].[Resource.IntendedAudience] base
  inner join [Codes.TagCategoryValue_summary] codes on base.AudienceId = codes.TagRelativeId
where codes.categoryId = 7
AND [AudienceId] is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)

print 'Assessment type'
--  ========== Assessment Type =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,25		--Assessment Type		,[AssessmentTypeId]
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,''
      
  FROM [dbo].[Resource.AssessmentType] base
  inner join [Codes.TagCategoryValue_summary] codes on base.AssessmentTypeId = codes.TagRelativeId
where codes.categoryId = 25
AND AssessmentTypeId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)


print 'Career Cluster'
--  ========== Career Cluster =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,8		--Career Cluster		,ClusterId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,''
      
  FROM [dbo].[Resource.Cluster] base
  inner join [Codes.TagCategoryValue_summary] codes on base.ClusterId = codes.TagRelativeId
where codes.categoryId = 8
AND ClusterId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)


print 'Educational Use'
--  ========== Educational Use =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,11		--Educational Use		,EducationUseId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,OriginalType
      
  FROM [dbo].[Resource.EducationUse] base
  inner join [Codes.TagCategoryValue_summary] codes on base.EducationUseId = codes.TagRelativeId
where codes.categoryId = 11
AND EducationUseId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)

print 'Grade Level'
--  ========== Grade Level =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,13		--Grade Level		,GradeLevelId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,OriginalLevel
      
  FROM [dbo].[Resource.GradeLevel]  base
  inner join [Codes.TagCategoryValue_summary] codes on base.GradeLevelId = codes.TagRelativeId
where codes.categoryId = 13
AND GradeLevelId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)


--  ========== Group Type =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,14	--Group Type		,GroupTypeId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,''	--OriginalLevel
      
  FROM [dbo].[Resource.GroupType]  base
  inner join [Codes.TagCategoryValue_summary] codes on base.GroupTypeId = codes.TagRelativeId
where codes.categoryId = 14
AND  GroupTypeId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)


--  ========== Item Type =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,15	--Item Type		,ItemTypeId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,''	--OriginalLevel
      
  FROM [dbo].[Resource.ItemType]  base
  inner join [Codes.TagCategoryValue_summary] codes on base.ItemTypeId = codes.TagRelativeId
where codes.categoryId = 15
AND  ItemTypeId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)


--  ========== Language =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 15000
		[ResourceIntId]
		--,17			--Language		,LanguageId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,OriginalLanguage
      
  FROM [dbo].[Resource.Language]  base
  inner join [Codes.TagCategoryValue_summary] codes on base.LanguageId = codes.TagRelativeId
where codes.categoryId = 17
AND  LanguageId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)

print 'Resource Format'
--  ========== Resource Format =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,18			--Resource Format		,CodeId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,OriginalValue
      
  FROM [dbo].[Resource.Format]  base
  inner join [Codes.TagCategoryValue_summary] codes on base.CodeId = codes.TagRelativeId
where codes.categoryId = 18
AND  base.CodeId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)

print 'Subject'
--  ========== Subject ????????????????????????? =================
-- not sure we want to use as tab or .Text
-- just do coded for now
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,20			--Subject		,base.CodeId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,[Subject]
      
  FROM [dbo].[Resource.Subject] base 
  inner join [Codes.TagCategoryValue_summary] codes on base.CodeId = codes.TagRelativeId
where codes.categoryId = 20
AND  base.CodeId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)

print 'Resource Type'
--  ========== Resource Type =================
INSERT INTO [dbo].[Resource.Tag]
           ([ResourceIntId]
           ,[TagValueId]
           ,[Created]
           ,[CreatedById]
           ,[OriginalValue])

SELECT 
--top 1000
		[ResourceIntId]
		--,19			--Resource Type		,ResourceTypeId
		,codes.TagValueId
		,[Created]
		,[CreatedById]
		,OriginalType
      
  FROM [dbo].[Resource.ResourceType] base
  inner join [Codes.TagCategoryValue_summary] codes on base.ResourceTypeId = codes.TagRelativeId
where codes.categoryId = 19
AND ResourceTypeId is not null 
and base.Created > @StartDate
and codes.TagValueId not in 
	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.ResourceIntId)


--  ========== target Site??? =================
--skip for now. use current context - don't want to add 500K+ rows
--INSERT INTO [dbo].[Resource.Tag]
--           ([ResourceIntId]
--           ,[TagValueId]
--           ,[Created]
--           ,[CreatedById]
--           ,[OriginalValue])

--SELECT 
--top 1000
--		[Id]
--		,266
--		,base.[Created]
--		,isnull(rp.PublishedById,0)		
--		,''
      
--  FROM [dbo].[Resource] base
--  inner join [Resource.PublishedBy] rp on base.Id = rp.ResourceIntId
--where base.IsActive = 1
and base.Created > @StartDate
--and 266 not in 
--	(select [TagValueId] from [Resource.Tag] where [ResourceIntId] = base.Id)

END

