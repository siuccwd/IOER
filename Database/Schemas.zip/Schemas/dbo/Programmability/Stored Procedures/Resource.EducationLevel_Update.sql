USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_Update]    Script Date: 08/29/2012 14:10:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Update a [Resource.EducationLevel] Row
-- =============================================
CREATE PROCEDURE [dbo].[Resource.EducationLevel_Update] 
	@RowId uniqueidentifier,
	@CodeId int,
	@MappedValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CodeId = 0 BEGIN
		SELECT @CodeId = id
		FROM [Codes.AudienceType]
		WHERE Title = @MappedValue
	END

	UPDATE [Resource.EducationLevel]
	SET PathwaysEducationLevelId = @CodeId
	WHERE RowId = @RowId
END

GO


grant execute on [Resource.EducationLevel_Update] to public
go