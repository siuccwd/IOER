use Isle_IOER
go
 
--- Insert Procedure for [Patron.Profile] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Patron.ProfileInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Patron.ProfileInsert]
Go
CREATE PROCEDURE [Patron.ProfileInsert]
            @UserId int, 
            @JobTitle varchar(100), 
            @PublishingRoleId int, 
            @RoleProfile varchar(500), 
            @OrganizationId int
			,@ImageUrl varchar(200)
As
--declare @ImageUrl varchar(200)
--set @ImageUrl= ''

If @JobTitle = ''   SET @JobTitle = NULL 
If @PublishingRoleId = 0   SET @PublishingRoleId = NULL 
If @RoleProfile = ''   SET @RoleProfile = NULL 
If @ImageUrl = ''   SET @ImageUrl = NULL 
If @OrganizationId = 0   SET @OrganizationId = NULL 

INSERT INTO [Patron.Profile] (
    UserId,
    JobTitle, 
    PublishingRoleId, 
    RoleProfile, 
    OrganizationId, 
    CreatedById, 
    LastUpdatedId,
	ImageUrl
)
Values (
    @UserId,
    @JobTitle, 
    @PublishingRoleId, 
    @RoleProfile, 
    @OrganizationId, 
    @UserId, 
    @UserId,
	@ImageUrl
)
 
select @@RowCount as Id
GO
grant execute on [Patron.ProfileInsert] to public
Go
 