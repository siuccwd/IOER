--- Get Procedure for [Patron] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[PatronSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [PatronSelect]
Go
CREATE PROCEDURE [PatronSelect]
As
SELECT 
    Id, 
    UserName,  
    FirstName, 
    LastName, 
    Email, 
    IsActive, 
    Created, 
    LastUpdated, 
    LastUpdatedById
FROM [Patron]
ORDER BY LastName, FirstName
GO
grant execute on [PatronSelect] to public 
Go
