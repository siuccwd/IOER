--- Get Procedure for [Patron] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Patron.GetByExtAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Patron.GetByExtAccount]
Go 
/*
PatronGet 'IllinoisPathways','77BAE02B-9E76-4877-A90C-BFFFE9B3464E'
*/
CREATE PROCEDURE [Patron.GetByExtAccount]
    @ExternalSiteId int,
    @LoginId  varchar(100), 
    @Token    varchar(50) 

As
if @ExternalSiteId = 0 set @ExternalSiteId = null
if len(@LoginId) = 0 set @LoginId = null
if len(@Token) = 0 set @Token = null

if @ExternalSiteId is null And @LoginId is null And @Token is null begin
  print 'no id provided'
  RAISERROR(' A valid id or rowId must be supplied', 18, 1)    
  RETURN -1 
  end

SELECT 
    base.Id, 
    base.UserName,  
    base.FirstName, 
    base.LastName, 
    base.Email, 
    base.IsActive, 
    base.Created, 
    base.LastUpdated,     base.LastUpdatedById
    ,ExternalSiteId, LoginId, Token
FROM [Patron] base
inner join [Patron.ExternalAccount] ext on base.Id = ext.PatronId

WHERE	
    (LoginId = @LoginId OR @LoginId is null)
And (Token = @Token OR @Token is null)    
And (ExternalSiteId = @ExternalSiteId OR @ExternalSiteId is null)
GO
grant execute on [Patron.GetByExtAccount] to public 
Go
