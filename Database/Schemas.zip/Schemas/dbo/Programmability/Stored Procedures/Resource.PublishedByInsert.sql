USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.PublishedByInsert]    Script Date: 01/17/2013 15:49:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@PublishedById int
DECLARE @PropertyName varchar(100), @Value varchar(500)

set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @PublishedById = 1


EXECUTE @RC = [dbo].[Resource.PublishedByInsert] 
   @ResourceId
  ,@PublishedById



*/
Alter PROCEDURE [dbo].[Resource.PublishedByInsert]
            @ResourceIntId int, 
            @PublishedById int

As
--if len(rtrim(@ResourceId)) = 0	Set @ResourceId = NULL
If @ResourceIntId = 0				SET @ResourceIntId = NULL 
If @PublishedById = 0				SET @PublishedById = NULL 

if @PublishedById is null OR @ResourceIntId is null begin
	print 'Resource.PublishedByInsert Error: Incomplete parameters were provided'
	RAISERROR('Resource.PublishedByInsert Error: incomplete parameters were provided. Require Source @ResourceIntId, and @PublishedById', 18, 1)    
	RETURN -1 
	end
	
	
INSERT INTO [dbo].[Resource.PublishedBy]
           (ResourceIntId
           ,[PublishedById])
Values (
	@ResourceIntId, 
	@PublishedById
)


GO
GRANT EXECUTE ON [dbo].[Resource.PublishedByInsert] TO [public] AS [dbo]