USE Isle_IOER
GO
 
--- Get Single Procedure for [Patron.Profile] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Patron.ProfileGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Patron.ProfileGet]
Go
/*
[Patron.ProfileGet] 44
*/
CREATE PROCEDURE [Patron.ProfileGet]
    @UserId int
As
SELECT     UserId, 
    JobTitle, 
    case when PublishingRoleId is null then 8
    else PublishingRoleId end as PublishingRoleId,
    
    case when PublishingRoleId is null then 'Public'
    else pr.Title end as PublishingRole,
	base.ImageUrl,  
    RoleProfile, 
    OrganizationId, 
    isnull(org.Name, '') as Organization,
    base.Created, 
    base.CreatedById, 
    base.LastUpdated, 
    base.LastUpdatedId
FROM [Patron.Profile] base
left join [Codes.AudienceType] pr on base.PublishingRoleId = pr.id
left join [Gateway.OrgSummary] org on OrganizationId = org.Id
WHERE base.UserId = @UserId
GO
grant execute on [Patron.ProfileGet] to Public
Go