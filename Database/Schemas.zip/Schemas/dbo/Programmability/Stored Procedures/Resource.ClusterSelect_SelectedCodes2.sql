USE Isle_IOER
GO

--- Get Procedure for Resource.Cluster---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.ClusterSelect_SelectedCodes2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ClusterSelect_SelectedCodes2]
Go

/*
[Resource.ClusterSelect_SelectedCodes2] 8
*/
CREATE PROCEDURE [Resource.ClusterSelect_SelectedCodes2]
    @ResourceIntId int
As
SELECT 
	base.Id, base.IlPathwayName As Title, base.[Description]
--    ,ResourceId
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as HasCluster	
FROM [dbo].CareerCluster base
Left Join [Resource.Cluster] rpw on base.Id = rpw.ClusterId
		and rpw.ResourceIntId = @ResourceIntId
where IsIlPathway = 1

Order by base.IlPathwayName
GO
grant execute on [Resource.ClusterSelect_SelectedCodes2] to public 
Go