USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.GradeLevel_Import]    Script Date: 01/09/2013 16:16:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Exec CodeTables_UpdateWarehouseTotals 10

DECLARE @OriginalValue varchar(500)

set @OriginalValue = '15  - 17'
--set @OriginalValue = Replace(@OriginalValue, ' - ', '-')
set @OriginalValue = Replace(@OriginalValue, ' ', '')
select @OriginalValue

SELECT [Id]
      ,[Title]

  FROM [dbo].[Codes.GradeLevel]
GO

select * from [dbo].[Audit.GradeLevel_Orphan]


SELECT    Id, PropertyTypeId, OriginalValue,  MappedValue
FROM         [Map.Rules]
WHERE     (PropertyTypeId = 2)
ORDER BY OriginalValue

SELECT    map.Id, map.PropertyTypeId, map.OriginalValue,  map.MappedValue
FROM         [Map.Rules] map
inner join [Codes.GradeLevel] codes on map.MappedValue = codes.Title
WHERE     (map.PropertyTypeId = 2)
ORDER BY map.OriginalValue


--===============
SELECT [ResourceIntId] ,[OriginalValue]

  FROM [dbo].[Audit.GradeLevel_Orphan]
  where MappingType = 'Map.GradeLevel'

--======================================================
DECLARE @RC int, @ResourceIntId uniqueidentifier,@OriginalValue varchar(500)
EXECUTE [dbo].[Resource.GradeLevel_ImportResProperty] 
SELECT 
@ResourceIntId=[ResourceIntId] ,@OriginalValue=[OriginalValue]

  FROM [dbo].[Audit.GradeLevel_Orphan]
  where MappingType = 'Map.GradeLevel'
  
--======================================================

SELECT top 1000
[ResourceIntId]
      ,[Name]
      ,[Value]
      ,[PropertyTypeId]
      ,[Imported]
  FROM [dbo].[Resource.Property]
  where PropertyTypeId = 2 AND Value = 'High School'
  order by 1

B773208E-FF0B-49CA-A416-000030A2138D
5360B642-B3B7-4CD7-B6E1-0000C3F499B8
33E8A821-C0F2-42CE-B7E6-0002D78CA861
0A62FF63-FC37-4DDD-8688-0007A01A6C04

-- ====================================================================
DECLARE @RC int, @ResourceIntId uniqueidentifier,@OriginalValue varchar(500)
, @totalRows  int

set @ResourceIntId = '5360B642-B3B7-4CD7-B6E1-0000C3F499B8'
set @OriginalValue = 'Summer School'
set @OriginalValue = '&gt;1'
set @OriginalValue = 'Grade 1'
*/
/*
select newId(), @ResourceIntId, isnull(codes.id,0), @OriginalValue
  FROM [Map.GradeLevel] map 
  inner join [dbo].[Codes.GradeLevel] codes on map.CodeId = codes.Id
  left join [dbo].[Resource.GradeLevel] red on @ResourceIntId = red.ResourceIntId and red.[GradeLevelId] = codes.id
    
 where map.OriginalValue  = @OriginalValue
 */
/* 
EXECUTE @RC = [dbo].[Resource.GradeLevel_Import]
   @ResourceIntId
  ,@OriginalValue, '', @totalRows OUTPUT
  
  select  @totalRows
  


*/
/*
Notes:
- may need to use a passed schema to help with mapping

- 2012-11-15 jgrimmer - Added checking for keyword.  If exists as keyword, delete from keywords.
- 2013-05-08 jgrimmer - Altered to use ResourceIntId instead of ResourceId
*/
ALTER PROCEDURE [dbo].[Resource.GradeLevel_Import]
            @ResourceIntId	int,
            @OriginalValue  varchar(500)
            ,@TotalRows     int OUTPUT

As
begin 
declare 
  @GradeLevelId int
  , @SuppressOutput bit
  , @RecordCount int
  
  set @SuppressOutput  = 0
  If @TotalRows = -1		SET @SuppressOutput = 1
  
  set @TotalRows = 0
  set @GradeLevelId = 0
  
If @OriginalValue = '' begin
  print 'no value provided'
  return -1
  end              
set @OriginalValue = Replace(@OriginalValue, '- ', '-')  
set @OriginalValue = Replace(@OriginalValue, ' -', '-')  
set @OriginalValue = Replace(@OriginalValue, '1-U', '1+') 
set @OriginalValue = Replace(@OriginalValue, 'U-U', '0-18') 
set @OriginalValue = Replace(@OriginalValue, '&gt;', '>')  
set @OriginalValue = Replace(@OriginalValue, '&lt;', '<')  
set @OriginalValue = Replace(@OriginalValue, '> ', '>') 
set @OriginalValue = Replace(@OriginalValue, '>1', '1+') 
set @OriginalValue = Replace(@OriginalValue, '>2', '2+') 
set @OriginalValue = Replace(@OriginalValue, '>3', '3+') 
set @OriginalValue = Replace(@OriginalValue, '>4', '4+') 
set @OriginalValue = Replace(@OriginalValue, '>5', '5+') 
set @OriginalValue = Replace(@OriginalValue, '>6', '6+') 
set @OriginalValue = Replace(@OriginalValue, '>7', '7+')
set @OriginalValue = Replace(@OriginalValue, '>8', '8+')
set @OriginalValue = Replace(@OriginalValue, '>9', '9+')
set @OriginalValue = Replace(@OriginalValue, '>10', '10+') 
set @OriginalValue = Replace(@OriginalValue, '>11', '11+') 
set @OriginalValue = Replace(@OriginalValue, '>12', '12+') 
set @OriginalValue = Replace(@OriginalValue, '>13', '13+') 
set @OriginalValue = Replace(@OriginalValue, '>14', '14+') 
set @OriginalValue = Replace(@OriginalValue, '>15', '15+') 
set @OriginalValue = Replace(@OriginalValue, '>16', '16+') 
set @OriginalValue = Replace(@OriginalValue, '>17', '17+') 
set @OriginalValue = Replace(@OriginalValue, '>18', '18+') 
set @OriginalValue = Replace(@OriginalValue, '>19', '19+') 
set @OriginalValue = Replace(@OriginalValue, '>20', '20+') 

set @OriginalValue = Replace(@OriginalValue, '03-', '3-') 
set @OriginalValue = Replace(@OriginalValue, '04-', '4-') 
set @OriginalValue = Replace(@OriginalValue, '05-', '5-') 
set @OriginalValue = Replace(@OriginalValue, '06-', '6-') 
set @OriginalValue = Replace(@OriginalValue, '07-', '7-') 
set @OriginalValue = Replace(@OriginalValue, '08-', '8-') 
set @OriginalValue = Replace(@OriginalValue, '09-', '9-') 

set @OriginalValue = Replace(@OriginalValue, '-U', '+') 
set @OriginalValue = Replace(@OriginalValue, '-+', '+') 

set @OriginalValue = Replace(@OriginalValue, '13-19', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-20', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-90', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-99', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-9999', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-U', '13+') 

set @OriginalValue = Replace(@OriginalValue, '14-19', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-20', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-90', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-99', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-9999', '14+') 

set @OriginalValue = Replace(@OriginalValue, '15-19', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-20', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-90', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-99', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-9999', '15+') 

set @OriginalValue = Replace(@OriginalValue, '16-19', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-20', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-90', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-99', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-9999', '16+') 

set @OriginalValue = Replace(@OriginalValue, '17-19', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-20', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-90', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-99', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-9999', '17+') 

set @OriginalValue = Replace(@OriginalValue, '18-18', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-20', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-90', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-99', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-9999', '18+') 

set @OriginalValue = Replace(@OriginalValue, '19-19', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-20', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-90', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-99', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-9999', '19+') 

set @OriginalValue = Replace(@OriginalValue, '20-20', '20+') 
set @OriginalValue = Replace(@OriginalValue, '20-90', '20+') 
set @OriginalValue = Replace(@OriginalValue, '20-99', '20+') 
set @OriginalValue = Replace(@OriginalValue, '20-9999', '20+') 


set @OriginalValue = Replace(@OriginalValue, '21-90', '21+') 
set @OriginalValue = Replace(@OriginalValue, '21-99', '21+') 
set @OriginalValue = Replace(@OriginalValue, '21-9999', '21+') 

set @OriginalValue = Replace(@OriginalValue, '0-3', '1+') 
set @OriginalValue = Replace(@OriginalValue, '0-16', '1+') 

set @OriginalValue = Replace(@OriginalValue, 'Nov-', '11-') 
set @OriginalValue = Replace(@OriginalValue, 'Dec-', '12-') 
set @OriginalValue = Replace(@OriginalValue, 'Oct-', '10-') 
set @OriginalValue = Replace(@OriginalValue, 'Sep-', '9-') 

set @OriginalValue = Replace(@OriginalValue, 'U-', '1-') 
-- ======================================================
-- If it exists as a keyword, blow it away because we're putting it in as an Education Level
DECLARE @KeywordId int
SELECT @KeywordId = Id
FROM [Resource.Keyword]
WHERE ResourceIntId = @ResourceIntId AND Keyword = @OriginalValue
IF @KeywordId IS NOT NULL AND @KeywordId <> 0 BEGIN
	DELETE FROM [Resource.Keyword]
	WHERE Id = @KeywordId
END
-- ======================================================
 -- now check if mapping exists
select @RecordCount = isnull(Count(*),0)
  FROM [Map.GradeLevel] map 
  inner join [dbo].[Codes.GradeLevel] codes on map.CodeId = codes.Id
  --inner join [dbo].[Codes.GradeLevel] codes on map.MappedValue = codes.[Title]
 where map.OriginalValue  = @OriginalValue
 
If @RecordCount is null OR @RecordCount = 0	begin 
  --no mapping, write to exceptions table and return
  if NOT exists(SELECT [ResourceIntId] FROM [dbo].[Audit.GradeLevel_Orphan] 
    where [ResourceIntId]= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
    print 'no mapping, writing to exceptions table: ' + @OriginalValue
    INSERT INTO [dbo].[Audit.GradeLevel_Orphan]
             ([RowId]
             ,[ResourceIntId]
             ,[OriginalValue])
       VALUES
             (newId()
             ,@ResourceIntId
             ,@OriginalValue)
    end
  return -1
  end
-- ======================================================
--mapping exists, need to handle already in target table 
--print 'doing insert'
  INSERT INTO [Resource.GradeLevel]
  (
	  ResourceIntId, 
	  GradeLevelId,
	  OriginalLevel
  )
  
select @ResourceIntId, isnull(codes.id,0), @OriginalValue
  FROM [Map.GradeLevel] map 
  inner join [dbo].[Codes.GradeLevel] codes on map.CodeId = codes.Id
  left join [dbo].[Resource.GradeLevel] red on @ResourceIntId = red.ResourceIntId and red.[GradeLevelId] = codes.id
    
 where map.OriginalValue  = @OriginalValue
 and red.Id is null

set @TotalRows = @@rowcount

end




GO
GRANT EXECUTE ON [dbo].[Resource.GradeLevel_Import] TO [public] AS [dbo]