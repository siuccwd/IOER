Use LearningRegistryCache_Dev
go
 
--- Delete Procedure for Resource.EducationLevel---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.EducationLevelDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.EducationLevelDelete]
GO
CREATE PROCEDURE [Resource.EducationLevelDelete]
        @ResourceId uniqueidentifier,
        @PathwaysEducationLevelId int
As
DELETE FROM [Resource.EducationLevel]
WHERE ResourceId = @ResourceId AND 
PathwaysEducationLevelId = @PathwaysEducationLevelId
GO
grant execute on [Resource.EducationLevelDelete] to public
Go
