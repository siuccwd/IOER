
--- Delete Procedure for [Resource.EducationUse] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.EducationUseDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.EducationUseDelete]
GO

CREATE PROCEDURE [Resource.EducationUseDelete]
        @ResourceIntId int,
        @EducationUseId int
        --,@Id int
As
DELETE FROM [Resource.EducationUse]
WHERE ResourceId = @ResourceIntId  
AND EducationUseId = @EducationUseId
GO
grant execute on [Resource.EducationUseDelete]  to public
Go
