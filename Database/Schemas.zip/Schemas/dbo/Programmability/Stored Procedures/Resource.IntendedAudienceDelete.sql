 
--- Delete Procedure for Resource.IntendedAudience---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.IntendedAudienceDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.IntendedAudienceDelete]
GO
CREATE PROCEDURE [Resource.IntendedAudienceDelete]
        @ResourceId uniqueidentifier,
        @AudienceId int
As
DELETE FROM [Resource.IntendedAudience]
WHERE ResourceId = @ResourceId  
AND AudienceId = @AudienceId
GO
grant execute on [Resource.IntendedAudienceDelete] to public
Go
