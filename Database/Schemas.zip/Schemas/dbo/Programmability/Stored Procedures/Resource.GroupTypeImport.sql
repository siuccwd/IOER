USE Isle_IOER
GO

/****** Object:  StoredProcedure [dbo].[Resource.EducationUseImport]    Script Date: 03/19/2013 14:04:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*


-- ====================================================================
DECLARE @RC int, @ResourceIntId uniqueidentifier, @GroupTypeId int, @OriginalValue varchar(100),@TotalRows     int

set @GroupTypeId= 0
set @ResourceIntId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @OriginalValue = 'Syllabus'

set @ResourceIntId = 'c73542af-bdaf-4043-be18-417d5a68e6be'
set @OriginalValue = 'Image/jpg2'



EXECUTE @RC = [dbo].[Resource.EducationUseImport] 
   @ResourceIntId, @GroupTypeId
  ,@OriginalValue, @totalRows OUTPUT

GO


*/
/* =============================================
Description:      [Resource.GroupTypeImport]
------------------------------------------------------
Modifications
14-05-09 mparsons - removed ResourceRowId
=============================================

*/
Alter PROCEDURE [dbo].[Resource.GroupTypeImport]
          @ResourceIntId     int, 
          @GroupTypeId	int,
          @OriginalValue  varchar(100)
          ,@TotalRows     int OUTPUT
         -- ,@ResourceRowId uniqueidentifier
As
declare @NewId uniqueidentifier
, @id int
, @mapperId int
, @exists int
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @KeywordRowId uniqueidentifier

if @OriginalValue = '' set @OriginalValue = NULL
If @GroupTypeId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @TotalRows = -1		SET @SuppressOutput = 1
If @GroupTypeId < 1		SET @GroupTypeId = NULL 
  
If @OriginalValue is NULL and @GroupTypeId is null begin
  print 'no values provided'
  return -1
  end    

set @IsDuplicate= 0
set @TotalRows= 0

-- ==================================================================
-- Do keyword check.  If keyword found, delete keyword.
--SELECT @KeywordRowId = RowId
--FROM [Resource.Keyword]
--WHERE ResourceId = @ResourceIntId AND Keyword = @OriginalValue
--IF @KeywordRowId IS NOT NULL AND @KeywordRowId <> '00000000-0000-0000-0000-000000000000' BEGIN
--	DELETE FROM [Resource.Keyword]
--	WHERE RowId = @KeywordRowId
--END

-- ==================================================================
if @GroupTypeId is null begin
	print 'insert via EducationUse'
	 -- so first check if mapping exists
	SELECT @GroupTypeId = isnull(base.id,0)
  FROM [dbo].[Codes.GroupType] base
  inner join [dbo].[Map.GroupType] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @GroupTypeId is null OR @GroupTypeId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT ResourceIntId FROM [dbo].[Audit.GroupType_Orphan] 
    where ResourceIntId= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.GroupType_Orphan]
           (ResourceIntId
           ,[OriginalValue])
      VALUES
           (@ResourceIntId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @GroupTypeId > 0 begin
  if @SuppressOutput = 0
    print '[GroupTypeId] = ' + convert(varchar, @GroupTypeId)

  set @NewId= NEWID()
  if @SuppressOutput = 0
    print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[Id]
	from [dbo].[Resource.GroupType] base
	where base.[ResourceIntId] = @ResourceIntId
	And base.[GroupTypeId] = @GroupTypeId
	
	if @exists is not NULL AND @exists != 0 begin
	 -- set @NewId= @exists
	  set @IsDuplicate= 1
	  if @SuppressOutput = 0
	    print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.GroupType]
	    ([ResourceIntId]
	    ,GroupTypeId)

    select
	    @ResourceIntId, 
	    @GroupTypeId 
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end





GO


