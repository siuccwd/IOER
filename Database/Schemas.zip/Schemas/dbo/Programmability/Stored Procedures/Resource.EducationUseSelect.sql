
/****** Object:  StoredProcedure [dbo].[Resource.EducationUseSelect]    Script Date: 10/05/2012 15:31:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--- Get Procedure for [Resource.EducationUse] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.EducationUseSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.EducationUseSelect]
Go
/*
[Resource.EducationUseSelect] 0, 2

*/
Create PROCEDURE [dbo].[Resource.EducationUseSelect]
	@ResourceIntId int,
	@EducationUseId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	IF @ResourceIntId = 0 SET @ResourceIntId = NULL
	IF @EducationUseId = 0 SET @EducationUseId = NULL

  SELECT 
      Id, 
      ResourceIntId, 
      EducationUseId, 
      OriginalType, 
      Created, 
      ResourceId
  FROM [Resource.EducationUse]
  where 
		(ResourceIntId = @ResourceIntId OR @ResourceIntId IS NULL) AND
		(EducationUseId = @EducationUseId OR @EducationUseId IS NULL)
END
GO
grant execute on [Resource.EducationUseSelect] to public 
Go