Use LearningRegistryCache_Dev_20121005
go
 
--- Delete Procedure for Resource.GradeLevel---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.GradeLevel_Delete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.GradeLevel_Delete]
GO
CREATE PROCEDURE [Resource.GradeLevel_Delete]
        @ResourceIntId int,
        @GradeLevelId int,
        @Id  int
As
If @Id = 0   SET @Id = NULL 
If @ResourceIntId = 0   SET @ResourceIntId = NULL 
If @GradeLevelId = 0   SET @GradeLevelId = NULL 

DELETE FROM [Resource.GradeLevel]
WHERE 
    (ResourceIntId = @ResourceIntId AND GradeLevelId = @GradeLevelId)
OR  (Id = @Id)    
GO
grant execute on [Resource.GradeLevel_Delete] to public
Go
