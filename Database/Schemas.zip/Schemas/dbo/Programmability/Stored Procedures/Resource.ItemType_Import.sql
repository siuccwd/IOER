USE [LearningRegistryCache_DEV_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.ItemType_Import]    Script Date: 05/24/2013 10:38:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





/* =============================================
Description:      [Resource.ItemType_Import]
------------------------------------------------------
Modifications
=============================================

*/
CREATE PROCEDURE [dbo].[Resource.ItemType_Import]
          @ResourceIntId int,
          @ItemTypeId	    int,
          @OriginalValue  varchar(100)
          ,@TotalRows     int OUTPUT

As
declare @mapperId int
, @exists int
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @KeywordId int

if @OriginalValue = '' set @OriginalValue = NULL
If @ItemTypeId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @ItemTypeId < 1		SET @ItemTypeId = NULL 
  
If @OriginalValue is NULL and @ItemTypeId is null begin
  print 'no values provided'
  return -1
  end    


set @IsDuplicate= 0
set @TotalRows= 0
-- ==================================================================
-- Do keyword check.  If keyword found, delete keyword.
SELECT @KeywordId = Id
FROM [Resource.Keyword]
WHERE ResourceIntId = @ResourceIntId AND Keyword = @OriginalValue
IF @KeywordId IS NOT NULL AND @KeywordId <> 0 BEGIN
	DELETE FROM [Resource.Keyword]
	WHERE Id = @KeywordId
END

-- ==================================================================

if @ItemTypeId is null begin
	print 'insert via ItemType'
	 -- so first check if mapping exists
	SELECT @ItemTypeId = isnull(base.id,0)
  FROM [dbo].[Codes.ItemType] base
  inner join [dbo].[Map.ItemType] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @ItemTypeId is null OR @ItemTypeId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceIntId] FROM [dbo].[Audit.ItemType_Orphan] 
    where [ResourceIntId] = @ResourceIntId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.ItemType_Orphan]
           ([ResourceIntId]
           ,[OriginalValue])
      VALUES
           (@ResourceIntId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @ItemTypeId > 0 begin
  print '[ItemTypeId] = ' + convert(varchar, @ItemTypeId)



-- exists check for dups, or allow fail on dup
  select @exists = base.[Id]
	from [dbo].[Resource.ItemType] base
	where base.[ResourceIntId] = @ResourceIntId
	And base.[ItemTypeId] = @ItemTypeId
	
	if @exists is not NULL AND @exists != 0 begin
	  set @IsDuplicate= 1
	  print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.ItemType]
	    ([ResourceIntId]
	    ,[ItemTypeId]
		,[CreatedById])

    select
	    @ResourceIntId, 
	    @ItemTypeId, 
		NULL
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @@IDENTITY as Id, @IsDuplicate As IsDuplicate    
end



GO

GRANT EXECUTE ON [Resource.ItemType_Import] TO PUBLIC
GO

