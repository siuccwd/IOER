USE [LearningRegistryCache_DEV_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.KeywordGet]    Script Date: 08/29/2012 14:20:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- 13-03-14 jgrimmer - Added ResourceIntId
-- 13-04-12 mparsons - changed to use integer PK, and updated columns
ALTER PROCEDURE [dbo].[Resource.KeywordGet]
	@Id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT Id, 
    --ResourceId, 
    Keyword, ResourceIntId, Created, CreatedById 
    FROM [Resource.Keyword]
    WHERE Id = @Id
END

GO


grant execute on [Resource.KeywordGet] to public
go