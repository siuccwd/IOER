 
--- Get Single Procedure for [Codes.GradeLevel] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Codes.GradeLevelGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Codes.GradeLevelGet]
Go
/*
[Codes.GradeLevelGet] 1, '', '', ''

[Codes.GradeLevelGet] 0, '7', '', ''

[Codes.GradeLevelGet] 0, '', 'Grade 7', ''

[Codes.GradeLevelGet] 0, '', '', 'http://purl.org/ASN/scheme/ASNEducationLevel/K'

MODIFICATIONS:
  2013-05-23 jgrimmer - Added IsEducationBand, FromAge, ToAge
*/
ALTER PROCEDURE [Codes.GradeLevelGet]
    @Id     int,
    @Title  varchar(50), 
    @Description varchar(100),
    @AlignmentUrl varchar(150)
As
if @Id= 0 set @Id = NULL
if @Title = '' set @Title = NULL
if @Description = '' set @Description = NULL
if @AlignmentUrl = '' set @AlignmentUrl = NULL

SELECT     Id, 
    Title, 
    AgeLevel, 
    Description, 
    IsPathwaysLevel, 
    AlignmentUrl, 
    SortOrder, 
    WarehouseTotal, 
    GradeRange, 
    GradeGroup, 
    IsActive, 
    PathwaysEducationLevelId,
    IsEducationBand,
    FromAge,
    ToAge
FROM [Codes.GradeLevel]
WHERE 
    (Id = @Id OR @Id is null)
AND (Title = @Title OR @Title is null)
AND (Description = @Description OR @Description is null)
AND (AlignmentUrl = @AlignmentUrl OR @AlignmentUrl is null)
GO
grant execute on [Codes.GradeLevelGet] to Public
Go
 