USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudience_ImportFromMappingOrphan]    Script Date: 09/08/2012 16:51:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
UPDATE [dbo].[Audit.AudienceType_Orphan]
   SET[FoundMapping] = 0
      ,[IsActive] = 1
-- ================================================
/*
DELETE FROM [dbo].[Audit.AudienceType_Orphan]
      WHERE FoundMapping = 1

*/     
       
--=======================================
SELECT  OriginalValue, count(*)
FROM         [Audit.AudienceType_Orphan]
WHERE     (FoundMapping = 0)
group by OriginalValue
ORDER BY OriginalValue
-- ================================================
SELECT 
--count(*)
TOP 1000 
--[RowId]      ,
[ResourceId]      ,[OriginalValue]      ,[FoundMapping]
      ,[IsActive]      ,[Created]      ,[LastRerunDate]
  FROM [LearningRegistryCache_Dev_20121005].[dbo].[Audit.AudienceType_Orphan]
  where [FoundMapping]= 0
  order by [Created] desc      
       
--=======================================

EXECUTE [dbo].[Resource.IntendedAudience_ImportFromMappingOrphan] 500, 4

-- ================================

Declare @cntr int, @loops int, @batchSize int, @nbrToProcess int
set @cntr= 0
set @loops= 5
set @batchSize = 500

WHILE @@FETCH_STATUS = 0 BEGIN
  SELECT 
  @nbrToProcess = isnull(count(*),0)
  --count(*) As OrphansCount
  FROM [dbo].[Audit.AudienceType_Orphan] base
  Inner join [Map.AudienceType] map on base.[OriginalValue] = map.OriginalValue
  Inner join [dbo].[Codes.AudienceType] codes on map.[CodeId] = codes.Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  
	  set @cntr = @cntr+ 1
	  if @loops > 0 AND @cntr > @loops begin
		  print '### Exiting based on @loops = ' + convert(varchar, @loops)
		  print '### Remaining: = ' + convert(varchar, @nbrToProcess)
		  BREAK
		  End	  


	  if @nbrToProcess > 0 begin
      EXECUTE [dbo].[Resource.IntendedAudience_ImportFromMappingOrphan] @batchSize, 2
      end
    else begin
   		BREAK
		  End	  
	END
	
	
*/
/*
Attempt to import Resource.IntendedAudience from the Audit.AudienceType_Orphan table
this would be run on demand after attempted cleanups of the mapping
We also need a process to permanently ignore some mappings
*/

-- 2013-03-13 jgrimmer - Added ResourceIntId
ALTER PROCEDURE [dbo].[Resource.IntendedAudience_ImportFromMappingOrphan]
            @MaxRecords int,
            @DebugLevel int

As
begin 
          
Declare @ResourceId uniqueidentifier
,@ResourceIntId int
,@RowId uniqueidentifier
,@Value varchar(200)
,@MappedCodeId int
,@cntr int
,@existsCntr int
,@totalRows int

set @cntr = 0
set @existsCntr = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor2 CURSOR FOR
	SELECT base.RowId, base.[ResourceId], base.[OriginalValue] As Value, isnull(map.CodeId, -1), [Resource].Id AS ResourceIntId
  FROM [dbo].[Audit.AudienceType_Orphan] base
  Inner join [Map.AudienceType] map on base.[OriginalValue] = map.OriginalValue
  Inner join [dbo].[Codes.AudienceType] codes on map.[CodeId] = codes.Id
  Inner join [Resource] ON base.ResourceIntId = [Resource].Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  --?? if not tried before, but don't want to all. actually ok, as we are doing a join
  -- still we want to be able to ignore stuff that won't be mapped
  -- maybe if the create date and last run date are X days apart, set the ignore flag

 
	OPEN thisCursor2
	FETCH NEXT FROM thisCursor2 INTO @RowId, @ResourceId, @Value, @MappedCodeId, @ResourceIntId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  if @MaxRecords > 0 AND @cntr < 25  
	    print '==========> ' +@Value

    set @totalRows = -1 
	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.IntendedAudience_Import] 
        @ResourceId, @MappedCodeId,
        @Value, @totalRows OUTPUT,
        @ResourceIntId
        
		--if map was successful, either delete or at least mark
		if @totalRows > 0 begin
		  if @DebugLevel > 5
		    print ' **appeared to be mapped, now mark/delete'
		  UPDATE [dbo].[Audit.AudienceType_Orphan]
        SET [LastRerunDate] = getdate()
        ,[FoundMapping] = 1
      WHERE [RowId] = @RowId
		  end
		else begin
		-- check if a entry already exists for the value (ie current results is a duplicate)
		
		  select @existsCntr = isnull(count(*),0)
        FROM [Map.AudienceType] map 
        inner join [dbo].[Codes.AudienceType] codes on map.[CodeId] = codes.Id
        inner join [dbo].[Resource.IntendedAudience] red 
              on @ResourceIntId = red.ResourceIntId 
              and red.[AudienceId] = codes.id
         where map.OriginalValue  = @Value
         group by red.ResourceIntId
         
    	if @existsCntr > 0 begin
		    if @DebugLevel > 5
		      print ' &&the orphan reference already exists, mark it'
		    UPDATE [dbo].[Audit.AudienceType_Orphan]
          SET [LastRerunDate] = getdate()
          ,[FoundMapping] = 1
        WHERE [RowId] = @RowId
		    end
		  else begin	
	      if @DebugLevel > 5
		      print ' ##not mapped, update rundate????'
	      UPDATE [dbo].[Audit.AudienceType_Orphan]
          SET [LastRerunDate] = getdate()
        WHERE [RowId] = @RowId
	      end
  		end
		
		FETCH NEXT FROM thisCursor2 INTO @RowId, @ResourceId, @Value, @MappedCodeId, @ResourceIntId
	END
	CLOSE thisCursor2
	DEALLOCATE thisCursor2
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.IntendedAudience_ImportFromMappingOrphan] TO [public] AS [dbo]

