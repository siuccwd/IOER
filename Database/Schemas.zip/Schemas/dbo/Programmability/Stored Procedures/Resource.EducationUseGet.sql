--- Get Single Procedure for [Resource.EducationUse] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.EducationUseGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.EducationUseGet]
Go

/*
[Resource.EducationUseGet] 1, 0, 0 

*/
CREATE PROCEDURE [Resource.EducationUseGet]
    @Id int,
    @ResourceIntId int, 
    @EducationUseId int 
As
If @Id = 0   SET @Id = NULL 
If @ResourceIntId = 0   SET @ResourceIntId = NULL 
If @EducationUseId = 0   SET @EducationUseId = NULL 

SELECT     
    Id, 
    ResourceIntId, 
    EducationUseId, 
    OriginalType, 
    Created, 
    ResourceId
FROM [Resource.EducationUse]
WHERE 
    (Id = @Id or @Id is null )
And (ResourceIntId = @ResourceIntId or @ResourceIntId is null )
And (EducationUseId = @EducationUseId or @EducationUseId is null )


GO
grant execute on [Resource.EducationUseGet] to Public
Go
 