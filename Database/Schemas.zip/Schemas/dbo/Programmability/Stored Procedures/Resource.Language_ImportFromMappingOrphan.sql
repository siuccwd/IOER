USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.Language_ImportFromMappingOrphan]    Script Date: 09/08/2012 16:51:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
declare @land varchar(50), @likeLand varchar(50)
set @land = 'ja'
set @likeLand = '%' + @land + '%'

UPDATE [dbo].[Audit.Language_Orphan]  SET[OriginalValue] = @land Where OriginalValue like @likeLand
  
  
      
--SELECT  OriginalValue FROM [Audit.Language_Orphan] Where OriginalValue like @likeLand


UPDATE [dbo].[Audit.Language_Orphan]
   SET[FoundMapping] = 0
      ,[IsActive] = 1
      
-- ================================================
/*
DELETE FROM [dbo].[Audit.Language_Orphan]
      WHERE FoundMapping = 1

*/      

--=======================================
SELECT  OriginalValue, count(*)
FROM         [Audit.Language_Orphan]
WHERE     (FoundMapping = 0)
group by OriginalValue
ORDER BY OriginalValue


--=======================================
EXECUTE [dbo].[Resource.Language_ImportFromMappingOrphan] 55, 6
--=======================================


Declare @cntr int, @loops int, @batchSize int, @nbrToProcess int
set @cntr= 0
set @loops= 1
set @batchSize = 500

WHILE @@FETCH_STATUS = 0 BEGIN
  SELECT 
  @nbrToProcess = isnull(count(*),0)
  -- select count(*) As OrphansCount
  FROM [dbo].[Audit.Language_Orphan] base
  Inner join [Map.Language] map on base.[OriginalValue] = map.LRValue
  Inner join [dbo].[Codes.Language] codes on map.[LanguageId] = codes.Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  
	  set @cntr = @cntr+ 1
	  if @loops > 0 AND @cntr > @loops begin
		  print '### Exiting based on @loops = ' + convert(varchar, @loops)
		  print '### Remaining: = ' + convert(varchar, @nbrToProcess)
		  BREAK
		  End	  


	  if @nbrToProcess > 0 begin
      EXECUTE [dbo].[Resource.Language_ImportFromMappingOrphan] @batchSize, 2
      end
    else begin
   		BREAK
		  End	  
	END	
*/
/*
Attempt to import Resource.Language from the Audit.Language_Orphan table
this would be run on demand after attempted cleanups of the mapping
We also need a process to permanently ignore some mappings
*/
/* =============================================
Description:     [Resource.Language_ImportFromMappingOrphan]
------------------------------------------------------
Modifications
  2013-03-13 jgrimmer - Added ResourceIntId
  2013-08-22 mparsons - dropped resourceId
=============================================

*/


Alter PROCEDURE [dbo].[Resource.Language_ImportFromMappingOrphan]
            @MaxRecords int,
            @DebugLevel int

As
begin 
          
Declare 
@ResourceIntId int
,@RowId uniqueidentifier
,@Value varchar(200)
,@MappedCodeId int
,@cntr int
,@existsCntr int
,@totalRows int

set @cntr = 0
set @existsCntr = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor3 CURSOR FOR
	SELECT base.RowId, base.[ResourceIntId], base.[OriginalValue] As Value, isnull(map.LanguageId, 0), [Resource].Id AS ResourceIntId
  --  select count(*) 
  FROM [dbo].[Audit.Language_Orphan] base
  Inner join [Map.Language] map on base.[OriginalValue] = map.LRValue
  Inner join [dbo].[Codes.Language] codes on map.[LanguageId] = codes.Id
  Inner join [Resource] ON base.ResourceIntId = [Resource].Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  --?? if not tried before, but don't want to all. actually ok, as we are doing a join
  -- still we want to be able to ignore stuff that won't be mapped
  -- maybe if the create date and last run date are X days apart, set the ignore flag

 
	OPEN thisCursor3
	FETCH NEXT FROM thisCursor3 INTO @RowId, @ResourceIntId, @Value, @MappedCodeId, @ResourceIntId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  if @MaxRecords > 0 AND @cntr < 25  
	    print ' ==> ' +@Value

	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.Language_Import] 
        '', @MappedCodeId,
        @Value, @totalRows OUTPUT,
        @ResourceIntId
        
		--if map was successful, either delete or at least mark
		if @totalRows > 0 begin
		  if @DebugLevel > 5
		    print ' **appeared to be mapped, now mark/delete'
		  UPDATE [dbo].[Audit.Language_Orphan]
        SET [LastRerunDate] = getdate()
        ,[FoundMapping] = 1
      WHERE [RowId] = @RowId
		  end
		else begin
		-- check if a entry already exists for the value (ie current results in a duplicate)
		
		  select @existsCntr = isnull(count(*),0)
        FROM [Map.Language] map 
        inner join [dbo].[Codes.Language] codes on map.[LanguageId] = codes.Id
        inner join [dbo].[Resource.Language] red 
              on @ResourceIntId = red.ResourceIntId 
              and red.[LanguageId] = codes.id
         where map.LRValue  = @Value
         group by red.ResourceIntId
         
    	if @existsCntr > 0 begin
		    if @DebugLevel > 5
		      print ' &&the orphan reference already exists, mark it'
		    UPDATE [dbo].[Audit.Language_Orphan]
          SET [LastRerunDate] = getdate()
          ,[FoundMapping] = 1
        WHERE [RowId] = @RowId
		    end
		  else begin	
	      if @DebugLevel > 5
		      print ' ##not mapped, update rundate????'
	      UPDATE [dbo].[Audit.Language_Orphan]
          SET [LastRerunDate] = getdate()
        WHERE [RowId] = @RowId
	      end
  		end
		
		FETCH NEXT FROM thisCursor3 INTO @RowId, @ResourceIntId, @Value, @MappedCodeId, @ResourceIntId
	END
	CLOSE thisCursor3
	DEALLOCATE thisCursor3
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.Language_ImportFromMappingOrphan] TO [public] AS [dbo]

