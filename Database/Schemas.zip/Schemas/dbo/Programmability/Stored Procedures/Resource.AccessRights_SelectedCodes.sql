﻿USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.AccessRights_SelectedCodes]    Script Date: 07/22/2013 13:47:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.AccessRights_SelectedCodes] 448010
*/
ALTER PROCEDURE [dbo].[Resource.AccessRights_SelectedCodes]
    @ResourceIntId int
As
SELECT distinct
	code.Id, code.Title, code.[Description]
   -- ,ResourceIntId
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.AccessRights] code
Left Join [Resource.Version] rpw on code.Id = rpw.AccessRightsId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsActive = 1
Go
Grant Execute on [Resource.AccessRights_SelectedCodes] to public
Go

