 
--- Insert Procedure for [Resource.EducationUse] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.EducationUseInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.EducationUseInsert]
Go
CREATE PROCEDURE [Resource.EducationUseInsert]
            @ResourceIntId int, 
            @EducationUseId int, 
            @OriginalValue varchar(100), 
            @CreatedById int, 
            @ResourceRowId varchar(40)
As
If @ResourceIntId = 0     SET @ResourceIntId = NULL 
If @EducationUseId = 0    SET @EducationUseId = NULL 
If @CreatedById = 0       SET @CreatedById = NULL 
If @OriginalValue = ''    SET @OriginalValue = NULL 
If @ResourceRowId = ''    SET @ResourceRowId = NULL 

INSERT INTO [Resource.EducationUse] (

    ResourceIntId, 
    EducationUseId, 
    OriginalType, 
    Created, 
    CreatedById,
    ResourceId
)
Values (

    @ResourceIntId, 
    @EducationUseId, 
    @OriginalValue, 
    getdate(), 
    @CreatedById,
    @ResourceRowId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Resource.EducationUseInsert] to public
Go
 