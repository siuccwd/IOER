USE Isle_IOER
GO

/****** Object:  StoredProcedure [dbo].[Resource.Format_Import]    Script Date: 07/02/2012 09:34:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


-- ====================================================================
DECLARE @RC int, @ResourceIntId int, @ResourceFormatId int, @OriginalValue varchar(100),@TotalRows     int

set @ResourceFormatId= 0
set @OriginalValue = 'Syllabus'

set @ResourceIntId = 8
set @OriginalValue = 'Image/jpg2'

EXECUTE @RC = [dbo].[Resource.Format_Import] 
   @ResourceIntId, @ResourceFormatId
  ,@OriginalValue, @totalRows OUTPUT

GO


*/
/* =============================================
Description:      [Resource.Format_Import]
------------------------------------------------------
Modifications
2012-11-15 jgrimmer - Added keyword checking.  If exists as keyword, delete keyword.
2013-03-15 jgrimmer - Added @ResourceIntId
2013-04-19 jgrimmer - Modified keyword check to use ResourceIntId
2013-08-28 mparsons - removed ResourceId
=============================================

*/
ALTER PROCEDURE [dbo].[Resource.Format_Import]
          @ResourceIntId		int,
          @ResourceFormatId	    int,
          @OriginalValue		varchar(100)
          ,@TotalRows			int OUTPUT


As
declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @KeywordId int

if @OriginalValue = '' set @OriginalValue = NULL
If @ResourceFormatId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @TotalRows = -1		SET @SuppressOutput = 1
If @ResourceFormatId < 1		SET @ResourceFormatId = NULL 
  
If @OriginalValue is NULL and @ResourceFormatId is null begin
  print 'no values provided'
  return -1
  end    

set @IsDuplicate= 0
set @TotalRows= 0

-- ==================================================================
-- Do keyword check.  If keyword found, delete keyword.
SELECT @KeywordId = Id
FROM [Resource.Keyword]
WHERE ResourceIntId = @ResourceIntId AND Keyword = @OriginalValue
IF @KeywordId IS NOT NULL AND @KeywordId <> 0 BEGIN
	DELETE FROM [Resource.Keyword]
	WHERE Id = @KeywordId
END
	
-- ==================================================================
if @ResourceFormatId is null begin
	if @SuppressOutput = 0
        print 'insert via Format'
	 -- so first check if mapping exists
	SELECT @ResourceFormatId = isnull(base.id,0)
  FROM [dbo].[Codes.ResourceFormat] base
  inner join [dbo].[Map.ResourceFormat] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @ResourceFormatId is null OR @ResourceFormatId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceIntId] FROM [dbo].[Audit.ResourceFormat_Orphan] 
    where [ResourceIntId]= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
      if @SuppressOutput = 0
        print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.ResourceFormat_Orphan]
           ([RowId]
           ,[ResourceIntId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceIntId
           ,@OriginalValue)
      
      end    
    else begin
      if @SuppressOutput = 0
        print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @ResourceFormatId > 0 begin
  if @SuppressOutput = 0
        print '[FormatId] = ' + convert(varchar, @ResourceFormatId)

  set @NewId= NEWID()
  if @SuppressOutput = 0
        print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.Format] base
	where base.[ResourceIntId] = @ResourceIntId
	And base.[CodeId] = @ResourceFormatId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  if @SuppressOutput = 0
        print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.Format]
	    ([RowId]
	    ,[CodeId]
	    ,OriginalValue
	    ,ResourceIntId)

    select
	    @NewId,
	    @ResourceFormatId, 
	    @OriginalValue,
	    @ResourceIntId
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end



GO
grant execute on [Resource.Format_Import] to public
go

