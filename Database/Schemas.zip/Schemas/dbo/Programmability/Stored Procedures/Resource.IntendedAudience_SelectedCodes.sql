USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudience_SelectedCodes]    Script Date: 09/08/2012 17:40:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.IntendedAudience_SelectedCodes] ''9B184F11-B032-4CDB-993D-00109FDCDF68''
*/
Alter PROCEDURE [dbo].[Resource.IntendedAudience_SelectedCodes]
    @ResourceIntId int
As
SELECT distinct
	code.Id, code.Title, code.[Description]
   -- ,ResourceIntId
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.AudienceType] code
Left Join [Resource.IntendedAudience] rpw on code.Id = rpw.AudienceId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsActive = 1
Order by 2

GO
GRANT EXECUTE ON [dbo].[Resource.IntendedAudience_SelectedCodes] TO [public] 
go