USE LearningRegistryCache_Dev_20121005
GO
/****** Object:  StoredProcedure [dbo].[Resource.Language_ImportResProperty]    Script Date: 09/08/2012 16:51:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
select [MappingType], LRValue from [dbo].[Audit.Language_Orphan]



EXECUTE [dbo].[Resource.Language_ImportResProperty] 100000


*/

Alter PROCEDURE [dbo].[Resource.Language_ImportResProperty]
            @MaxRecords int
As
begin 
          
Declare @ResourceId uniqueidentifier
,@Value varchar(200)
,@cntr int
,@totalRows int
set @cntr= 0
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
    select base.ResourceId, base.Value
      FROM [dbo].[Resource.Property] base
      left join [Map.Language] map            on base.Value = map.LRValue
      --left join [dbo].[Codes.Language] codes  on map.LanguageId = codes.Id
      left join [dbo].[Resource.Language] red on base.ResourceId = red.ResourceId and red.[LanguageId] = map.LanguageId
    where base.[PropertyTypeId]= 4
     and red.ResourceId is  null
 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @ResourceId, @Value
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.Language_Import] 
        @ResourceId,
        -1, @Value, @totalRows OUTPUT
		
		FETCH NEXT FROM thisCursor INTO @ResourceId, @Value
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.Language_ImportResProperty] TO [public] AS [dbo]

/*
  INSERT INTO [Resource.Language]
  (
	  RowId,
	  ResourceId, 
	  LanguageId,
	  OriginalLevel
  )
  
select top 8000 newId(), base.ResourceId, isnull(codes.id,0), base.Value
  FROM [dbo].[Resource.Property] base
  inner join [Map.Language] map on base.Value = map.LRValue
  inner join [dbo].[Codes.Language] codes on map.MappedValue = codes.[Title]
  left join [dbo].[Resource.Language] red on base.ResourceId = red.ResourceId and red.[LanguageId] = codes.id
    
where base.[PropertyTypeId]= 2
 and red.ResourceId is  null
--

*/