USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.Version_Display]    Script Date: 07/11/2012 11:01:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select top 10 * from [Resource.Version]

exec [Resource.Version_Display] '063438CA-9FF4-42B9-A511-000028286F04'

[Resource.Version_Display] 291571

*/


/* ============================================================
-- Description:	Get a resource version for display
-- 12-09-02 mparsons - added 
-- 12-10-10 mparsons - changed to use Resource.Subject, added Keywords
-- 13-01-31 mparsons - added join for new AccessRightsId
-- 13-02-13 mparsons - added return of res.Id
-- 13-02-19 mparsons - added InteractivityTypeId
-- 13-03-12 mparsons - removed keywords and subject for performanance
-- 13-06-12 mparsons - probably obsolete, but updated for int id just in case
-- 13-10-21 mparsons - used in webservice prototype, so updated to replace ed levels with grade levels
-- ============================================================
*/
Alter PROCEDURE [dbo].[Resource.Version_Display]
	@Id int
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT distinct
		base.RowId, 
		base.Id,
		res.Id As ResourceIntId,
		res.ResourceUrl, 
		res.ViewCount,
		res.FavoriteCount,
		base.DocId,
		base.Title, base.SortTitle,
		base.[Description], 
		isnull(base.Publisher, 'Unknown') As Publisher,
		isnull(base.Creator, 'Unknown') As Creator,
		isnull(base.Rights, 'Unknown') As Rights,
		--isnull(base.AccessRights, 'Unknown') As AccessRights,
		AccessRightsId,
		isnull(codes.title, 'Unknown') As AccessRights,
	    
		isnull(InteractivityTypeId, 0) As InteractivityTypeId,
		isnull(iatCodes.title, 'Unknown') As InteractivityType,
          
		isnull(base.TypicalLearningTime, '') As TypicalLearningTime,
		base.Modified, base.[Schema],
		base.Submitter, 
		isnull(base.Imported, base.Modified) As Imported,
		base.Created,
		base.IsSkeletonFromParadata
		,base.IsActive
		,res.IsActive As ResourceIsActive
		
		--,replace(isnull(rsub.Subjects, ''), '","', ', ') As Subjects
		,'' As Subjects
		,isnull(edList.GradeLevels,'') As GradeLevels
		--	,replace(isnull(rkwd.Keywords, ''), '","', ', ') As Keywords
		,'' As Keywords
		--,'TBD' As Keywords
		
		,isnull(langList.LanguageList,'') As LanguageList
		,isnull(typesList.ResourceTypesList,'') As ResourceTypesList
		,isnull(audienceList.AudienceList,'') As AudienceList
			
	FROM [Resource.Version] base		
	inner join [Resource] res on base.ResourceIntId = res.Id
	Left Join dbo.[Codes.AccessRights] codes on base.AccessRightsId = codes.Id
  Left Join dbo.[Codes.InteractivityType] iatCodes on base.InteractivityTypeId = codes.Id
	--Left Join [dbo].[Resource.SubjectCsv] rsub on res.RowId = rsub.ResourceId
	--Inner Join [dbo].[Resource.SubjectsCsvList] rsub on res.RowId = rsub.ResourceId
	--Left Join [dbo].[Resource.KeywordCsv] rkwd on res.RowId = rkwd.ResourceId
	--Left Join [dbo].[Resource.KeywordsCsvList] rkwd on res.RowId = rkwd.ResourceId
  Left Join [dbo].[Resource.GradeLevelList] edList on res.Id = edList.ResourceIntId
    Left Join [dbo].[Resource.LanguagesList] langList on res.Id = langList.ResourceIntId
    Left Join [dbo].[Resource.IntendedAudienceList] audienceList on res.Id = audienceList.ResourceIntId
    Left Join [dbo].[Resource.ResourceTypesList] typesList on res.Id = typesList.ResourceIntId
        
	WHERE (base.Id = @Id)
	
END
go
grant execute on [Resource.Version_Display] to public
go
