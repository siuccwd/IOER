
 
--- Delete Procedure for [Resource.Comment] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.CommentDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.CommentDelete]
GO
CREATE PROCEDURE [Resource.CommentDelete]
        @Id int
As
DELETE FROM [Resource.Comment]
WHERE Id = @Id
GO
grant execute on [Resource.CommentDelete]  to public
Go
