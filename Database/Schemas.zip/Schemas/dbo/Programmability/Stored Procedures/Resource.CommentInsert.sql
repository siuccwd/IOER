
--- Insert Procedure for [Resource.Comment] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.CommentInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.CommentInsert]
Go
CREATE PROCEDURE [Resource.CommentInsert]
            @ResourceIntId int, 
            @Comment varchar(MAX), 
            @IsActive bit,
            @CreatedById int,
            @CreatedBy varchar(100),
            @Commenter varchar(500)
As
--@ResourceId uniqueidentifier,
If @CreatedById = 0   SET @CreatedById = NULL 
If @CreatedBy = ''   SET @CreatedBy = NULL 
If @Commenter = ''   SET @Commenter = NULL 

INSERT INTO [Resource.Comment] (

    ResourceIntId, 
    Comment, 
    IsActive,
    CreatedById,
    CreatedBy,
    Commenter
)
Values (

    @ResourceIntId, 
    @Comment,  
    @IsActive,
    @CreatedById,
    @CreatedBy,
    @Commenter
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Resource.CommentInsert] to public
Go
 