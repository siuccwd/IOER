USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[Resource.ClusterGet2]    Script Date: 03/05/2013 17:06:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.ClusterGet2] 8, 13

*/
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 09/13/2012
-- Description:	Get a Resource.Cluster row
-- =============================================
Alter PROCEDURE [dbo].[Resource.ClusterGet2]
	@ResourceIntId int,
	@ClusterId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT ResourceId, ResourceIntId, ClusterId
	FROM [Resource.Cluster]
	WHERE ResourceIntId = @ResourceIntId AND ClusterId = @ClusterId
END
