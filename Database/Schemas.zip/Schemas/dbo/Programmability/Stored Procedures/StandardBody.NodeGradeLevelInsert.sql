
 
--- Insert Procedure for [StandardBody.NodeGradeLevel] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[StandardBody.NodeGradeLevelInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [StandardBody.NodeGradeLevelInsert]
Go
CREATE PROCEDURE [StandardBody.NodeGradeLevelInsert]
            @ParentId int, 
            @LevelType varchar(25), 
            @GradeLevelId int
As
If @ParentId = 0   SET @ParentId = NULL 
If @LevelType = ''   SET @LevelType = NULL 
If @GradeLevelId = 0   SET @GradeLevelId = NULL 
INSERT INTO [StandardBody.NodeGradeLevel] (

    ParentId, 
    GradeLevel, 
    GradeLevelId
)
Values (

    @ParentId, 
    @LevelType, 
    @GradeLevelId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [StandardBody.NodeGradeLevelInsert] to public
Go