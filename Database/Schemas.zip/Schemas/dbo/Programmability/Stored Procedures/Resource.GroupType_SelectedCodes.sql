USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.GroupType_SelectedCodes]    Script Date: 09/08/2012 17:40:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.GroupType_SelectedCodes] 444662
*/
Alter PROCEDURE [dbo].[Resource.GroupType_SelectedCodes]
    @ResourceIntId int
    --    @ResourceIntId uniqueidentifier
As
SELECT distinct
	code.Id, code.Title, code.[Description]
   -- ,ResourceId
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.GroupType] code
Left Join [Resource.GroupType] rpw on code.Id = rpw.GroupTypeId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsActive = 1
Order by 2

GO
GRANT EXECUTE ON [dbo].[Resource.GroupType_SelectedCodes] TO [public] 
go