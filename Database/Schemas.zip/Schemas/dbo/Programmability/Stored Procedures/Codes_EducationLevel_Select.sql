USE LearningRegistryCache_Dev
GO

/****** Object:  StoredProcedure [dbo].[Codes_EducationLevel_Select]    Script Date: 07/02/2012 17:08:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Create date: 7/02/2012
-- Description:	Select [Codes.EducationLevel]
-- =============================================
Alter PROCEDURE [dbo].[Codes_EducationLevel_Select]

AS
BEGIN
SELECT [Id]
      ,[Title]
      ,[Title] + ' (' + isnull(convert(varchar,WareHouseTotal),0) + ')' As FormattedTitle
      ,isnull(WareHouseTotal,0) As WareHouseTotal
      ,[Description]
      ,[IsPathwaysLevel]
  FROM [dbo].[Codes.PathwaysEducationLevel]
  where [IsPathwaysLevel]= 1
  order by SortOrder
END

GO
grant execute on [Codes_EducationLevel_Select] to public
go


