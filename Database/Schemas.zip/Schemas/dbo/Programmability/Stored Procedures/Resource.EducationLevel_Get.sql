USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_Get]    Script Date: 08/29/2012 14:08:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Get a record from [Resource.EducationLevel]
-- =============================================
CREATE PROCEDURE [dbo].[Resource.EducationLevel_Get]
	@RowId uniqueidentifier,
	@ResourceId uniqueidentifier,
	@OriginalValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @RowId = '00000000-0000-0000-0000-000000000000' SET @RowId = NULL
	IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
	IF @OriginalValue = '' SET @OriginalValue = NULL

	SELECT RowId, ResourceId, OriginalLevel AS OriginalValue, PathwaysEducationLevelId AS CodeId,
		cpel.Title AS MappedValue
	FROM [Resource.EducationLevel] rel
	INNER JOIN [Codes.PathwaysEducationLevel] cpel ON rel.PathwaysEducationLevelId = cpel.Id
	WHERE   (RowId = @RowId OR @RowId IS NULL)
		AND (ResourceId = @ResourceId OR @ResourceId IS NULL)
		AND (OriginalLevel = @OriginalValue OR @OriginalValue IS NULL)
END

GO


grant execute on [Resource.EducationLevel_Get] to public
go