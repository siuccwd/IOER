 
 
--- Get Procedure for [StandardBody.Node] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[StandardBody.NodeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [StandardBody.NodeSelect]
Go
/*

[StandardBody.NodeSelect] 2501

*/
CREATE PROCEDURE [StandardBody.NodeSelect]
	@ParentId int

As
SELECT 
    Id, 
    ParentId, 
    LevelType, 
    NotationCode, 
    Description, 
    StandardUrl, 
    AltUrl, 
    StandardGuid, 
	GradeLevels,
    WarehouseTotal
FROM [StandardBody.Node]
where ParentId= @ParentId
Order by ParentId, NotationCode
GO
grant execute on [StandardBody.NodeSelect] to public 
Go
 