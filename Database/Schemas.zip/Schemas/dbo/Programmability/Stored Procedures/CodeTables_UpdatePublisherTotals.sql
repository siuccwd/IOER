USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[CodeTables_UpdatePublisherTotals]    Script Date: 01/11/2013 10:48:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
Exec CodeTables_UpdatePublisherTotals 10
*/
-- =========================================================================
-- 13/03/04 mparsons - was taking too long, so split up
-- =========================================================================
Alter  Procedure [dbo].[CodeTables_UpdatePublisherTotals]
    @debugLevel int = 0

AS
--declare @debugLevel int
-- ==========================================================
print 'updating Publishers ...'
-- updates -----------------------------------
UPDATE [dbo].[PublisherSummary]
   SET [ResourceTotal] = totals.ResourcesCount
   ,IsActive= 1
from [dbo].[PublisherSummary] ps
inner join (
 SELECT base.[Publisher], count(*) As ResourcesCount
  FROM [dbo].[Resource.Version_Summary] base
  inner join [dbo].[PublisherSummary] existing on base.[Publisher] = existing.[Publisher]
  group by base.[Publisher]
 -- Order by 2 desc
  ) totals on ps.Publisher = totals.Publisher
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))


-- inserts -----------------------------------
INSERT INTO [dbo].[PublisherSummary]
           ([Publisher],[IsActive],[ResourceTotal])
SELECT base.[Publisher], 1,count(*) As Resources
  FROM [dbo].[Resource.Version_Summary] base
  left join [dbo].[PublisherSummary] existing on base.[Publisher] = existing.[Publisher]
  where 
		base.[Publisher] is not null 
  AND existing.[Publisher] is null
  group by base.[Publisher]
  order by 3 desc
  
print 'Insert = ' + convert(varchar, isnull(@@rowcount,0))  
-- ============================================================================
--handle delete of publishers, or mark of inactive 
--this can only be done if all related resources are inactive 
/*

UPDATE [dbo].[PublisherSummary]
   SET IsActive = 0
--    select count(*)
from [dbo].[PublisherSummary] ps
inner join (
 SELECT distinct rv.[Publisher], lr.IsActive
 --, lr.ResourceUrl
  FROM [dbo].[Resource.Version] rv  
  Inner JOIN dbo.[Resource] lr ON lr.Id = rv.ResourceIntId
  inner join [dbo].[PublisherSummary] existing on rv.[Publisher] = existing.[Publisher]
  Where existing.IsActive = 1 AND lr.IsActive = 0

  ) totals on ps.Publisher = totals.Publisher
  
  
Inner join [dbo].[Resource.Version] rv  ON ps.Publisher = rv.Publisher
Inner JOIN dbo.[Resource] lr ON lr.Id = rv.ResourceIntId
Where ps.IsActive = 1 AND lr.IsActive = 0

-- ============== OR maybe this:
SELECT ps.[Publisher]
--, isnull(ActiveResources.ActiveTotals, 0) As ActiveTotals
FROM [PublisherSummary]  ps
  left Join 
  (
 SELECT rv.[Publisher], isnull(count(*),0) As ActiveTotals
 --, lr.ResourceUrl
  FROM [dbo].[Resource.Version] rv  
  Inner JOIN dbo.[Resource] lr ON lr.Id = rv.ResourceIntId
  Where 
  lr.Isactive = 1

  --lr.ResourceUrl like '%actionbioscience.org%'
  --AND lr.IsActive = 1
  group by rv.[Publisher]
  --order by 2 
  ) As ActiveResources on ps.[Publisher] = ActiveResources.[Publisher]
  where ActiveResources.ActiveTotals = 0


print 'Set inactive = ' + convert(varchar, isnull(@@rowcount,0)) 
*/

-- ==========================================================



  
