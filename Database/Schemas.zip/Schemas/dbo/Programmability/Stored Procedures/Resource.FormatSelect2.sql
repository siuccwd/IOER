USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.FormatSelect2]    Script Date: 06/03/2013 17:08:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Resource.FormatSelect2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Resource.FormatSelect2]
GO

/****** Object:  StoredProcedure [dbo].[Resource.FormatSelect2]    Script Date: 06/03/2013 17:08:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Resource.FormatSelect2]
	@ResourceIntId int
AS
BEGIN
	SET NOCOUNT ON;
    
    SELECT RowId, ResourceIntId, OriginalValue, CodeId, Created, CreatedById
    ,ResourceId
    FROM [Resource.Format]
    WHERE (ResourceIntId = @ResourceIntId)
    Order by CodeId
END


GO


