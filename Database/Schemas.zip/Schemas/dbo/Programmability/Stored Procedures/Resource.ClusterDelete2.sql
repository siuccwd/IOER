
--- Delete Procedure for Resource.Cluster---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.ClusterDelete2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ClusterDelete2]
GO

CREATE PROCEDURE [Resource.ClusterDelete2]
        @ResourceIntId int,
        @ClusterId int
        
As
DELETE FROM [Resource.Cluster] 
WHERE ClusterId = @ClusterId AND 
ResourceIntId = @ResourceIntId
GO
grant execute on [Resource.ClusterDelete2] to public
Go