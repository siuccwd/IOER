USE Isle_IOER
GO

--- Get Procedure for Resource.Cluster---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.ClusterSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ClusterSelect]
Go

/*
[Resource.ClusterSelect] 'E74B0BEF-4074-4937-81D6-0000C7FC4EA2'

[Resource.ClusterSelect] 'B0BDDDF1-75DA-4D6D-8555-0027D1ACCC4A'

*/
CREATE PROCEDURE [Resource.ClusterSelect]
    @ResourceId varchar(50)
As
SELECT base.[ResourceIntId]
      ,base.[ClusterId], cc.IlPathwayName As Cluster
  FROM [dbo].[Resource.Cluster] base
  inner join CareerCluster cc on base.ClusterId = cc.Id
where base.ResourceId = @ResourceId  
Order by cc.IlPathwayName

GO

grant execute on [Resource.ClusterSelect] to public 
Go