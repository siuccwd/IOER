 
 
--- Delete Procedure for [Resource.GroupType] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.GroupTypeDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.GroupTypeDelete]
GO
CREATE PROCEDURE [Resource.GroupTypeDelete]
            @ResourceIntId int, 
            @GroupTypeId int, 
            @Id int
As
If @ResourceIntId = 0   SET @ResourceIntId = NULL 
If @GroupTypeId = 0   SET @GroupTypeId = NULL 
If @Id = 0   SET @Id = NULL 

DELETE FROM [Resource.GroupType]
WHERE (Id = @Id OR @Id is NULL)
AND (ResourceIntId = @ResourceIntId OR @ResourceIntId is NULL)
And (GroupTypeId = @GroupTypeId OR @GroupTypeId is NULL)

GO
grant execute on [Resource.GroupTypeDelete]  to public
Go