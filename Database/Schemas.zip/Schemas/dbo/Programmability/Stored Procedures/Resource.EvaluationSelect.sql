USE [LearningRegistryCache_DEV_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.EvaluationSelect]    Script Date: 05/09/2013 14:53:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Resource.EvaluationSelect]
	@ResourceIntId int,
	@CreatedById int,
	@StandardId int,
	@RubricId int
As

	IF @ResourceIntId = 0 SET @ResourceIntId = NULL
	IF @CreatedById = 0 SET @CreatedById = NULL
	IF @StandardId = 0 SET @StandardId = NULL
	IF @RubricId = 0 SET @RubricId = NULL
	
SELECT 
    Id, 
    ResourceIntId, 
    Created, 
    CreatedById, 
    StandardId, 
    RubricId, 
    Value, 
    ScaleMin, 
    ScaleMax, 
    CriteriaInfo
FROM [Resource.Evaluation]
WHERE (ResourceIntId = @ResourceIntId OR @ResourceIntId IS NULL) AND
	(CreatedById = @CreatedById OR @CreatedById IS NULL) AND
	(StandardId = @StandardId OR @StandardId IS NULL) AND
	(RubricId = @RubricId OR @RubricId IS NULL)

GO


