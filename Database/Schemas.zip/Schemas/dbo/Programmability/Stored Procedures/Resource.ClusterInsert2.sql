USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[Resource.ClusterInsert2]    Script Date: 07/12/2012 12:48:10 ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.ClusterInsert2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ClusterInsert2]
Go

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@ClusterId int
DECLARE @PropertyName varchar(100), @Value varchar(500)

set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @ClusterId = 1


EXECUTE @RC = [.[dbo].[Resource.ClusterInsert2]     @ResourceId  ,@ClusterId, 2
GO


*/
Create PROCEDURE [dbo].[Resource.ClusterInsert2]
            @ResourceIntId int, 
            @ClusterId int
            ,@CreatedById int

As
--declare @CreatedById int
--set @CreatedById = 0

if @ResourceIntId = 0	Set @ResourceIntId = NULL
If @ClusterId = 0				SET @ClusterId = NULL 
If @CreatedById = 0			SET @CreatedById = NULL 

if @ClusterId is null OR @ResourceIntId is null begin
	print 'Resource.ClusterInsert2 Error: Incomplete parameters were provided'
	RAISERROR('Resource.ClusterInsert2 Error: incomplete parameters were provided. Require Source ResourceIntId, and @ClusterId', 18, 1)    
	RETURN -1 
	end
	
	
INSERT INTO [dbo].[Resource.Cluster]
           (ResourceIntId
           ,[ClusterId], CreatedById)
Values (
	@ResourceIntId, 
	@ClusterId, @CreatedById
)

go
grant execute on [Resource.ClusterInsert2] to public
go


