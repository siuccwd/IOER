USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[RatingTypeGet]    Script Date: 08/29/2012 14:06:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Get RatingType
-- =============================================
CREATE PROCEDURE [dbo].[RatingTypeGet]
	@Id int,
	@Type varchar(50),
	@Identifier varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT Id, [Type], Identifier, [Description], Created
	FROM RatingType
	WHERE (Id = @Id OR @Id IS NULL) AND
		([Type] = @Type OR @Type IS NULL) AND
		(Identifier = @Identifier OR @Identifier IS NULL)
END

GO


grant execute on RatingTypeGet to public
go