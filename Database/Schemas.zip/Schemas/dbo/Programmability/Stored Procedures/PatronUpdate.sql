USE Isle_Ioer
GO

/****** Object:  StoredProcedure [dbo].[PatronUpdate]    Script Date: 01/25/2013 16:38:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PatronUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[PatronUpdate]
GO

/****** Object:  StoredProcedure [dbo].[PatronUpdate]    Script Date: 01/25/2013 16:38:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/* 
==================================================================
--- Update Procedure for [Patron] ---
Modifications
13-04-29 mparsons - added IsActive 
==================================================================
*/
CREATE PROCEDURE [dbo].[PatronUpdate]
    @Id int,
    @Password varchar(50), 
    @FirstName varchar(50), 
    @LastName varchar(50), 
    @Email varchar(100), 
    @IsActive int 

As

If @Password = ''   SET @Password = NULL 
If @FirstName = ''  SET @FirstName = NULL 
If @LastName = ''   SET @LastName = NULL 
If @Email = ''      SET @Email = NULL 

If @Password is NULL begin
  select @Password = [Password] from [Patron] WHERE Id = @Id
end

UPDATE [Patron] 
SET 
    Password = @Password, 
    FirstName = @FirstName, 
    LastName = @LastName, 
    Email = @Email, 
    IsActive = @IsActive,
	LastUpdated = getdate() 
    
WHERE Id = @Id

GO

GRANT EXECUTE ON [dbo].[PatronUpdate] TO [public] AS [dbo]
GO

