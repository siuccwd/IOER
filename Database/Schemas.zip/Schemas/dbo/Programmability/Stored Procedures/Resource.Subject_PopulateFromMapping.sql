USE [Isle_IOER]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

select count(*) from [Resource]
go

SELECT top 1000
 base.[ResourceIntId]
      ,[ClusterId]
      ,[ResourceUrl]
      ,[Title]
      ,[Description]
      ,keys.[Keywords]
      ,subs.[Subjects]
  FROM [Resource.Version_Summary] base
  Left join [dbo].[Resource.Cluster] rclu 
          on base.ResourceIntId = rclu.ResourceIntId And rclu.[ClusterId] = 91
	Left Join [dbo].[Resource.KeywordsCsvList] keys on base.ResourceIntId = keys.ResourceIntId
	Left Join [dbo].[Resource.SubjectsCsvList] subs on base.ResourceIntId = subs.ResourceIntId
where rclu.[ClusterId] is not null
  
  
GO

UPDATE [dbo].[Map.Subject]
   SET [IsActive] = 1
 WHERE Id < 72
GO




EXECUTE [dbo].[Resource.Subject_PopulateFromMapping] 0, 91


EXECUTE [dbo].[Resource.Subject_PopulateFromMapping] 0, 4
 

*/

/*
Map Subjects 
Loop thru defined mapping values, and apply to existing resources

Notes
- should join to resource version to only target resources already in the pathway
- add a date or means to only target recent additions rather than the whole database
	===> would not pick up new filters if we did the latter
*/
Alter PROCEDURE [dbo].[Resource.Subject_PopulateFromMapping]
            @MaxRecords int
            ,@SubjectId int

As
begin 
          
Declare 
@MapId int
,@MappedSubjectId int
,@Subject varchar(100)
,@FilterValue varchar(200)
,@Filter varchar(200)
,@cntr int
,@interval int
,@debugLevel int
,@affectedCount int
,@totalCount int
set @interval= 25
set @cntr= 0
set @debugLevel= 10
set @affectedCount= 0
set @totalCount= 0

SET NOCOUNT ON;
-- ===============================================
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT  FilterValue, MappedSubjectId, base.Id, codes.Title
      FROM   [Map.K12Subject] base
	  Inner join [Codes.Subject] codes on base.MappedSubjectId = codes.Id
      where base.IsActive= 1 
      AND (MappedSubjectId = @SubjectId or @SubjectId = 0)

	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @FilterValue, @MappedSubjectId, @MapId, @Subject
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
		  
    select @cntr As Cntr,convert(varchar, @MappedSubjectId) As SubjectId,@FilterValue	As Filter
    print convert(varchar, @cntr) + '. Subject/Filter: ' + convert(varchar, @MappedSubjectId) + ' - ' + @FilterValue		
		set @Filter = '%' + ltrim(rtrim(@FilterValue)) + '%'
		
    -- === via title =======================================================  		
    INSERT INTO [dbo].[Resource.Subject]
               ([ResourceIntId]
               ,[CodeId], Subject)
    SELECT distinct lrs.ResourceIntId,  @MappedSubjectId, @Subject
    FROM dbo.[Resource.Version_Summary] lrs 
    left join [dbo].[Resource.Subject] rc on lrs.ResourceIntId = rc.ResourceIntId AND rc.CodeId = @MappedSubjectId
	--Left Join [dbo].[Resource.KeywordsCsvList] keys on lrs.ResourceIntId = keys.ResourceIntId
	--Left Join [dbo].[Resource.SubjectsCsvList] subs on lrs.ResourceIntId = subs.ResourceIntId
    where rc.[CodeId] is null
    And (lrs.Title like @Filter 
         OR lrs.[Description] like @Filter
        -- OR keys.Keywords like @Filter
        -- OR subs.Subjects like @Filter
         )
    set @affectedCount = @@rowcount
    if @affectedCount is not null AND @affectedCount > 0 begin
      set @totalCount= @totalCount + @affectedCount
      print '-> match found for Subject using filter. Count: '  
              + convert(varchar, @affectedCount)  + '. #' 
              + convert(varchar, @MappedSubjectId) + ' - ' + @Filter
      --if ((@dupsCntr / @interval) * @interval) = @dupsCntr 
      
      end

    -- todo - once run, could arbitrarily set to false?
    --      - probably only useful for initial runs, as in prod will run regularly against new records
    
  	-- === via keywords =======================================================
    INSERT INTO [dbo].[Resource.Subject]
               ([ResourceIntId]
               ,[CodeId], Subject)
    SELECT distinct lrs.ResourceIntId,  @MappedSubjectId, @Subject
    FROM dbo.[Resource.Keyword] lrs 
    left join [dbo].[Resource.Subject] rc on lrs.ResourceIntId = rc.ResourceIntId AND rc.CodeId = @MappedSubjectId
    where rc.[CodeId] is null
    And lrs.Keyword like @Filter

  	set @affectedCount = @@rowcount
    if @affectedCount is not null AND @affectedCount > 0 begin
      set @totalCount= @totalCount + @affectedCount
      print 'KKKKKKK match found on keywords for Subject. Count: '  
              + convert(varchar, @affectedCount)  + '. #' 
	  end
    
    
    -- === via subjects =======================================================   
	-- different - probably an update 
	UPDATE [dbo].[Resource.Subject]
		SET [CodeId] = @MappedSubjectId
	From [dbo].[Resource.Subject] base
	where base.[CodeId] is null
    And base.Subject like @Filter

	set @affectedCount = @@rowcount
    if @affectedCount is not null AND @affectedCount > 0 begin
      set @totalCount= @totalCount + @affectedCount
      print '$$$$$$$ match found on subjects for Subject. Count: '  
              + convert(varchar, @affectedCount)  + '. #' 
	  end
    
  	 -- =====================================
  	 
	FETCH NEXT FROM thisCursor INTO @FilterValue, @MappedSubjectId, @MapId, @Subject
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  select 'Subjects created: ' + convert(varchar, @totalCount)
  
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.Subject_PopulateFromMapping] TO [public] AS [dbo]

go