
 
--- Get Procedure for [Resource.GroupType] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.GroupTypeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.GroupTypeSelect]
Go
CREATE PROCEDURE [Resource.GroupTypeSelect]
  @ResourceIntId int
As
SELECT 
    base.Id, 
    ResourceIntId, 
    GroupTypeId, codes.Title As GroupType,  
    base.Created, 
    base.CreatedById, 
    base.ResourceId
FROM [Resource.GroupType] base
inner join [Codes.GroupType] codes on base.GroupTypeId = codes.Id
where ResourceIntId= @ResourceIntId
order by codes.Title

GO
grant execute on [Resource.GroupTypeSelect] to public 
Go
 