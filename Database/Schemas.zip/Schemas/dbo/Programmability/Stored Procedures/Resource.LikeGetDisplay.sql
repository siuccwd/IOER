USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.LikeGetDisplay]    Script Date: 10/10/2014 2:31:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

[Resource.LikeGetDisplay] 62858, 2

*/
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 3/7/2013
-- Description:	Get resource Like Summary
-- mods
-- 14-10-10 mparsons - added HasRating to simplify checking if user has rated the resource
-- =============================================
ALTER PROCEDURE [dbo].[Resource.LikeGetDisplay]
	@Id int, 
	@UserId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT rls.ResourceIntId, rls.LikeCount
		, rls.DislikeCount, IsNull(YouLikeThis,'False') AS YouLikeThis
		, isnull(YouDislikeThis,'False') AS YouDislikeThis
		, case when isnull(ylt.ResourceIntId, 0) > 0 then 1 else 0 end As HasRating
	FROM [Resource.LikesSummary] rls
	LEFT JOIN (SELECT ResourceIntId,
		CASE WHEN IsLike = 'True' THEN 'True' ELSE 'False' END AS YouLikeThis,
		CASE WHEN IsLike = 'False' THEN 'True' ELSE 'False' END AS YouDislikeThis
		FROM [Resource.Like] WHERE CreatedById = @UserId) ylt ON rls.ResourceIntId = ylt.ResourceIntId
	WHERE rls.ResourceIntId = @Id
END
go
grant execute on [Resource.LikeGetDisplay] to public
go

