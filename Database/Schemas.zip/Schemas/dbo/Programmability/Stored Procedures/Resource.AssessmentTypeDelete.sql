USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.AssessmentTypeDelete]    Script Date: 03/19/2013 18:03:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [dbo].[Resource.AssessmentTypeDelete]
            @ResourceIntId int, 
            @AssessmentTypeId int, 
            @Id int
As
If @ResourceIntId = 0   SET @ResourceIntId = NULL 
If @AssessmentTypeId = 0   SET @AssessmentTypeId = NULL 
If @Id = 0   SET @Id = NULL 

DELETE FROM [Resource.AssessmentType]
WHERE (Id = @Id OR @Id is NULL)
AND (ResourceIntId = @ResourceIntId OR @ResourceIntId is NULL)
And (AssessmentTypeId = @AssessmentTypeId OR @AssessmentTypeId is NULL)


GO


