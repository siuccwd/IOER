
 
--- Insert Procedure for [Resource.RelatedUrl] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.RelatedUrlInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RelatedUrlInsert]
Go
CREATE PROCEDURE [Resource.RelatedUrlInsert]
            @ResourceIntId int, 
            @RelatedUrl varchar(300), 
            @CreatedById int
            --,@ResourceId varchar(40)
As
If @ResourceIntId = 0   SET @ResourceIntId = NULL 
If @CreatedById = 0   SET @CreatedById = NULL 
--If @ResourceId = ''   SET @ResourceId = NULL 

INSERT INTO [Resource.RelatedUrl] (

    ResourceIntId, 
    RelatedUrl, 
    CreatedById 
    --,ResourceId
)
Values (

    @ResourceIntId, 
    @RelatedUrl, 
    @CreatedById
    --,@ResourceId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Resource.RelatedUrlInsert] to public
Go