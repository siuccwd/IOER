
--- Get Single Procedure for [StandardBody.Subject] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[StandardBody.SubjectGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [StandardBody.SubjectGet]
Go

/*
[StandardBody.SubjectGet] 1, 0, ''

*/
CREATE PROCEDURE [StandardBody.SubjectGet]
    @Id int,
    @StandardBodyId int, 
    @Title varchar(200) 
As

If @StandardBodyId = 0   SET @StandardBodyId = NULL 
If @Title = ''   SET @Title = NULL 
If @Id = 0   SET @Id = NULL 


SELECT     Id, 
    StandardBodyId, 
    Title, 
    Description, 
    Url, 
    Language
FROM [StandardBody.Subject]
WHERE 
    (Id = @Id OR @Id is null)
AND (StandardBodyId = @StandardBodyId OR @StandardBodyId is null)    
AND (Title = @Title OR @Title is null)

GO
grant execute on [StandardBody.SubjectGet] to Public
Go
 
 