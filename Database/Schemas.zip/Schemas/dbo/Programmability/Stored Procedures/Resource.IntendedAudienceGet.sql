USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceGet]    Script Date: 08/29/2012 14:17:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
[dbo].[Resource.IntendedAudienceGet] '', '0F8FA077-3B64-4440-81C5-105F97BBB159', 1
*/
Alter PROCEDURE [dbo].[Resource.IntendedAudienceGet]
	@RowId      varchar(36),
	@ResourceId varchar(36),
	@AudienceId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  IF @RowId = ''      SET @RowId = NULL
  IF @ResourceId = '' SET @ResourceId = NULL
  IF @AudienceId = 0 SET @AudienceId = NULL
    
    SELECT RowID, ResourceId, AudienceId, OriginalAudience
    FROM [Resource.IntendedAudience]
    WHERE 
        (RowID = @RowId  OR @RowId IS NULL)
    AND	(ResourceId = @ResourceId OR @ResourceId IS NULL)
    AND	(AudienceId = @AudienceId OR @AudienceId IS NULL)
END

GO


grant execute on [Resource.IntendedAudienceGet] to public
go