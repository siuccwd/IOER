USE [LearningRegistryCache2]
GO

/****** Object:  StoredProcedure [dbo].[Codes_ResourceType_Select]    Script Date: 07/02/2012 17:14:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Create date: 6/16/2012
-- Description:	Select one or more name/value pairs for a resource
-- =============================================
Create PROCEDURE [dbo].[Codes_ResourceType_Select]

AS
BEGIN
SELECT [Id]
      ,[Title]

  FROM [dbo].[Codes.ResourceType]
  order by       
  [SortOrder], [Title]


END

GO


