USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.Language_SelectedCodes]    Script Date: 09/08/2012 17:40:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.Language_SelectedCodes] 444662
*/
Alter PROCEDURE [dbo].[Resource.Language_SelectedCodes]
    @ResourceIntId int
    --    @ResourceId uniqueidentifier
As
SELECT distinct
	code.Id, code.Title
   -- ,ResourceId
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.Language] code
Left Join [Resource.Language] rpw on code.Id = rpw.LanguageId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsPathwaysLanguage = 1
Order by 2

GO
GRANT EXECUTE ON [dbo].[Resource.Language_SelectedCodes] TO [public] 
go