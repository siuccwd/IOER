USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionGet]    Script Date: 12/17/2012 16:25:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select top 10 * from [Resource.Version]

exec [Resource.VersionGet] '063438CA-9FF4-42B9-A511-000028286F04'

[Resource.Version_Get]  '261F947B-25D4-4976-9A0C-00007994619C'
go
[Resource.VersionGet]  '3674fb51-ae70-454f-94bb-1929e4629230'



*/

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/30/2012
-- Description:	Get Resource info from ResourceVersion (and other tables/views)
-- 13-01-31 mparsons - added join for new AccessRightsId
-- 13-02-13 mparsons - added return of res.Id
-- 13-02-19 mparsons - added InteractivityTypeId
-- 13-03-28 mparsons - added Requirements, fixed InteractivityTypeId
-- =============================================
ALTER PROCEDURE [dbo].[Resource.VersionGet]
	@RowId uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
	  base.RowId,
	  base.Id,
    NULL As ResourceId, 
    res.Id As ResourceIntId,
		res.ResourceUrl,
		res.ViewCount,
		res.FavoriteCount,
		base.DocId,
		base.Title, base.SortTitle,
		base.[Description],
		ISNULL(base.Publisher,'Unknown') AS Publisher,
		ISNULL(base.Creator,'Unknown') AS Creator,
		ISNULL(base.Rights,'Unknown') AS Rights,
		AccessRightsId,
    isnull(codes.title, 'Unknown') As AccessRights,
    
    isnull(InteractivityTypeId, 0) As InteractivityTypeId,
    isnull(iatCodes.title, 'Unknown') As InteractivityType,
    
		ISNULL(base.TypicalLearningTime, 'Unknown') AS TypicalLearningTime,
		base.Modified,base.[Schema],

		base.Submitter,
		ISNULL(base.Imported, base.Modified) AS Imported,
		base.Created,
		base.IsSkeletonFromParadata
	  ,Requirements
				
		--==== get related tablelstuff, may not be needed anymore??
		,replace(isnull(rsub.Subjects, ''), '","', ', ') As Subjects
	,'' As Subjects2
		,isnull(edList.EducationLevels,'') As EducationLevels
		,replace(isnull(rkwd.Keywords, ''), '","', ', ') As Keywords
	--,'' As Keywords
		--,'TBD' As Keywords
		
		,isnull(langList.LanguageList,'') As LanguageList
		,isnull(typesList.ResourceTypesList,'') As ResourceTypesList
		,isnull(audienceList.AudienceList,'') As AudienceList

	FROM [Resource.Version] base
	inner join [Resource] res on base.ResourceIntId = res.Id
	Left Join dbo.[Codes.AccessRights] codes on base.AccessRightsId = codes.Id
  Left Join dbo.[Codes.InteractivityType] iatCodes on base.InteractivityTypeId = iatCodes.Id
	--Left Join [dbo].[Resource.SubjectCsv] rsub2 on res.RowId = rsub.ResourceId
	Left Join [dbo].[Resource.SubjectsCsvList] rsub on res.Id = rsub.ResourceIntId
	--Left Join [dbo].[Resource.KeywordCsv] rkwd2 on res.RowId = rkwd.ResourceId
	Left Join [dbo].[Resource.KeywordsCsvList] rkwd on res.Id = rkwd.ResourceIntId
  Left Join [dbo].[Resource.EducationLevelsList] edList on res.Id = edList.ResourceIntId
    Left Join [dbo].[Resource.LanguagesList] langList on res.Id = langList.ResourceIntId
    Left Join [dbo].[Resource.IntendedAudienceList] audienceList on res.Id = audienceList.ResourceIntId
    Left Join [dbo].[Resource.ResourceTypesList] typesList on res.Id = typesList.ResourceIntId
	WHERE base.RowId = @RowId
END

GO
GRANT EXECUTE ON [dbo].[Resource.VersionGet] TO [public] AS [dbo]