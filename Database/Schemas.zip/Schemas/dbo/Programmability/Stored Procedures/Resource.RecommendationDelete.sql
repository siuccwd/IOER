
--- Delete Procedure for [Resource.Recommendation] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.RecommendationDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RecommendationDelete]
GO
CREATE PROCEDURE [Resource.RecommendationDelete]
        @Id int
As
DELETE FROM [Resource.Recommendation]
WHERE Id = @Id
GO
grant execute on [Resource.RecommendationDelete]  to public
Go
