use LearningRegistryCache_dev
go

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
GetCodeValues "Gender", "IntegerValue" ,"en"

[CodeTable_Select] "GridPageSize", "IntegerValue" ,"en"

[P_VOS_GET_CODES] "Ethnicity", "IntegerValue" ,"es"
*/

-- =============================================
-- CodeTable_Select
-- Description:	copied [P_VOS_GET_CODES] to replicate processing
-- =============================================
Alter PROCEDURE CodeTable_Select 
			@Code varchar(50),
			@Sort varchar(20),
			@Language	varchar(10)
AS
BEGIN
	SET NOCOUNT ON;
	
SELECT *	
FROM [codeTable]
Where CodeName = @Code 
AND LanguageCode = @Language
And IsActive = 1
Order by 
	CASE @Sort 
		WHEN 'CodeName' THEN CodeName 
		WHEN 'StringValue' THEN StringValue 
		WHEN 'Description' Then Description
	END, 
	CASE @Sort 
		WHEN 'NumericValue' THEN NumericValue
	END,
	CASE @Sort 
		WHEN 'Id' THEN Id
		WHEN 'IntegerValue' THEN IntegerValue 
		WHEN 'SortOrder' THEN SortOrder
	END,
	CASE @Sort
		WHEN 'Created' THEN Created
		WHEN 'Modified' THEN Modified
	END

END
GO

grant execute on CodeTable_Select to public
go
