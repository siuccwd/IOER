USE [Isle_IOER]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
select *   from [System.GenerateLoginId]
WHERE (IsActive = 1) and ExpiryDate < getdate()

[dbo].[SystemProxies_DeleteInActivate]

*/

-- =============================================
-- Description:	Delete all inactive rows
-- Modifications
-- =============================================
CREATE PROCEDURE [dbo].[SystemProxies_DeleteInActivate]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
Delete [System.GenerateLoginId]
WHERE (IsActive = 0) 
END


GO
grant execute on [SystemProxies_DeleteInActivate] to public
go

