--USE [LRCache_120621a]
Use LearningRegistryCache_Dev
GO
/****** Object:  StoredProcedure [dbo].[ResourceType_SearchCounts]    Script Date: 06/30/2012 15:18:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
  
/*
SELECT [RowId]
      ,[ResourceId]
      ,[ResourceTypeId]
      ,[OriginalType]
  FROM [dbo].[Resource.ResourceType] base
  inner join [Codes.ResourceType] crt on base.ResourceTypeId = crt.Id
  
SELECT crt.Title,  SortOrder      ,Count(*) As RecordCount
  FROM [dbo].[Resource.ResourceType] base
  inner join [Codes.ResourceType] crt on base.ResourceTypeId = crt.Id
  group by crt.Title,  SortOrder
  
  
  Order by crt.SortOrder
  
GO


-- ===========================================================
DECLARE @RC int,@Filter varchar(5000)

set @Filter = ' where lr.Title like ''%manu%'' OR lr.Description like
''%manu%''  '

set @Filter = ' where ( (lr.Title like ''%Energy%'' OR lr.[Description] like ''%Energy%'' OR lrp.Value like ''%Energy%'') OR (lr.Title like ''%Finance%'' OR lr.[Description] like ''%Finance%'' OR lrp.Value like ''%Finance%'') OR (lr.Title like ''%Health Science%'' OR lr.[Description] like ''%Health Science%'' OR lrp.Value like ''%Health Science%'') ) AND (lrp.Value in (''high school'',''Higher Education'')) '

--set @Filter = @Filter + ' AND (edList.Level in (''secondary'')) '
set @Filter = ''
EXECUTE @RC = ResourceType_SearchCounts  @Filter

*/

/* =============================================
      Description:      Resource Type search - returns group by count, typically using the same filter as for the research search
  
------------------------------------------------------
Modifications
12-06-29 mparsons - new
=============================================

*/

Alter PROCEDURE [dbo].[ResourceType_SearchCounts]
		@Filter           varchar(5000)
As

SET NOCOUNT ON;
-- paging
DECLARE
      @debugLevel      int
      ,@SQL             varchar(5000)
      ,@GroupBy         varchar(200)

-- =================================

Set @debugLevel = 4

set @GroupBy = ' group by rrt.ResourceTypeId  '

-- =================================

CREATE TABLE #tempWorkTable(
      ResourceTypeId int,
      RecordCount	int
)

-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
--        Left JOIN dbo.[EducationLevel] edList ON lr.RowId = edList.ResourceId 
  set @SQL = 'SELECT rrt.ResourceTypeId, Count(*) As RecordCount 
		FROM dbo.Resource lr
        INNER JOIN dbo.[Resource.Property] lrp ON lr.RowId = lrp.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.RowId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId  '
        + @Filter

  set @SQL = @SQL + ' ' + @GroupBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (ResourceTypeId,RecordCount)
  exec (@SQL)
  
  
SELECT rrt.ResourceTypeId As Id, 
crt.Title, 
crt.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
RecordCount 
FROM #tempWorkTable rrt
Inner Join dbo.[Codes.ResourceType] crt on rrt.ResourceTypeId = crt.Id
order by crt.SortOrder, crt.Title

-- =================================
GO
grant execute on [ResourceType_SearchCounts] to public
go
