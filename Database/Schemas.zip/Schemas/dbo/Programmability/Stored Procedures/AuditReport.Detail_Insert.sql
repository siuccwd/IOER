USE Isle_IOER
GO

/****** Object:  StoredProcedure [dbo].[AuditReport.Detail_Insert]    Script Date: 08/29/2012 14:00:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/2/2012
-- Description:	Create a detail record for the audit report
-- =============================================
Alter PROCEDURE [dbo].[AuditReport.Detail_Insert]
	@ReportId int, 
	@FileName varchar(100), 
	@DocID varchar(100),
	@URI varchar(500), 
	@MessageType char(1), 
	@MessageRouting varchar(2),
	@Message varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [AuditReport.Detail] (ReportId, [Filename], DocID, URI, MessageType,
		MessageRouting, Message)
	VALUES (@ReportId, @FileName, @DocID, @URI, @MessageType, @MessageRouting, @Message)
END

GO


GRANT EXECUTE ON [AuditReport.Detail_Insert] TO PUBLIC
GO