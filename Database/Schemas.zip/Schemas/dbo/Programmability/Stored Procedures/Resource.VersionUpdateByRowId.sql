USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionUpdateByRowId]    Script Date: 12/21/2012 15:45:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/30/2012
-- Description:	Update a Resource Version
-- 2012-11-08 jgrimmer - Added Schema field
-- 2012-12-13 jgrimmer - Added logic to calculate SortTitle from Title and update it
-- 2013-01-31 mparsons - added handling of AccessRights or AccessRightsId
-- 2013-02-19 mparsons - added @InteractivityTypeId - need to coordinate with live import
-- 2012-02-27 mparsons - removed columns that cannot be updated, like resourceId, docId, created, etc
-- 2013-08-22 mparsons - renamed, preparing for obsoletion
-- =============================================
Create PROCEDURE [dbo].[Resource.VersionUpdateByRowId]
	@RowId uniqueidentifier,
	@Title varchar(200),
	@Description varchar(max),
	@Rights varchar(500),
	@AccessRights varchar(100),
	@AccessRightsId int,
	@TypicalLearningTime varchar(50),
	@Schema varchar(50)
  ,@InteractivityTypeId int
  ,@Modified datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @Description = '' SET @Description = NULL

	IF @Rights = '' SET @Rights = NULL
	IF @TypicalLearningTime = '' SET @TypicalLearningTime = NULL
	IF @Schema = '' SET @Schema = NULL
		--should we have a default?
	IF @InteractivityTypeId = 0 SET @InteractivityTypeId = NULL
	
	if @AccessRightsId > 0 begin
	  IF @AccessRights is NULL OR rtrim(@AccessRights) = '' begin
	    SELECT @AccessRights = isnull(codes.Title,'Unknown')
      FROM dbo.[Codes.AccessRights] codes where codes.Id = @AccessRightsId
      end
	  end
	else begin 
    IF @AccessRights is NULL OR rtrim(@AccessRights) = '' SET @AccessRights = 'Unknown'
	  SELECT @AccessRightsId = isnull(codes.Id,8)
    FROM dbo.[Codes.AccessRights] codes where codes.Title = @AccessRights
      
		end
		
	UPDATE [Resource.Version]
	SET 
		Title = @Title,
		[Description] = @Description,
		--Publisher = @Publisher,
		--Creator = @Creator,
		Rights = @Rights,
		--AccessRights = @AccessRights,
		AccessRightsId = @AccessRightsId,
		Modified = @Modified,
		--Submitter = @Submitter,
		--Imported = @Imported,
		--Created = @Created,
		TypicalLearningTime = @TypicalLearningTime,
		--IsSkeletonFromParadata = @IsSkeletonFromParadata,
		--[Schema] = @Schema,
		InteractivityTypeId = @InteractivityTypeId,
		SortTitle = dbo.BuildSortTitle(@Title)
		
	WHERE RowId = @RowId
END

