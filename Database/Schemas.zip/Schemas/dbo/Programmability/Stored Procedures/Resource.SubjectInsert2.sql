USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[Resource.SubjectInsert2]    Script Date: 12/21/2012 16:24:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select top 100 * from [Resource.PublishedBy] 
where PublishedById = 2
--

SELECT rs.[Id],rs.[ResourceIntId]
      ,PublishedById
      ,rs.[Subject],rs.[Created]

  FROM [dbo].[Resource.Subject] rs
  inner join [Resource.PublishedBy] rp on rs.ResourceIntId = rp.ResourceIntId
where 
PublishedById= 2  
  order by 2, 3
  --
  
SELECT rs.[Id],rs.[ResourceIntId]
      ,PublishedById
      ,rs.[Keyword],rs.[Created]

  FROM [dbo].[Resource.Keyword] rs
  inner join [Resource.PublishedBy] rp on rs.ResourceIntId = rp.ResourceIntId
where 
PublishedById= 2

--rs.[ResourceIntId] = 288525  
  order by 2, 3
 
 
 
exec [dbo].[Resource.SubjectInsert2] 449805  ,'Arts'  ,2




*/
/*************************************************************
Modifications
2012-11-15 jgrimmer - Added duplicate checking and keyword check
2013-03-14 jgrimmer - Added ResourceIntId
2014-04-17 mparsons - added handling for k12 subjects
*/
Alter PROCEDURE [dbo].[Resource.SubjectInsert2]
	@ResourceIntId int,
	@Subject varchar(100),
	@CreatedById int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @KeywordId int, @CodeId int,
			@exists int
	
	--IF @ResourceIntId = 0 SELECT @ResourceIntId = Id FROM [Resource] WHERE RowId = @ResourceId
	
	--=========================================================
	-- Do keyword check.  If keyword found, delete keyword.
	SELECT @KeywordId = isnull(Id, 0)
	FROM [Resource.Keyword]
	WHERE ResourceIntId = @ResourceIntId 
	AND Keyword = @Subject
	
	IF @KeywordId IS NOT NULL AND @KeywordId > 0 BEGIN
		DELETE FROM [Resource.Keyword]
		WHERE Id = @KeywordId
	END

	--=========================================================
	-- Do K12 subject check.  If found, use codeId.
	SELECT @CodeId = isnull(Id, 0)
	FROM [Codes.Subject]
	WHERE Title = @Subject 
		
	if isnull(@CodeId,0) = 0 set @CodeId = NULL

  --=========================================================
  -- Do Duplicate check.  If already in table, skip the add
  SELECT @exists = Id
  FROM [Resource.Subject]
  WHERE ResourceIntId = @ResourceIntId AND [Subject] = @Subject
 	if @exists is not NULL AND @exists > 0 begin
    print 'found duplicate'
  end
  else begin
      INSERT INTO [Resource.Subject] ( ResourceIntId, [Subject], CreatedById, CodeId)
	  VALUES ( @ResourceIntId, @Subject, @CreatedById, @CodeId)
  end    
END
go
grant execute on [Resource.SubjectInsert2] to public
go