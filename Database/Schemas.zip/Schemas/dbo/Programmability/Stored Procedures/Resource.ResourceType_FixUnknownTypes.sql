--USE LearningRegistryCache_Dev_20120928
--GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceType_FixUnknownTypes]    Script Date: 09/08/2012 16:51:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Exec CodeTables_UpdateWarehouseTotals 10

select [MappingType], OriginalValue from [dbo].[Audit.ResourceType_Orphan]



EXECUTE [dbo].[Resource.ResourceType_FixUnknownTypes] 0


*/

Alter PROCEDURE [dbo].[Resource.ResourceType_FixUnknownTypes]
            @MaxRecords int

As
begin 
          
Declare 
@ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@OriginalValue varchar(200)
,@cntr int
,@orphanCntr int
,@totalRows int
,@ResourceTypeId	int


set @cntr= 0
set @orphanCntr = 0
set @ResourceTypeId = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
    select base.RowId, base.ResourceId, base.[OriginalType]
      FROM [dbo].[Resource.ResourceType] base
      left join [Map.ResourceType] map on base.[OriginalType] = map.LRValue
      left join [dbo].[Codes.ResourceType] codes on map.[CodeId] = codes.Id
      --left join [dbo].[Resource.ResourceType] rtype on base.ResourceId = rtype.ResourceId and rtype.[ResourceTypeId] = codes.id
    where [ResourceTypeId] = 18
    -- and rtype.ResourceId is  null
 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @OriginalValue
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
		  
 --   if @cntr < 50 print '-- ' + convert(varchar(50),@ResourceId) + ' / ' + @OriginalValue 
    
	  SELECT @ResourceTypeId = isnull(base.id,0)
    FROM [dbo].[Codes.ResourceType] base
    inner join [dbo].[Map.ResourceType] mapper on base.Id = mapper.[CodeId]
    where mapper.LRValue = @OriginalValue		  
		  
	  If @ResourceTypeId is null OR @ResourceTypeId = 0	begin	
	    --no mapping, check if exists in audit
	    if NOT exists(SELECT [ResourceId] FROM [dbo].[Audit.ResourceType_Orphan] 
      where [ResourceId]= @ResourceId and [OriginalValue] = @OriginalValue) begin
        print '@@ no mapping, writing to audit table: ' + @OriginalValue
        set @orphanCntr = @orphanCntr+ 1
        INSERT INTO [dbo].[Audit.ResourceType_Orphan]
             ([RowId]
             ,[ResourceId]
             ,[OriginalValue])
        VALUES
             (newId()
             ,@ResourceId
             ,@OriginalValue)
        
        end    
      else begin
        print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
        end
      end
	   else begin
	    --do update
	    print '** updating value: ' + @OriginalValue + ' to type id: ' + convert(varchar,@ResourceTypeId)
      UPDATE [dbo].[Resource.ResourceType]
         SET [ResourceTypeId] = @ResourceTypeId
       WHERE RowId= @RowId
       	  
	    end

		
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @OriginalValue
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  select 'Orphans count: ' + convert(varchar, @orphanCntr)
  
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.ResourceType_FixUnknownTypes] TO [public] AS [dbo]

go