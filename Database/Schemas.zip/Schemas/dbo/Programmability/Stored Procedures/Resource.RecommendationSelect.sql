USE [Isle_IOER]
GO

--- Select Procedure for [Resource.Recommendation] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.RecommendationSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RecommendationSelect]
Go
CREATE PROCEDURE [Resource.RecommendationSelect]
			@ResourceIntId int
As
SELECT 
    Id, 
    ResourceIntId, 
    TypeId, 
    IsActive, 
    Comment, 
    Created, 
    CreatedById
FROM [Resource.Recommendation]
WHERE ResourceIntId = @ResourceIntId
Order by Created

GO
grant execute on [Resource.RecommendationSelect] to public 
Go
 