USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationUseImport]    Script Date: 01/16/2013 18:52:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*


-- ====================================================================
DECLARE @RC int, @ResourceIntId uniqueidentifier, @EducationUseId int, @OriginalValue varchar(100),@TotalRows     int

set @EducationUseId= 0
set @ResourceIntId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @OriginalValue = 'Syllabus'

set @ResourceIntId = 'c73542af-bdaf-4043-be18-417d5a68e6be'
set @OriginalValue = 'Image/jpg2'



EXECUTE @RC = [dbo].[Resource.EducationUseImport] 
   @ResourceIntId, @EducationUseId
  ,@OriginalValue, @totalRows OUTPUT

GO


*/
/* =============================================
Description:      [Resource.EducationUseImport]
------------------------------------------------------
Modifications
2013-08-29 jgrimmer - Code table is [Codes.EducationalUse] not [Codes.EducationUse].  Fixed.
=============================================

*/
Alter PROCEDURE [dbo].[Resource.EducationUseImport]
          @ResourceIntId     int, 
          @EducationUseId	int,
          @OriginalValue  varchar(100)
          ,@TotalRows     int OUTPUT
          ,@ResourceRowId uniqueidentifier
As
declare @NewId uniqueidentifier
, @id int
, @mapperId int
, @exists int
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @KeywordRowId uniqueidentifier

if @OriginalValue = '' set @OriginalValue = NULL
If @EducationUseId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @TotalRows = -1		SET @SuppressOutput = 1
If @EducationUseId < 1		SET @EducationUseId = NULL 
  
If @OriginalValue is NULL and @EducationUseId is null begin
  print 'no values provided'
  return -1
  end    

set @IsDuplicate= 0
set @TotalRows= 0

-- ==================================================================
-- Do keyword check.  If keyword found, delete keyword.
--SELECT @KeywordRowId = RowId
--FROM [Resource.Keyword]
--WHERE ResourceId = @ResourceIntId AND Keyword = @OriginalValue
--IF @KeywordRowId IS NOT NULL AND @KeywordRowId <> '00000000-0000-0000-0000-000000000000' BEGIN
--	DELETE FROM [Resource.Keyword]
--	WHERE RowId = @KeywordRowId
--END

-- ==================================================================
if @EducationUseId is null begin
	print 'insert via EducationUse'
	 -- so first check if mapping exists
	SELECT @EducationUseId = isnull(base.id,0)
  FROM [dbo].[Codes.EducationalUse] base
  inner join [dbo].[Map.EducationUse] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @EducationUseId is null OR @EducationUseId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT ResourceIntId FROM [dbo].[Audit.EducationUse_Orphan] 
    where ResourceIntId= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.EducationUse_Orphan]
           (ResourceIntId
           ,[OriginalValue])
      VALUES
           (@ResourceIntId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @EducationUseId > 0 begin
  if @SuppressOutput = 0
    print '[EducationUseId] = ' + convert(varchar, @EducationUseId)

  set @NewId= NEWID()
  if @SuppressOutput = 0
    print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[Id]
	from [dbo].[Resource.EducationUse] base
	where base.[ResourceIntId] = @ResourceIntId
	And base.[EducationUseId] = @EducationUseId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	 -- set @NewId= @exists
	  set @IsDuplicate= 1
	  if @SuppressOutput = 0
	    print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.EducationUse]
	    ([ResourceIntId]
	    ,EducationUseId
	    ,[OriginalType])

    select
	    @ResourceIntId, 
	    @EducationUseId, 
	    @OriginalValue
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end



GO
GRANT EXECUTE ON [dbo].[Resource.EducationUseImport] TO [public] AS [dbo]