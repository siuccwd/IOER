USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_ImportFromMappingOrphan]    Script Date: 01/23/2013 13:23:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--     11-14     --
/*
INSERT INTO [LearningRegistryCache_Dev_20121005].[dbo].[Map.EducationLevel]
           ([OriginalValue]
           --,[CodeId]
         )
SELECT distinct 
--rtrim(ltrim([OriginalValue]))
OriginalValue
FROM         [Audit.EducationLevel_Orphan]
WHERE     (FoundMapping = 0)
ORDER BY OriginalValue
--======================================================
UPDATE [LearningRegistryCache_Dev_20121005].[dbo].[Audit.EducationLevel_Orphan]
   SET [OriginalValue] = replace([OriginalValue], '-9999', '-99')
WHERE     (FoundMapping = 0)
--
UPDATE [LearningRegistryCache_Dev_20121005].[dbo].[Audit.EducationLevel_Orphan]
   SET [OriginalValue] = rtrim(ltrim([OriginalValue]))
WHERE     (FoundMapping = 0)

-- =======================================
DELETE FROM [LearningRegistryCache_Dev_20121005].[dbo].[Audit.EducationLevel_Orphan]
WHERE     (FoundMapping = 1)
GO

--======================================================

UPDATE [dbo].[Audit.EducationLevel_Orphan]
   SET[FoundMapping] = 0
      ,[IsActive] = 1
      
      
      
select [MappingType], OriginalValue from [dbo].[Audit.EducationLevel_Orphan]

select count(*) FROM [dbo].[Audit.EducationLevel_Orphan] where [FoundMapping]= 0
--34739
-- ================================


Declare @cntr int, @loops int, @batchSize int, @nbrToProcess int
set @cntr= 0
set @loops= 8
set @batchSize = 2000

WHILE @@FETCH_STATUS = 0 BEGIN
  SELECT 
  @nbrToProcess = isnull(count(*),0)
  -- Select count(*) As OrphansCount
  FROM [dbo].[Audit.EducationLevel_Orphan] base
  Inner join [Map.EducationLevel] map on base.[OriginalValue] = map.OriginalValue
  Inner join [dbo].[Codes.PathwaysEducationLevel] codes on map.[CodeId] = codes.Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  
	  set @cntr = @cntr+ 1
	  if @loops > 0 AND @cntr > @loops begin
		  print '### Exiting based on @loops = ' + convert(varchar, @loops)
		  print '### Remaining: = ' + convert(varchar, @nbrToProcess)
		  BREAK
		  End	  

	  if @nbrToProcess > 0 begin
      EXECUTE [dbo].[Resource.EducationLevel_ImportFromMappingOrphan] @batchSize, 2
      end
    else begin
   		BREAK
		  End	  
	END
	
	
-- ================================	

EXECUTE [dbo].[Resource.EducationLevel_ImportFromMappingOrphan] 1500, 4


*/
/*
Attempt to import Resource.EducationLevel from the Audit.EducationLevel_Orphan table
this would be run on demand after attempted cleanups of the mapping
We also need a process to permanently ignore some mappings
*/

-- 2013-03-13 jgrimmer - Added ResourceIntId to processing

ALTER PROCEDURE [dbo].[Resource.EducationLevel_ImportFromMappingOrphan]
            @MaxRecords int,
            @DebugLevel int

As
begin 
          
Declare @ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@Value varchar(200)
,@MappedCodeId int
,@ResourceIntId int
,@cntr int
,@existsCntr int
,@TotalRows int

set @cntr = 0
set @existsCntr = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
	SELECT base.RowId, base.[ResourceId], base.[OriginalValue] As Value, isnull(map.CodeId, -1) As CodeId, [Resource].Id AS ResourceIntId

  FROM [dbo].[Audit.EducationLevel_Orphan] base
  Inner join [Map.EducationLevel] map on base.[OriginalValue] = map.OriginalValue
  Inner join [dbo].[Codes.PathwaysEducationLevel] codes on map.CodeId = codes.Id
  Inner join [Resource] ON base.ResourceId = [Resource].RowId
  where 
  --base.[OriginalValue] = 'Grade 7' And
  --and red.ResourceId is  null
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  --?? if not tried before, but don't want to all. actually ok, as we are doing a join
  -- still we want to be able to ignore stuff that won't be mapped
  -- maybe if the create date and last run date are X days apart, set the ignore flag

 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value, @MappedCodeId, @ResourceIntId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  if @MaxRecords > 0 AND @cntr < 25  
	    print ' ==> ' +@Value

    set @TotalRows = -1 
	  -- not sure what to use for schema here
	  --not using @MappedCodeId, for now 
    --EXECUTE [dbo].[Resource.EducationLevel_Import] 
    --    @ResourceId, 
    --    @Value, '', @TotalRows OUTPUT
        
    -- =====================================================================
    --mapping exists, need to handle already in target table 
    --print 'doing insert'
      INSERT INTO [Resource.EducationLevel]
      (
	      RowId,
	      ResourceId, 
	      PathwaysEducationLevelId,
	      OriginalLevel,
	      ResourceIntId
      )
      
    select newId(), @ResourceId, @MappedCodeId, @Value, @ResourceIntId
      FROM [dbo].[Codes.PathwaysEducationLevel] codes 
      left join [dbo].[Resource.EducationLevel] red on @ResourceId = red.ResourceId 
                and red.[PathwaysEducationLevelId] = codes.id
     where codes.id  = @MappedCodeId
     and red.RowId is null

    set @TotalRows = @@rowcount
    
    -- =====================================================================
            
		--if map was successful, either delete or at least mark
		if @TotalRows > 0 begin
		  print 'appeared to be mapped, now mark/delete'
		  UPDATE [dbo].[Audit.EducationLevel_Orphan]
        SET [LastRerunDate] = getdate()
        ,[FoundMapping] = 1
      WHERE [RowId] = @RowId
		  end
		else begin
		-- check if a entry already exists for the value (ie current results in a duplicate)
		
		  select @existsCntr = isnull(count(*),0)
        FROM [dbo].[Resource.EducationLevel] red 
         where red.ResourceId = @ResourceId 
         And red.PathwaysEducationLevelId  = @MappedCodeId
         group by red.ResourceId
         
    	if @existsCntr > 0 begin
		    print 'the ed level already exists, mark it'
		    UPDATE [dbo].[Audit.EducationLevel_Orphan]
          SET [LastRerunDate] = getdate()
          ,[FoundMapping] = 1
        WHERE [RowId] = @RowId
		    end
		  else begin	
	      print 'not mapped, update rundate????'
	      UPDATE [dbo].[Audit.EducationLevel_Orphan]
          SET [LastRerunDate] = getdate()
        WHERE [RowId] = @RowId
	      end
  		end
		
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value, @MappedCodeId, @ResourceIntId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end


GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevel_ImportFromMappingOrphan] TO [public] AS [dbo]

/*
  INSERT INTO [Resource.EducationLevel]
  (
	  RowId,
	  ResourceId, 
	  PathwaysEducationLevelId,
	  OriginalLevel
  )
  
select top 8000 newId(), base.ResourceId, isnull(codes.id,0), base.Value
  FROM [dbo].[Resource.Property] base
  inner join [Audit.EducationLevel] map on base.Value = map.OriginalValue
  inner join [dbo].[Codes.PathwaysEducationLevel] codes on map.MappedValue = codes.[Title]
  left join [dbo].[Resource.EducationLevel] red on base.ResourceId = red.ResourceId and red.[PathwaysEducationLevelId] = codes.id
    
where base.[PropertyTypeId]= 2
 and red.ResourceId is  null
--

*/