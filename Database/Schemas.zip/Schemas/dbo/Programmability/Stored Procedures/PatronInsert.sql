USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[PatronInsert]    Script Date: 01/25/2013 16:37:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* 
==================================================================
--- Insert Procedure for [Patron] ---
Modifications
13-04-29 mparsons - added IsActive
==================================================================
*/
ALTER PROCEDURE [dbo].[PatronInsert]
            @UserName   varchar(50), 
            @Password   varchar(50), 
            @FirstName  varchar(50), 
            @LastName   varchar(50), 
            @Email      varchar(100),  
            @IsActive   bit
As
If @UserName = ''   SET @UserName = NULL 
If @Password = ''   SET @Password = NULL 
If @FirstName = ''   SET @FirstName = NULL 
If @LastName = ''   SET @LastName = NULL 
If @Email = ''   SET @Email = NULL 

if @Email is null OR @Password is null  begin
  print 'no id provided'
  RAISERROR('Error - at minimum, a valid email address and password are required', 18, 1)    
  RETURN -1 
  end
  
INSERT INTO [Patron] (
    UserName, 
    Password, 
    FirstName, 
    LastName, 
    Email,  
    IsActive
)
Values (

    @UserName, 
    @Password, 
    @FirstName, 
    @LastName, 
    @Email,  
    @IsActive
)
 
select SCOPE_IDENTITY() as Id

GO
GRANT EXECUTE ON [dbo].[PatronInsert] TO [public] AS [dbo]