USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.StandardInsert]    Script Date: 02/26/2013 16:16:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[Resource.StandardInsert]
            @ResourceIntId int, 
            @StandardId int, 
            @StandardUrl varchar(200), 
            @AlignedById int,
            @AlignmentTypeCodeId int,
            @AlignmentDegreeId int
As
-- @ResourceId uniqueidentifier, 
If @StandardId = 0   SET @StandardId = NULL 
If @StandardUrl = ''   SET @StandardUrl = NULL 
If @AlignedById = 0   SET @AlignedById = NULL 
If @AlignmentTypeCodeId = 0 SET @AlignmentTypeCodeId = NULL
If @AlignmentDegreeId = 0 SET @AlignmentDegreeId = 2


INSERT INTO [Resource.Standard] (
    ResourceIntId, 
    StandardId, 
    StandardUrl, 
    AlignedById,
    AlignmentTypeCodeId,
    AlignmentDegreeId
)
Values (
    @ResourceIntId,
    @StandardId, 
    @StandardUrl, 
    @AlignedById,
    @AlignmentTypeCodeId,
    @AlignmentDegreeId
)
select SCOPE_IDENTITY() as Id 
--select @newId as Id

go
GRANT EXECUTE ON [dbo].[Resource.StandardInsert] TO [public] AS [dbo]
go

