USE [Isle_IOER]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
select *   from [System.GenerateLoginId]
WHERE (IsActive = 1) and ExpiryDate < getdate()

[dbo].[SystemProxies_InactivateExpired]

*/

-- =============================================
-- Description:	Set all rows to inactive where expiry date is in the past 
-- Modifications
-- =============================================
CREATE PROCEDURE [dbo].[SystemProxies_InActivateExpired]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
Update         [System.GenerateLoginId]
set IsActive = 0
WHERE (IsActive = 1) and ExpiryDate < getdate()
END


GO
grant execute on [SystemProxies_InActivateExpired] to public
go

