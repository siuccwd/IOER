use Isle_IOER
go

if exists (select * from dbo.sysobjects where id = object_id(N'[MapK12Subject.Search]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [MapK12Subject.Search]
Go
/*

-- ===========================================================

DECLARE @RC int,@Filter varchar(500), @StartPageIndex int, @PageSize int, @totalRows int,@SortOrder varchar(100)
set @SortOrder = '' 
set @Filter = ''

set @Filter = ' MappedSubjectId= 4 '

set @StartPageIndex = 1
set @PageSize = 25

exec [MapK12Subject.Search] @Filter, @SortOrder, @StartPageIndex  ,@PageSize  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/

/* =================================================
= MapK12Subject.Search
=		@StartPageIndex - starting page number. If interface is at 20 when next page is requested, this would be set to 21?
=		@PageSize - number of records on a page
=		@totalRows OUTPUT - total available rows. Used by interface to build a custom pager
= ------------------------------------------------------
= Modifications
= 14-03-17 mparsons - Created 
-- ================================================= */
Create PROCEDURE [dbo].[MapK12Subject.Search]
		@Filter				varchar(500)
		,@SortOrder			varchar(500)
		,@StartPageIndex	int
		,@PageSize		    int
		,@TotalRows			int OUTPUT
AS 
DECLARE 
	@first_id			int
	,@startRow		int
	,@debugLevel	int
	,@SQL             varchar(5000)
	,@OrderBy         varchar(100)

	SET NOCOUNT ON;

-- ==========================================================
Set @debugLevel = 4
if len(@SortOrder) > 0
	set @OrderBy = ' Order by ' + @SortOrder
else 
  set @OrderBy = ' Order by [FilterValue] '
--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

 
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	Id int NOT NULL,
	MappedSubjectId int

)
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter 
     end
	 else begin 
	 set @Filter =     '  '
	 end
 
set @SQL = 'SELECT [Id]  ,[MappedSubjectId]   FROM [dbo].[Map.K12Subject] mcc  '  
	  + @Filter


if charindex( 'order by', lower(@Filter) ) = 0 
	set @SQL = 	@SQL + @OrderBy
if @debugLevel > 3 begin
  print '@SQL len: '  +  convert(varchar,len(@SQL))
	print @SQL
	end
	
INSERT INTO #tempWorkTable (Id, MappedSubjectId)
exec (@sql)
   SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Show the StartPageIndex
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

SELECT     Distinct
		RowNumber,
		base.[Id]
      ,[FilterValue]
      ,[IsRegex]
      ,base.[MappedSubjectId], cc.Title As SubjectTitle
      ,base.[IsActive]
      ,base.[Created]
      ,base.[LastUpdated]
      ,base.[LastUpdatedBy]

From #tempWorkTable temp
inner join [dbo].[Map.K12Subject]  base on temp.Id = base.Id
inner join [dbo].[Codes.Subject] cc on base.MappedSubjectId = cc.Id

WHERE RowNumber > @first_id 
order by RowNumber		

SET ROWCOUNT 0
Go
grant execute on [MapK12Subject.Search] to public 
Go