USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.SubjectCSVInsert]    Script Date: 10/05/2012 15:32:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[Resource.SubjectCSVInsert]
	@ResourceId uniqueidentifier,
	@SubjectCsv varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
    INSERT INTO [Resource.SubjectCsv] (ResourceId, SubjectCsv)
    VALUES (@ResourceId, @SubjectCsv)
    
END
