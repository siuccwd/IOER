USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[ResourceUpdateById]    Script Date: 10/05/2012 10:58:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		MP
-- Create date: 2/3/2014
-- Description:	Update Resource By Id - should replace the existing one by rowId
-- 2014-11-27 mparsons - changed URL to 600
-- =============================================
Alter PROCEDURE [dbo].[ResourceUpdateById]
	@Id int, 
	@ResourceUrl varchar(600),
	@ViewCount int,
	@FavoriteCount int,
	@IsActive bit
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	UPDATE [Resource]
	SET ResourceUrl = @ResourceUrl,
		ViewCount = @ViewCount,
		FavoriteCount = @FavoriteCount,
		LastUpdated = GETDATE(), 
		IsActive = @IsActive
	WHERE Id = @Id
END
