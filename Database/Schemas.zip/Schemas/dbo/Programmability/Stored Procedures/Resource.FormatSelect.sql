USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.FormatSelect]    Script Date: 08/29/2012 14:14:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Resource.FormatSelect]
	@ResourceId uniqueidentifier, @CodeId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @CodeId = 0 SET @CodeId = NULL
    IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
    
    SELECT RowId, ResourceId, OriginalValue, CodeId
    FROM [Resource.Format]
    WHERE (ResourceId = @ResourceId OR @ResourceId IS NULL) AND
		(CodeId = @CodeId OR @CodeId IS NULL)
END

GO


grant execute on [Resource.FormatSelect] to public
go