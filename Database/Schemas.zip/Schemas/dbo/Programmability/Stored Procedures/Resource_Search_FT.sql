USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource_Search_FT]    Script Date: 10/02/2012 09:17:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
SELECT distinct lr.RowId, lr.Title  FROM dbo.Resource lr
        Left JOIN dbo.[Resource.Property] lrp ON lr.RowId = lrp.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.RowId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId   
        where  (FREETEXT(lr.[Description], ' Manufacturing Research and Development ') or FREETEXT(lr.Title, ' Manufacturing Research and Development ') ) 
        UNION SELECT distinct lr.RowId, lr.Title  FROM dbo.Resource lr
        Left JOIN dbo.[Resource.Property] lrp ON lr.RowId = lrp.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.RowId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId   
        where  (lrp.PropertyTypeId = 6 and FREETEXT(lrp.Value, ' Manufacturing Research and Development ') )   
        Order by lr.Title 

        
2 sec
-- ===========================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000),@Keywords        varchar(1000)
DECLARE @StartPageIndex int, @PageSize int, @totalRows int, @OutputRelTables bit
--
set @Filter = ''
set @SortOrder = 'lr.ResourceVersionIntId'
set @Keywords =  ''

set @Filter = ' where (lr.AccessRightsId in (2,4))  '
--set @Filter = ''
set @Keywords =  ' algebra, math, integration '

--set @Filter =  ' ResourceUrl = ''http://phet.colorado.edu/en/simulation/battery-resistor-circuit'' '

set @OutputRelTables = 0 
set @StartPageIndex = 1
set @PageSize = 25
set statistics time on
EXECUTE @RC = Resource_Search_FT
     @Filter, @Keywords, @SortOrder, @StartPageIndex  ,@PageSize, @OutputRelTables  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)
set statistics time off

*/

/* =============================================
  Description:      Resource search using full text catalog
  Uses custom paging to only return enough rows for one page
     Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @totalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
12-07-30 mparsons - new, now uses full text catalogs
12-09-05 mparsons - convert to use Resource.Version_Summary
12-10-23 jgrimmer - modified to use SortTitle instead of Title as the default sort field.
=============================================

*/

ALTER PROCEDURE [dbo].[Resource_Search_FT]
	@Filter           nvarchar(4000)
	,@Keywords        nvarchar(1000)
	,@SortOrder       varchar(100)
	,@StartPageIndex  int
	,@PageSize        int
	,@OutputRelTables bit
	,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@minRows         int
      ,@debugLevel      int
      ,@FTFilter1        nvarchar(4000)
      ,@FTFilter2        nvarchar(4000)
      ,@UsingKeywordFilter bit
      ,@FTFilter3        nvarchar(4000)
      ,@SQL             varchar(8000)
      ,@TopClause       varchar(100)
      ,@OrderBy         varchar(100)
      ,@UsingCodeTableValues bit
      ,@And             varchar(15)
-- =================================

Set @UsingCodeTableValues = 0
Set @debugLevel = 4
Set @TopClause= ''
Set @FTFilter2= ''
set @UsingKeywordFilter= 1
Set @FTFilter3= ''
if @StartPageIndex < 1        set @StartPageIndex = 1

if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by lr.SortTitle '

--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
SET @minRows =  @StartPageIndex + @PageSize

if len(isnull(@Filter,'')) = 0 begin
   --Set @TopClause= ' TOP 25000 '
   --MP - actually, just use code table directly!!
   --Set @OutputRelTables = 0 
   Set @UsingCodeTableValues = 1
   end
else if @minRows < 1000   begin 
  set @TopClause= ' TOP 25000 '   
  end  
-- =================================

CREATE TABLE #tempWorkTable(
      RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
      ResourceIntId    int,
      ResourceVersionIntId int,
      Title             varchar(200)
)
-- =================================

  if len(@Filter) > 0 begin
     set @And= ' AND '
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end
  else if len(@Keywords) > 0 begin
    set @Filter = ' where '
    set @And= ''
    end
  print '@Filter len: '  +  convert(varchar,len(@Filter))
       
       --     or FREETEXT(lrkey.KeywordsIdx, ''' + @Keywords + ''') 
       --     or FREETEXT(lr.Publisher, ''' + @Keywords + ''')
            --or FREETEXT(lr.Description, ''' + @Keywords + ''')  
                -- or FREETEXT(lrkey.OriginalValue, ''' + @Keywords + ''') 
                    -- or FREETEXT(lrs.Subject, ''' + @Keywords + ''') 
     if len(@Keywords) > 0 begin
       set @FTFilter1 = @And + 
       ' (FREETEXT(lr.[Title], ''' + @Keywords + ''') 
       or FREETEXT(lr.ResourceUrl, ''' + @Keywords + ''')
       or FREETEXT(lr.Description, ''' + @Keywords + ''') 
       ) '
       
  --print '@FTFilter1: '  +  @FTFilter1
       set @FTFilter2 = @And + 
         ' lr.ResourceIntid in (select ResourceIntid from dbo.[Resource.Subject] 
    where FREETEXT(Subject, ''' + @Keywords + ''') )'
    
  --print '@FTFilter2: '  +  @FTFilter2


      set @SQL = 'SELECT distinct ' + @TopClause + ' lr.Id, lr.ResourceVersionIntId, lr.SortTitle  
        FROM [dbo].[Resource.Version_Summary] lr '
        + @Filter
        + @FTFilter1

      set @SQL = @SQL + 'UNION SELECT distinct ' + @TopClause + ' lr.Id, lr.ResourceVersionIntId, lr.SortTitle  
        FROM [dbo].[Resource.Version_Summary] lr '
        + @Filter
        + @FTFilter2  

      if @UsingKeywordFilter = 1 begin
        set @FTFilter3 = @And + 
         ' lr.ResourceIntid in (select ResourceIntid from dbo.[Resource.Keyword] 
        where FREETEXT(Keyword, ''' + @Keywords + ''') )'

       -- print '@FTFilter3: '  +  @FTFilter3
        set @SQL = @SQL + 'UNION SELECT distinct ' + @TopClause + ' lr.Id, lr.ResourceVersionIntId, lr.SortTitle  
            FROM [dbo].[Resource.Version_Summary] lr '
            + @Filter
            + @FTFilter3   
        end
       
     end
else begin
--  Left JOIN dbo.[Resource.Subject] lrs ON lr.Id = lrs.ResourceIntId
  set @SQL = 'SELECT distinct ' + @TopClause + ' lr.Id, lr.ResourceVersionIntId, lr.SortTitle  
        FROM [dbo].[Resource.Version_Summary] lr
          '
        + @Filter
	end     

--         

  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (ResourceIntId, ResourceVersionIntId, Title)
  exec (@SQL)
  SELECT @totalRows = @@ROWCOUNT
-- =================================
print 'added to temp table: ' + convert(varchar,@totalRows)

--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- =================================
SELECT Distinct    
   -- RowNumber,
    '' As ResourceId, 
    lr.ResourceIntId,
    lr.ResourceVersionId As RowId,
    lr.ResourceVersionId,
    lr.ResourceVersionIntId,
    lr.ResourceUrl,
    --DocId,
    CASE
      WHEN lr.Title IS NULL THEN 'No Title'
      WHEN len(lr.Title) = 0 THEN 'No Title'
      ELSE lr.Title
    END AS Title,
    lr.SortTitle,
    lr.[Description],
    isnull(Publisher,'Unknown') As Publisher,
    rtrim(ltrim(isnull(Creator,''))) As Creator,
    lr.ViewCount,
    lr.FavoriteCount,
    --Subjects,
    --replace(isnull(lr.Subjects, ''), '","', ', ') As Subjects,
    --replace(isnull(rsub.Subjects, ''), '","', ', ') As Subjects,
    --replace(isnull(rsub.SubjectCsv, ''), '","', ', ') As Subjects,
    '' As Subjects,
    --edList.EducationLevels,    
   '' As EducationLevels,
    Rights,
    AccessRights
   -- ,Modified
		--,isnull(audienceList.AudienceList,'') As AudienceList
		,'' As AudienceList
		,[LikeCount],[DislikeCount]
From #tempWorkTable
    Inner join [dbo].[Resource.Version_Summary] lr on #tempWorkTable.ResourceIntId = lr.ResourceIntId
    left Join [dbo].[Resource.LikesSummary] rlike on lr.ResourceIntId = rlike.ResourceIntId


WHERE RowNumber > @first_id
--order by RowNumber 


if @OutputRelTables = 1 begin
	--==============================================================================================
	if @UsingCodeTableValues = 0 begin
	  CREATE TABLE #edWorkTable(
		    PathwaysEducationLevelId int,
		    RecordCount	int
	  )
	  --			
	  INSERT INTO #edWorkTable (PathwaysEducationLevelId,RecordCount)
	  SELECT rel.PathwaysEducationLevelId, Count(*) As RecordCount 
	  FROM #tempWorkTable work
	  Inner JOIN [Resource.EducationLevelsSummary] rel ON work.ResourceIntId = rel.ResourceIntId 
	  group by rel.PathwaysEducationLevelId
	  --			
	  SELECT rel.PathwaysEducationLevelId As Id, codes.Title, 
	  codes.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
	  RecordCount 
	  FROM #edWorkTable rel
	  INNER JOIN dbo.[Codes.PathwaysEducationLevel] codes ON rel.PathwaysEducationLevelId = codes.Id
	  where codes.IsPathwaysLevel= 1
	  order by codes.SortOrder, codes.Title
	  end
	else begin
  	SELECT codes.[Id]
      ,codes.[Title]
	    ,codes.Title + '  (' + convert(varchar,isnull(WarehouseTotal,0)) + ')' As FormattedTitle  
	   ,WarehouseTotal  
    FROM [dbo].[Codes.PathwaysEducationLevel] codes
    where codes.IsPathwaysLevel= 1 AND isnull(WarehouseTotal,0) > 0
    order by SortOrder, codes.Title
	  end
	--			
	--=====================================
	if @UsingCodeTableValues = 0 begin
	  CREATE TABLE #rtWorkTable(
		    ResourceTypeId int,
		    RecordCount	int
	  )	
	  INSERT INTO #rtWorkTable (ResourceTypeId,RecordCount)
	  SELECT rel.ResourceTypeId, Count(*) As RecordCount 
	  FROM #tempWorkTable work
	  Inner JOIN [Resource.ResourceType] rel ON work.ResourceIntId = rel.ResourceIntId 
	  group by rel.ResourceTypeId
	  --			
	  SELECT rrt.ResourceTypeId As Id, 
	  crt.Title, 
	  crt.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
	  RecordCount 
	  FROM #rtWorkTable rrt
	  Inner Join dbo.[Codes.ResourceType] crt on rrt.ResourceTypeId = crt.Id
	  order by crt.SortOrder, crt.Title
	  end
	else begin
  	SELECT [Id]
      ,[Title]
	    ,Title + '  (' + convert(varchar,isnull(WarehouseTotal,0)) + ')' As FormattedTitle  
	   ,WarehouseTotal  
    FROM [dbo].[Codes.ResourceType]
    where isnull(WarehouseTotal,0) > 0
    order by SortOrder, Title
	  end
  	
	end

Go
grant execute on [Resource_Search_FT] to public
Go
--grant execute on [Resource_Search_FT] to lrreader
--Go 
-- =================================

/*
      SELECT rsl.[Subject] + ';'
      FROM [Resource.SubjectsList] rsl 
      
      ORDER BY  rsl.[Subject]
      FOR XML Path('') 
) D (ContentExpert)


*/ 
