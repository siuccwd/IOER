--- Delete Procedure for [Resource.RelatedUrl] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.RelatedUrlDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RelatedUrlDelete]
GO
CREATE PROCEDURE [Resource.RelatedUrlDelete]
        @Id int
As
DELETE FROM [Resource.RelatedUrl]
WHERE Id = @Id
GO
grant execute on [Resource.RelatedUrlDelete]  to public
Go