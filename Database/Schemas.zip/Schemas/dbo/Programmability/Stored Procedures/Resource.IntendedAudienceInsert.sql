USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceInsert]    Script Date: 03/26/2013 16:50:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- Insert Procedure for Resource.IntendedAudience---


ALTER PROCEDURE [dbo].[Resource.IntendedAudienceInsert]
            --@ResourceId uniqueidentifier, 
			@ResourceIntId int,
            @AudienceId int, 
            @OriginalAudience varchar(50),
            @CreatedById int

As
--declare @CreatedById int
--set @CreatedById = 0

If @OriginalAudience = ''	SET @OriginalAudience = NULL 
If @CreatedById = 0	SET @CreatedById = NULL 

declare @NewId uniqueidentifier
set @NewId= NEWID()

-- ========================================
if @AudienceId is null begin
	print 'insert via @OriginalAudience'
	select @AudienceId = isnull(id,0) from  [Codes.AudienceType]  rpt 
	where rpt.Title = @OriginalAudience
	
	If @AudienceId is null OR @AudienceId = 0	begin	
		SET @AudienceId = 1 
		print 'the property name was not found: ' + @OriginalAudience
		end
	end
else begin
	print 'insert via @AudienceId'
	end
	
--========================================	
INSERT INTO [Resource.IntendedAudience](
	RowId,
    --ResourceId, 
	ResourceIntId,
    AudienceId, 
    OriginalAudience, CreatedById
)
Values (
	@NewId,
    --@ResourceId, 
	@ResourceIntId,
    @AudienceId, 
    @OriginalAudience, @CreatedById
)
 
select @NewId as Id
