USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationUse_SelectedCodes]    Script Date: 09/08/2012 17:40:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.EducationUse_SelectedCodes] 10
*/
Alter PROCEDURE [dbo].[Resource.EducationUse_SelectedCodes]
    @ResourceIntId int
    --    @ResourceId uniqueidentifier
As
SELECT distinct
	code.Id, code.Title, code.[Description]
	--code.EdUseCategoryId as Category, 
   -- ,ResourceIntId
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.EducationalUse] code
Left Join [Resource.EducationUse] rpw on code.Id = rpw.EducationUseId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsActive = 1
Order by code.Title ASC

GO
GRANT EXECUTE ON [dbo].[Resource.EducationUse_SelectedCodes] TO [public] 
go