USE [Isle_IOER]
GO
 
--- Insert Procedure for [Resource.Recommendation] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.RecommendationInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RecommendationInsert]
Go
CREATE PROCEDURE [Resource.RecommendationInsert]
            @ResourceIntId int, 
            @TypeId int, 
            @Comment varchar(MAX), 
            @CreatedById int
As

If @TypeId = 0   SET @TypeId = NULL 
If @Comment = ''   SET @Comment = NULL 
If @CreatedById = 0   SET @CreatedById = NULL 

INSERT INTO [Resource.Recommendation] (

    ResourceIntId, 
    TypeId, 
    Comment, 
    Created, 
    CreatedById
)
Values (

    @ResourceIntId, 
    @TypeId, 
    @Comment, 
    getdate(), 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Resource.RecommendationInsert] to public
Go