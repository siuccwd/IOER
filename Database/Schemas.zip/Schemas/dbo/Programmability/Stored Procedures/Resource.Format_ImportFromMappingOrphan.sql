USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[Resource.Format_ImportFromMappingOrphan]    Script Date: 09/08/2012 16:51:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
				
/*
--==============
UPDATE [LearningRegistryCache_Dev_20121005].[dbo].[Audit.ResourceFormat_Orphan]
   SET [OriginalValue] = 'application/java-archive'
--  select count(*) from [LearningRegistryCache_Dev_20121005].[dbo].[Audit.ResourceFormat_Orphan] 
 WHERE [OriginalValue] like '%application/java-archiv%'
-- ================================================
SELECT  OriginalValue, count(*)
FROM         [Audit.ResourceFormat_Orphan]
WHERE     (FoundMapping = 0)
group by OriginalValue
ORDER BY OriginalValue
-- ================================================
/*
DELETE FROM [LearningRegistryCache_Dev_20121005].[dbo].[Audit.ResourceFormat_Orphan]
      WHERE FoundMapping = 1

*/     
--=====      
SELECT 
--count(*)
TOP 1000 
--[RowId]      ,
[OriginalValue]      ,[FoundMapping]
      ,[IsActive]      ,[Created]      ,[LastRerunDate]
  FROM [LearningRegistryCache_Dev_20121005].[dbo].[Audit.ResourceType_Orphan]
  where [FoundMapping]= 0
  order by [Created] desc      
--=======================================
SELECT [OriginalValue]      ,[FoundMapping]
,Count(*)
      --,[IsActive]      ,[Created]      ,[LastRerunDate]
  FROM [LearningRegistryCache_Dev_20121005].[dbo].[Audit.ResourceFormat_Orphan]
  where [FoundMapping]= 0
  group by [OriginalValue]      ,[FoundMapping]
  order by [OriginalValue]      ,[FoundMapping]
       

EXECUTE [dbo].[Resource.Format_ImportFromMappingOrphan] 30, 5
-- =========================

Declare @cntr int, @loops int, @batchSize int, @nbrToProcess int
set @cntr= 0
set @loops= 1
set @batchSize = 500

WHILE @@FETCH_STATUS = 0 BEGIN
  SELECT 
  @nbrToProcess = isnull(count(*),0)
  -- SELECT count(*) As OrphansCount
  FROM [dbo].[Audit.ResourceFormat_Orphan] base
  Inner join [Map.ResourceFormat] map on base.[OriginalValue] = map.LRValue
  Inner join [dbo].[Codes.ResourceFormat] codes on map.CodeId = codes.Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  
	  set @cntr = @cntr+ 1
	  if @loops > 0 AND @cntr > @loops begin
		  print '### Exiting based on @loops = ' + convert(varchar, @loops)
		  print '### Remaining: = ' + convert(varchar, @nbrToProcess)
		  BREAK
		  End	  


	  if @nbrToProcess > 0 begin
      EXECUTE [dbo].[Resource.Format_ImportFromMappingOrphan] @batchSize, 2
      end
    else begin
   		BREAK
		  End	  
	END


*/
/*
Attempt to import Resource.Format from the Audit.ResourceFormat_Orphan table
this would be run on demand after attempted cleanups of the mapping
We also need a process to permanently ignore some mappings
*/


-- 2013-03-13 jgrimmer - Added ResourceIntId
Alter PROCEDURE [dbo].[Resource.Format_ImportFromMappingOrphan]
      @MaxRecords int,
      @DebugLevel int

As
begin 
          
Declare 
@ResourceIntId int
,@RowId uniqueidentifier
,@Value varchar(200)
,@MappedCodeId int
,@cntr int
,@existsCntr int
,@totalRows int

set @cntr = 0
set @existsCntr = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
	SELECT base.RowId, base.[ResourceIntId], base.[OriginalValue] As Value, isnull(map.CodeId, -1)
	  FROM [dbo].[Audit.ResourceFormat_Orphan] base
	  Inner join [Map.ResourceFormat] map on base.[OriginalValue] = map.LRValue
	  Inner join [dbo].[Codes.ResourceFormat] codes on map.CodeId = codes.Id
	  Inner join [Resource] ON base.ResourceIntId = [Resource].Id
	  where 
		  (base.IsActive is null OR base.IsActive = 1)
	--AND map.CodeId = 4      
	  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)

  --?? if not tried before, but don't want to do all. actually ok, as we are doing a join
  -- still we want to be able to ignore stuff that won't be mapped
  -- maybe if the create date and last run date are X days apart, set the ignore flag

 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceIntId, @Value, @MappedCodeId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  if @MaxRecords > 0 AND @cntr < 25  
	    print ' =======> ' +@Value

    set @totalRows = -1 
	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.Format_Import] 
        @ResourceIntId, @MappedCodeId,
        @Value, @totalRows OUTPUT
        
		--if map was successful, either delete or at least mark
		if @totalRows > 0 begin
		  if @DebugLevel > 5
		    print 'appeared to be mapped, now mark/delete'

		  UPDATE [dbo].[Audit.ResourceFormat_Orphan]
			SET [LastRerunDate] = getdate()
			,[FoundMapping] = 1
		  WHERE [RowId] = @RowId
		  end
		else begin
		-- check if a entry already exists for the value (ie current results in a duplicate)
		
		  select @existsCntr = isnull(count(*),0)
			FROM [Map.ResourceFormat] map 
			inner join [dbo].[Codes.ResourceFormat] codes on map.[CodeId] = codes.Id
			inner join [dbo].[Resource.Format] red 
				  on @ResourceIntId = red.ResourceIntId 
				  and red.[CodeId] = codes.id
			 where map.LRValue  = @Value
			 group by red.ResourceIntId
         
    	if @existsCntr > 0 begin
		    if @DebugLevel > 5
		    print 'the orphan reference already exists, mark it'
		    UPDATE [dbo].[Audit.ResourceFormat_Orphan]
			  SET [LastRerunDate] = getdate()
			  ,[FoundMapping] = 1
			WHERE [RowId] = @RowId
		    end
		  else begin	
	      if @DebugLevel > 5
		    print 'not mapped, update rundate????'
			UPDATE [dbo].[Audit.ResourceFormat_Orphan]
			  SET [LastRerunDate] = getdate()
			WHERE [RowId] = @RowId
	      end
  		end
		
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceIntId, @Value, @MappedCodeId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.Format_ImportFromMappingOrphan] TO [public] AS [dbo]
