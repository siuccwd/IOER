
 
--- Insert Procedure for [Resource.GroupType] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.GroupTypeInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.GroupTypeInsert]
Go
CREATE PROCEDURE [Resource.GroupTypeInsert]
            @ResourceIntId int, 
            @GroupTypeId int,  
            @CreatedById int
            --,@ResourceId uniqueidentifier
As

If @CreatedById = 0   SET @CreatedById = NULL 
--If @ResourceId = ''   SET @ResourceId = NULL 
INSERT INTO [Resource.GroupType] (

    ResourceIntId, 
    GroupTypeId, 
    CreatedById
    --,ResourceId
)
Values (

    @ResourceIntId, 
    @GroupTypeId, 
    @CreatedById
    --,@ResourceId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Resource.GroupTypeInsert] to public
Go