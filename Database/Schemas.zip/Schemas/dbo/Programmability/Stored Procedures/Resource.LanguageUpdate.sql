USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.LanguageUpdate]    Script Date: 08/29/2012 14:23:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Resource.LanguageUpdate]
	@RowId uniqueidentifier,
	@Language varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [Resource.Language]
    SET Language = @Language
    WHERE RowId = @RowId
END

GO


grant execute on [Resource.LanguageUpdate] to public
go