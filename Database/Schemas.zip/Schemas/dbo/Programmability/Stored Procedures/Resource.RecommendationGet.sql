USE [Isle_IOER]
GO


 
--- Get Single Procedure for [Resource.Recommendation] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.RecommendationGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RecommendationGet]
Go
CREATE PROCEDURE [Resource.RecommendationGet]
    @Id int
As
SELECT     Id, 
    ResourceIntId, 
    TypeId, 
    IsActive, 
    Comment, 
    Created, 
    CreatedById
FROM [Resource.Recommendation]
WHERE Id = @Id
GO
grant execute on [Resource.RecommendationGet] to Public
Go