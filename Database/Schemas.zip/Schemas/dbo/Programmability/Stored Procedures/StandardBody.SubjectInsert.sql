

--- Insert Procedure for [StandardBody.Subject] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[StandardBody.SubjectInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [StandardBody.SubjectInsert]
Go
CREATE PROCEDURE [StandardBody.SubjectInsert]
            @StandardBodyId int, 
            @Title varchar(200), 
            @Description varchar(MAX), 
            @Url varchar(200), 
            @Language varchar(200)
As

If @Title = ''   SET @Title = NULL 
If @Description = ''   SET @Description = NULL 
If @Url = ''   SET @Url = NULL 
If @Language = ''   SET @Language = 'en' 

INSERT INTO [StandardBody.Subject] (

    StandardBodyId, 
    Title, 
    Description, 
    Url, 
    Language
)
Values (

    @StandardBodyId, 
    @Title, 
    @Description, 
    @Url, 
    @Language
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [StandardBody.SubjectInsert] to public
Go
 