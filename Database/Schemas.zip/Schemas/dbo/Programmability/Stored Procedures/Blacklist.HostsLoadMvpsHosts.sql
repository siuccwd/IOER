USE Isle_IOER
GO

CREATE PROCEDURE [Blacklist.HostsLoadMvpsHosts] AS BEGIN
	-- Delete rows from Blacklist where source is 'MVPS Hosts'
	DELETE FROM [Blacklist.Hosts]
	WHERE RecordSource = 'MVPS Hosts'

	DECLARE @Line varchar(500), @HostName varchar(100), @IdInTable int
	DECLARE LineCursor CURSOR FOR
	SELECT Line
	FROM [Blacklist.StagingHosts]
	WHERE Line NOT LIKE '#%'
	OPEN LineCursor
	FETCH NEXT FROM LineCursor INTO @Line

	WHILE @@FETCH_STATUS = 0 BEGIN
		SELECT @HostName = Data
		FROM dbo.SplitString(@Line, ' ')
		WHERE Id = 2

		IF @HostName IS NOT NULL AND @HostName <> '' AND @HostName <> 'localhost' BEGIN
			SET @IdInTable = 0
			SELECT @IdInTable = Id
			FROM [Blacklist.Hosts]
			WHERE Hostname = @Hostname
			Print @IdInTable
			IF @IdInTable IS NULL OR @IdInTable = 0 BEGIN
				INSERT INTO [Blacklist.Hosts] (Hostname, RecordSource)
				VALUES (@HostName, 'MVPS Hosts')
			END
		END

		FETCH NEXT FROM LineCursor INTO @Line
	END
	CLOSE LineCursor
	DEALLOCATE LineCursor
END
GO