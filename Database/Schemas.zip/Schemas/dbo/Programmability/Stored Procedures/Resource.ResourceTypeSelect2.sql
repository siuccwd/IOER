USE [Isle_IOER]
GO

/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeSelect2]    Script Date: 06/03/2013 14:55:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Resource.ResourceTypeSelect2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Resource.ResourceTypeSelect2]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [dbo].[Resource.ResourceTypeSelect2]
	@ResourceIntId int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	

    SELECT RowId, ResourceIntId, ResourceTypeId, OriginalType, Created, CreatedById

    FROM [Resource.ResourceType]
    WHERE 
    (ResourceIntId = @ResourceIntId)

    Order by ResourceIntId
END

GO
grant execute on [Resource.ResourceTypeSelect2] to public
go


