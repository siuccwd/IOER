
 
--- Insert Procedure for [Publish.Pending] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Publish.PendingInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Publish.PendingInsert]
Go

CREATE PROCEDURE [Publish.PendingInsert]
        @ResourceId int, 
        @ResourceVersionId int, 
        @Reason varchar(100), 
        @CreatedById int, 
        @LrEnvelope varchar(MAX)
As
--??
If @ResourceId = 0   SET @ResourceId = NULL 
If @ResourceVersionId = 0   SET @ResourceVersionId = NULL 

If @Reason = ''   SET @Reason = 'Approval Pending' 

INSERT INTO [Publish.Pending] (

    ResourceIntId, 
    ResourceVersionIntId, 
    Reason, 
    IsPublished, 
    Created, 
    CreatedById, 
    LrEnvelope
)
Values (

    @ResourceId, 
    @ResourceVersionId, 
    @Reason, 
    0, 
    getdate(), 
    @CreatedById, 
    @LrEnvelope
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Publish.PendingInsert] to public
Go
 
 