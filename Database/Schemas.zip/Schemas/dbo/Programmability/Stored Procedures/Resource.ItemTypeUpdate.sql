
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.ItemTypeUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ItemTypeUpdate]
Go
--- Update Procedure for [Resource.ItemType] ---
CREATE PROCEDURE [Resource.ItemTypeUpdate]
        @Id int,
        @ItemTypeId int, 
        @LastUpdatedById int

As

If @ItemTypeId = 0   SET @ItemTypeId = NULL 
If @LastUpdatedById = 0   SET @LastUpdatedById = NULL 

UPDATE [Resource.ItemType] 
SET 
    ItemTypeId = @ItemTypeId, 
    LastUpdated = GETDATE(), 
    LastUpdatedById = @LastUpdatedById
WHERE Id = @Id
GO
grant execute on [Resource.ItemTypeUpdate] to public
Go
 
 