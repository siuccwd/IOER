USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.RatingSummaryUpdate]    Script Date: 03/14/2013 08:47:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Update Paradata Rating Summary Record
--
-- 2013-03-14 jgrimmer - Added @ResourceIntId
-- =============================================
ALTER PROCEDURE [dbo].[Resource.RatingSummaryUpdate]
	@ResourceId uniqueidentifier,
	@RatingTypeId int,
	@RatingCount int,
	@RatingTotal int,
	@RatingAverage decimal(5,2),
	@ResourceIntId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [Resource.RatingSummary]
    SET RatingCount = @RatingCount,
		RatingTotal = @RatingTotal,
		RatingAverage = @RatingAverage,
		LastUpdated = GETDATE()
	WHERE (ResourceId = @ResourceId OR ResourceIntId = @ResourceIntId) AND RatingTypeId = @RatingTypeId
END

go
grant execute on [Resource.RatingSummaryUpdate]to public
go

