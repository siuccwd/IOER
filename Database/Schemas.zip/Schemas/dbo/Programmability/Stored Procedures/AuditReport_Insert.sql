USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[AuditReport_Insert]    Script Date: 08/29/2012 14:01:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/2/2012
-- Description:	Create an Audit Report record
-- =============================================
CREATE PROCEDURE [dbo].[AuditReport_Insert]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO AuditReport (Created)
	VALUES (getdate())

	SELECT @@IDENTITY AS ReportId
END

GO


GRANT EXECUTE ON [AuditReport_Insert] TO PUBLIC
GO