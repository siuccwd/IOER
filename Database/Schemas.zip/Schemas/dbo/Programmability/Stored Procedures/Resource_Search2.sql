--WHERE ID BETWEEN @startRowIndex AND (@startRowIndex + @maximumRows) - 1
--ROW_NUMBER()
/*

  SELECT 
  --distinct count(*)
  distinct ROW_NUMBER() As Id, lr.ResourceId, lr.ResourceVersionId, lr.Title  
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN [Resource.Cluster] rcl ON lr.ResourceId = rcl.ResourceId 
        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        --Left JOIN dbo.[Resource.Keyword] lrkey ON lr.ResourceId = lrkey.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevel] edList ON lr.ResourceId = edList.ResourceId  
WHERE ID BETWEEN 100 AND 200
-- =======================================================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @totalRows int, @OutputRelTables bit
--
set @SortOrder = ''
-- OR lr.[Description] like ''%Finance%'' OR lr.[Description] like ''%Manufacturing%'' 
 
-- blind search 
set @Filter = ''
set @Filter = ' where ( lr.id in (select ResourceIntId from [Resource.Language] where LanguageId in (1)) ) AND ( (lr.AccessRightsId in (2,4)) ) AND ( lr.id in (select ResourceIntId from [Resource.Cluster] where ClusterId in (8,11)) )  '

set @filter = ' where  ( lr.id in (select ResourceIntId from [Resource.Language] where LanguageId in (1)) ) '
    
set @OutputRelTables = 1
set @StartPageIndex = 1
set @PageSize = 55

set statistics time on     

EXECUTE @RC = Resource_Search2
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @OutputRelTables  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)

set statistics time off   
    
*/



Alter PROCEDURE [dbo].[Resource_Search2]
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@OutputRelTables bit
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@lastRow int
      ,@minRows int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@TopClause       varchar(100)
      ,@DefaultFilter   varchar(1000)
      ,@OrderBy         varchar(100)
-- =================================

Set @debugLevel = 4
Set @TopClause= ''
--actually the following is implied in the view (and IsPathwayLevel)
Set @DefaultFilter= ' Where (edList.PathwaysEducationLevelId in (3,4,5,6)) ' 
if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by lr.SortTitle '
--===================================================
-- Calculate the range
--===================================================      
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
SET @lastRow =  @StartPageIndex + @PageSize

--
if len(isnull(@Filter,'')) = 0 begin
   Set @TopClause= ' TOP 8000 '
   Set @OutputRelTables = 0 
   end
else if @minRows < 1000   begin 
  set @TopClause= ' TOP 8000 '   
  end   
--
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
--                 Left JOIN dbo.[Resource.Property] lrp ON lr.ResourceId = lrp.ResourceId 
--Left JOIN [Resource.EducationLevelsSummary] edList ON lr.ResourceId = edList.ResourceId 
 
--Left JOIN [Resource.Cluster] rcl ON lr.ResourceId = rcl.ResourceId 
--Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
--Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
--Left JOIN [Resource.EducationLevel] edList ON lr.ResourceId = edList.ResourceId  
--    Left Join [dbo].[Resource.EducationLevelsList] edList on lr.ResourceId = edList.ResourceId
--Left JOIN dbo.[Resource.Subject] rsub ON lr.ResourceIntId = rsub.ResourceIntId 



  set @SQL = '  
SELECT Distinct    
   -- RowNumber,
    lr.ResourceId,
    lr.ResourceIntId,
    lr.ResourceVersionId As RowId,
    lr.ResourceVersionId,
    lr.ResourceUrl,
     CASE
      WHEN lr.Title IS NULL THEN ''No Title''
      WHEN len(lr.Title) = 0 THEN ''No Title''
      ELSE lr.Title
    END AS Title,
    lr.SortTitle,
    [Description],
    isnull(Publisher,''Unknown'') As Publisher,
    rtrim(ltrim(isnull(Creator,''''))) As Creator,
    lr.ViewCount,
    lr.FavoriteCount,
    '''' As Subjects,
    '''' As EducationLevels, 
    '''' As AudienceList, 
    Rights,
    AccessRights
FROM
   (SELECT distinct  TOP 25000 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
        lr.ResourceIntId, lr.Title  
        FROM [dbo].[Resource.Version_Summary] lr
        --Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceIntId = lrs.ResourceIntId  
        ' 
        + @Filter + ' 
   ) as DerivedTableName
       Inner join [dbo].[Resource.Version_Summary] lr on DerivedTableName.ResourceIntId = lr.ResourceIntId

WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' ' 


  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  exec (@SQL)
  --===============================
  
--DECLARE @TempItems TABLE
--(
--   ID int IDENTITY,
--   ResourceIntId int
--)

--INSERT INTO @TempItems (ResourceIntId)
--SELECT distinct lr.ResourceId 
--        FROM [dbo].[Resource.Version_Summary] lr
--        Left JOIN [Resource.Cluster] rcl ON lr.ResourceId = rcl.ResourceId 
--        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
--        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
--        Left JOIN [Resource.EducationLevel] edList ON lr.ResourceId = edList.ResourceId 
--        Where (rcl.ClusterId > 1 )
        
--select @TotalRows= count(*) from @TempItems 

--select @TotalRows


go
        
        
     