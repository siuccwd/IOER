USE LearningRegistryCache_DEV_20121005
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 3/7/2013
-- Description:	Get resource LikeSummary row by ResourceIntId
-- =============================================
CREATE PROCEDURE [Resource.LikeSummaryGet]
	@ResourceIntId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT Id, ResourceId, ResourceIntId, LikeCount, DislikeCount, LastUpdated
	FROM [Resource.LikeSummary]
	WHERE ResourceIntId = @ResourceIntId
END
GO
GRANT EXECUTE ON [Resource.LikeSummaryGet] TO PUBLIC
GO