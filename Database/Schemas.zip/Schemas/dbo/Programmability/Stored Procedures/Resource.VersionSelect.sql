USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionSelect]    Script Date: 11/27/2014 8:53:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.VersionSelect] ' where vers.RowId =  ''3674fb51-ae70-454f-94bb-1929e4629230'' ' 
*/
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/30/2012
-- Description:	Select ResourceVersion rows
--
-- 2012-11-20 jgrimmer - Added SortTitle and Schema
-- 2013-06-20 jgrimmer - Removed reference to Resource.EducationLevelsList
-- 2013-08-29 jgrimmer - Added IsActive
-- 2014-02-25 jgrimmer - Added [Resource.Version].Id
-- 2014-11-27 mparsons - changed filter 1000
-- =============================================
ALTER PROCEDURE [dbo].[Resource.VersionSelect]
	@Filter varchar(1000)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @sql varchar(max)
	SET @sql = 'SELECT vers.RowId, vers.Id, 
	'''' AS ResourceId, base.Id As ResourceIntId,
	base.ResourceUrl,
	base.ViewCount,
	base.FavoriteCount,
	vers.IsActive,
	vers.InteractivityTypeId,
	vers.InteractivityType,
	vers.Requirements,
	vers.DocId,
	vers.Title,
	vers.[Description],
	isnull(vers.Publisher,''Unknown'') AS Publisher,
	isnull(vers.Creator,''Unknown'') AS Creator,
	isnull(vers.Rights,''Unknown'') AS Rights,
  AccessRightsId,
  isnull(codes.title, ''Unknown'') As AccessRights,
	vers.Modified,
	vers.Submitter,
	isnull(vers.Imported, vers.Modified) AS Imported,
	vers.Created,
	isnull(vers.TypicalLearningTime,''Unknown'') AS TypicalLearningTime,
	vers.IsSkeletonFromParadata,
	vers.SortTitle,
	vers.[Schema],
	isnull(rsub.subjects,'''') AS Subjects,
	'''' AS EducationLevels,
	''TBD'' AS Keywords,
	isnull(langList.LanguageList,'''') AS LanguageList,
	isnull(typesList.ResourceTypesList,'''') AS ResourceTypesList
FROM [Resource] base
INNER JOIN [Resource.Version] vers on base.Id = vers.ResourceIntId
Left Join dbo.[Codes.AccessRights] codes on vers.AccessRightsId = codes.Id
LEFT JOIN [dbo].[Resource.SubjectsCsvList] rsub on base.Id = rsub.ResourceIntId
LEFT JOIN [dbo].[Resource.LanguagesList] langList on base.Id = langList.ResourceIntId
LEFT JOIN [dbo].[Resource.ResourceTypesList] typesList ON base.Id = typesList.ResourceIntId
 ' + @Filter
 
	EXEC(@sql)
END

