USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeUpdate]    Script Date: 08/30/2012 08:53:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Update [Resource.ResourceType] Row
-- =============================================
Alter PROCEDURE [dbo].[Resource.ResourceTypeUpdate]
	@RowId uniqueidentifier,
	@CodeId int,
	@MappedValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- If no CodeId is passed in, look it up
	IF @CodeId = 0 BEGIN
		SELECT @CodeId = id
		FROM [Codes.ResourceType]
		WHERE Title = @MappedValue
	END
  --TODO - need error checking!!!!!!!!!!!!!!!!!
	UPDATE [Resource.ResourceType]
	SET ResourceTypeId = @CodeId
	WHERE RowId = @RowId
END

GO


grant execute on [Resource.ResourceTypeUpdate] to public
go