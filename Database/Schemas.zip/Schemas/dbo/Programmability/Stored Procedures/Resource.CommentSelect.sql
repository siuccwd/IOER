
--- Get Procedure for [Resource.Comment] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.CommentSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.CommentSelect]
Go
CREATE PROCEDURE [Resource.CommentSelect]
  @ResourceIntId int
As
--@ResourceId varchar(40)
SELECT 
    Id, 
    --ResourceId, 
    ResourceIntId, 
    Comment, IsActive,
    Created, 
    CreatedById,
    CreatedBy,
    Commenter
FROM [Resource.Comment]
where ResourceIntId = @ResourceIntId 
Order by created desc

GO
grant execute on [Resource.CommentSelect] to public 
Go
 
 