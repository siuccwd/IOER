USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.FormatGet]    Script Date: 08/29/2012 14:13:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Resource.FormatGet]
	@RowId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT RowId, ResourceId, OriginalValue, CodeId
	FROM [Resource.Format]
	WHERE RowId = @RowId
END

GO


grant execute on [Resource.FormatGet] to public
go