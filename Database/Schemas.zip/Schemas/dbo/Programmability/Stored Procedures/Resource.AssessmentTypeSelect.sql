USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.AssessmentTypeSelect]    Script Date: 03/19/2013 18:04:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [dbo].[Resource.AssessmentTypeSelect]
  @ResourceIntId int
As
SELECT 
    base.Id, 
    ResourceIntId, 
    AssessmentTypeId, codes.Title As AssessmentType,  
    base.Created, 
    base.CreatedById 
    
FROM [Resource.AssessmentType] base
inner join [Codes.AssessmentType] codes on base.AssessmentTypeId = codes.Id
where ResourceIntId= @ResourceIntId
order by codes.Title


GO


