USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.GradeLevel_Import]    Script Date: 01/09/2013 16:16:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Notes:
- may need to use a passed schema to help with mapping

*/
CREATE PROCEDURE [dbo].[Resource.AssessmentType_Import]
            @ResourceIntId	int,
            @OriginalValue  varchar(500)
            ,@TotalRows     int OUTPUT

As
begin 
declare 
  @GradeLevelId int
  , @SuppressOutput bit
  , @RecordCount int
  
  set @SuppressOutput  = 0
  If @TotalRows = -1		SET @SuppressOutput = 1
  
  set @TotalRows = 0
  set @GradeLevelId = 0
  
If @OriginalValue = '' begin
  print 'no value provided'
  return -1
  end              
-- ======================================================
-- If it exists as a keyword, blow it away because we're putting it in as an Assessment Type
DECLARE @KeywordId int
SELECT @KeywordId = Id
FROM [Resource.Keyword]
WHERE ResourceIntId = @ResourceIntId AND Keyword = @OriginalValue
IF @KeywordId IS NOT NULL AND @KeywordId <> 0 BEGIN
	DELETE FROM [Resource.Keyword]
	WHERE Id = @KeywordId
END
-- ======================================================
 -- now check if mapping exists
select @RecordCount = isnull(Count(*),0)
  FROM [Map.AssessmentType] map 
  inner join [dbo].[Codes.AssessmentType] codes on map.CodeId = codes.Id
  --inner join [dbo].[Codes.GradeLevel] codes on map.MappedValue = codes.[Title]
 where map.LRValue  = @OriginalValue
 
If @RecordCount is null OR @RecordCount = 0	begin 
  --no mapping, write to exceptions table and return
  if NOT exists(SELECT [ResourceIntId] FROM [dbo].[Audit.GradeLevel_Orphan] 
    where [ResourceIntId]= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
    print 'no mapping, writing to exceptions table: ' + @OriginalValue
    INSERT INTO [dbo].[Audit.AssessmentType_Orphan]
             ([ResourceIntId]
             ,[OriginalValue])
       VALUES
             (@ResourceIntId
             ,@OriginalValue)
    end
  return -1
  end
-- ======================================================
--mapping exists, need to handle already in target table 
--print 'doing insert'
  INSERT INTO [Resource.AssessmentType]
  (
	  ResourceIntId, 
	  AssessmentTypeId
  )
  
select @ResourceIntId, isnull(codes.id,0)
  FROM [Map.AssessmentType] map 
  inner join [dbo].[Codes.AssessmentType] codes on map.CodeId = codes.Id
  left join [dbo].[Resource.AssessmentType] red on @ResourceIntId = red.ResourceIntId and red.[AssessmentTypeId] = codes.id
    
 where map.LRValue  = @OriginalValue
 and red.Id is null

set @TotalRows = @@rowcount

end




GO
GRANT EXECUTE ON [dbo].[Resource.AssessmentType_Import] TO [public] AS [dbo]