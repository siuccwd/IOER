USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.SubjectSelect]    Script Date: 03/05/2013 10:15:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.SubjectSelect] 444671
*/
Create PROCEDURE [dbo].[Resource.SubjectSelect]
    @ResourceIntId int
As

SELECT [Id]
      ,[ResourceIntId]
      ,[Subject]
      ,[Created]
      ,[CreatedById]
  FROM [dbo].[Resource.Subject]
 WHERE ResourceIntId = @ResourceIntId
 Order by [Subject]


