USE [Isle_IOER]
GO

/****** Object:  StoredProcedure [dbo].[ResourceVersion_SetActiveState]    Script Date: 06/26/2013 11:56:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ResourceVersion_SetActiveState]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ResourceVersion_SetActiveState]
GO

USE [Isle_IOER]
GO

/****** Object:  StoredProcedure [dbo].[ResourceVersion_SetActiveState]    Script Date: 06/26/2013 11:56:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Create date: 6/5/2012
-- Description:	Update Resource
-- 
-- =============================================
Create PROCEDURE [dbo].[ResourceVersion_SetActiveState]
	@Id int, 
	@IsActive bit

AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	UPDATE [Resource.Version]
	SET IsActive = @IsActive
	WHERE Id = @Id
END

GO


