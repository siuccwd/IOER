USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].[ResourceSelect]    Script Date: 07/17/2012 15:28:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 6/5/2012
-- Description:	Select resources
-- 2012-07-02 jgrimmer Added SubmitterRowId and Created fields
-- 2012-08-30 jgrimmer Dropped fields moved to [Resource.Version] table.
-- 2013-01-02 jgrimmer - Added HasPathwayGradeLevel, Created, LastUpdated
-- =============================================
ALTER PROCEDURE [dbo].[ResourceSelect]
	@filter varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @sql varchar(max)
	SET @sql = 'SELECT RowId, ResourceUrl, ViewCount, FavoriteCount, HasPathwayGradeLevel, Created, LastUpdated
FROM [Resource]
' + @filter

	PRINT @sql
	EXEC(@sql)
END

GO


