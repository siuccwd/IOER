USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[RatingTypeInsert]    Script Date: 08/29/2012 14:07:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Create RatingType record
-- =============================================
CREATE PROCEDURE [dbo].[RatingTypeInsert]
	@Type varchar(50),
	@Identifier varchar(500),
	@Description varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO RatingType ([Type], Identifier, [Description], Created)
	VALUES (@Type, @Identifier, @Description, GETDATE())
	
	SELECT @@IDENTITY AS Id
END

GO


grant execute on RatingTypeInsert to public
go