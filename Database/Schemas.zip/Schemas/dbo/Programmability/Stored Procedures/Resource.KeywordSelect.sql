USE [LearningRegistryCache_DEV_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.KeywordSelect]    Script Date: 08/29/2012 14:20:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[Resource.KeywordSelect]
	@ResourceIntId int,
	@OriginalValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @ResourceIntId = 0   SET @ResourceIntId = NULL
	IF @OriginalValue = ''  SET @OriginalValue = NULL
	
	SELECT Id, ResourceIntId, Keyword, CreatedById, Created
	FROM [Resource.Keyword]
	WHERE (ResourceIntId = @ResourceIntId OR @ResourceIntId IS NULL) AND
		(Keyword = @OriginalValue OR @OriginalValue IS NULL)
END

GO


grant execute on [Resource.KeywordSelect] to public
go