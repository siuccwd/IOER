USE [Isle_IOER]
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.RecommendationUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RecommendationUpdate]
Go
--- Update Procedure for [Resource.Recommendation] ---
CREATE PROCEDURE [Resource.RecommendationUpdate]
        @Id int, 
        @IsActive bit, 
        @Comment varchar(MAX)

As

If @Comment = ''   SET @Comment = NULL 


UPDATE [Resource.Recommendation] 
SET 
    IsActive = @IsActive, 
    Comment = @Comment
WHERE Id = @Id
GO
grant execute on [Resource.RecommendationUpdate] to public
Go
 
 