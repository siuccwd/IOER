 
 
--- Delete Procedure for [Resource.Standard] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.StandardDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.StandardDelete]
GO
CREATE PROCEDURE [Resource.StandardDelete]
        @Id int
As
DELETE FROM [Resource.Standard]
WHERE Id = @Id
GO
grant execute on [Resource.StandardDelete]  to public
Go
