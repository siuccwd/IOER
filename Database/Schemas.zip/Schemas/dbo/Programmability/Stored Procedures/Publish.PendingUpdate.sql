
 
if exists (select * from dbo.sysobjects where id = object_id(N'[Publish.PendingUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Publish.PendingUpdate]
Go

/*
--- Update Procedure for [Publish.Pending] ---
- if only reason for update is to publish, then just call DoPublish or something??
=> would be called after the publish, and provide the DocId
*/
CREATE PROCEDURE [Publish.PendingUpdate]
        @Id int,
        @DocId varchar(500), 
        @IsPublished bit, 
        @PublishedDate datetime

As

If @DocId = ''   SET @DocId = NULL 
If @PublishedDate < '2000-01-01'   SET @PublishedDate = NULL 

UPDATE [Publish.Pending] 
SET 
    DocId = @DocId, 
    --Reason = @Reason, 
    IsPublished = @IsPublished, 
    PublishedDate = @PublishedDate
WHERE Id = @Id
GO
grant execute on [Publish.PendingUpdate] to public
Go
 