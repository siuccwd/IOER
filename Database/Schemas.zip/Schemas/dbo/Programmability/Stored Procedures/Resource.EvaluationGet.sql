USE [LearningRegistryCache_DEV_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.EvaluationGet]    Script Date: 05/09/2013 14:53:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Resource.EvaluationGet]
    @Id int
As
SELECT     Id, 
    ResourceIntId, 
    Created, 
    CreatedById, 
    StandardId, 
    RubricId, 
    Value, 
    ScaleMin, 
    ScaleMax, 
    CriteriaInfo
FROM [Resource.Evaluation]
WHERE Id = @Id

GO


