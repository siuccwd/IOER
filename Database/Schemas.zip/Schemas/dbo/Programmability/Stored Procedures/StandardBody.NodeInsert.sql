
--- Insert Procedure for [StandardBody.Node] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[StandardBody.NodeInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [StandardBody.NodeInsert]
Go
CREATE PROCEDURE [StandardBody.NodeInsert]
            @ParentId int, 
            @LevelType varchar(50), 
            @NotationCode varchar(50), 
            @Description varchar(MAX), 
            @StandardUrl varchar(200), 
            @AltUrl varchar(200), 
            @StandardGuid varchar(50)
As
If @ParentId = 0   SET @ParentId = NULL 
If @LevelType = ''   SET @LevelType = NULL 
If @NotationCode = ''   SET @NotationCode = NULL 
If @Description = ''   SET @Description = NULL 
If @StandardUrl = ''   SET @StandardUrl = NULL 
If @AltUrl = ''   SET @AltUrl = NULL 
If @StandardGuid = ''   SET @StandardGuid = NULL 

INSERT INTO [StandardBody.Node] (

    ParentId, 
    LevelType, 
    NotationCode, 
    Description, 
    StandardUrl, 
    AltUrl, 
    StandardGuid
)
Values (

    @ParentId, 
    @LevelType, 
    @NotationCode, 
    @Description, 
    @StandardUrl, 
    @AltUrl, 
    @StandardGuid
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [StandardBody.NodeInsert] to public
Go