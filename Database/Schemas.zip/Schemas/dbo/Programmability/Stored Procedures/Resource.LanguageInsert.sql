USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.LanguageInsert]    Script Date: 2/17/2014 5:17:16 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =============================================
Description:      [Resource.LanguageInsert]
------------------------------------------------------
Modifications
  2013-08-22 mparsons - dropped resourceId (left parm for now)
  2013-08-27 mparsons - removed resourceId parm
=============================================
*/
ALTER PROCEDURE [dbo].[Resource.LanguageInsert]
	@LanguageId			int,
	@ResourceIntId		int,
	@CreatedById		int,
	@OriginalLanguage	varchar(100)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if @OriginalLanguage = '' set @OriginalLanguage= NULL
	if @CreatedById = 0 set @CreatedById= NULL


    DECLARE @RowId uniqueidentifier
    SET @RowId = NEWID()
    
    INSERT INTO [Resource.Language] (RowId, LanguageId, ResourceIntId, OriginalLanguage, CreatedById)
    VALUES (@RowId, @LanguageId, @ResourceIntId, @OriginalLanguage, @CreatedById)
    
    SELECT @RowId AS RowId
END
GO


grant execute on [Resource.LanguageInsert] to public
go
