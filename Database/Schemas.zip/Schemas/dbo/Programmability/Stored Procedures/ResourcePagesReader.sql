USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].ResourcePagesSelect    Script Date: 05/23/2013 16:34:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--WHERE ID BETWEEN @startRowIndex AND (@startRowIndex + @maximumRows) - 1
--ROW_NUMBER()
/*


-- =======================================================================================

DECLARE @Filter varchar(5000), @@StartingId int, @DatasetSize int
--
-- blind search 
set @Filter = ''
    

set @@StartingId = 713
set @@StartingId = 790
set @DatasetSize = 55

set statistics time on     

EXECUTE dbo.ResourcePagesReader     @Filter, @@StartingId  ,@DatasetSize

set statistics time off   
    
*/



Alter PROCEDURE [dbo].ResourcePagesReader
		@Filter           varchar(5000)
		,@StartingId  int
		,@DatasetSize        int

As

SET NOCOUNT ON;
-- paging
DECLARE
      @debugLevel      int
      ,@SQL             varchar(5000)

-- =================================

Set @debugLevel = 4


--
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
--                

SET ROWCOUNT @DatasetSize
SELECT [ResourceVersionId]
      ,[ResourceIntId]
      ,[DocId]
      ,[Title]
      ,[Description]
      ,[Publisher]
      ,[Created]
      ,[AccessRights]
      ,[Keywords]
      ,[Subjects]
      ,[LanguageIds]
      ,[Languages]
      ,[ClusterIds]
      ,[Clusters]
      ,[AudienceIds]
      ,[Audiences]
      ,[EducationLevelIds]
      ,[EducationLevels]
      ,[ResourceTypeIds]
      ,[ResourceTypes]
      ,[ResourceFormatIds]
      ,[ResourceFormats]
      ,[GroupTypeIds]
      ,[GroupTypes]
      ,[ItemTypeIds]
      ,[ItemTypes]
      ,[StandardIds]
      ,[Standards]
      ,[AssessmentTypeId]
      ,[EducationUseId]
      ,[OriginalType]
      ,[ResourceURL]
FROM [dbo].[Resource.SearchableIndexView2] lr
where ResourceIntId > @StartingId
order by ResourceIntId


  --===============================
  



GO


