﻿USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[Resource.LanguageSelect]    Script Date: 7/19/2013 2:37:27 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/* =============================================
Description:      [Resource.LanguageSelect]
------------------------------------------------------
Modifications
  2013-08-22 mparsons - dropped resourceId
=============================================
*/
CREATE PROCEDURE [dbo].[Resource.LanguageSelect2]
  @ResourceIntId int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  IF @ResourceIntId = 0   SET @ResourceIntId = NULL
  If  @ResourceIntId = NULL begin
    RAISERROR('Error - require resourceIntId', 18, 1) 
    return -1
    end
    
  SELECT RowId, ResourceIntId, OriginalLanguage, LanguageId
 
  FROM [Resource.Language]
  WHERE 
      (ResourceIntId = @ResourceIntId)
END
GO
grant execute on [Resource.LanguageSelect2] to public
go

