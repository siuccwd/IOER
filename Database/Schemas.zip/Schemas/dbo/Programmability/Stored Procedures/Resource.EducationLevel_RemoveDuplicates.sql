USE LearningRegistryCache_Dev_20121005
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_RemoveDuplicates]    Script Date: 09/08/2012 16:51:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
select count(*) from [Resource]
go
select count(*) from [Resource.EducationLevel]
go
select * from [Resource.EducationLevel]
where convert(varchar(36),resourceId) = '2B31483C-A433-47F0-82B2-5999877C5A97'
or  convert(varchar(36),resourceId) = 'B9983709-FD70-41E7-8365-72A538269B96'
ORDER BY ResourceId, PathwaysEducationLevelId


UPDATE [dbo].[Resource.EducationLevel]
   SET [PathwaysEducationLevelId] = 6
   
--  select count(*) from [dbo].[Resource.EducationLevel]
 WHERE PathwaysEducationLevelId= 7 AND [OriginalLevel] = 'Informal Education'
GO


EXECUTE [dbo].[Resource.EducationLevel_RemoveDuplicates] 0, 500
go
EXECUTE [dbo].[Resource.EducationLevel_RemoveDuplicates] 0, 500

*/

Alter PROCEDURE [dbo].[Resource.EducationLevel_RemoveDuplicates]
            @MaxRecords int
            ,@interval int

As
begin 
          
Declare 
@ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@PathwaysEducationLevelId int
,@PrevResourceId uniqueidentifier
,@PrevEducationLevelId int
,@cntr int
,@dupsCntr int
--,@interval int
,@totalRows int
,@debugLevel int

--set @interval= 25
set @cntr= 0
set @dupsCntr = 0
set @PrevEducationLevelId = 0
set @PrevResourceId= NULL
set @debugLevel= 10

select 'started',  getdate(), 'remember hard coding top 25000!!!'
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT distinct    TOP 25000 base.RowId, base.ResourceId, base.PathwaysEducationLevelId
        FROM          [Resource.EducationLevel] AS base 
        INNER JOIN
          (SELECT     ResourceId, PathwaysEducationLevelId, COUNT(*) AS DupCount
          FROM          [Resource.EducationLevel]
          GROUP BY ResourceId, PathwaysEducationLevelId
          HAVING      (COUNT(*) > 1)) AS dupEds ON base.ResourceId = dupEds.ResourceId
      ORDER BY base.ResourceId, base.PathwaysEducationLevelId
 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @PathwaysEducationLevelId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
		  
 --   if @cntr < 50 print '-- ' + convert(varchar(50),@ResourceId) + ' / ' + @OriginalValue 
    if @ResourceId = @PrevResourceId AND @PathwaysEducationLevelId = @PrevEducationLevelId begin
      --delete dup
      set @dupsCntr = @dupsCntr + 1
      if ((@dupsCntr / @interval) * @interval) = @dupsCntr 
        print '@@ deleting dup @ResourceId/@PathwaysEducationLevelId ' + convert(varchar(50), @ResourceId )+ ' - ' + convert(varchar, @PathwaysEducationLevelId) + '  #' + convert(varchar, @dupsCntr)
        
      DELETE FROM [dbo].[Resource.EducationLevel]
      WHERE RowId= @RowId
      end
      
    set @PrevResourceId=@ResourceId
    Set @PrevEducationLevelId = @PathwaysEducationLevelId 
	 
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @PathwaysEducationLevelId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  select 'Duplicated deleted count: ' + convert(varchar, @dupsCntr)
  
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevel_RemoveDuplicates] TO [public] AS [dbo]

go