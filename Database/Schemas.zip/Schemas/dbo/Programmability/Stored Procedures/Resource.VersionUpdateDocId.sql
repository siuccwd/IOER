USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionUpdate]    Script Date: 12/21/2012 15:45:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Create date: 05/24/2013
-- Description:	Update the docId for Resource Version
-- =============================================
Create PROCEDURE [dbo].[Resource.VersionUpdateDocId]
	@Id int,
	@DocId varchar(50)
AS
BEGIN
	SET NOCOUNT ON;

		
	UPDATE [Resource.Version]
	SET 
		DocId = @DocId
		
	WHERE Id = @Id
END
go
grant execute on [Resource.VersionUpdateDocId] to public
go

