USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[ResourceUpdate]    Script Date: 10/05/2012 10:58:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Create date: 6/5/2012
-- Description:	Update Resource
-- 
-- =============================================
Alter PROCEDURE [dbo].Resource_SetActiveState
	@ResourceId int, 
	@IsActive bit

AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	UPDATE [Resource]
	SET IsActive = @IsActive,
		LastUpdated = GETDATE()
	WHERE Id = @ResourceId
END
go 
grant execute on Resource_SetActiveState to public
go
