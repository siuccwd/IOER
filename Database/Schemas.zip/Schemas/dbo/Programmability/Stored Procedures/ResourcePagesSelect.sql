USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].ResourcePagesSelect    Script Date: 05/23/2013 16:34:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--WHERE ID BETWEEN @startRowIndex AND (@startRowIndex + @maximumRows) - 1
--ROW_NUMBER()
/*


-- =======================================================================================

DECLARE @Filter varchar(5000), @StartPageIndex int, @PageSize int
--
-- blind search 
set @Filter = ''
    

set @StartPageIndex = 10
set @PageSize = 55

set statistics time on     

EXECUTE dbo.ResourcePagesSelect     @Filter, @StartPageIndex  ,@PageSize

set statistics time off   
    
*/



Alter PROCEDURE [dbo].ResourcePagesSelect
		@Filter           varchar(5000)
		,@StartPageIndex  int
		,@PageSize        int

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@lastRow int
      ,@minRows int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@OrderBy         varchar(100)
-- =================================

Set @debugLevel = 4
set @OrderBy = ' Order by ResourceIntId '

--===================================================
-- Calculate the range
--===================================================      
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
SET @lastRow =  @StartPageIndex + @PageSize

--
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
--                

  set @SQL = '  
SELECT [ResourceVersionId]
      ,DerivedTableName.[ResourceIntId]
      ,[DocId]
      ,DerivedTableName.[Title]
      ,[Description]
      ,[Publisher]
      ,[Created]
      ,[AccessRights]
      ,[Keywords]
      ,[Subjects]
      ,[LanguageIds]
      ,[Languages]
      ,[ClusterIds]
      ,[Clusters]
      ,[AudienceIds]
      ,[Audiences]
      ,[EducationLevelIds]
      ,[EducationLevels]
      ,[ResourceTypeIds]
      ,[ResourceTypes]
      ,[ResourceFormatIds]
      ,[ResourceFormats]
      ,[GroupTypeIds]
      ,[GroupTypes]
      ,[ItemTypeIds]
      ,[ItemTypes]
      ,[StandardIds]
      ,[Standards]
      ,[AssessmentTypeId]
      ,[EducationUseId]
      ,[OriginalType]
      ,[ResourceURL]
FROM
   (SELECT distinct  
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
        lr.ResourceIntId, lr.Title  
        FROM [dbo].[Resource.SearchableIndexView2] lr
        where ResourceIntId > 0
   ) as DerivedTableName
       Inner join [dbo].[Resource.SearchableIndexView2] lr on DerivedTableName.ResourceIntId = lr.ResourceIntId

WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' ' 


  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  exec (@SQL)
  --===============================
  



GO


