USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[StandardBody.SubjectStandardConnectorInsert]    Script Date: 01/10/2013 13:14:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 --[Standard.SubjectStandardConnectorInsert]
Create PROCEDURE [dbo].[StandardBody.SubjectStandardConnectorInsert]
            @StandardSubjectId int, 
            @DomainNodeId int
As

If @StandardSubjectId = 0   SET @StandardSubjectId = NULL 
If @DomainNodeId = 0        SET @DomainNodeId = NULL 


INSERT INTO [Standard.SubjectStandardConnector] (
  StandardSubjectId, 
  DomainNodeId 
)
Values (
  @StandardSubjectId, 
  @DomainNodeId 
)

GO
GRANT EXECUTE ON [dbo].[StandardBody.SubjectStandardConnectorInsert] TO [public] AS [dbo]