USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.AgeRangeImport]    Script Date: 11/13/2013 8:38:24 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 5/8/2013
-- Description:	Imports Age Range
--
-- 2013-11-13 jgrimmer - If the top end of the age range indicates Adult Ed., and a lower age range exists
--						 and ends before High School (age 14), throw out the Adult Ed. range and keep the
--						 lower age range.
-- =============================================
ALTER PROCEDURE [dbo].[Resource.AgeRangeImport]
	@ResourceIntId int,
	@iFromAge int,
	@iToAge int,
	@iOriginalValue varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @id int, @FromAge int, @ToAge int, @OriginalValue varchar(50), @AgeRange int, @swapAge int
	IF @iFromAge > @iToAge BEGIN
		-- Swap From and To ages
		SET @swapAge = @iFromAge
		SET @iFromAge = @iToAge
		SET @iToAge = @swapAge
	END
	
	SELECT @id = Id, @FromAge = FromAge, @ToAge = ToAge, @OriginalValue = OriginalLevel
	FROM [Resource.AgeRange]
	WHERE ResourceIntId = @ResourceIntId
	
	IF @id IS NULL BEGIN
		-- Row does not exist
		SET @AgeRange = ABS(@iToAge - @iFromAge) + 1
		INSERT INTO [Resource.AgeRange] (ResourceIntId, FromAge, ToAge, AgeSpan, OriginalLevel, Created, CreatedById)
		VALUES (@ResourceIntId, @iFromAge, @iToAge, @AgeRange, @iOriginalValue, GETDATE(), NULL)
	END ELSE BEGIN
		-- If already flagged as Adult Ed and a lower end of age range < high school, toss adult ed.
		IF @ToAge >= 21 AND (@iFromAge < 14 OR @FromAge < 14) BEGIN
			IF @iFromAge < @FromAge SET @FromAge = @iFromAge
			IF @iToAge < @ToAge SET @ToAge = @iToAge
		END ELSE IF @ToAge >= 21 AND (@iFromAge >= 14) BEGIN
			IF @iFromAge < @FromAge SET @FromAge = @iFromAge
			IF @iToAge > @ToAge SET @ToAge = @iToAge
		END

		-- Update row if not adult ed, or adult ed but also includes high school
		IF @iToAge < 21 OR (@iToAge >= 21 AND @ToAge > 13) BEGIN
			-- Update existing row
			IF @iFromAge < @FromAge SET @FromAge = @iFromAge
			IF @iToAge > @ToAge SET @ToAge = @iToAge
			SET @AgeRange = ABS(@iToAge - @iFromAge) + 1
			UPDATE [Resource.AgeRange]
			SET FromAge = @FromAge,
				ToAge = @ToAge,
				AgeSpan = @AgeRange,
				Created = GETDATE(),
				CreatedById = NULL
			WHERE Id = @id
		END
	END
END
