USE [LearningRegistryCache_Dev_20121005]
GO

--- Get Procedure for Resource.Cluster---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.ClusterSelect_SelectedCodes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ClusterSelect_SelectedCodes]
Go

/*
[Resource.ClusterSelect_SelectedCodes] 'B0BDDDF1-75DA-4D6D-8555-0027D1ACCC4A'
*/
CREATE PROCEDURE [Resource.ClusterSelect_SelectedCodes]
    @ResourceId uniqueidentifier
As
SELECT 
	base.Id, base.IlPathwayName As Title, base.[Description]
--    ,ResourceId
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as HasCluster	
FROM [dbo].CareerCluster base
Left Join [Resource.Cluster] rpw on base.Id = rpw.ClusterId
		and rpw.ResourceId = @ResourceId
where IsIlPathway = 1
And base.IsActive = 1

Order by base.IlPathwayName
GO
grant execute on [Resource.ClusterSelect_SelectedCodes] to public 
Go