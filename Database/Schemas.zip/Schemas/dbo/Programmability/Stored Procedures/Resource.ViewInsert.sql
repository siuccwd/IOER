SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 6/5/2013
-- Description:	Insert a Resource.View row
-- =============================================
CREATE PROCEDURE [Resource.ViewInsert]
	@ResourceIntId int,
	@CreatedById int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @ReturnValue int
	INSERT INTO [Resource.View] (ResourceIntId, Created, CreatedById)
	VALUES (@ResourceIntId, GETDATE(), @CreatedById)
	
	SET @ReturnValue = @@IDENTITY
	
	UPDATE [Resource]
	SET ViewCount = ViewCount + 1
	WHERE Id = @ResourceIntId
	
	SELECT @ReturnValue AS Id	
END
GO

GRANT EXECUTE ON [Resource.ViewInsert] TO PUBLIC
GO