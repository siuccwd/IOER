USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.AssessmentTypeInsert]    Script Date: 03/19/2013 18:03:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [dbo].[Resource.AssessmentTypeInsert]
            @ResourceIntId int, 
            @AssessmentTypeId int,  
            @CreatedById int
            --,@ResourceId uniqueidentifier
As

If @CreatedById = 0   SET @CreatedById = NULL 
--If @ResourceId = ''   SET @ResourceId = NULL 
INSERT INTO [Resource.AssessmentType] (

    ResourceIntId, 
    AssessmentTypeId, 
    CreatedById
    --,ResourceId
)
Values (

    @ResourceIntId, 
    @AssessmentTypeId, 
    @CreatedById
    --,@ResourceId
)
 
select SCOPE_IDENTITY() as Id

GO


