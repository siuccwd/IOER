USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.GradeLevel_Insert]    Script Date: 01/23/2013 13:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@GradeLevelId int
DECLARE @OriginalValue varchar(500)

set @ResourceId = '987b71d5-9ba8-4703-b885-a80564ed30f1'
set @GradeLevelId = 6
set @OriginalValue = ''

EXECUTE @RC = [dbo].[Resource.GradeLevel_Insert] 
   @ResourceId
  ,@GradeLevelId
  ,@OriginalValue



*/
/*
-- =============================================
-- Create date: 3/12/2013
-- Description:	Insert row into [Resource.GradeLevel] table
-- =============================================
modifications
12-11-05 mparsons - need to remove unknown grade level when inserting actual gl
*/
Create PROCEDURE [dbo].[Resource.GradeLevel_Insert]
            @ResourceIntId  int,
            @GradeLevelId   int,
            @CreatedById   int
           

As
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  If @ResourceIntId = 0   SET @ResourceIntId = NULL 
  If @GradeLevelId = 0   SET @GradeLevelId = NULL 

  If @ResourceIntId is NULL OR @GradeLevelId is null begin
    print 'no values provided'
    return -1
    end    
  
  declare @RecordCount int
  
    --should ensure doesn't already exist
    select @RecordCount = isnull(Count(*),0)
    FROM [dbo].[Resource.GradeLevel] rel 
    where rel.ResourceIntId  = @ResourceIntId AND rel.GradeLevelId = @GradeLevelId 	
    If @RecordCount is null OR @RecordCount = 0	begin	
      INSERT INTO [Resource.GradeLevel]
      (
	      ResourceIntId, 
	      GradeLevelId,
	      CreatedById
      )
	    Values (
		    @ResourceIntId, 
		    @GradeLevelId, 
		    @CreatedById
	    )
	    SELECT SCOPE_IDENTITY() AS Id

	      
	    end
    else begin
    	print 'Duplicate GradeLevelId'
      SELECT 0 AS Id
      end
    
End

GO
GRANT EXECUTE ON [dbo].[Resource.GradeLevel_Insert] TO [public] 

go