USE LearningRegistryCache_DEV_20121005
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 3/7/2013
-- Description:	Insert resource LikeSummary row
-- =============================================
CREATE PROCEDURE [Resource.LikeSummaryInsert]
	@ResourceId uniqueidentifier, @ResourceIntId int, @LikeCount int, @DislikeCount int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [Resource.LikeSummary] (ResourceId, ResourceIntId, LikeCount, DislikeCount, LastUpdated)
	VALUES (@ResourceId, @ResourceIntId, @LikeCount, @DislikeCount, GETDATE())
	
	SELECT @@IDENTITY AS Id
END
GO
GRANT EXECUTE ON [Resource.LikeSummaryInsert] TO PUBLIC
GO