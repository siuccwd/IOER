USE [Isle_IOER]
GO

/****** Object:  StoredProcedure [dbo].[Resource.Language_Import]    Script Date: 07/02/2012 09:34:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier, @LanguageId int, @OriginalValue varchar(100),@TotalRows     int

set @LanguageId= 0
set @ResourceIntId = 8
set @OriginalValue = 'en'


EXECUTE @RC = [dbo].[Resource.Language_Import] 
   '', @LanguageId  ,@OriginalValue, @totalRows OUTPUT, @ResourceIntId

GO


*/
/* =============================================
Description:      [Resource.Language_Import]
------------------------------------------------------
Modifications
  2012-11-15 jgrimmer - Added keyword checking.  If exists as keyword, delete keyword.
  2013-03-13 jgrimmer - Added @ResourceIntId
  2013-04-19 jgrimmer - Modified keyword check to use ResourceIntId
  2013-08-22 mparsons - dropped resourceId
=============================================

*/
ALTER PROCEDURE [dbo].[Resource.Language_Import]
          @ResourceId     varchar(50), 
          @LanguageId	    int,
          @OriginalValue  varchar(100)
          ,@TotalRows     int OUTPUT
          ,@ResourceIntId int

As
declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @KeywordId int

if @OriginalValue = '' set @OriginalValue = NULL
If @LanguageId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @LanguageId < 1		SET @LanguageId = NULL 
  
If @OriginalValue is NULL and @LanguageId is null begin
  print 'no values provided'
  return -1
  end    


set @IsDuplicate= 0
set @TotalRows= 0
-- ==================================================================
-- Do keyword check.  If keyword found, delete keyword.
SELECT @KeywordId = Id
FROM [Resource.Keyword]
WHERE ResourceIntId = @ResourceIntId AND Keyword = @OriginalValue
IF @KeywordId IS NOT NULL AND @KeywordId <> 0 BEGIN
	DELETE FROM [Resource.Keyword]
	WHERE Id = @KeywordId
END

-- ==================================================================

if @LanguageId is null begin
	print 'insert via Language'
	 -- so first check if mapping exists
	SELECT @LanguageId = isnull(base.id,0)
	  FROM [dbo].[Codes.Language] base
	  inner join [dbo].[Map.Language] mapper on base.Id = mapper.[LanguageId]
	  where mapper.LRValue = @OriginalValue
   
	If @LanguageId is null OR @LanguageId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT OriginalValue FROM [dbo].[Audit.Language_Orphan] 
		where [ResourceIntId]= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.Language_Orphan]
           ([RowId]
           ,[ResourceIntId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceIntId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

	--return -1
	if @SuppressOutput = 0
		select '' as Id, 0 As IsDuplicate
		end
	end

if @LanguageId > 0 begin
  print '[LanguageId] = ' + convert(varchar, @LanguageId)

  set @NewId= NEWID()
  print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.Language] base
	where base.[ResourceIntId] = @ResourceIntId
	And base.[LanguageId] = @LanguageId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.Language]
	    ([RowId]
	    ,[LanguageId]
	    ,OriginalLanguage
		,ResourceIntId)

    select
	    @NewId,
	    @LanguageId, 
	    @OriginalValue,
	    @ResourceIntId
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end


GO
grant execute on [Resource.Language_Import] to public
go

