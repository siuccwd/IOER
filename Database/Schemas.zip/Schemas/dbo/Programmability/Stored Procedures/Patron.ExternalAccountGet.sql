 
--- Get Single Procedure for [Patron.ExternalAccount] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Patron.ExternalAccountGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Patron.ExternalAccountGet]
Go
CREATE PROCEDURE [Patron.ExternalAccountGet]
    @Id int,
    @PatronId int, 
    @ExternalSiteId int,
    @Token  varchar(50) 
As
if @Id = 0 set @Id = null
if @PatronId = 0 set @PatronId = null
if @ExternalSiteId = 0 set @ExternalSiteId = null
if len(@Token) = 0 set @Token = null

if @id is null And @PatronId is null And @ExternalSiteId is null begin
  print 'no id provided'
  RAISERROR(' A valid id or rowId must be supplied', 18, 1)    
  RETURN -1 
  end
  
SELECT     
    PatronId, 
    Id, 
    ExternalSiteId, 
    LoginId, 
    Token
FROM [Patron.ExternalAccount]
WHERE 
    (Id = @Id OR @Id is null)
And (PatronId = @PatronId OR @PatronId is null)    
And (ExternalSiteId = @ExternalSiteId OR @ExternalSiteId is null)
And (Token = @Token OR @Token is null)
GO
grant execute on [Patron.ExternalAccountGet] to Public
Go
 