USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[ResourceUpdateFavorite]    Script Date: 4/21/2014 5:57:37 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT TOP 1000 
Id,[ResourceUrl]
      ,[ViewCount]
      ,[FavoriteCount]
      ,[Created]
      --,[LastUpdated]
      --,[IsActive]
      --,[HasPathwayGradeLevel]
      
  FROM [Isle_IOER].[dbo].[Resource]
  where id = 10107

[ResourceUpdateFavorite] 10107

*/
-- =============================================
-- Author:		MP
-- Create date: 2/3/2014
-- Description:	update favorite count

-- =============================================
ALTER PROCEDURE [dbo].[ResourceUpdateFavorite]
	@Id int
AS
declare @CurrentCnt int 
BEGIN TRANSACTION 
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	select @CurrentCnt= isnull(FavoriteCount, 0) from Resource where Id = @Id
	print 'current fav count: ' + convert(varchar,@CurrentCnt)

	UPDATE [Resource]
	SET FavoriteCount = isnull(@CurrentCnt,0) + 1
	
	WHERE Id = @Id
COMMIT 
