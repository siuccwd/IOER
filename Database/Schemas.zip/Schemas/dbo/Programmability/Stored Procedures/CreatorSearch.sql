USE Isle_IOER
GO
/****** Object:  StoredProcedure [dbo].[CreatorSearch]    Script Date: 10/22/2012 10:37:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

SELECT [Creator], count(*) As ResourceTotal
      
  FROM [dbo].[Resource.Version] base
  inner join [Resource] res on base.ResourceIntId = res.Id
Where base.isActive = 1
group by Creator

  
-- ==========================================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @totalRows int
--
set @SortOrder = '[Creator] desc'

-- blind search 
set @Filter = ''
set @Filter = ' rv.creator like ''illinois%'' ' 
set @Filter = ' rv.creator like ''c%'' ' 

set @Filter = ''
set @StartPageIndex = 1
set @PageSize = 100

EXECUTE @RC = CreatorSearch
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)



*/


Alter PROCEDURE [dbo].[CreatorSearch]
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@lastRow int
      ,@minRows int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@Sql2            varchar(200)
      ,@DefaultFilter   varchar(1000)
      ,@OrderBy         varchar(100)
-- =================================

Set @debugLevel = 4

Set @DefaultFilter= ' (IsActive = 1) '
if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by Creator '
--===================================================
-- Calculate the range
--===================================================      
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
SET @lastRow =  @StartPageIndex + @PageSize

-- =================================

  if len(isnull(@Filter,'')) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
        
     set @Filter =  @Filter + ' AND ' + @DefaultFilter
     end
  else begin
    set @Filter =     ' where rv.Creator is not null AND ' + @DefaultFilter
    end

  print '@Filter len: '  +  convert(varchar,len(@Filter))

  set @SQL = 'SELECT Distinct  pub.[Creator], ResourceTotal FROM
   (SELECT  ROW_NUMBER() OVER('+ @OrderBy + ') as RowNumber,
      [Creator], count(*) As ResourceTotal
  FROM [dbo].[Resource.Version] rv ' 
        + @Filter + ' group by [Creator]  
   ) as DerivedTableName
       Inner join [dbo].[Resource.Version] pub on DerivedTableName.[Creator] = pub.[Creator]
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' ' 
+ @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  exec (@SQL)
  
  --===============================
  DECLARE @TempItems TABLE
(
   RowsFound int
)


set @Sql2= 'SELECT distinct  count(Creator) FROM [dbo].[Resource.Version] rv '
        + @Filter + ' '

 print @Sql2
 INSERT INTO @TempItems (RowsFound)
  exec (@Sql2)
  
  select @TotalRows= RowsFound from @TempItems
go
grant execute on CreatorSearch to public
go
