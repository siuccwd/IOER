USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeDelete]    Script Date: 11/06/2012 17:08:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Resource.ResourceTypeDelete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Resource.ResourceTypeDelete]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Mods
13-08-22 mparsons - change to use @ResourceIntId
*/
Create PROCEDURE [dbo].[Resource.ResourceTypeDelete]
        @ResourceIntId int,
        @ResourceTypeId int
As
DELETE FROM [Resource.ResourceType]
WHERE ResourceIntId = @ResourceIntId  
AND ResourceTypeId = @ResourceTypeId
