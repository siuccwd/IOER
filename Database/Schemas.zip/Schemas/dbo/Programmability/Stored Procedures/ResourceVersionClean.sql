USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[ResourceVersionClean]    Script Date: 2/1/2014 1:14:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
--=======================================================================
--start: 1769679
select count(*) FROM [dbo].[Resource.Version]
--=======================================================================
SELECT     TOP (1000) Id, ResourceIntId, Title, IsActive, Description, Imported, Modified, Publisher, Creator, Submitter, AccessRightsId, AccessRights, Rights, DocId
FROM         [Resource.Version]
WHERE     (ResourceIntId IN
                          (SELECT     r.Id
                            FROM          Resource AS r INNER JOIN
                                                   [Resource.Version] AS rv ON r.Id = rv.ResourceIntId
                            WHERE      (r.IsActive = 1 AND rv.IsActive = 1)
                            GROUP BY r.Id
                            HAVING      (COUNT(*) > 1)
							)
)
ORDER BY ResourceIntId, Id DESC

  where title = 'Chameleons: Masters of Disguise!'
--=======================================================================


EXECUTE [dbo].[ResourceVersionClean] 1, 3562, 1, 1

EXECUTE [dbo].[ResourceVersionClean] 50000, 0, 1, 1
go
EXECUTE [dbo].[ResourceVersionClean] 600, 0, 1, 1

*/

/*
cleanup Versions

*/
Create PROCEDURE [dbo].[ResourceVersionClean]
            @MaxRecords int
            ,@ResId int
			,@DoingBackup bit
			,@DoingUpdate bit
As
begin 
          
Declare 
--@DoingBackup bit
--,@DoingUpdate bit
@cntr int

,@KeysCount int
,@StartingKeyId int
,@interval int
,@debugLevel int
,@affectedCount int
,@totalCount int
,@PrevResourceIntId int
,@BaseId int
,@BaseDesc varchar(max)
,@BaseTitle varchar(300)
,@Id int
,@ResourceIntId int
,@Title varchar(300)
,@Desc varchar(max)
,@IsActive bit
,@HoldDesc varchar(max)
,@HoldTitle varchar(300)


set @interval= 25
set @cntr= 0
--set @clusterId = 91

if @ResId= 0	set @ResId= NULL
set @BaseId = 0
set @PrevResourceIntId= 0
set @HoldTitle = ''
set @HoldDesc = ''
--set @DoingBackup= 1
--set @DoingUpdate = 0
set @debugLevel= 10
set @affectedCount= 0
set @totalCount= 0

-- ===============================================
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT  Id, ResourceIntId, Title, [Description], IsActive
			--, Imported, Modified, 
			--Publisher, Creator, Submitter, 
			--AccessRightsId, AccessRights, Rights, DocId

		FROM [Resource.Version]
		where 
			--(ResourceIntId = @ResId or @ResId is null )
		--OR 
		ResourceIntId IN
        (	SELECT     r.Id
            FROM Resource AS r 
			INNER JOIN [Resource.Version] AS rv ON r.Id = rv.ResourceIntId
            WHERE      (r.IsActive = 1 AND rv.IsActive = 1)
            GROUP BY r.Id
            HAVING      (COUNT(*) > 1)
		)
		ORDER BY ResourceIntId, Id DESC

	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @Id, @ResourceIntId, @Title,@Desc,@IsActive
	WHILE @@FETCH_STATUS = 0 BEGIN
		set @cntr = @cntr+ 1
		if @MaxRecords > 0 AND @cntr > @MaxRecords begin
			print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
			select 'exiting',  getdate()
			set @cntr = @cntr - 1
			BREAK
			End	  

		--if @PrevResourceIntId = 0 set @PrevResourceIntId = @ResourceIntId
		--if @BaseId = 0 set @BaseId = @Id

		if  @PrevResourceIntId <> @ResourceIntId begin
			-- update prev
			if @DoingUpdate= 1 AND @BaseId > 0 begin
				UPDATE [dbo].[Resource.Version]
					SET Title = @HoldTitle, [Description] = @HoldDesc
				where Id = @BaseId
				end

			print convert(varchar, @cntr)	
				+ '. New-ResId: ' + convert(varchar, @ResourceIntId) 	
				+ '. Id: ' + convert(varchar, @Id) 	
				+ '. Title: ' + @Title	
				+ '. IsActve: ' + convert(varchar, @IsActive)

			set @HoldTitle = isnull(@Title,'')
			set @HoldDesc = isnull(@Desc,'')
			set @PrevResourceIntId = @ResourceIntId
			set @BaseId = @Id
			end
		else begin
		
			print convert(varchar, @cntr)	
				+ '. ResId: ' + convert(varchar, @ResourceIntId) 	
				+ '. Next-Id: ' + convert(varchar, @Id) 	
				+ '. Title: ' + @Title	
				+ '. IsActve: ' + convert(varchar, @IsActive)

			if len(isnull(@Title,'')) > len(@HoldTitle) 
				set @HoldTitle = @Title

			if len(isnull(@Desc,'')) > len(@HoldDesc) 
				set @HoldDesc = @Desc

			if @DoingUpdate= 1 begin
				UPDATE [dbo].[Resource.Version]
					SET [IsActive] = 0
				where Id = @Id

				if @DoingBackup= 1 begin
					--DELETE FROM [dbo].[Resource.Version]
					--  where [ResourceIntId]= @ResourceIntId
					--	  and Id > @StartingKeyId

					INSERT INTO [dbo].[Resource.Version_Extras]
					   (Id, [ResourceIntId],[Title] )
					SELECT [Id]	,[ResourceIntId],[Title] 
						FROM [dbo].[Resource.Version]
						where Id = @Id
					end
				end
							
				set @totalCount= @totalCount+1
			end


		FETCH NEXT FROM thisCursor INTO @Id, @ResourceIntId, @Title,@Desc,@IsActive
	END

	if @DoingUpdate= 1 AND @BaseId > 0 begin
		UPDATE [dbo].[Resource.Version]
			SET Title = @HoldTitle, [Description] = @HoldDesc
		where Id = @BaseId
		end

	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  select 'Versions inactivated: ' + convert(varchar, @totalCount)
  
  
end

