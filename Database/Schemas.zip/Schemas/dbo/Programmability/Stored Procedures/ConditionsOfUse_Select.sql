USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[ConditionsOfUse_Select]    Script Date: 09/08/2012 17:40:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

Alter PROCEDURE [dbo].[ConditionsOfUse_Select]
As
SELECT	[Id],
		[Summary] AS [Title],
		[Title] AS [Description],
		[Url],
		[IconUrl],
		[MiniIconUrl]

FROM [ConditionOfUse]

WHERE     (IsActive = 1)
ORDER BY SortOrderAuthoring

GO
GRANT EXECUTE ON [dbo].[ConditionsOfUse_Select] TO [public] 
GO