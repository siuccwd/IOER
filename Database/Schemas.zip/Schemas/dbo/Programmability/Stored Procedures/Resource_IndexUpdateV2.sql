USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource_IndexUpdateV2]    Script Date: 1/29/2015 2:29:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[dbo].[Resource_IndexUpdateV2]

*/
-- ======================================================================
-- Author:		Jerome Grimmer
-- Create date: 4/25/2013
-- Description:	Update Resource_IndexV2 table for ElasticSearch
--
-- 2013-07-08 jgrimmer - Remove resources where [Resource.Version].IsActive <> 'True'
-- 2013-08-20 jgrimmer - Added likeCount and dislikeCount
-- 2013-11-20 jgrimmer - Added check for IsDeleted in the LinkChecker database
-- 2014-02-03 jgrimmer - Modify favorites to rely on [Resource].FavoriteCount only.  It is detail/library page's responsibility to update that count.
--						 Also add Submitter.
-- 2014-05-19 jgrimmer - Exclude resources from Smarter Balance, since Illinois is a PARCC member and not a Smarter Balance member state, and remove 
--						 check for PrivateResource (docID is null)
-- ======================================================================
-- 2014-05-21 mparsons - create new version using Resource.Tag
-- 2014-05-28 mparsons - added sortTitle
-- 2014-08-14 jgrimmer - Allow submitter to be NULL.
-- 2014-08-08 mparsons - changed targetSiteIDs to be based on the relative CodeId, not the absolute id (not Resource.Site for now)
-- 2014-10-16 mparsons - added qualify - renaming??
-- 2014-10-29 mparsons - added wioaWorks (replaces wioaWorks - 23)
-- 2014-11-25 mparsons - added layoff assistance (30)
-- 2015-01-29 mparsons - added check for unique resourceId, and for url <500
-- ======================================================================
ALTER PROCEDURE [dbo].[Resource_IndexUpdateV2]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @InitStartTime datetime, @StartTime datetime, @EndTime datetime, @ElapsedTime float, @FinishTime datetime, @categoryId int, @processName varchar(50)

SET @StartTime = GETDATE()
SET @InitStartTime = @StartTime

-- Remove inactive resources
DELETE
FROM [Resource_IndexV2]
WHERE intID IN (SELECT Id FROM [Resource] WHERE IsActive = 0) 
OR	versionID IN (SELECT Id FROM [Resource.Version] WHERE IsActive = 0) 
OR	intId IN (Select ResourceIntId FROM [Resource.Link] WHERE IsDeleted = 1)
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'Delete inactive resources = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()


-- Update existing resources Resource.Version data
UPDATE Resource_IndexV2
SET title = rv.Title, 
	[description] = rv.[Description],
	publisher = rv.Publisher,
	created = rv.Created,
	accessRights = rv.AccessRights,
	accessRightsID = rv.AccessRightsId,
	LastUpdated = GETDATE(),
	url = r.ResourceUrl,
	usageRightsURL = rv.Rights,
	usageRights = 
		CASE 
			WHEN cou.Id IS NOT NULL THEN cou.Summary
			WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN 'Read the Fine Print'
			ELSE NULL
		END,
	usageRightsID = 
		CASE 
			WHEN cou.Id IS NOT NULL THEN cou.Id
			WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN 4  -- Read the Fine Print
			ELSE NULL
		END,
	usageRightsIconURL = 
		CASE 
			WHEN cou.Id IS NOT NULL THEN cou.IconUrl
			WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN 'http://mirrors.creativecommons.org/presskit/cc.primary.srr.gif'
			ELSE NULL
		END,
	usageRightsMiniIconURL = 
		CASE 
			WHEN cou.Id IS NOT NULL THEN cou.MiniIconUrl
			WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN '/images/icons/rightsreserved.png'
			ELSE NULL
		END,
	viewsCount = ViewCount,
	timeRequired = TypicalLearningTime,
	creator = rv.Creator,
	requirements = rv.Requirements,
	isBasedOnUrl = RelatedUrl,
	favorites = r.FavoriteCount,
	submitter = rv.Submitter,
	 [SortTitle] = [dbo].[BuildSortTitle] (rv.[Title])
FROM [Resource.Version] rv
INNER JOIN [Resource] r ON rv.ResourceIntId = r.Id
LEFT JOIN [ConditionOfUse] cou ON rv.Rights = cou.Url
LEFT JOIN [Resource.RelatedUrl] rru ON r.Id = rru.ResourceIntId
WHERE Resource_IndexV2.versionId = rv.Id AND
	(Resource_IndexV2.title <> rv.Title OR Resource_IndexV2.[description] <> rv.[Description] OR
	 Resource_IndexV2.publisher <> rv.Publisher OR  Resource_IndexV2.accessRights <> rv.AccessRights OR
	 Resource_IndexV2.accessRightsId <> rv.AccessRightsId OR Resource_IndexV2.url <> r.ResourceUrl OR
	 Resource_IndexV2.usageRightsURL <> rv.Rights OR viewsCount <> ViewCount OR
	 Resource_IndexV2.timeRequired <> rv.TypicalLearningTime OR Resource_IndexV2.creator <> rv.Creator OR
	 Resource_IndexV2.requirements <> rv.Requirements OR Resource_IndexV2.isBasedOnUrl <> rru.RelatedUrl OR
 	 Resource_IndexV2.favorites <> r.FavoriteCount OR
	 Resource_IndexV2.submitter <> rv.Submitter) AND
	 Resource_IndexV2.intID NOT IN (SELECT ResourceIntId FROM [Resource.Link] WHERE IsDeleted = 'True') AND
	 (rv.Submitter IS NULL OR rv.Submitter NOT LIKE '%smarterbalanced.org%' )

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Resource.Version] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Add new resources, skipping inactive and private resources
INSERT INTO Resource_IndexV2 (versionId, intId, title, [description], publisher,
	created, accessRights, accessRightsId, LastUpdated, url, usageRightsUrl, usageRights, usageRightsID, usageRightsIconURL, usageRightsMiniIconURL,
	viewsCount, timeRequired, creator, requirements, isBasedOnUrl, favorites, submitter)
SELECT DISTINCT rv.Id, rv.ResourceIntId, rv.Title, rv.[Description], rv.Publisher, rv.Created, rv.AccessRights, rv.AccessRightsId, GETDATE(), r.ResourceUrl,
	rv.Rights, 
	CASE 
		WHEN cou.Id IS NOT NULL THEN cou.Summary
		WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN 'Read the Fine Print'
		ELSE NULL
	END AS usageRights,
	CASE 
		WHEN cou.Id IS NOT NULL THEN cou.Id
		WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN 4 -- Read the Fine Print
		ELSE NULL
	END AS usageRightsId,
	CASE 
		WHEN cou.Id IS NOT NULL THEN cou.IconUrl
		WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN 'http://mirrors.creativecommons.org/presskit/cc.primary.srr.gif'
		ELSE NULL
	END AS usageRightsIconURL,
	CASE 
		WHEN cou.Id IS NOT NULL THEN cou.MiniIconUrl
		WHEN rv.Rights IS NOT NULL AND cou.Id IS NULL THEN '/images/icons/rightsreserved.png'
		ELSE NULL
	END AS usageRightsMiniIconURL,
	ViewCount, TypicalLearningTime, Creator, Requirements, RelatedUrl, r.FavoriteCount, rv.Submitter
FROM [Resource.Version] rv
INNER JOIN [Resource] r ON rv.ResourceIntId = r.Id
LEFT JOIN [Resource.PublishedBy] rpb ON rv.ResourceIntId = rpb.ResourceIntId
LEFT JOIN [ConditionOfUse] cou ON rv.Rights = cou.Url
LEFT JOIN [Resource.RelatedUrl] rru ON r.Id = rru.ResourceIntId
WHERE rv.Id NOT IN 	(SELECT versionId FROM Resource_IndexV2) 
AND rv.ResourceIntId NOT IN 	(SELECT intId FROM Resource_IndexV2) 
AND (cou.Id IS NULL OR cou.Id <> 3) 
AND r.IsActive = 1 
AND rv.IsActive = 1 
AND (rpb.PublishedById IS NULL OR rpb.PublishedById <> 22) 
AND	r.Id NOT IN (SELECT ResourceIntId FROM [Resource.Link] WHERE IsDeleted = 'True') 
AND	(rv.Submitter IS NULL OR rv.Submitter NOT LIKE '%smarterbalanced.org%' )
and len(r.ResourceUrl) < 500

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'INSERT from [Resource.Version] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Keywords
UPDATE Resource_IndexV2
SET keywords = rk.Keywords,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Keywords, LEN(Keywords) - 1) AS Keywords
	FROM (SELECT ResourceIntId, (
		SELECT isnull(itbl.[Keyword],'')+','
		FROM [Resource.Keyword] itbl
		WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Keywords
	FROM [Resource.Keyword] tbl
	GROUP BY ResourceIntId) otab) rk
WHERE Resource_IndexV2.intId = rk.ResourceIntId AND
	(Resource_IndexV2.keywords <> rk.Keywords OR 
	(Resource_IndexV2.keywords IS NULL AND rk.Keywords IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Resource.Keyword] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Subjects ???? how to merge k12 subject, and existing subjects
UPDATE Resource_IndexV2
SET [subjects] = rs.[Subjects],
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Subjects, LEN(Subjects) - 1) AS Subjects
	FROM (SELECT ResourceIntId, (
		SELECT itbl.[Subject]+','
		FROM [Resource.Subject] itbl
		WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Subjects
	FROM [Resource.Subject] tbl
	GROUP BY ResourceIntId) otab) rs 
WHERE Resource_IndexV2.intId = rs.ResourceIntId AND
	(Resource_IndexV2.subjects <> rs.Subjects OR
	(Resource_IndexV2.subjects IS NULL AND rs.Subjects IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Resource.Subject] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- k12Subject Ids
UPDATE Resource_IndexV2
SET k12SubjectIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 20 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 20
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.k12SubjectIDs <> rs.relatedTags OR
	(Resource_IndexV2.k12SubjectIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [k12Subject Ids] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- k12Subjects
UPDATE Resource_IndexV2
SET k12Subjects = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 20 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 20
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.k12Subjects <> rs.relatedTags OR
	(Resource_IndexV2.k12Subjects IS NULL AND rs.relatedTags IS NOT NULL))


SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [k12Subjects] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Language IDs
UPDATE Resource_IndexV2
SET [languageIDs] = rl1.[LanguageIds],
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Languages, LEN(Languages) - 1) AS LanguageIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 17 AND itbl.ResourceIntId = tbl.ResourceIntId
		for xml path('')) Languages
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 17
	GROUP BY ResourceIntId) otab) rl1
WHERE Resource_IndexV2.intId = rl1.ResourceIntId AND
	(Resource_IndexV2.languageIDs <> rl1.LanguageIds OR
	(Resource_IndexV2.languageIDs IS NULL AND rl1.LanguageIds IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.Language] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Languages
UPDATE Resource_IndexV2
SET [languages] = rl2.[Languages],
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Languages, LEN(Languages) - 1) AS Languages
	FROM (SELECT ResourceIntId, (
		SELECT itbl.TagTitle +','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 17 AND itbl.ResourceIntId = tbl.ResourceIntId
		for xml path('')) Languages
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 17
	GROUP BY ResourceIntId) otab) rl2
WHERE Resource_IndexV2.intId = rl2.ResourceIntId AND
	(Resource_IndexV2.languages <> rl2.Languages OR
	(Resource_IndexV2.languages IS NULL AND rl2.Languages IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.Language] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Career Cluster IDs
UPDATE Resource_IndexV2
SET clusterIDs = cc1.ClusterIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Clusters, LEN(Clusters) - 1) AS ClusterIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 8 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Clusters
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 8
	GROUP BY ResourceIntId) otab) cc1
WHERE Resource_IndexV2.intId = cc1.ResourceIntId AND
	(Resource_IndexV2.clusterIDs <> cc1.ClusterIds OR 
	(Resource_IndexV2.clusterIDs IS NULL AND cc1.ClusterIds IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.Cluster] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Clusters
UPDATE Resource_IndexV2
SET clusters = cc2.Clusters,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Clusters, LEN(Clusters) - 1) AS Clusters
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 8 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Clusters
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 8
	GROUP BY ResourceIntId) otab) cc2
WHERE Resource_IndexV2.intId = cc2.ResourceIntId AND
	(Resource_IndexV2.clusters <> cc2.Clusters OR
	(Resource_IndexV2.clusters IS NULL AND cc2.Clusters IS NOT NULL))


SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.Cluster] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Intended Audience Ids
UPDATE Resource_IndexV2
SET audienceIDs = ia1.AudienceIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Audiences, LEN(Audiences) - 1) AS AudienceIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 7 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Audiences
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 7
	GROUP BY ResourceIntId) otab) ia1
WHERE Resource_IndexV2.intId = ia1.ResourceIntId AND
	(Resource_IndexV2.audienceIDs <> ia1.AudienceIds OR
	(Resource_IndexV2.audienceIDs IS NULL AND ia1.AudienceIds IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.IntendedAudience] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Intended Audiences
UPDATE Resource_IndexV2
SET audiences = ia2.Audiences,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Audiences, LEN(Audiences) - 1) AS Audiences
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 7 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Audiences
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 7
	GROUP BY ResourceIntId) otab) ia2
WHERE Resource_IndexV2.intId = ia2.ResourceIntId AND
	(Resource_IndexV2.audiences <> ia2.Audiences OR
	(Resource_IndexV2.audiences IS NULL AND ia2.Audiences IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.IntendedAudience] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- gradeLevelIds
UPDATE Resource_IndexV2
SET gradeLevelIDs = el1.gradeLevelIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(gradeLevels, LEN(gradeLevels) - 1) AS gradeLevelIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 13 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) gradeLevels
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 13
	GROUP BY ResourceIntId) otab) el1
WHERE Resource_IndexV2.intId = el1.ResourceIntId AND
	(Resource_IndexV2.gradeLevelIds <> el1.gradeLevelIds OR
	(Resource_IndexV2.gradeLevelIds IS NULL AND el1.gradeLevelIds IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.GradeLevel] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- gradeLevels
UPDATE Resource_IndexV2
SET gradeLevels = el2.RelatedTags,
	LastUpdated = GETDATE()	
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS RelatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 13 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 13
	GROUP BY ResourceIntId) otab) el2
WHERE Resource_IndexV2.intId = el2.ResourceIntId AND
	(Resource_IndexV2.gradeLevels <> el2.RelatedTags OR
	(Resource_IndexV2.gradeLevels IS NULL AND el2.RelatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.GradeLevel] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- gradeLevelAliases		
UPDATE Resource_IndexV2
SET gradeLevelAliases = el2.RelatedTags,
	LastUpdated = GETDATE()	
FROM (SELECT ResourceIntId, 
		CASE 
			WHEN LEN(RelatedList) > 1 THEN replace(left(RelatedList, LEN(RelatedList) - 1),',,',',')
			ELSE NULL
		END AS RelatedTags
	FROM (SELECT ResourceIntId, (
		SELECT itbl.AliasValues + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 13 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 13
	GROUP BY ResourceIntId) otab) el2
WHERE Resource_IndexV2.intId = el2.ResourceIntId AND
	(Resource_IndexV2.gradeLevelAliases <> el2.RelatedTags OR
	(Resource_IndexV2.gradeLevelAliases IS NULL AND el2.RelatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #3 from [Resource.GradeLevel] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Resource Type Ids
UPDATE Resource_IndexV2
SET resourceTypeIDs = rt1.ResourceTypeIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(ResourceTypes, LEN(ResourceTypes) - 1) AS ResourceTypeIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 19 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) ResourceTypes
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 19
	GROUP BY ResourceIntId) otab) rt1
WHERE Resource_IndexV2.intId = rt1.ResourceIntId AND
	(Resource_IndexV2.resourceTypeIds <> rt1.ResourceTypeIds OR
	(Resource_IndexV2.resourceTypeIds IS NULL AND rt1.ResourceTypeIds IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.ResourceType] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Resource Types
UPDATE Resource_IndexV2
SET resourceTypes = rt2.ResourceTypes,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(ResourceTypes, LEN(ResourceTypes) - 1) AS ResourceTypes
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 19 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) ResourceTypes
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 19
	GROUP BY ResourceIntId) otab) rt2
WHERE Resource_IndexV2.intId = rt2.ResourceIntId AND
	(Resource_IndexV2.resourceTypes <> rt2.ResourceTypes OR
	(Resource_IndexV2.resourceTypes IS NULL AND rt2.ResourceTypes IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.ResourceType] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Resource Format Ids
UPDATE Resource_IndexV2
SET mediaTypeIDs = rf1.ResourceFormatIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(ResourceFormats, LEN(ResourceFormats) - 1) AS ResourceFormatIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 18 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) ResourceFormats
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 18
	GROUP BY ResourceIntId) otab) rf1
WHERE Resource_IndexV2.intId = rf1.ResourceIntId AND
	(Resource_IndexV2.mediaTypeIDs <> rf1.ResourceFormatIds OR
	(Resource_IndexV2.mediaTypeIDs IS NULL AND rf1.ResourceFormatIds IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.Format] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Resource Formats
UPDATE Resource_IndexV2
SET mediaTypes = rf2.ResourceFormats,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(ResourceFormats, LEN(ResourceFormats) - 1) AS ResourceFormats
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 18 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) ResourceFormats
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 18
	GROUP BY ResourceIntId) otab) rf2
WHERE Resource_IndexV2.intId = rf2.ResourceIntId AND
	(Resource_IndexV2.mediaTypes <> rf2.ResourceFormats OR
	(Resource_IndexV2.mediaTypes IS NULL AND rf2.ResourceFormats IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.Format] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Group Type Ids
UPDATE Resource_IndexV2
SET groupTypeIDs = gt1.GroupTypeIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(GroupTypes, LEN(GroupTypes) - 1) AS GroupTypeIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 14 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) GroupTypes
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 14
	GROUP BY ResourceIntId) otab) gt1
WHERE Resource_IndexV2.intId = gt1.ResourceIntId AND
	(Resource_IndexV2.groupTypeIds <> gt1.GroupTypeIds OR
	(Resource_IndexV2.groupTypeIds IS NULL AND gt1.GroupTypeIds IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.GroupTypes] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Group Types
UPDATE Resource_IndexV2
SET groupTypes = gt2.GroupTypes,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(GroupTypes, LEN(GroupTypes) - 1) AS GroupTypes
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 14 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) GroupTypes
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 14
	GROUP BY ResourceIntId) otab) gt2
WHERE Resource_IndexV2.intId = gt2.ResourceIntId AND
	(Resource_IndexV2.groupTypes <> gt2.GroupTypes OR
	(Resource_IndexV2.groupTypes IS NULL AND gt2.GroupTypes IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.GroupTypes] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Item Type Ids
UPDATE Resource_IndexV2
SET itemTypeIDs = it1.ItemTypeIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(ItemTypes, LEN(ItemTypes) - 1) AS ItemTypeIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 15 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) ItemTypes
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 15
	GROUP BY ResourceIntId) otab) it1
WHERE Resource_IndexV2.intId = it1.ResourceIntId AND
	(Resource_IndexV2.itemTypeIds <> it1.ItemTypeIds OR
	(Resource_IndexV2.itemTypeIds IS NULL AND it1.ItemTypeIds IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.ItemTypes] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
	
-- Item Types
UPDATE Resource_IndexV2
SET itemTypes = it2.ItemTypes,
	LastUpdated = getdate()
FROM (SELECT ResourceIntId, left(ItemTypes, LEN(ItemTypes) - 1) AS ItemTypes
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 15 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) ItemTypes
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 15
	GROUP BY ResourceIntId) otab) it2 
WHERE Resource_IndexV2.intId = it2.ResourceIntId AND
	(Resource_IndexV2.itemTypes <> it2.ItemTypes OR
	(Resource_IndexV2.itemTypes IS NULL AND it2.ItemTypes IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.ItemTypes] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Standard Ids
UPDATE Resource_IndexV2
SET standardIDs = rst1.StandardIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Standards, LEN(Standards) - 1) AS StandardIds
	FROM (SELECT ResourceIntId, (
		SELECT isnull(convert(varchar,itbl.[StandardId]),'')+','
		FROM [Resource.Standard] itbl
		WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Standards
	FROM [Resource.Standard] tbl
	GROUP BY ResourceIntId) otab) rst1
WHERE Resource_IndexV2.intId = rst1.ResourceIntId AND
	(Resource_IndexV2.StandardIDs <> rst1.StandardIds OR
	(Resource_IndexV2.StandardIDs IS NULL AND rst1.StandardIds IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.Standards] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Standards
UPDATE Resource_IndexV2
SET standardNotations = rst2.Standards,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(Standards, LEN(Standards) - 1) AS Standards
	FROM (SELECT ResourceIntId, (
		SELECT [StandardBody.Node].NotationCode+','
		FROM [Resource.Standard] itbl
		INNER JOIN [StandardBody.Node] ON itbl.StandardId = [StandardBody.Node].Id
		WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) Standards
	FROM [Resource.Standard] tbl
	GROUP BY ResourceIntId) otab) rst2 
WHERE Resource_IndexV2.intId = rst2.ResourceIntId AND
	(Resource_IndexV2.standardNotations <> rst2.Standards OR
	(Resource_IndexV2.standardNotations IS NULL AND rst2.Standards IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
SET @FinishTime = @EndTime
PRINT 'UPDATE #2 from [Resource.Standards] = ' + convert(varchar,@ElapsedTime)

-- Alignment Type IDs - ???????????????????
UPDATE Resource_IndexV2
SET alignmentTypeIDs = rs.AlignmentTypeIDs,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(AlignmentTypeIDs, LEN(AlignmentTypeIDs) - 1) AS AlignmentTypeIDs
		FROM (SELECT ResourceIntId, (
			SELECT convert(nvarchar,isnull(itbl.[AlignmentTypeCodeId],2))+','
			FROM [Resource.Standard] itbl
			WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (CreatedById IS NULL OR CreatedById <> 22)
			for xml path('')) AlignmentTypeIDs
		FROM [Resource.Standard] tbl
		GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND 
	(Resource_IndexV2.alignmentTypeIDs <> rs.AlignmentTypeIDs OR
	(Resource_IndexV2.alignmentTypeIDs IS NULL AND rs.AlignmentTypeIDs IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
SET @FinishTime = @EndTime
PRINT 'UPDATE Alignment Type IDs = ' + convert(varchar,@ElapsedTime)
	
-- Alignment Types		?????????????????????
UPDATE Resource_IndexV2
SET alignmentTypes = rs.AlignmentTypes,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(AlignmentTypes, LEN(AlignmentTypes) - 1) AS AlignmentTypes
		FROM (SELECT ResourceIntId, (
			SELECT isnull([Codes.AlignmentType].Title,'Teaches')+','
			FROM [Resource.Standard] itbl
			LEFT JOIN [Codes.AlignmentType] ON itbl.AlignmentTypeCodeId = [Codes.AlignmentType].Id
			WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (CreatedById IS NULL OR CreatedById <> 22)
			for xml path('')) AlignmentTypes
		FROM [Resource.Standard] tbl
		GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.alignmentTypes <> rs.AlignmentTypes OR
	(Resource_IndexV2.alignmentTypes IS NULL AND rs.AlignmentTypes IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
SET @FinishTime = @EndTime
PRINT 'UPDATE Alignment Types = ' + convert(varchar,@ElapsedTime)

-- EducationalUseIds
UPDATE Resource_IndexV2
SET educationalUseIDs = eu1.EducationalUseIds,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(EducationalUse, LEN(EducationalUse) - 1) AS EducationalUseIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 11 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) EducationalUse
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 11
	GROUP BY ResourceIntId) otab) eu1
WHERE Resource_IndexV2.intId = eu1.ResourceIntId AND
	(Resource_IndexV2.educationalUseIDs <> eu1.EducationalUseIds OR
	(Resource_IndexV2.educationalUseIDs IS NULL AND eu1.EducationalUseIds IS NOT NULL))
	
SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.EducationUse] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- EducationalUse
UPDATE Resource_IndexV2
SET educationalUses = eu2.EducationalUses,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(EducationalUse, LEN(EducationalUse) - 1) AS EducationalUses
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 11 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) EducationalUse
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 11
	GROUP BY ResourceIntId) otab) eu2 
WHERE Resource_IndexV2.intId = eu2.ResourceIntId AND
	(Resource_IndexV2.educationalUses <> eu2.EducationalUses OR
	(Resource_IndexV2.educationalUses IS NULL AND eu2.EducationalUses IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.EducationUse] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Likes minus Dislikes
UPDATE Resource_IndexV2
SET likesSummary = rls.LikeCount - rls.DislikeCount,
	LastUpdated = GETDATE()
FROM [Resource.LikesSummary] rls
WHERE Resource_IndexV2.intId = rls.ResourceIntId AND
	((Resource_IndexV2.likesSummary <> (rls.LikeCount - rls.DislikeCount) OR
	(Resource_IndexV2.likesSummary IS NULL AND (rls.LikeCount - rls.DislikeCount) IS NOT NULL)))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE likesSummary from [Resource.LikesSummary] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Likes and Dislikes
UPDATE Resource_IndexV2
SET likeCount = rls.LikeCount,
	dislikeCount = rls.DislikeCount,
	LastUpdated = GETDATE()
FROM [Resource.LikesSummary] rls
WHERE Resource_IndexV2.intID = rls.ResourceIntId AND
 ((Resource_IndexV2.likeCount <> rls.LikeCount OR (Resource_IndexV2.likeCount IS NULL AND rls.LikeCount IS NOT NULL)) OR
 (Resource_IndexV2.dislikeCount <> rls.DislikeCount OR (Resource_IndexV2.dislikeCount IS NULL AND rls.DislikeCount IS NOT NULL)))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE likeCount, dislikeCount from [Resource.LikesSummary] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
	
-- Library IDs
UPDATE Resource_IndexV2
SET libraryIDs = rs.LibraryIDs,
		LastUpdated = GETDATE()
	FROM (SELECT ResourceIntId, left(LibraryIDs, LEN(LibraryIDs) - 1) AS LibraryIDs
		FROM (SELECT ResourceIntId, (
			SELECT convert(nvarchar,[IsleContent].[dbo].[Library.Section].LibraryId)+','
			FROM [IsleContent].[dbo].[Library.Resource] itbl
			INNER JOIN [IsleContent].[dbo].[Library.Section] 
				ON itbl.LibrarySectionId = [IsleContent].[dbo].[Library.Section].Id
			WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (itbl.CreatedById IS NULL OR itbl.CreatedById <> 22)
			for xml path('')) LibraryIDs
		FROM [IsleContent].[dbo].[Library.Resource] tbl
		GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.libraryIDs <> rs.LibraryIDs OR
	(Resource_IndexV2.libraryIDs IS NULL AND rs.LibraryIDs IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Library.Section] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Collection IDs
UPDATE Resource_IndexV2
SET collectionIDs = rs.CollectionIDs,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(CollectionIDs, LEN(CollectionIDs) - 1) AS CollectionIDs
	FROM (SELECT ResourceIntId, (
		SELECT convert(nvarchar,itbl.[LibrarySectionId])+','
		FROM [IsleContent].[dbo].[Library.Resource] itbl
		WHERE itbl.ResourceIntId = tbl.ResourceIntId AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) CollectionIDs
	FROM [IsleContent].[dbo].[Library.Resource] tbl
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.collectionIDs <> rs.CollectionIDs OR
	(Resource_IndexV2.collectionIDs IS NULL AND rs.CollectionIDs IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Library.Resource] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Comments Count
UPDATE Resource_IndexV2
SET commentsCount = rs.CommentsCount,
	LastUpdated = getdate()
FROM (SELECT ResourceIntId, COUNT(*) AS CommentsCount
	FROM [Resource.Comment]
	WHERE (CreatedById IS NULL OR CreatedById <> 22)
	GROUP BY ResourceIntId) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.commentsCount <> rs.CommentsCount OR
	(Resource_IndexV2.commentsCount IS NULL AND rs.CommentsCount IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Resource.Comments] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- AssessmentTypeIDs
UPDATE Resource_IndexV2
SET assessmentTypeIDs = rs.relatedIds
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedIds
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 25 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 25
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.assessmentTypeIDs <> rs.relatedIds OR
	(Resource_IndexV2.assessmentTypeIDs IS NULL AND rs.relatedIds IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.AssessmentType] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- AssessmentTypes
UPDATE Resource_IndexV2
SET assessmentTypes = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 4 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 4
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.assessmentTypes <> rs.relatedTags OR
	(Resource_IndexV2.assessmentTypes IS NULL AND rs.relatedTags IS NOT NULL))


SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.AssessmentType] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- DetailViews
UPDATE Resource_IndexV2
SET detailViews = rs.DetailViews,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, COUNT(*) AS DetailViews
	FROM [Resource.DetailView]
	WHERE (CreatedById IS NULL OR CreatedById <> 22)
	GROUP BY ResourceIntId) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.detailViews <> rs.DetailViews OR
	(Resource_IndexV2.detailViews IS NULL AND rs.DetailViews IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Resource.DetailView] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- Favorites - commented out.  Relying only on [Resource].FavoriteCount
/* UPDATE Resource_IndexV2
SET favorites = rs.Favorites,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, r.FavoriteCount + COUNT(*) AS Favorites
	FROM [IsleContent].[dbo].[Library.Resource] lr
	INNER JOIN [Resource] r ON lr.ResourceIntId = r.Id
	WHERE (CreatedById IS NULL OR CreatedById <> 22)
	GROUP BY ResourceIntId, FavoriteCount) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.detailViews <> rs.Favorites OR
	(Resource_IndexV2.detailViews IS NULL AND rs.Favorites IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE from [Library.Resource] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE() */


-- accessibilityApi IDs
/*--====== why is the format different for these???
Missing:
WHERE Resource_IndexV2.intId = cc1.ResourceIntId AND
	(Resource_IndexV2.clusterIDs <> cc1.ClusterIds OR 
	(Resource_IndexV2.clusterIDs IS NULL AND cc1.ClusterIds IS NOT NULL))
also:
LastUpdated = GETDATE()

*/
UPDATE Resource_IndexV2
SET accessibilityApiIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 2 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 2
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.AccessibilityApi] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- accessibilityApis
UPDATE Resource_IndexV2
SET accessibilityApis = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 2 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 2
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.AccessibilityApi] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- accessibilityControl IDs
UPDATE Resource_IndexV2
SET accessibilityControlIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 3 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 3
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.AccessibilityControl] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- accessibilityControls
UPDATE Resource_IndexV2
SET accessibilityControls = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 3 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 3
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.AccessibilityControl] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- accessibilityFeature IDs
UPDATE Resource_IndexV2
SET accessibilityFeatureIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 4 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 4
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.AccessibilityFeature] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- accessibilityFeatures
UPDATE Resource_IndexV2
SET accessibilityFeatures = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 4 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 4
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.AccessibilityFeature] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- accessibilityHazard IDs
UPDATE Resource_IndexV2
SET accessibilityHazardIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 5 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 5
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #1 from [Resource.AccessibilityHazard] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- accessibilityHazards
UPDATE Resource_IndexV2
SET accessibilityHazards = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = 5 AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = 5
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.accessibilityApiIDs <> rs.relatedTags OR
	(Resource_IndexV2.accessibilityApiIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT 'UPDATE #2 from [Resource.AccessibilityHazard] = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- =======================================================================
-- 9 - career planning IDs == to Training & Credentials
set @categoryId= 9
set @processName= '9 - Training & Credentials'
UPDATE Resource_IndexV2
SET trainingIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.trainingIDs <> rs.relatedTags OR
	(Resource_IndexV2.trainingIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET training = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.training <> rs.relatedTags OR
	(Resource_IndexV2.training IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- =======================================================================
-- Disability Topic IDs
set @categoryId= 10
set @processName= '10 - Disability Topic'
UPDATE Resource_IndexV2
SET disabilityTopicIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.disabilityTopicIDs <> rs.relatedTags OR
	(Resource_IndexV2.disabilityTopicIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET disabilityTopics = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.disabilityTopics <> rs.relatedTags OR
	(Resource_IndexV2.disabilityTopics IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- =======================================================================
-- Disability - Region IDs
set @categoryId= 26
set @processName= '26 - - Region IDs'
UPDATE Resource_IndexV2
SET regionIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.regionIDs <> rs.relatedTags OR
	(Resource_IndexV2.regionIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET regions = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.regions <> rs.relatedTags OR
	(Resource_IndexV2.regions IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()


-- =======================================================================
-- Employer Program IDs  == to Network & Connect
set @categoryId= 12
set @processName= '12 - Network & Connect'
UPDATE Resource_IndexV2
SET networkingIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.networkingIDs <> rs.relatedTags OR
	(Resource_IndexV2.networkingIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET networking = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.networking <> rs.relatedTags OR
	(Resource_IndexV2.networking IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()


-- =======================================================================
-- Job Preparation IDs		== to jobs
set @categoryId= 16
set @processName= '16 - Job Preparation'
UPDATE Resource_IndexV2
SET jobIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.jobIDs <> rs.relatedTags OR
	(Resource_IndexV2.jobIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET jobs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.jobs <> rs.relatedTags OR
	(Resource_IndexV2.jobs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()


-- =======================================================================
-- Veterans Service IDs		to Resources
set @categoryId= 21
set @processName= '21 - Resources'
UPDATE Resource_IndexV2
SET resourceIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.resourceIDs <> rs.relatedTags OR
	(Resource_IndexV2.resourceIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET resources = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.resources <> rs.relatedTags OR
	(Resource_IndexV2.resources IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- =======================================================================
-- Workforce Education Partner IDs
set @categoryId= 22
set @processName= '22 - Workforce Education Partner'
UPDATE Resource_IndexV2
SET wfePartnerIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.wfePartnerIDs <> rs.relatedTags OR
	(Resource_IndexV2.wfePartnerIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET wfePartners = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.wfePartners <> rs.relatedTags OR
	(Resource_IndexV2.wfePartners IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()


-- =======================================================================
-- wioaWorks (formerly workSupportServiceIDs
set @categoryId= 23
set @processName= '23 - wioaWorks'
UPDATE Resource_IndexV2
SET wioaWorksIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.wioaWorksIDs <> rs.relatedTags OR
	(Resource_IndexV2.wioaWorksIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET wioaWorks = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.wioaWorks <> rs.relatedTags OR
	(Resource_IndexV2.wioaWorks IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- =======================================================================
-- Workplace Skill IDs		=== Explore Careers
set @categoryId= 24
set @processName= '24 - explore'
UPDATE Resource_IndexV2
SET exploreIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.exploreIDs <> rs.relatedTags OR
	(Resource_IndexV2.exploreIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET explore = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.explore <> rs.relatedTags OR
	(Resource_IndexV2.explore IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- =======================================================================
-- Qualify for Jobs IDs
set @categoryId= 29
set @processName= '29 - Qualify'
UPDATE Resource_IndexV2
SET qualifyIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.qualifyIDs <> rs.relatedTags OR
	(Resource_IndexV2.qualifyIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET qualify = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.qualify <> rs.relatedTags OR
	(Resource_IndexV2.qualify IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()


-- =======================================================================
-- Qualify for Jobs IDs
set @categoryId= 30
set @processName= '30 - Layoff Assistance'
UPDATE Resource_IndexV2
SET layoffAssistIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.TagValueId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.layoffAssistIDs <> rs.relatedTags OR
	(Resource_IndexV2.layoffAssistIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET layoffAssist = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.layoffAssist <> rs.relatedTags OR
	(Resource_IndexV2.layoffAssist IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()

-- =======================================================================
-- TargetSite IDs
-- - use codeId rather than TagValueId. 
-- - OR convert to use resource.site??
set @categoryId= 27
set @processName= '27 - TargetSite'
--UPDATE Resource_IndexV2
--SET targetSiteIDs = rs.relatedTags,
--	LastUpdated = GETDATE()
--FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
--	FROM (SELECT ResourceIntId, (
--		SELECT convert(varchar,itbl.TagValueId)+','
--		FROM [Resource_TagSummary] itbl
--		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
--		for xml path('')) RelatedList
--		FROM [Resource_TagSummary] tbl
--	WHERE tbl.CategoryId = @categoryId
--	GROUP BY ResourceIntId) otab) rs
--WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
--	(Resource_IndexV2.targetSiteIDs <> rs.relatedTags OR
--	(Resource_IndexV2.targetSiteIDs IS NULL AND rs.relatedTags IS NOT NULL))

UPDATE Resource_IndexV2
SET targetSiteIDs = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT convert(varchar,itbl.CodeId)+','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		for xml path('')) RelatedList
		FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.targetSiteIDs <> rs.relatedTags OR
	(Resource_IndexV2.targetSiteIDs IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #1 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
		
-- titles
UPDATE Resource_IndexV2
SET targetSites = rs.relatedTags,
	LastUpdated = GETDATE()
FROM (SELECT ResourceIntId, left(RelatedList, LEN(RelatedList) - 1) AS relatedTags
	FROM (SELECT ResourceIntId, (
		SELECT  itbl.TagTitle + ','
		FROM [Resource_TagSummary] itbl
		WHERE itbl.CategoryId = @categoryId AND itbl.ResourceIntId = tbl.ResourceIntId 
		AND (CreatedById IS NULL OR CreatedById <> 22)
		for xml path('')) RelatedList
	FROM [Resource_TagSummary] tbl
	WHERE tbl.CategoryId = @categoryId
	GROUP BY ResourceIntId) otab) rs
WHERE Resource_IndexV2.intID = rs.ResourceIntId AND
	(Resource_IndexV2.targetSites <> rs.relatedTags OR
	(Resource_IndexV2.targetSites IS NULL AND rs.relatedTags IS NOT NULL))

SET @EndTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@StartTime,@EndTime)
PRINT @processName + ' UPDATE #2 = ' + convert(varchar,@ElapsedTime)
SET @StartTime = GETDATE()
-- =======================================================================
SET @StartTime = GETDATE()
SET @ElapsedTime = DATEDIFF(s,@InitStartTime,@FinishTime)
PRINT 'Total Time: ' + convert(varchar,@ElapsedTime)
END
