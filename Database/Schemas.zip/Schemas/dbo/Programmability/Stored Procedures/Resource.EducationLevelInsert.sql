USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevelInsert]    Script Date: 01/23/2013 13:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@PathwaysEducationLevelId int
DECLARE @OriginalValue varchar(500)

set @ResourceId = '987b71d5-9ba8-4703-b885-a80564ed30f1'
set @PathwaysEducationLevelId = 6
set @OriginalValue = ''

EXECUTE @RC = [dbo].[Resource.EducationLevelInsert] 
   @ResourceId
  ,@PathwaysEducationLevelId
  ,@OriginalValue



*/
/*
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Insert row into [Resource.EducationLevel] table
-- =============================================
modifications
12-11-05 mparsons - need to remove unknown grade level when inserting actual gl
*/
ALTER PROCEDURE [dbo].[Resource.EducationLevelInsert]
            @ResourceId     varchar(40),
            @PathwaysEducationLevelId int,
            @OriginalValue varchar(100)
           

As
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  If @PathwaysEducationLevelId = 0		    SET @PathwaysEducationLevelId = NULL 
  If @OriginalValue = ''  SET @OriginalValue = NULL 

	DECLARE @NewId uniqueidentifier
	,  @RecordCount int
	,  @totalRows int
	,  @DoUnknownCheck bit
	
	SET @NewId = NEWID()
	Set @DoUnknownCheck= 1

  If @OriginalValue is NULL and @PathwaysEducationLevelId is null begin
    print 'no values provided'
    return -1
    end    
  
  if @PathwaysEducationLevelId is null begin
	  print 'insert via OriginalValue - using import proc'  
  		
	    -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.EducationLevel_Import] 
        @ResourceId,
        @OriginalValue, '', @totalRows OUTPUT
        
    SELECT '' AS RowId
	  end
  else begin

    --should ensure doesn't already exist
    select @RecordCount = isnull(Count(*),0)
    FROM [dbo].[Resource.EducationLevel] rel 
    where rel.ResourceId  = @ResourceId AND rel.PathwaysEducationLevelId = @PathwaysEducationLevelId 	
    If @RecordCount is null OR @RecordCount = 0	begin	
    	  print 'insert via @PathwaysEducationLevelId'
      INSERT INTO [Resource.EducationLevel]
      (
	      RowId,
	      ResourceId, 
	      PathwaysEducationLevelId,
	      OriginalLevel
      )
	    Values (
		    @NewId,
		    @ResourceId, 
		    @PathwaysEducationLevelId, 
		    @OriginalValue
	    )
	    SELECT @NewId AS RowId
	    
	    if @DoUnknownCheck = 1 begin
	      select @RecordCount = isnull(Count(*),0)
        FROM [dbo].[Resource.EducationLevel] rel 
        where rel.ResourceId  = @ResourceId 
        
        if @RecordCount > 1 begin
          --delete unknown
          print 'Deleting UNKNOWN entry'
          DELETE FROM [dbo].[Resource.EducationLevel]
          where ResourceId  = @ResourceId AND PathwaysEducationLevelId = 7 	
          end
	      end
	      
	    end
    else begin
    	  print 'Duplicate PathwaysEducationLevelId'
      SELECT '' AS RowId
      end
    END
End

GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevelInsert] TO [public] AS [dbo]