 
--- Get Single Procedure for [Publish.Pending] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Publish.PendingGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Publish.PendingGet]
Go
CREATE PROCEDURE [Publish.PendingGet]
    @ResourceId int
    ,@ResourceVersionId int
    ,@Id int
As
if @ResourceId = 0     set @ResourceId = NULL
if @ResourceVersionId = 0     set @ResourceVersionId = NULL
if @Id = 0     set @Id = NULL


SELECT     Id, 
    ResourceIntId, 
    ResourceVersionIntId, 
    DocId, 
    Reason, 
    IsPublished, 
    Created, 
    CreatedById, 
    PublishedDate, 
    LrEnvelope
FROM [Publish.Pending]
WHERE 
    (ResourceIntId = @ResourceId or @ResourceId is null)
AND (ResourceVersionIntId = @ResourceVersionId or @ResourceVersionId is null)    
AND (Id = @Id or @Id is null)
GO
grant execute on [Publish.PendingGet] to Public
Go
 