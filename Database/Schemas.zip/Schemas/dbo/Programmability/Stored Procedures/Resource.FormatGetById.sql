USE Isle_IOER
GO

/****** Object:  StoredProcedure [dbo].[Resource.FormatGetById]    Script Date: 06/03/2013 14:42:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Resource.FormatGetById]
	@ResourceIntId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT ResourceIntId, OriginalValue, CodeId, Created, CreatedById
        ,RowId, ResourceId
	FROM [Resource.Format]
	WHERE ResourceIntId = @ResourceIntId
END

GO


