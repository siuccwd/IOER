USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.FormatDelete]    Script Date: 11/08/2012 14:13:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[Resource.FormatDelete]
        @ResourceId uniqueidentifier,
        @CodeId int
As
DELETE FROM [Resource.Format]
WHERE ResourceId = @ResourceId  
AND CodeId = @CodeId
