USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.GradeLevel_SelectedCodes]    Script Date: 04/08/2013 13:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.GradeLevel_SelectedCodes] 1518
*/
ALTER PROCEDURE [dbo].[Resource.GradeLevel_SelectedCodes]
    @ResourceIntId int

As
SELECT distinct
	code.Id, code.Title, code.[Description], code.[AliasValues]
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
	,code.[SortOrder]
FROM [dbo].[Codes.GradeLevel] code
Left Join dbo.[Resource.GradeLevel] rpw on code.Id = rpw.GradeLevelId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsActive = 1
Order by code.[SortOrder]

go
grant execute on [Resource.GradeLevel_SelectedCodes] to public
go




