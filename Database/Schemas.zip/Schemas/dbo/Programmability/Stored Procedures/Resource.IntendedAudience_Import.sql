USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudience_Import]    Script Date: 5/9/2014 2:48:15 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =============================================
Description:      [Resource.IntendedAudience_Import]
------------------------------------------------------
Modifications
2013-03-13 jgrimmer - Added @ResourceIntId 
2013-04-19 jgrimmer - Modified keyword check to use ResourceIntId
2014-05-09 mparsons - overdue chg to use res int id, not res id
=============================================

*/
ALTER PROCEDURE [dbo].[Resource.IntendedAudience_Import]
          @ResourceId     uniqueidentifier, 
          @IntendedAudienceId	    int,
          @OriginalValue  varchar(100)
          ,@TotalRows     int OUTPUT
          ,@ResourceIntId int

As
declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @KeywordId int

if @OriginalValue = '' set @OriginalValue = NULL
If @IntendedAudienceId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @IntendedAudienceId < 1		SET @IntendedAudienceId = NULL 
  
If @OriginalValue is NULL and @IntendedAudienceId is null begin
  print 'no values provided'
  return -1
  end    

set @IsDuplicate= 0
set @TotalRows= 0

-- ==================================================================
-- Do keyword check.  If keyword found, delete keyword.
SELECT @KeywordId = Id
FROM [Resource.Keyword]
WHERE ResourceIntId = @ResourceIntId AND Keyword = @OriginalValue
IF @KeywordId IS NOT NULL AND @KeywordId <> 0 BEGIN
	DELETE FROM [Resource.Keyword]
	WHERE Id = @KeywordId
END
	
-- ==================================================================
if @IntendedAudienceId is null begin
	print 'insert via Format'
	 -- so first check if mapping exists
	SELECT @IntendedAudienceId = isnull(base.id,0)
  FROM [dbo].[Codes.AudienceType] base
  inner join [dbo].[Map.AudienceType] mapper on base.Title = mapper.MappedValue
  where mapper.OriginalValue = @OriginalValue
   
	If @IntendedAudienceId is null OR @IntendedAudienceId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceIntId] FROM [dbo].[Audit.AudienceType_Orphan]
    where [ResourceIntId]= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.AudienceType_Orphan]
           ([RowId]
           ,[ResourceIntId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceIntId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @IntendedAudienceId > 0 begin
  print '[FormatId] = ' + convert(varchar, @IntendedAudienceId)

  set @NewId= NEWID()
  print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.IntendedAudience] base
	where base.[ResourceIntId] = @ResourceIntId
	And base.[AudienceId] = @IntendedAudienceId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.IntendedAudience]
	    ([RowId]
	    ,[AudienceId]
	    ,OriginalAudience
	    ,ResourceIntId)

    select
	    @NewId,
	    @IntendedAudienceId, 
	    @OriginalValue,
	    @ResourceIntId
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end



