USE [Isle_IOER]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

select count(*) from [Resource]
go

SELECT top 1000
 base.[ResourceId]
      ,[ClusterId]
      ,[ResourceUrl]
      ,[Title]
      ,[Description]
      ,[Keywords]
      ,[Subjects]
  FROM [Resource.Version_Summary] base
  Left join [dbo].[Resource.Cluster] rclu 
          on base.ResourceId = rclu.ResourceId And rclu.[ClusterId] = 91
where rclu.[ClusterId] is not null
  
  
GO

UPDATE [dbo].[Map.CareerCluster]
   SET [IsActive] = 1
 WHERE Id < 72
GO




EXECUTE [dbo].[Resource.Cluster_PopulateFromMapping] 0, 91



EXECUTE [dbo].[Resource.Cluster_PopulateResourceFromMapping] 450295, 0


*/

/*
Map clusters 
Loop thru defined mapping values, and apply to existing resources

Notes
- should join to resource version to only target resources already in the pathway
- add a date or means to only target recent additions rather than the whole database
*/
Alter PROCEDURE [dbo].[Resource.Cluster_PopulateResourceFromMapping]
            @ResourceIntId int
            ,@clusterId int

As
begin 
          
Declare 
@MapId int
,@MappedClusterId int
,@FilterValue varchar(200)
,@Filter varchar(200)
,@cntr int
--,@clusterId int
,@interval int
,@debugLevel int
,@affectedCount int
,@totalCount int
set @interval= 25
set @cntr= 0
--set @clusterId = 91
set @debugLevel= 10
set @affectedCount= 0
set @totalCount= 0

SET NOCOUNT ON;
-- ===============================================
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT  FilterValue, MappedClusterId, Id
      FROM   [Map.CareerCluster]
      where IsActive= 1 
      AND (MappedClusterId = @clusterId or @clusterId = 0)

	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @FilterValue, @MappedClusterId, @MapId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1  
		  
    select @cntr As Cntr,convert(varchar, @MappedClusterId) As ClusterId,@FilterValue	As Filter
    print convert(varchar, @cntr) + '. Cluster/Filter: ' + convert(varchar, @MappedClusterId) + ' - ' + @FilterValue		
		set @Filter = '%' + ltrim(rtrim(@FilterValue)) + '%'
		
    -- === via title =======================================================  		
    INSERT INTO [dbo].[Resource.Cluster]
               ([ResourceIntId]
               ,[ClusterId])
    SELECT distinct lrs.ResourceIntId,  @MappedClusterId
    FROM dbo.[Resource.Version_Summary] lrs 
    left join [dbo].[Resource.Cluster] rc on lrs.ResourceIntId = rc.ResourceIntId AND rc.ClusterId = @MappedClusterId
    where lrs.ResourceIntId = @ResourceIntId 
	AND rc.[ClusterId] is null
    And (lrs.Title like @Filter 
         OR lrs.[Description] like @Filter
         )
    set @affectedCount = @@rowcount
    if @affectedCount is not null AND @affectedCount > 0 begin
      set @totalCount= @totalCount + @affectedCount
      print '-> match found for cluster using filter. Count: '  
              + convert(varchar, @affectedCount)  + '. #' 
              + convert(varchar, @MappedClusterId) + ' - ' + @Filter
      --if ((@dupsCntr / @interval) * @interval) = @dupsCntr 
      
      end

    -- === via subjects =======================================================    
    INSERT INTO [dbo].[Resource.Cluster]
               ([ResourceIntId]
               ,[ClusterId])
    SELECT distinct lrs.ResourceIntId,  @MappedClusterId
    FROM dbo.[Resource.Subject] lrs 
    left join [dbo].[Resource.Cluster] rc on lrs.ResourceIntId = rc.ResourceIntId AND rc.ClusterId = @MappedClusterId
        where lrs.ResourceIntId = @ResourceIntId 
	AND rc.[ClusterId] is null
    And lrs.Subject like @Filter

	set @affectedCount = @@rowcount
    if @affectedCount is not null AND @affectedCount > 0 begin
      set @totalCount= @totalCount + @affectedCount
      print '$$$$$$$ match found on subjects for cluster. Count: '  
              + convert(varchar, @affectedCount)  + '. #' 
	  end
    
  	 
  	-- === via keywords =======================================================
    INSERT INTO [dbo].[Resource.Cluster]
               ([ResourceIntId]
               ,[ClusterId])
    SELECT distinct lrs.ResourceIntId,  @MappedClusterId
    FROM dbo.[Resource.Keyword] lrs 
    left join [dbo].[Resource.Cluster] rc on lrs.ResourceIntId = rc.ResourceIntId AND rc.ClusterId = @MappedClusterId
    where lrs.ResourceIntId = @ResourceIntId 
	AND rc.[ClusterId] is null
    And lrs.Keyword like @Filter

  	set @affectedCount = @@rowcount
    if @affectedCount is not null AND @affectedCount > 0 begin
      set @totalCount= @totalCount + @affectedCount
      print 'KKKKKKK match found on keywords for cluster. Count: '  
              + convert(varchar, @affectedCount)  + '. #' 
	  end
    
  	 
		FETCH NEXT FROM thisCursor INTO @FilterValue, @MappedClusterId, @MapId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  select 'Clusters created: ' + convert(varchar, @totalCount)
  
  
end

GO
GRANT EXECUTE ON [dbo].[Resource.Cluster_PopulateFromMapping] TO [public] AS [dbo]

go