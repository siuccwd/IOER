USE LearningRegistryCache_DEV_20121005
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 3/7/2013
-- Description:	Insert resource Like row
-- =============================================
CREATE PROCEDURE [Resource.LikeInsert]
	@ResourceId uniqueidentifier, @ResourceIntId int, @IsLike bit, @CreatedById int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [Resource.Like] (ResourceId, ResourceIntId, IsLike, Created, CreatedById)
	VALUES (@ResourceId, @ResourceIntId, @IsLike, GETDATE(), @CreatedById)
	
	SELECT @@IDENTITY AS Id
END
GO
GRANT EXECUTE ON [Resource.LikeInsert] TO PUBLIC
GO