USE Isle_IOER
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[PatronGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [PatronGet]
Go 
/*
PatronGet 0, 'IllinoisPathways','', ''

PatronGet 0, '','info@illinoisworknet.com', ''

PatronGet '','','','A7D110F7-AC7F-44B8-B2DE-CB1F1BFFC15C'
PatronGet 2, '', '', ''

*/
/* 
==================================================================
--- Get Procedure for [Patron] ---
Modifications
13-04-29 mparsons - added IsActive 
==================================================================
*/
CREATE PROCEDURE [PatronGet]
		@Id int,
		@UserName varchar(50),
		@Email varchar(100),
		@RowId varchar(40)


As
if @Id = 0            set @Id = null
if len(@RowId) = 0    set @RowId = null
if len(@Email) = 0    set @Email = null
if len(@UserName) = 0 set @UserName = null

if @id is null And @RowId is null And @Email is null And @UserName is null begin
  print 'no id provided'
  RAISERROR(' A valid id or rowId, or email address, or usernme must be supplied', 18, 1)      
  RETURN -1 
  end

SELECT 
    Id, 
    UserName,  [Password],
    FirstName, 
    LastName, 
    Email, 
    IsActive, 
    Created, 
    LastUpdated, 
    LastUpdatedById,
    RowId
FROM [Patron]

WHERE	
    (Id = @Id OR @Id is null)
And (UserName = @UserName OR @UserName is null)
And (Email = @Email OR @Email is null)
And (RowId = @RowId OR @RowId is null)
GO
grant execute on [PatronGet] to public 
Go
