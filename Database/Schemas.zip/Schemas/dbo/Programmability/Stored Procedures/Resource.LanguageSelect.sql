USE Isle_IOER
GO

/****** Object:  StoredProcedure [dbo].[Resource.LanguageSelect]    Script Date: 08/29/2012 14:23:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* =============================================
Description:      [Resource.LanguageSelect]
------------------------------------------------------
Modifications
  2013-08-22 mparsons - dropped resourceId
=============================================
*/
ALTER PROCEDURE [dbo].[Resource.LanguageSelect]
  @ResourceIntId int,
	@OriginalLanguage varchar(100)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  IF @OriginalLanguage = ''       SET @OriginalLanguage = NULL
  IF @ResourceIntId = 0   SET @ResourceIntId = NULL
  If  @ResourceIntId = NULL begin
    RAISERROR('Error - require resourceIntId', 18, 1) 
    return -1
    end
    
  SELECT RowId, ResourceIntId, OriginalLanguage, LanguageId
  
  FROM [Resource.Language]
  WHERE 
      (ResourceIntId = @ResourceIntId OR @ResourceIntId IS NULL)
  AND (OriginalLanguage = @OriginalLanguage OR @OriginalLanguage IS NULL)
   
END

GO


grant execute on [Resource.LanguageSelect] to public
go