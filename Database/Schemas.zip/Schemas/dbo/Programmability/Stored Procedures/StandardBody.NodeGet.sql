
--- Get Single Procedure for [StandardBody.Node] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[StandardBody.NodeGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [StandardBody.NodeGet]
Go
/*
 [StandardBody.NodeGet] 1, '', ''
[StandardBody.NodeGet] 0, '', ''

[StandardBody.NodeGet] 0, 'http://asn.jesandco.org/resources/S114343C','',''

[StandardBody.NodeGet] 0,'','','http://purl.org/ASN/resources/S114343D'


*/
CREATE PROCEDURE [StandardBody.NodeGet]
    @Id int,
    @StandardUrl varchar(200),
    @NotationCode varchar(200),
    @AltUrl varchar(200)
As
if @Id = 0 set @Id = NULL
If @NotationCode = ''		SET @NotationCode = NULL 
if @StandardUrl = '' set @StandardUrl = NULL
If @AltUrl = ''		SET @AltUrl = NULL 

SELECT     
    Id, 
    ParentId, 
    LevelType, 
    NotationCode, 
    Description, 
    StandardUrl, 
    AltUrl, 
    StandardGuid, GradeLevels,
    WarehouseTotal
FROM [StandardBody.Node]
WHERE 
    (Id = @Id OR @Id is null)
and (StandardUrl = @StandardUrl OR @StandardUrl is null)
and (NotationCode = @NotationCode OR @NotationCode is null)
and (AltUrl = @AltUrl OR @AltUrl is null)

GO
grant execute on [StandardBody.NodeGet] to Public
Go
 
 