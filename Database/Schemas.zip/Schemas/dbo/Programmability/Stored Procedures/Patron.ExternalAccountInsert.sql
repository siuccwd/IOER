--- Insert Procedure for [Patron.ExternalAccount] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Patron.ExternalAccountInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Patron.ExternalAccountInsert]
Go

CREATE PROCEDURE [Patron.ExternalAccountInsert]
            @PatronId int,  
            @ExternalSiteId int, 
            @LoginId varchar(100), 
            @Token varchar(50)
As
If @PatronId = 0   SET @PatronId = NULL 
If @ExternalSiteId = 0   SET @ExternalSiteId = NULL 
If @LoginId = ''   SET @LoginId = NULL 
--If @Password = ''   SET @Password = NULL 
If @Token = ''   SET @Token = NULL 

INSERT INTO [Patron.ExternalAccount] (

    PatronId, 
    ExternalSiteId, 
    LoginId, 
    Token
)
Values (

    @PatronId, 
    @ExternalSiteId, 
    @LoginId, 
    @Token
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Patron.ExternalAccountInsert] to public
Go
 