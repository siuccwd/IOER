USE [LearningRegistryCache_DEV_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.EvaluationInsert]    Script Date: 05/09/2013 14:51:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Resource.EvaluationInsert]
            @ResourceIntId int, 
            @CreatedById int, 
            @StandardId int, 
            @RubricId int, 
            @Value float, 
            @ScaleMin int, 
            @ScaleMax int, 
            @CriteriaInfo varchar(500)
As
If @ResourceIntId = 0   SET @ResourceIntId = NULL 
If @CreatedById = 0   SET @CreatedById = NULL 
If @StandardId = 0   SET @StandardId = NULL 
If @RubricId = 0   SET @RubricId = NULL 
If @Value = 0   SET @Value = NULL 
If @ScaleMin = 0   SET @ScaleMin = NULL 
If @ScaleMax = 0   SET @ScaleMax = NULL 
If @CriteriaInfo = ''   SET @CriteriaInfo = NULL 
INSERT INTO [Resource.Evaluation] (

    ResourceIntId, 
    Created, 
    CreatedById, 
    StandardId, 
    RubricId, 
    Value, 
    ScaleMin, 
    ScaleMax, 
    CriteriaInfo
)
Values (

    @ResourceIntId, 
    GETDATE(), 
    @CreatedById, 
    @StandardId, 
    @RubricId, 
    @Value, 
    @ScaleMin, 
    @ScaleMax, 
    @CriteriaInfo
)
 
select SCOPE_IDENTITY() as Id

GO


