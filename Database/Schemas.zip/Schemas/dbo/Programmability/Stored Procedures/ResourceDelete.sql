USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[ResourceDelete]    Script Date: 01/08/2013 14:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/24/2012
-- Description:	Delete a resource
-- Mods
-- 13-04-25 mparsons - updated to allow by id or rowId
-- =============================================
ALTER PROCEDURE [dbo].[ResourceDelete]
	@Id int,
	@RowId varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  If @Id = 0          SET @Id = NULL
  If @RowId = ''      SET @RowId = NULL 
  if @Id is null AND @RowId is null begin
	  print 'ResourceGet - invalid request'
	  RAISERROR('ResourceGet - invalid request. Require Source @Id, OR @RowId', 18, 1)    
	  RETURN -1 
	  end
  
  DELETE FROM [Resource]
  WHERE (RowId = @RowId OR @RowId is null)
  AND (Id = @Id OR @Id is null)
END
