USE Isle_IOER
GO

--- Get Procedure for Resource.Cluster---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.ClusterSelect2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ClusterSelect2]
Go

/*
[Resource.ClusterSelect2] 8



*/
CREATE PROCEDURE [Resource.ClusterSelect2]
    @ResourceIntId int
As
SELECT ResourceIntId
      ,base.[ClusterId], cc.IlPathwayName As Cluster
  FROM [dbo].[Resource.Cluster] base
  inner join CareerCluster cc on base.ClusterId = cc.Id
where base.ResourceIntId = @ResourceIntId  
Order by cc.IlPathwayName

GO

grant execute on [Resource.ClusterSelect2] to public 
Go