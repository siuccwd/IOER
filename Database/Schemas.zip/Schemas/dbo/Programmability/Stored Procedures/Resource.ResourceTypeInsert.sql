USE Isle_IOER
GO

/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeInsert]    Script Date: 07/02/2012 09:34:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


-- ====================================================================

DECLARE @RC int, @ResourceIntId int, @ResourceTypeId int, @OriginalValue varchar(100),@TotalRows     int

set @ResourceTypeId= 0
set @ResourceIntId = 10
set @OriginalValue = 'Syllabus'

set @ResourceIntId = 1
set @OriginalValue = 'Student Guide'



EXECUTE @RC = [dbo].[Resource.ResourceTypeInsert] 
   @ResourceIntId, @ResourceTypeId
  ,@OriginalValue
  ,22
  

GO


*/
/* =============================================
Description:      [Resource.ResourceTypeInsert]
------------------------------------------------------
Modifications
12-09-19 mparsons - added duplicates check (multiple inputs can map to same output)
13-08-22 mparsons - dropped resourceId
=============================================

*/
Alter PROCEDURE [dbo].[Resource.ResourceTypeInsert]
		  @ResourceIntId int,
          @ResourceTypeId	int,
          @OriginalValue varchar(100)
          ,@CreatedById int
As

declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @ErrorMsg varchar(100)
--, @CreatedById int
--set @CreatedById = 0

if @OriginalValue = '' set @OriginalValue = NULL
If @ResourceTypeId < 1		SET @ResourceTypeId = NULL 
If @CreatedById = 0		SET @CreatedById = NULL
else set @SuppressOutput  = 0
If @ResourceTypeId < 1		SET @ResourceTypeId = NULL 
  
If @OriginalValue is NULL and @ResourceTypeId is null begin
  print 'no values provided'
  return -1
  end    


set @IsDuplicate= 0
--set @TotalRows= 0
	set @ErrorMsg = ''
-- ==================================================================
if @ResourceTypeId is null begin
	print 'insert via ResourceType'
	 -- so first check if mapping exists
	SELECT @ResourceTypeId = isnull(base.id,0)
	  FROM [dbo].[Codes.ResourceType] base
	  inner join [dbo].[Map.ResourceType] mapper on base.Id = mapper.[CodeId]
	  where mapper.LRValue = @OriginalValue
   
	If @ResourceTypeId is null OR @ResourceTypeId = 0	begin	
		--no mapping, write to exceptions table and return
		-- when called from interface, may need real message?
		if NOT exists(SELECT [OriginalValue] FROM [dbo].[Audit.ResourceType_Orphan] 
		where [ResourceIntId]= @ResourceIntId and [OriginalValue] = @OriginalValue) begin
		set @ErrorMsg = 'No mapping was found for parameter, writing to audit table'
		  print '@@ no mapping, writing to audit table: ' + @OriginalValue
		  INSERT INTO [dbo].[Audit.ResourceType_Orphan]
			   ([RowId]
			   ,[ResourceIntId]
			   ,[OriginalValue])
		  VALUES
			   (newId()
			   ,@ResourceIntId
			   ,@OriginalValue)
      
		  end    
		else begin
		  print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
		  set @ErrorMsg = 'No mapping was found for parameter, the value already exists in audit table'
		  end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate, @ErrorMsg
    end
	end

if @ResourceTypeId > 0 begin
  print '[ResourceTypeId] = ' + convert(varchar, @ResourceTypeId)

  set @NewId= NEWID()
  print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.ResourceType] base
	where ( base.[ResourceIntId] = @ResourceIntId )
	And base.[ResourceTypeId] = @ResourceTypeId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
		  set @NewId= @exists
		  set @IsDuplicate= 1
		  print 'found duplicate'
		  end
	else begin
		INSERT INTO [dbo].[Resource.ResourceType]
			([RowId]
			,[ResourceIntId]
			,[ResourceTypeId]
			,[OriginalType]
			,CreatedById)

		select
			@NewId,
			@ResourceIntId,
			@ResourceTypeId, 
			@OriginalValue,
			@CreatedById
		end
  --set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As sDuplicate, @ErrorMsg As [Message]    
end


GO
grant execute on [Resource.ResourceTypeInsert] to public
go



/*
declare 
@ActivitiesLabs int,
@Assessments int,
@AudioLectures int,
@CareerInformation int,
@CurriculumStandards int,
@DiscussionForums int,
@FullCourse int,
@Games int,
@HomeworkAssignments int,
@LectureNotes int,
@LessonPlans int,
@Other int,
@Readings int,
@Reference int,
@Simulations int,
@Syllabi int,
@TeachingLearningStrategies int,
@Textbooks int,
@Tools int,
@TrainingMaterials int,
@VideoLectures int


Set @ActivitiesLabs = 1
Set @Assessments = 2
Set @AudioLectures = 3
Set @CareerInformation = 21
Set @CurriculumStandards = 4
Set @DiscussionForums = 5	
Set @FullCourse = 6
Set @Games = 7
Set @HomeworkAssignments = 8
Set @LectureNotes = 9
Set @LessonPlans = 10
Set @Other = 18
Set @Readings = 11
Set @Reference =23
Set @Simulations = 12
Set @Syllabi = 13
Set @TeachingLearningStrategies = 14
Set @Textbooks = 15
Set @Tools = 19
Set @TrainingMaterials = 16
Set @VideoLectures = 17
	
-- =====================================================

Set @ResourceTypeId = case
when @OriginalValue = 'Abstract' then @Readings
when @OriginalValue = 'Activity' then @ActivitiesLabs
when @OriginalValue = 'Annotation' then @Readings
when @OriginalValue = 'Answer Key' then @ActivitiesLabs
when @OriginalValue = 'Article' then @Readings
when @OriginalValue = 'Ask-an-Expert' then @DiscussionForums
when @OriginalValue = 'Assessment Material' then @Assessments
when @OriginalValue = 'Audio/Visual' then @VideoLectures
when @OriginalValue = 'Award/Recognition/Scholarship' then @Other
when @OriginalValue = 'Bibliography' then @Reference
when @OriginalValue = 'Book' then @Textbooks
when @OriginalValue = 'Broadcast' then @AudioLectures
when @OriginalValue = 'Calculation or Tool' then @Tools
when @OriginalValue = 'Call for Participation' then @Other
when @OriginalValue = 'Career Information' then @CareerInformation
when @OriginalValue = 'Case Study' then @Reference
when @OriginalValue = 'Classification Key' then @Reference
when @OriginalValue = 'Code' then @Reference
when @OriginalValue = 'Collection' then @Reference
when @OriginalValue = 'Community' then @Other
when @OriginalValue = 'Conference' then @Other
when @OriginalValue = 'Course' then @FullCourse
when @OriginalValue = 'Curriculum' then @Reference
when @OriginalValue = 'Database' then @Reference
when @OriginalValue = 'Dataset' then @Reference
when @OriginalValue = 'Demonstration' then @ActivitiesLabs
when @OriginalValue = 'Educational Standard' then @CurriculumStandards
when @OriginalValue = 'Event' then @Other
when @OriginalValue = 'Exhibit' then @Other
when @OriginalValue = 'Experiment/Lab Activity' then @ActivitiesLabs
when @OriginalValue = 'FAQ' then @Reference
when @OriginalValue = 'Field Trip' then @Other
when @OriginalValue = 'Form' then @Other
when @OriginalValue = 'Forum' then @DiscussionForums
when @OriginalValue = 'Game' then @Games
when @OriginalValue = 'Glossary/Index' then @Reference
when @OriginalValue = 'Graph' then @Reference
when @OriginalValue = 'Illustration' then @Reference
when @OriginalValue = 'Image' then @Reference
when @OriginalValue = 'Image/Image Set' then @Reference
when @OriginalValue = 'Instructional Material' then @TeachingLearningStrategies
when @OriginalValue = 'Instructional Strategy' then @TeachingLearningStrategies
when @OriginalValue = 'Instructor Guide/Manual' then @TeachingLearningStrategies
when @OriginalValue = 'Interactive Simulation' then @Simulations
when @OriginalValue = 'InteractiveResource' then @TeachingLearningStrategies
when @OriginalValue = 'Learning/Research Opportunity' then @TeachingLearningStrategies
when @OriginalValue = 'Lecture/Presentation' then @LectureNotes
when @OriginalValue = 'Lesson/Lesson Plan' then @LessonPlans
when @OriginalValue = 'List/Table' then @Reference
when @OriginalValue = 'Listserv' then @Reference
when @OriginalValue = 'Map' then @Reference
when @OriginalValue = 'Model' then @Reference
when @OriginalValue = 'Movie/Animation' then @VideoLectures
when @OriginalValue = 'Music' then @Reference
when @OriginalValue = 'News' then @Readings
when @OriginalValue = 'Nonfiction Reference' then @Reference
when @OriginalValue = 'Numerical Model' then @Reference
when @OriginalValue = 'Observed Data' then @Reference
when @OriginalValue = 'Periodical' then @Readings
when @OriginalValue = 'Photograph' then @Reference
when @OriginalValue = 'Policy' then @Reference
when @OriginalValue = 'Problem Set' then @Reference
when @OriginalValue = 'Proceedings' then @Readings
when @OriginalValue = 'Project' then @Reference
when @OriginalValue = 'Proposal' then @Reference
when @OriginalValue = 'Reference Material' then @Reference
when @OriginalValue = 'Remotely Sensed Data' then @Reference
when @OriginalValue = 'Report' then @Readings
when @OriginalValue = 'Rubric' then @Syllabi
when @OriginalValue = 'Scientific Visualization' then @Reference
when @OriginalValue = 'Search Engine' then @Reference
when @OriginalValue = 'Service' then @Reference
when @OriginalValue = 'Simulation' then @Simulations
when @OriginalValue = 'Software' then @Reference
when @OriginalValue = 'Sound' then @Reference
when @OriginalValue = 'Specimen' then @Reference
when @OriginalValue = 'Student Guide' then @LessonPlans
when @OriginalValue = 'Syllabus' then @Syllabi
when @OriginalValue = 'Test' then @Assessments
when @OriginalValue = 'Text' then @Readings
when @OriginalValue = 'Textbook' then @Textbooks
when @OriginalValue = 'Tool' then @Tools
when @OriginalValue = 'Tutorial' then @Readings
when @OriginalValue = 'Unit of Instruction' then @LectureNotes
when @OriginalValue = 'Voice Recording' then @AudioLectures
when @OriginalValue = 'Weblog' then @Reference
when @OriginalValue = 'Wiki' then @Reference
when @OriginalValue = 'Workshop' then @ActivitiesLabs
Else @Other end 

print '@OriginalValue = ' + @OriginalValue + ', @ResourceTypeId= ' + convert(varchar, @ResourceTypeId)
	
INSERT INTO [dbo].[Resource.ResourceType]
	([RowId]
	,[ResourceId]
	,[ResourceTypeId]
	,[OriginalType])

select
	@NewId,
	@ResourceId, 
	@ResourceTypeId, 
	@OriginalValue

select @NewId as Id
*/

