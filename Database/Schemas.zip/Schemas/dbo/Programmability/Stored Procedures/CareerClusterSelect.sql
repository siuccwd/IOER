

/****** Object:  StoredProcedure [dbo].CareerClusterSelect    Script Date: 10/09/2012 18:58:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
CareerClusterSelect 0, ''

CareerClusterSelect 11, ''

*/
-- =============================================
-- Author:		Michael Parsons
-- get list of IL Pathways career clusters
-- Modifications
-- 
-- =============================================
Alter PROCEDURE [dbo].CareerClusterSelect
	@ClusterId		      int,
  @IlPathwayChannel  varchar(50)
AS
BEGIN
	SET NOCOUNT ON;
  If @ClusterId = 0				      SET @ClusterId = null
  If @IlPathwayChannel = ''			SET @IlPathwayChannel = null
  SELECT 
      [Id]
      ,IlPathwayName As Title
      ,IlPathwayName + ' (' + convert(varchar, isnull(WareHouseTotal,0)) + ')' As FormattedTitle
      ,[prefix], [Description]
      ,IlPathwayChannel

    FROM [CareerCluster]
  Where 
  (IsActive = 1 and IsIlPathway = 1)
  And (Id = @ClusterId		or @ClusterId is null)
  And (IlPathwayChannel = @IlPathwayChannel		or @IlPathwayChannel is null)
  Order by IlPathwayName
END

GO

GRANT EXECUTE ON [dbo].CareerClusterSelect TO public
GO

