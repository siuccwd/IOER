USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Patron.RecoverPassword]    Script Date: 02/26/2013 22:49:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Patron.RecoverPassword] 'IllinoisPathways'


[Patron.RecoverPassword] 'mparsons'

*/
Alter PROCEDURE [dbo].[Patron.RecoverPassword]
		@Lookup varchar(100)


As
if len(@Lookup) = 0    set @Lookup = null

if @Lookup is null begin
  print 'no @Lookup provided'
  RAISERROR(' A valid lookup must be supplied', 18, 1)    
  RETURN -1 
  end

SELECT 
    Id, 
    UserName,  [Password],
    FirstName, 
    LastName, 
    Email, 
    IsActive, 
    Created, 
    LastUpdated, 
    LastUpdatedById,
    RowId
FROM [Patron]

WHERE	
    (UserName = @Lookup OR Email = @Lookup)
--AND IsActive = 1
-- not sure if IsActive should be checked here, or let interface
-- for example user may be attempting password recovery on an unconfirmed account
-- Actually in the latter case, it would be OK. The recover password code, would have to ensure IsActive is updated!!

go 
grant execute on [Patron.RecoverPassword] to public

