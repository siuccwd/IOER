USE LearningRegistryCache_DEV_20121005
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 3/7/2013
-- Description:	Get Likes/Dislikes for a resource by Id, Date Range, IsLike
-- NOTE: If IsLike is NULL, the proc will pull for both
-- =============================================
CREATE PROCEDURE [Resource.LikeSelect]
	@ResourceIntId int, @StartDate datetime, @EndDate datetime, @IsLike varchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @IsLike = 'both' SET @IsLike = NULL
	IF @IsLike = 'like' SET @IsLike = 'True'
	IF @IsLike = 'dislike' SET @IsLike = 'False'
	SELECT Id, ResourceId, ResourceIntId, IsLike, Created, CreatedById
	FROM [Resource.Like]
	WHERE (ResourceIntId = @ResourceIntId OR @ResourceIntId IS NULL) AND
		(Created >= @StartDate AND Created <= @EndDate) AND
		(IsLike = @IsLike OR @IsLike IS NULL)
END
GO
GRANT EXECUTE ON [Resource.LikeSelect] TO PUBLIC
GO