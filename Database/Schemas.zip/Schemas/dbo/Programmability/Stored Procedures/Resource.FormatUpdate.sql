USE [LearningRegistryCache_Dev]
GO

/****** Object:  StoredProcedure [dbo].[Resource.FormatUpdate]    Script Date: 08/29/2012 14:14:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Resource.FormatUpdate]
	@RowId uniqueidentifier,
	@CodeId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [Resource.Format]
    SET CodeId = @CodeId
    WHERE RowId = @RowId
END

GO


grant execute on [Resource.FormatUpdate] to public
go