USE [LearningRegistryCache_Dev_20121005]
GO

/****** Object:  StoredProcedure [dbo].[Resource.AssessmentType_SelectedCodes]    Script Date: 03/19/2013 18:03:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
[Resource.AssessmentType_SelectedCodes] 444662
*/
CREATE PROCEDURE [dbo].[Resource.AssessmentType_SelectedCodes]
    @ResourceIntId int

As
SELECT distinct
	code.Id, code.Title, code.[Description]
	,CASE
		WHEN rpw.ResourceIntId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.AssessmentType] code
Left Join dbo.[Resource.AssessmentType] rpw on code.Id = rpw.AssessmentTypeId
		and rpw.ResourceIntId = @ResourceIntId
		where code.IsActive = 1
Order by 2

GO


