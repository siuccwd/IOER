USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[ResourceVersion_InactivateDups]    Script Date: 2/1/2014 1:14:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
--=======================================================================
--start: 1769679
select count(*) FROM [dbo].[Resource.Version]
--=======================================================================
SELECT     TOP (1000) Id, ResourceIntId, Title, IsActive, Description, Imported, Modified, Publisher, Creator, Submitter, AccessRightsId, AccessRights, Rights, DocId
FROM         [Resource.Version]
WHERE     (ResourceIntId IN
                          (SELECT     r.Id
                            FROM          Resource AS r INNER JOIN
                                                   [Resource.Version] AS rv ON r.Id = rv.ResourceIntId
                            WHERE      (r.IsActive = 1 AND rv.IsActive = 1)
                            GROUP BY r.Id
                            HAVING      (COUNT(*) > 1)
							)
)
ORDER BY ResourceIntId, Id DESC

  
--=======================================================================


EXECUTE [dbo].[ResourceVersion_InactivateDups] 1000, 1

EXECUTE [dbo].[ResourceVersion_InactivateDups] 50000, 1
go
EXECUTE [dbo].[ResourceVersion_InactivateDups] 600, 0, 1, 1

*/

/*
cleanup Versions

*/
Alter PROCEDURE [dbo].[ResourceVersion_InactivateDups]
            @MaxRecords int
			,@DoingUpdate bit
As
begin 
          
Declare 
@ShowingAllRecords bit
,@cntr int

,@KeysCount int
,@StartingKeyId int
,@interval int
,@debugLevel int
,@affectedCount int
,@totalCount int
,@PrevResourceIntId int
,@BaseId int
,@BaseDesc varchar(max)
,@BaseTitle varchar(300)
,@Id int
,@ResourceIntId int
,@Title varchar(300)
,@Desc varchar(max)
,@IsActive bit
,@HoldDesc varchar(max)
,@HoldTitle varchar(300)

set @ShowingAllRecords= 0
set @interval= 25
set @cntr= 0
--set @clusterId = 91

set @BaseId = 0
set @PrevResourceIntId= 0
set @HoldTitle = ''
set @HoldDesc = ''

--set @DoingUpdate = 0
set @debugLevel= 10
set @affectedCount= 0
set @totalCount= 0

if @MaxRecords > 10000
	set @ShowingAllRecords= 0

-- ===============================================
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT  Id, ResourceIntId, Title, [Description], IsActive
		FROM [Resource.Version]
		where 
		ResourceIntId IN
        (	SELECT     r.Id
            FROM Resource AS r 
			INNER JOIN [Resource.Version] AS rv ON r.Id = rv.ResourceIntId
            WHERE      (r.IsActive = 1 AND rv.IsActive = 1)
            GROUP BY r.Id
            HAVING      (COUNT(*) > 1)
		)
		ORDER BY ResourceIntId, Id DESC

	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @Id, @ResourceIntId, @Title,@Desc,@IsActive
	WHILE @@FETCH_STATUS = 0 BEGIN
		set @cntr = @cntr+ 1
		if @MaxRecords > 0 AND @cntr > @MaxRecords begin
			print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
			select 'exiting',  getdate()
			set @cntr = @cntr - 1
			BREAK
			End	  

		if  @PrevResourceIntId <> @ResourceIntId begin
			-- NOTE rvId sorts desc, so keep first one - no action
			print convert(varchar, @cntr)	
				+ '. New-ResId: ' + convert(varchar, @ResourceIntId) 	
				+ '. Last-Id: ' + convert(varchar, @Id) 	
				+ '. Title: ' + @Title	

			set @PrevResourceIntId = @ResourceIntId
			set @BaseId = @Id
			end
		else begin
			if @ShowingAllRecords = 1 begin
				print convert(varchar, @cntr)	
					+ '. Nxt-ResId: ' + convert(varchar, @ResourceIntId) 	
					+ '. Next-Id: ' + convert(varchar, @Id) 	
					+ '. Title: ' + @Title	
				end

			if @DoingUpdate= 1 begin
				UPDATE [dbo].[Resource.Version]
					SET [IsActive] = 0
				where Id = @Id
							
				set @totalCount= @totalCount+1
			end
		end

		FETCH NEXT FROM thisCursor INTO @Id, @ResourceIntId, @Title,@Desc,@IsActive
	END

	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
	select 'processed records: ' + convert(varchar, @cntr)
	select 'Versions inactivated: ' + convert(varchar, @totalCount)

end
