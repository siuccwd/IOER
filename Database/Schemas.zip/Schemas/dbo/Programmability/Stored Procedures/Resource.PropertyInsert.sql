 
 
 
--- Insert Procedure for Resource.Property---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.PropertyInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.PropertyInsert]
Go
/*
declare @PropertyName varchar(100),@NewId uniqueidentifier
set @NewId= NEWID()
set @PropertyName = 'subject'

Select
	@NewId,
    '@ResourceId', 
    @PropertyName, 
    '@Value', 
    rpt.Id	--PropertyTypeId
from [Resource.Property] base    
left Join [Codes.ResPropertyType] rpt on @PropertyName = rpt.Title

8B5D62B9-CCBF-4E01-8177-DB746540F397

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@PropertyTypeId int
DECLARE @PropertyName varchar(100), @Value varchar(500)

set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @PropertyTypeId = 0
set @PropertyName = 'subjecterr'
set @Value = 'test2'

EXECUTE @RC = [LearningRegistryCache2].[dbo].[Resource.PropertyInsert] 
   @ResourceId
  ,@PropertyTypeId
  ,@PropertyName
  ,@Value
GO

-- 2013-03-13 jgrimmer - Added ResourceIntId
*/
CREATE PROCEDURE [Resource.PropertyInsert]
            @ResourceId uniqueidentifier, 
            @PropertyTypeId int,
            @PropertyName varchar(100), 
            @Value varchar(500),
            @ResourceIntId

As
if @PropertyName is null OR LEN(@PropertyName) = 0 set @PropertyName = 'other'
If @PropertyTypeId = 0		SET @PropertyTypeId = NULL 
  
declare @NewId uniqueidentifier
set @NewId= NEWID()
print '@NewId: ' + convert(varchar(50), @NewId)

if @PropertyTypeId is null begin
	print 'insert via PropertyName'
	select @PropertyTypeId = isnull(id,0) from  [Codes.ResPropertyType]  rpt 
	where rpt.Title = @PropertyName
	
	If @PropertyTypeId is null OR @PropertyTypeId = 0	begin	
		SET @PropertyTypeId = 8 
		print 'the property name was not found: ' + @PropertyName
		end
	end
else begin
	print 'insert via @PropertyTypeId'
	end
	
	
	INSERT INTO [Resource.Property]
	(
		RowId,
		ResourceId, 
		PropertyTypeId,
		Value,
		ResourceIntId
	)
	Values (
		@NewId,
		@ResourceId, 
		@PropertyTypeId, 
		@Value,
		@ResourceIntId
	)

--)
 
select @NewId as Id
GO
grant execute on [Resource.PropertyInsert] to public
Go
 