USE [Isle_IOER]
GO
/****** Object:  StoredProcedure [dbo].[Patron.ProfileUpdate]    Script Date: 2/7/2014 11:48:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
	--confirm
	SELECT [Id] As UserId,[FullName],[Email],[JobTitle],[RoleProfile],[OrganizationId],Organization,[PublishingRole],[Created]      ,[LastUpdated]
	  FROM [Isle_IOER].[dbo].[Patron_Summary]
	  WHERE Id = @UserId
*/
Create PROCEDURE [dbo].[Patron.ProfileAssignOrgId]
        @UserId int,
        @OrganizationId int,
		@OrgMbrTypeId int 
As

If @OrganizationId = 0   SET @OrganizationId = NULL 
If @OrgMbrTypeId = 0   SET @OrgMbrTypeId = 2 

if @UserId is not null AND @UserId > 0 begin
	print 'check for proflie'
	if NOT exists( SELECT [UserId] FROM [dbo].[Patron.Profile] where [UserId]= @UserId)  begin
		--do insert
		INSERT INTO [dbo].[Patron.Profile] ([UserId] ,[OrganizationId],[CreatedById] ,[LastUpdatedId])
		 VALUES (@UserId ,@OrganizationId ,@UserId,@UserId)
      end    
    else begin
		--do update
		print 'Assigning user to org '
		UPDATE [dbo].[Patron.Profile]
		   SET [OrganizationId] = @OrganizationId,
		   LastUpdated = getdate()
		 WHERE UserId = @UserId
		 end

	end
else begin 
	print 'error, user was not found, not assigned to org'
	end
go
grant execute on [Patron.ProfileAssignOrgId] to public
go
