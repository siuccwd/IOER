USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.GradeLevelSelect]    Script Date: 04/08/2013 13:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.GradeLevelSelect] 1518
*/
Create PROCEDURE [dbo].[Resource.GradeLevelSelect]
    @ResourceIntId int

As
SELECT [Id]
      ,[ResourceIntId]
      ,[GradeLevelId]
      ,[OriginalLevel]
      ,[Created]
      ,[CreatedById]
      ,[PathwaysEducationLevelId]
  FROM [dbo].[Resource.GradeLevel]
  WHERE (ResourceIntId = @ResourceIntId)
GO



go
grant execute on [Resource.GradeLevelSelect] to public
go




