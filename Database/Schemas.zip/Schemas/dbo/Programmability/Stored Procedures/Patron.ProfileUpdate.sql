use Isle_IOER
go

if exists (select * from dbo.sysobjects where id = object_id(N'[Patron.ProfileUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Patron.ProfileUpdate]
Go
/*
USE [Isle_IOER]
GO

SELECT [Id]
      ,[UserName]
      ,[FirstName]
      ,[LastName]
      ,[FullName]
      ,[SortName]
      ,[Email]
      ,[JobTitle]
      ,[RoleProfile]
      ,[OrganizationId]
      ,[Organization]
      ,[PublishingRoleId]
      ,[PublishingRole]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[Patron_Summary]
where OrganizationId is null


DECLARE @RC int, @UserId int, @JobTitle varchar(100),@PublishingRoleId int, @RoleProfile varchar(500), @OrganizationId int

-- TODO: Set parameter values here.
Set @UserId = 244
Set @JobTitle = ' test set of insert'
Set @PublishingRoleId = 1
Set @RoleProfile = ''
Set @OrganizationId = 3

-- TODO: Set parameter values here.

EXECUTE @RC = [dbo].[Patron.ProfileUpdate] 
   @UserId
  ,@JobTitle
  ,@PublishingRoleId
  ,@RoleProfile
  ,@OrganizationId
GO


EXECUTE @RC = [dbo].[Patron.ProfileUpdate] 
   @UserId
  ,@JobTitle
  ,@PublishingRoleId
  ,@RoleProfile
  ,@OrganizationId
GO




*/
--- Update Procedure for [Patron.Profile] ---
--Modifications
--14-02-07 mparsons - add existance check, as profile may not exist yet
CREATE PROCEDURE [Patron.ProfileUpdate]
        @UserId int,
        @JobTitle varchar(100), 
        @PublishingRoleId int, 
        @RoleProfile varchar(500), 
        @OrganizationId int 
		,@ImageUrl varchar(200)
As
--declare @ImageUrl varchar(200)
--set @ImageUrl= ''

If @JobTitle = ''   SET @JobTitle = NULL 
If @PublishingRoleId = 0   SET @PublishingRoleId = NULL 
If @RoleProfile = ''   SET @RoleProfile = NULL 
If @ImageUrl = ''   SET @ImageUrl = NULL 
If @OrganizationId = 0   SET @OrganizationId = NULL 
--If @LastUpdatedId = 0   SET @LastUpdatedId = NULL 

print 'check for proflie'
	if NOT exists( SELECT [UserId] FROM [dbo].[Patron.Profile] where [UserId]= @UserId)  begin
		--do insert
		 INSERT INTO [Patron.Profile] (
			UserId,
			JobTitle, 
			PublishingRoleId, 
			RoleProfile, 
			OrganizationId, 
			CreatedById, 
			LastUpdatedId,
			ImageUrl
		)
		Values (
			@UserId,
			@JobTitle, 
			@PublishingRoleId, 
			@RoleProfile, 
			@OrganizationId, 
			@UserId, 
			@UserId,
			@ImageUrl
		)

      end    
    else begin
		--do update
		UPDATE [Patron.Profile] 
		SET 
			JobTitle = @JobTitle, 
			PublishingRoleId = @PublishingRoleId, 
			RoleProfile = @RoleProfile, 
			ImageUrl= @ImageUrl,
			OrganizationId = @OrganizationId, 
			LastUpdated = getdate()
			--,LastUpdatedId = @LastUpdatedId
		WHERE UserId = @UserId
		end
GO
grant execute on [Patron.ProfileUpdate] to public
Go
 
 