USE Isle_IOER
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 11/14/2013
-- Description:	Get age range record based on ResourceIntId
-- =============================================
CREATE PROCEDURE [Resource.AgeRangeGetByIntId]
	@ResourceIntId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT Id, ResourceIntId, FromAge, ToAge, OriginalLevel,
		Created, CreatedById
	FROM [Resource.AgeRange]
	WHERE ResourceIntId = @ResourceIntId
END
GO
