﻿USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceSelect2]    Script Date: 7/19/2013 1:58:09 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[Resource.IntendedAudienceSelect2]
	@ResourceIntId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    IF @ResourceIntId = 0 SET @ResourceIntId = NULL
    
    SELECT RowId, ResourceIntId, AudienceId, OriginalAudience
    ,ResourceId
    FROM [Resource.IntendedAudience]
    WHERE (ResourceIntId = @ResourceIntId)
END
go
grant execute on [Resource.IntendedAudienceSelect2] to public
go
