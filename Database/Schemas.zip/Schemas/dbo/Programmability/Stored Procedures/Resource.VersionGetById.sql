USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionGet]    Script Date: 03/23/2013 16:37:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select top 10 * from [Resource.Version]


exec [Resource.VersionGetById] 213385

[Resource.VersionGetById] 445731

--has requirements
[Resource.VersionGetById] 1149

*/


-- =============================================
-- Description:	Get Resource info from ResourceVersion 

-- 13-03-23 mparsons - added 
-- 13-03-28 mparsons - added Requirements, fixed InteractivityTypeId
-- =============================================
Alter PROCEDURE [dbo].[Resource.VersionGetById]
	@Id int
AS
BEGIN

	SET NOCOUNT ON;

	SELECT 
	  base.RowId,
	  base.Id,
    NULL As ResourceId, 
    res.Id As ResourceIntId,
		res.ResourceUrl,
		res.ViewCount,
		res.FavoriteCount,
		base.DocId,
		base.IsActive,
		res.IsActive As ResourceIsActive,
		base.Title, base.SortTitle,
		base.[Description],
		ISNULL(base.Publisher,'Unknown') AS Publisher,
		ISNULL(base.Creator,'Unknown') AS Creator,
		ISNULL(base.Rights,'Unknown') AS Rights,
		AccessRightsId,
    isnull(codes.title, 'Unknown') As AccessRights,
    
    isnull(InteractivityTypeId, 0) As InteractivityTypeId,
    isnull(iatCodes.title, 'Unknown') As InteractivityType,
    
		ISNULL(base.TypicalLearningTime, 'Unknown') AS TypicalLearningTime,
		base.Modified,base.[Schema],

		base.Submitter,
		ISNULL(base.Imported, base.Modified) AS Imported,
		base.Created,
		base.IsSkeletonFromParadata
		,Requirements
		
	FROM [Resource.Version] base
	inner join [Resource] res on base.ResourceIntId = res.Id
	Left Join dbo.[Codes.AccessRights] codes on base.AccessRightsId = codes.Id
  Left Join dbo.[Codes.InteractivityType] iatCodes on base.InteractivityTypeId = iatCodes.Id

	WHERE base.Id = @Id
END
go
grant execute on [Resource.VersionGetById] to public
go


