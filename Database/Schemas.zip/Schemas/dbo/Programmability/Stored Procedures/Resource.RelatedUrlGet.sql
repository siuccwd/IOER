--- Get Single Procedure for [Resource.RelatedUrl] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.RelatedUrlGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RelatedUrlGet]
Go
CREATE PROCEDURE [Resource.RelatedUrlGet]
    @Id int
As
SELECT     Id, 
    ResourceIntId, 
    RelatedUrl, 
    IsActive, 
    Created, 
    CreatedById, 
    ResourceId
FROM [Resource.RelatedUrl]
WHERE Id = @Id
GO
grant execute on [Resource.RelatedUrlGet] to Public
Go