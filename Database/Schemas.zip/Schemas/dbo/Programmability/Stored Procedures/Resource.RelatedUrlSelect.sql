--- Get Procedure for [Resource.RelatedUrl] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Resource.RelatedUrlSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.RelatedUrlSelect]
Go
CREATE PROCEDURE [Resource.RelatedUrlSelect]
            @ResourceIntId int
            --,@ResourceId varchar(40)
As
If @ResourceIntId = 0   SET @ResourceIntId = NULL 

SELECT 
    Id, 
    ResourceIntId, 
    RelatedUrl, 
    IsActive, 
    Created, 
    CreatedById, 
    ResourceId
FROM [Resource.RelatedUrl]
where ResourceIntId= @ResourceIntId
Order by RelatedUrl

GO
grant execute on [Resource.RelatedUrlSelect] to public 
Go
 