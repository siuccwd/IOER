USE [LearningRegistryCache_Dev]
GO
 
--- Delete Procedure for Resource.Cluster---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Resource.ClusterDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Resource.ClusterDelete]
GO

CREATE PROCEDURE [Resource.ClusterDelete]
        @ResourceId uniqueidentifier,
        @ClusterId int
        
As
DELETE FROM [Resource.Cluster] 
WHERE ClusterId = @ClusterId AND 
ResourceId = @ResourceId
GO
grant execute on [Resource.ClusterDelete] to public
Go