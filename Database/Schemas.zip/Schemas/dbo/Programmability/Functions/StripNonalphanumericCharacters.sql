USE [LearningRegistryCache_Dev_Test]
GO

/****** Object:  UserDefinedFunction [dbo].[StripNonalphanumericCharacters]    Script Date: 10/23/2012 11:28:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 10/18/2012
-- Description:	Strips non-alphanumeric, non-space characters. Works for English, Polish, and Spanish.
--
-- 2012-10-25 jgrimmer - Added capability to drop/replace HTML entities in table with other strings
-- 2012-10-29 jgrimmer - Added capability to drop the '#' character if it is the first character in the string.
--						 It is not dropped in other locations as it is an integral part of HTML entities.
-- =============================================
ALTER FUNCTION [dbo].[StripNonalphanumericCharacters] 
(
	-- Add the parameters for the function here
	@Input nvarchar(max)
)
RETURNS nvarchar(max)
AS
BEGIN
	DECLARE @Output nvarchar(max), @CharactersToKeep nvarchar(100), @CharactersToToss nvarchar(110)

	SET @CharactersToKeep = N'0-9A-Za-z������������&#; '
	SET @CharactersToToss = N'%[^'+@CharactersToKeep+']%'

	SET @Output = @Input
	-- Declare the return variable here
	IF(PATINDEX(@CharactersToToss,@Output) > 0)
	WHILE PATINDEX(@CharactersToToss,@Output)>0 BEGIN
		SET @Output = STUFF(@Output,PATINDEX(@CharactersToToss,@Output),1,'')
	END
	
	IF LEFT(@Output,1) = '#' BEGIN
		SET @Output = RIGHT(@Output, LEN(@Output) - 1)
	END
	
	SET @Output = LTRIM(rtrim(@Output))
	
	IF LEN(@Output) > 0 AND PATINDEX('%&%',@Output) > 0 AND PATINDEX('%&%',@Output) < PATINDEX('%;%',@Output) BEGIN
	/* There are characters present and the '&' character comes before a ';' character; it's probable there's an HTML entity
	 * here.  We need to check to see if it is one of the ones we want to replace or delete.  If so, replace/delete it from
	 * the string. */
		DECLARE @EntityNbr varchar(10), @EntityName varchar(10), @IsDrop bit, @IsReplace bit, @ReplaceWith varchar(10)
		DECLARE specialCharCursor CURSOR FOR
			SELECT EntityNbr, EntityName, IsDrop, IsReplace, ReplaceWith
			FROM [Sort.SpecialCharacter]
		OPEN specialCharCursor
		FETCH NEXT FROM specialCharCursor INTO @EntityNbr, @EntityName, @IsDrop, @IsReplace, @ReplaceWith
		
		WHILE @@FETCH_STATUS = 0 BEGIN
			IF @IsDrop = 'True' BEGIN
				IF @EntityNbr IS NOT NULL
					SET @Output = REPLACE(@Output,@EntityNbr,'')
				IF @EntityName IS NOT NULL
					SET @Output = REPLACE(@Output,@EntityName,'')
			END ELSE IF @IsReplace = 'True' BEGIN
				IF @EntityNbr IS NOT NULL
					SET @Output = REPLACE(@Output,@EntityNbr,@ReplaceWith)
				IF @EntityName IS NOT NULL
					SET @Output = REPLACE(@Output,@EntityName,@ReplaceWith)
			END
		
			FETCH NEXT FROM specialCharCursor INTO @EntityNbr, @EntityName, @IsDrop, @IsReplace, @ReplaceWith
		END
		CLOSE specialCharCursor
		DEALLOCATE specialCharCursor
	END

	IF len(@Output) = 0
		SET @Output = @Input

	RETURN @Output
END

GO


