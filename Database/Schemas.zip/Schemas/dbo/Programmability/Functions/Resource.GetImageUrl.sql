USE [Isle_IOER]
GO
/****** Object:  UserDefinedFunction [dbo].[BuildSortTitle]    Script Date: 3/31/2014 11:01:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

select [dbo].[Resource.GetImageUrl]('http://owl.english.purdue.edu/workshops/pp/writewithppt.ppt',71278)

*/
-- =============================================
-- Create date: 03/31/2014
-- Description:	Determine image url for a resource, handling special files like pdfs, etc
-- Modifications
-- 14-06-18 mparsons - removed swf
-- =============================================
Alter FUNCTION [dbo].[Resource.GetImageUrl]
(
	@ResourceUrl varchar(300), 
	@ResourceIntId int
)
RETURNS varchar(300)
AS
BEGIN
	
DECLARE @ImageUrl varchar(300)
	
Declare @ResImgeUrl varchar(200)
,@PdfImageUrl varchar(200),@PPTImageUrl varchar(200),@WordImageUrl varchar(200)
,@XlxImageUrl  varchar(200)
,@SwfImageUrl  varchar(200)

--set @ResImgeUrl = '//ioer.ilsharedlearning.org/OERThumbs/thumb/@rvid-thumb.png'
set @ResImgeUrl = '//ioer.ilsharedlearning.org/OERThumbs/large/@rid-large.png'
set @PdfImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_pdf_200x150.png'
set @PPTImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_pptx_200x150.png'
set @WordImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_docx_200x150.png'
set @XlxImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_xlsx_200x150.png'
set @SwfImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_swf_200x200.png'
--		when Right(rtrim(lower(@ResourceUrl)), 4) = '.swf' then @SwfImageUrl
	Select @ImageUrl =
		case 
		when Right(rtrim(lower(@ResourceUrl)), 4) = '.pdf' then @PdfImageUrl
		when charindex('.ppt',Right(rtrim(lower(@ResourceUrl)), 5)) > 0 then @PPTImageUrl
		when charindex('.doc',Right(rtrim(lower(@ResourceUrl)), 5)) > 0 then @WordImageUrl
		when charindex('.xls',Right(rtrim(lower(@ResourceUrl)), 5)) > 0 then @XlxImageUrl
		else replace(@ResImgeUrl, '@rid', @ResourceIntId) end 

	SET @ImageUrl = LTRIM(rtrim(@ImageUrl))
	
	RETURN @ImageUrl

END
go

grant execute on [dbo].[Resource.GetImageUrl] to public
go


