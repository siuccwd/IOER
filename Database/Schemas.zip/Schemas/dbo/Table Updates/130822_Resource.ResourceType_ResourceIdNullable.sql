

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.ResourceType]
	DROP CONSTRAINT [FK_Resource.ResourceType_Resource]
GO
ALTER TABLE dbo.Resource SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.ResourceType]
	DROP CONSTRAINT [FK_Resource.ResourceType_Codes.ResourceType]
GO
ALTER TABLE dbo.[Codes.ResourceType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.ResourceType]
	DROP CONSTRAINT [DF_Resource.ResourceType_RowId]
GO
ALTER TABLE dbo.[Resource.ResourceType]
	DROP CONSTRAINT [DF_Resource.ResourceType_Created]
GO
CREATE TABLE dbo.[Tmp_Resource.ResourceType]
	(
	RowId uniqueidentifier NOT NULL,
	ResourceId uniqueidentifier NULL,
	ResourceTypeId int NULL,
	OriginalType varchar(100) NULL,
	Created datetime NULL,
	CreatedById int NULL,
	ResourceIntId int NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Resource.ResourceType] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Resource.ResourceType] ADD CONSTRAINT
	[DF_Resource.ResourceType_RowId] DEFAULT (newid()) FOR RowId
GO
ALTER TABLE dbo.[Tmp_Resource.ResourceType] ADD CONSTRAINT
	[DF_Resource.ResourceType_Created] DEFAULT (getdate()) FOR Created
GO
IF EXISTS(SELECT * FROM dbo.[Resource.ResourceType])
	 EXEC('INSERT INTO dbo.[Tmp_Resource.ResourceType] (RowId, ResourceId, ResourceTypeId, OriginalType, Created, CreatedById, ResourceIntId)
		SELECT RowId, ResourceId, ResourceTypeId, OriginalType, Created, CreatedById, ResourceIntId FROM dbo.[Resource.ResourceType] WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.[Resource.ResourceType]
GO
EXECUTE sp_rename N'dbo.[Tmp_Resource.ResourceType]', N'Resource.ResourceType', 'OBJECT' 
GO
ALTER TABLE dbo.[Resource.ResourceType] ADD CONSTRAINT
	PK_Resource_ResourceType PRIMARY KEY NONCLUSTERED 
	(
	RowId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE CLUSTERED INDEX [IX_Resource.ResourceId_Type] ON dbo.[Resource.ResourceType]
	(
	ResourceIntId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.ResourceType_Id] ON dbo.[Resource.ResourceType]
	(
	ResourceTypeId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Resource.ResourceType] ADD CONSTRAINT
	[FK_Resource.ResourceType_Codes.ResourceType] FOREIGN KEY
	(
	ResourceTypeId
	) REFERENCES dbo.[Codes.ResourceType]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.[Resource.ResourceType] ADD CONSTRAINT
	[FK_Resource.ResourceType_Resource] FOREIGN KEY
	(
	ResourceIntId
	) REFERENCES dbo.Resource
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT