


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_IsRegex] DEFAULT 0 FOR IsRegex
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_IsCaseSensitive] DEFAULT 0 FOR IsCaseSensitive
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_ImportWithoutTranslation] DEFAULT 0 FOR ImportWithoutTranslation
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_DoNotImport] DEFAULT 0 FOR DoNotImport
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_Sequence] DEFAULT 10 FOR Sequence
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_IsActive] DEFAULT 1 FOR IsActive
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_Created] DEFAULT getdate() FOR Created
GO
ALTER TABLE dbo.[Map.Rules] ADD CONSTRAINT
	[DF_Map.Rules_LastUpdated] DEFAULT getdate() FOR LastUpdated
GO
ALTER TABLE dbo.[Map.Rules] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
