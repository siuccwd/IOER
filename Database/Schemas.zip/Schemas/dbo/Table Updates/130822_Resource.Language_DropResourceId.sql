---***** do after change that adds created, createdById

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Language]
	DROP CONSTRAINT [FK_Resource.Language_Codes.Language]
GO
ALTER TABLE dbo.[Codes.Language] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Language]
	DROP CONSTRAINT [FK_Resource.Language_Resource]
GO
ALTER TABLE dbo.Resource SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Language]
	DROP CONSTRAINT [DF_Resource.Language_Created]
GO
CREATE TABLE dbo.[Tmp_Resource.Language]
	(
	RowId uniqueidentifier NOT NULL,
	LanguageId int NULL,
	OriginalLanguage varchar(100) NULL,
	ResourceIntId int NULL,
	Created datetime NULL,
	CreatedById int NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Resource.Language] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Resource.Language] ADD CONSTRAINT
	[DF_Resource.Language_Created] DEFAULT (getdate()) FOR Created
GO
IF EXISTS(SELECT * FROM dbo.[Resource.Language])
	 EXEC('INSERT INTO dbo.[Tmp_Resource.Language] (RowId, LanguageId, OriginalLanguage, ResourceIntId, Created, CreatedById)
		SELECT RowId, LanguageId, OriginalLanguage, ResourceIntId, Created, CreatedById FROM dbo.[Resource.Language] WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.[Resource.Language]
GO
EXECUTE sp_rename N'dbo.[Tmp_Resource.Language]', N'Resource.Language', 'OBJECT' 
GO
ALTER TABLE dbo.[Resource.Language] ADD CONSTRAINT
	PK_ResourceLanguage PRIMARY KEY CLUSTERED 
	(
	RowId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX [IX_Resource.Language_ResourceId] ON dbo.[Resource.Language]
	(
	ResourceIntId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.LanguageId] ON dbo.[Resource.Language]
	(
	LanguageId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Resource.Language] ADD CONSTRAINT
	[FK_Resource.Language_Resource] FOREIGN KEY
	(
	ResourceIntId
	) REFERENCES dbo.Resource
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Resource.Language] ADD CONSTRAINT
	[FK_Resource.Language_Codes.Language] FOREIGN KEY
	(
	LanguageId
	) REFERENCES dbo.[Codes.Language]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
COMMIT