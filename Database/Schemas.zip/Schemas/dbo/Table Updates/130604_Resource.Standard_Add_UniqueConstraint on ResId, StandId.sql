/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Resource.Standard_2] ON dbo.[Resource.Standard]
	(
	ResourceIntId,
	StandardId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Resource.Standard] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

/*
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Standard]
	DROP CONSTRAINT [FK_Resource.Standard_StandardBody.Node]
GO
ALTER TABLE dbo.[StandardBody.Node] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Standard]
	DROP CONSTRAINT [FK_Resource.Standard_Resource]
GO
ALTER TABLE dbo.Resource SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Standard]
	DROP CONSTRAINT [DF_Resource.Standard_AlignmentDegreeId]
GO
ALTER TABLE dbo.[Resource.Standard]
	DROP CONSTRAINT [DF_Resource.Standard_Created]
GO
CREATE TABLE dbo.[Tmp_Resource.Standard]
	(
	Id int NOT NULL IDENTITY (1, 1),
	ResourceIntId int NOT NULL,
	StandardId int NOT NULL,
	StandardUrl varchar(200) NULL,
	AlignedById int NULL,
	AlignmentTypeCodeId int NULL,
	AlignmentDegreeId int NULL,
	Created datetime NULL,
	CreatedById int NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Resource.Standard] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Resource.Standard] ADD CONSTRAINT
	[DF_Resource.Standard_AlignmentDegreeId] DEFAULT ((2)) FOR AlignmentDegreeId
GO
ALTER TABLE dbo.[Tmp_Resource.Standard] ADD CONSTRAINT
	[DF_Resource.Standard_Created] DEFAULT (getdate()) FOR Created
GO
SET IDENTITY_INSERT dbo.[Tmp_Resource.Standard] ON
GO
IF EXISTS(SELECT * FROM dbo.[Resource.Standard])
	 EXEC('INSERT INTO dbo.[Tmp_Resource.Standard] (Id, ResourceIntId, StandardId, StandardUrl, AlignedById, AlignmentTypeCodeId, AlignmentDegreeId, Created, CreatedById)
		SELECT Id, ResourceIntId, StandardId, StandardUrl, AlignedById, AlignmentTypeCodeId, AlignmentDegreeId, Created, CreatedById FROM dbo.[Resource.Standard] WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.[Tmp_Resource.Standard] OFF
GO
DROP TABLE dbo.[Resource.Standard]
GO
EXECUTE sp_rename N'dbo.[Tmp_Resource.Standard]', N'Resource.Standard', 'OBJECT' 
GO
ALTER TABLE dbo.[Resource.Standard] ADD CONSTRAINT
	[PK_Resource.StandardAlignment] PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX [IX_Resource.Standard] ON dbo.[Resource.Standard]
	(
	ResourceIntId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Standard_1] ON dbo.[Resource.Standard]
	(
	StandardId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Resource.Standard_2] ON dbo.[Resource.Standard]
	(
	ResourceIntId,
	StandardId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Resource.Standard] ADD CONSTRAINT
	[FK_Resource.Standard_Resource] FOREIGN KEY
	(
	ResourceIntId
	) REFERENCES dbo.Resource
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Resource.Standard] ADD CONSTRAINT
	[FK_Resource.Standard_StandardBody.Node] FOREIGN KEY
	(
	StandardId
	) REFERENCES dbo.[StandardBody.Node]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO
COMMIT


*/

