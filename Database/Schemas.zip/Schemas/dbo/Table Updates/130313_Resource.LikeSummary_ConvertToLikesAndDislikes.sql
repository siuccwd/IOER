/* The big scary looking statement for when the RatingAverage is between 1.4 and 2.4 is needed
 * so that when a fractional Like or dislike is generated, it will be handled as an integer.
 * For example, a single rating of 2.0 should probably be handled as a "like" not a "dislike" because
 * it is 60% of the way between 1.4 and 2.4.  Otherwise it would be handled as a "dislike" when that is not
 * really the case and could bias the conversion slightly towards dislikes. */

INSERT INTO [Resource.LikeSummary] (ResourceId, ResourceIntId, LikeCount, DislikeCount, LastUpdated)
SELECT ResourceId, ResourceIntId, 
	CASE
		WHEN RatingAverage <= 1.4 THEN 0
		WHEN RatingAverage >= 2.4 THEN RatingCount
		ELSE FLOOR(((RatingAverage - 1.4) / 1.00 * RatingCount) + 0.5)
	END AS LikeCount,
	CASE
		WHEN RatingAverage <= 1.4 THEN RatingCount
		WHEN RatingAverage >= 2.4 THEN 0
		ELSE FLOOR(((1 - (RatingAverage - 1.4) / 1.00) * RatingCount) + 0.5)
	END AS DislikeCount,
	LastUpdated
FROM [Resource.RatingSummary]
WHERE RatingTypeId = 2
