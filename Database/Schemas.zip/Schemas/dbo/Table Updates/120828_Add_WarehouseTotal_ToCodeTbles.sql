

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.AlignmentType] ADD
	WarehouseTotal int NULL
GO
ALTER TABLE dbo.[Codes.AlignmentType] ADD CONSTRAINT
	[DF_Codes.AlignmentType_WarehouseTotal] DEFAULT ((0)) FOR WarehouseTotal1
GO
ALTER TABLE dbo.[Codes.AlignmentType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

-- =================
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.AudienceType] ADD
	WarehouseTotal int NULL
GO
ALTER TABLE dbo.[Codes.AudienceType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

-- =================

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.PathwaysEducationLevel] ADD
	WarehouseTotal1 int NULL
GO
ALTER TABLE dbo.[Codes.PathwaysEducationLevel] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

-- =================
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.ResourceFormat] ADD
	WarehouseTotal int NULL
GO
ALTER TABLE dbo.[Codes.ResourceFormat] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT


-- =================
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.ResourceType] ADD
	WarehouseTotal int NULL
GO
ALTER TABLE dbo.[Codes.ResourceType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT


-- =================
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.ResourceTypeCategory] ADD
	WarehouseTotal int NULL
GO
ALTER TABLE dbo.[Codes.ResourceTypeCategory] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT


