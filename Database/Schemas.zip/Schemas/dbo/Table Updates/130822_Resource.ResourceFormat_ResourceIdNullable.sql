/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Format]
	DROP CONSTRAINT [FK_Resource.Format_Resource]
GO
ALTER TABLE dbo.Resource SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Format]
	DROP CONSTRAINT [FK_Resource.Format_Codes.ResourceFormat]
GO
ALTER TABLE dbo.[Codes.ResourceFormat] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Format]
	DROP CONSTRAINT [DF_Resource.Format_Created]
GO
CREATE TABLE dbo.[Tmp_Resource.Format]
	(
	RowId uniqueidentifier NOT NULL,
	ResourceId uniqueidentifier NULL,
	OriginalValue varchar(200) NULL,
	CodeId int NULL,
	Created datetime NULL,
	CreatedById int NULL,
	ResourceIntId int NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Resource.Format] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Resource.Format] ADD CONSTRAINT
	[DF_Resource.Format_Created] DEFAULT (getdate()) FOR Created
GO
IF EXISTS(SELECT * FROM dbo.[Resource.Format])
	 EXEC('INSERT INTO dbo.[Tmp_Resource.Format] (RowId, ResourceId, OriginalValue, CodeId, Created, CreatedById, ResourceIntId)
		SELECT RowId, ResourceId, OriginalValue, CodeId, Created, CreatedById, ResourceIntId FROM dbo.[Resource.Format] WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.[Resource.Format]
GO
EXECUTE sp_rename N'dbo.[Tmp_Resource.Format]', N'Resource.Format', 'OBJECT' 
GO
ALTER TABLE dbo.[Resource.Format] ADD CONSTRAINT
	[PK_Resource.Format] PRIMARY KEY CLUSTERED 
	(
	RowId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_ResourceFormat_ResourceIntId ON dbo.[Resource.Format]
	(
	ResourceIntId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_ResourceFormat_CodeId ON dbo.[Resource.Format]
	(
	CodeId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = OFF) ON [PRIMARY]
GO
ALTER TABLE dbo.[Resource.Format] ADD CONSTRAINT
	[FK_Resource.Format_Codes.ResourceFormat] FOREIGN KEY
	(
	CodeId
	) REFERENCES dbo.[Codes.ResourceFormat]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.[Resource.Format] ADD CONSTRAINT
	[FK_Resource.Format_Resource] FOREIGN KEY
	(
	ResourceIntId
	) REFERENCES dbo.Resource
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT