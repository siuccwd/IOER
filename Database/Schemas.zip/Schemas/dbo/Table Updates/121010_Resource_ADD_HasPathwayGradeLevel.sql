/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Resource ADD
	HasPathwayGradeLevel bit NULL
GO
--ALTER TABLE dbo.Resource ADD CONSTRAINT
--	DF_Resource_HasPathwayGradeLevel DEFAULT 0 FOR HasPathwayGradeLevel
--GO
ALTER TABLE dbo.Resource SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

/*

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Resource
	DROP CONSTRAINT DF_Resource_HasPathwayGradeLevel
GO
ALTER TABLE dbo.Resource SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

Update [Resource]
Set HasPathwayGradeLevel=0


Update [Resource]
Set HasPathwayGradeLevel=1

--  select count(*)
FROM [dbo].[Resource] lr
Inner JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId  
where lr.HasPathwayGradeLevel = 0
AND (edList.PathwaysEducationLevelId > 2 AND edList.PathwaysEducationLevelId < 7)


set @Filter = ' Where (edList.PathwaysEducationLevelId > 3) ' 
set @Filter = @Filter + ' AND (rcl.ClusterId > 0 ) ' 
--set @Filter = @Filter + ' AND (rcl.ClusterId in (1,2,6,8,11,13,16) ) ' 
*/
