

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Patron.Profile]
	DROP CONSTRAINT [FK_Patron.Profile_Patron]
GO
ALTER TABLE dbo.Patron SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Patron.Profile]
	DROP CONSTRAINT [DF_Patron.Profile_Created]
GO
ALTER TABLE dbo.[Patron.Profile]
	DROP CONSTRAINT [DF_Patron.Profile_LastUpdated]
GO
CREATE TABLE dbo.[Tmp_Patron.Profile]
	(
	UserId int NOT NULL,
	MainPhone varchar(15) NULL,
	JobTitle varchar(100) NULL,
	PublishingRoleId int NULL,
	RoleProfile varchar(500) NULL,
	OrganizationId int NULL,
	Created datetime NULL,
	CreatedById int NULL,
	LastUpdated datetime NULL,
	LastUpdatedId int NULL,
	Notes varchar(1000) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Patron.Profile] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Patron.Profile] ADD CONSTRAINT
	[DF_Patron.Profile_Created] DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.[Tmp_Patron.Profile] ADD CONSTRAINT
	[DF_Patron.Profile_LastUpdated] DEFAULT (getdate()) FOR LastUpdated
GO
IF EXISTS(SELECT * FROM dbo.[Patron.Profile])
	 EXEC('INSERT INTO dbo.[Tmp_Patron.Profile] (UserId, MainPhone, JobTitle, PublishingRoleId, RoleProfile, OrganizationId, Created, CreatedById, LastUpdated, LastUpdatedId, Notes)
		SELECT UserId, MainPhone, JobTitle, PublishingRoleId, RoleProfile, OrganizationId, Created, CreatedById, LastUpdated, LastUpdatedId, Notes FROM dbo.[Patron.Profile] WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.[Patron.Profile]
GO
EXECUTE sp_rename N'dbo.[Tmp_Patron.Profile]', N'Patron.Profile', 'OBJECT' 
GO
ALTER TABLE dbo.[Patron.Profile] ADD CONSTRAINT
	[PK_Patron.Profile] PRIMARY KEY CLUSTERED 
	(
	UserId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.[Patron.Profile] ADD CONSTRAINT
	[FK_Patron.Profile_Patron] FOREIGN KEY
	(
	UserId
	) REFERENCES dbo.Patron
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT