USE [Isle_IOER]
GO
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Resource.Language] ADD
	Created datetime NULL,
	CreatedById int NULL
GO
ALTER TABLE dbo.[Resource.Language] ADD CONSTRAINT
	[DF_Resource.Language_Created] DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.[Resource.Language] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

/*
USE [Isle_IOER]
GO


UPDATE [dbo].[Resource.Language]
   SET [Created] = r.Created
from [Resource.Language] base
Inner join Resource r on base.ResourceIntId = r.Id
 
GO



*/
