BEGIN TRANSACTION
UPDATE [Resource.Version]
SET SortTitle = Title

UPDATE [Resource.Version]
SET SortTitle = RIGHT(SortTitle, len(SortTitle) - 2)
WHERE SortTitle LIKE 'A %' AND (SortTitle NOT LIKE 'A[^<=>]%' OR SortTitle NOT LIKE 'A [^<=>]%')

WHILE @@ROWCOUNT > 0
	UPDATE [Resource.Version]
	SET SortTitle = RIGHT(SortTitle, len(SortTitle) - 2)
	WHERE SortTitle LIKE 'A %' AND (SortTitle NOT LIKE 'A[^<=>]%' OR SortTitle NOT LIKE 'A [^<=>]%')

UPDATE [Resource.Version]
SET SortTitle = ltrim(rtrim(dbo.StripNonalphanumericCharacters(SortTitle)))

UPDATE [Resource.Version]
SET SortTitle = RIGHT(SortTitle, len(SortTitle) - 3)
WHERE SortTitle LIKE 'An %'

WHILE @@ROWCOUNT > 0
	UPDATE [Resource.Version]
	SET SortTitle = RIGHT(SortTitle, len(SortTitle) - 3)
	WHERE SortTitle LIKE 'An %'

UPDATE [Resource.Version]
SET SortTitle = RIGHT(SortTitle, len(SortTitle) - 4)
WHERE SortTitle LIKE 'The %'

WHILE @@ROWCOUNT > 0
	UPDATE [Resource.Version]
	SET SortTitle = RIGHT(SortTitle, len(SortTitle) - 4)
	WHERE SortTitle LIKE 'The %'
	
UPDATE [Resource.Version]
SET SortTitle = REPLACE(SortTitle,' a ', ' ')

UPDATE [Resource.Version]
SET SortTitle = REPLACE(SortTitle, ' an ', ' ')

UPDATE [Resource.Version]
SET SortTitle = REPLACE(SortTitle, ' the ', ' ')

COMMIT
