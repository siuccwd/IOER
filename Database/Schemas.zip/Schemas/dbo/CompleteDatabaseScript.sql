USE [LearningRegistryCache_Dev_20121005]
GO
/****** Object:  Table [dbo].[Map.PathwayRules]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.PathwayRules](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PropertyTypeId] [int] NULL,
	[OriginalValue] [varchar](500) NULL,
	[IsRegex] [bit] NULL,
	[IsCaseSensitive] [bit] NULL,
	[MappedValue] [varchar](100) NULL,
	[Sequence] [int] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[CreatedBy] [varchar](75) NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedBy] [varchar](75) NULL,
 CONSTRAINT [PK_Map.PathwayRules] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Map.Language]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.Language](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LRValue] [varchar](300) NULL,
	[MappedValue] [varchar](30) NULL,
	[LanguageId] [int] NULL,
 CONSTRAINT [PK_Map.Language] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Map.EducationLevel]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.EducationLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[OriginalValue] [varchar](500) NULL,
	[IsRegex] [bit] NULL,
	[IsCaseSensitive] [bit] NULL,
	[ImportWithoutTranslation] [bit] NULL,
	[DoNotImport] [bit] NULL,
	[MappedValue] [varchar](100) NULL,
	[Sequence] [int] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[CreatedBy] [varchar](75) NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedBy] [varchar](75) NULL,
 CONSTRAINT [PK_Map.EducationLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Map.CareerCluster]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.CareerCluster](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FilterValue] [varchar](500) NULL,
	[IsRegex] [bit] NULL,
	[IsCaseSensitive] [bit] NULL,
	[MappedClusterId] [int] NOT NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedBy] [varchar](50) NULL,
 CONSTRAINT [PK_Map.CareerCluster] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Map.AudienceType]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.AudienceType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[OriginalValue] [varchar](500) NULL,
	[IsRegex] [bit] NULL,
	[IsCaseSensitive] [bit] NULL,
	[ImportWithoutTranslation] [bit] NULL,
	[DoNotImport] [bit] NULL,
	[MappedValue] [varchar](100) NULL,
	[Sequence] [int] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[CreatedBy] [varchar](75) NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedBy] [varchar](75) NULL,
 CONSTRAINT [PK_Map.AudienceType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Library.Resource]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Library.Resource](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[LibraryId] [uniqueidentifier] NULL,
	[LibraryCategory] [varchar](50) NULL,
	[Comment] [varchar](500) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [uniqueidentifier] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Library.Resource] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Library]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Library](
	[RowId] [uniqueidentifier] NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Description] [varchar](500) NULL,
	[Creator] [varchar](100) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [uniqueidentifier] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Library] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ApplicationLog]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ApplicationLog](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[AppProcedure] [varchar](50) NULL,
	[Event] [varchar](50) NULL,
	[Type] [varchar](50) NULL,
	[Comment] [varchar](1000) NULL,
	[CreatedDate] [datetime] NULL,
 CONSTRAINT [PKY_ApplicationLog] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[_DictTable]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_DictTable](
	[tablename] [nvarchar](128) NOT NULL,
	[Description] [nvarchar](133) NOT NULL,
	[IsActive] [int] NOT NULL,
	[ReportGroup] [int] NOT NULL,
	[ReportOrder] [int] NOT NULL,
	[Synchronize] [int] NOT NULL,
	[Created] [datetime] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[_Dictionary]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Dictionary](
	[tableName] [nvarchar](128) NOT NULL,
	[col_id] [int] NOT NULL,
	[colName] [nvarchar](128) NOT NULL,
	[datatype] [nvarchar](30) NOT NULL,
	[col_precScale] [nvarchar](50) NULL,
	[col_null] [bit] NOT NULL,
	[DefaultValue] [nvarchar](257) NULL,
	[col_identity] [bit] NULL,
	[col_desc] [nvarchar](250) NULL,
	[entityType] [nvarchar](25) NULL,
	[CreatedDate] [datetime] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CodeTable]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CodeTable](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CodeName] [varchar](50) NOT NULL,
	[LanguageCode] [varchar](10) NOT NULL,
	[StringValue] [varchar](100) NOT NULL,
	[NumericValue] [decimal](12, 4) NULL,
	[IntegerValue] [int] NULL,
	[Description] [varchar](500) NULL,
	[SortOrder] [tinyint] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[Modified] [datetime] NULL,
 CONSTRAINT [PK_CodeTable] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Map.Rules]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.Rules](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PropertyTypeId] [int] NULL,
	[OriginalValue] [varchar](500) NULL,
	[IsRegex] [bit] NULL,
	[IsCaseSensitive] [bit] NULL,
	[ImportWithoutTranslation] [bit] NULL,
	[DoNotImport] [bit] NULL,
	[MappedValue] [varchar](100) NULL,
	[Sequence] [int] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[CreatedBy] [varchar](75) NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedBy] [varchar](75) NULL,
 CONSTRAINT [PK_Map.Rules] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Map.ResourceType]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.ResourceType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LRValue] [varchar](100) NULL,
	[CodeId] [int] NULL,
 CONSTRAINT [PK_Mapping.ResourceType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Map.ResourceFormat]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Map.ResourceFormat](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LRValue] [varchar](100) NULL,
	[CodeId] [int] NULL,
 CONSTRAINT [PK_Map.ResourceFormat] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.ResPropertyType]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.ResPropertyType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
 CONSTRAINT [PK_ResourcePropertyType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.ResourceTypeCategory]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.ResourceTypeCategory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Category] [varchar](50) NULL,
	[Description] [varchar](200) NULL,
	[SortOrder] [int] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.ResourceTypeCategory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.ResourceType]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.ResourceType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[Description] [varchar](200) NULL,
	[SortOrder] [int] NULL,
	[WarehouseTotal] [int] NULL,
	[CategoryId] [int] NULL,
 CONSTRAINT [PK_CodesResourceType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.ResourceFormat]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.ResourceFormat](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_ResourceMaterialType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AuditReport.Detail]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AuditReport.Detail](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReportId] [int] NOT NULL,
	[Filename] [varchar](100) NULL,
	[DocID] [varchar](100) NULL,
	[URI] [varchar](500) NULL,
	[MessageType] [char](1) NULL,
	[MessageRouting] [varchar](2) NULL,
	[Message] [varchar](200) NULL,
 CONSTRAINT [PK_AuditReport.Detail] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AuditReport]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditReport](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Report] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Audit.ResourceType_Orphan]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Audit.ResourceType_Orphan](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[OriginalValue] [varchar](200) NULL,
	[FoundMapping] [bit] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[LastRerunDate] [datetime] NULL,
 CONSTRAINT [PK_Audit.ResourceType_Orphan] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Audit.ResourceFormat_Orphan]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Audit.ResourceFormat_Orphan](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[OriginalValue] [varchar](200) NULL,
	[FoundMapping] [bit] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[LastRerunDate] [datetime] NULL,
 CONSTRAINT [PK_Audit.ResourceFormat_Orphan] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Audit.Language_Orphan]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Audit.Language_Orphan](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[OriginalValue] [varchar](200) NULL,
	[FoundMapping] [bit] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[LastRerunDate] [datetime] NULL,
 CONSTRAINT [PK_Audit.Language_Orphan] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Audit.EducationLevel_Orphan]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Audit.EducationLevel_Orphan](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[OriginalValue] [varchar](200) NULL,
	[FoundMapping] [bit] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[LastRerunDate] [datetime] NULL,
 CONSTRAINT [PK_Audit.EducationLevel_Orphan] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[aspCreateProcedure_Update]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Exec aspCreateProcedure_Update 'Contact', 1

Exec aspCreateProcedure_Update 'Contact', 1, 0, '', '_usp', 'Update', 'GrantToMtce'

Exec aspCreateProcedure_Update 'WiaContract.Action', 1, 0, '', '_Insert', '', 'GrantToMtce'
*/
-- =========================================================================
-- 08/05/28 mparsons - added code to handle varchar(MAX) - length is equal to -1 in CHARACTER_MAXIMUM_LENGTH
-- 12/09/13 mparsons - updated to handle tables with dot notation (ex.Policy.Version)
-- =========================================================================
CREATE  Procedure [dbo].[aspCreateProcedure_Update] 
		@tableName 		varchar(128) 
		,@print 		bit 
		,@tableFirst	bit = 1
		,@Prefix		varchar(20) = '' 
		,@Suffix		varchar(20) = '' 
		,@ProcName		varchar(128) = 'Update' 
		,@GrantGroup	varchar(128) = '' 
AS
-- =============================================================
-- = TODO
-- =	- consider trying to handle nullable fields on input parms 
-- =	  (i.e. default to null, so don't have to be provided)
-- =
-- =============================================================
Declare 
	@SQLStatement 		varchar(8000), --Actual Delete Procedure string
	@parameters 		varchar(8000), -- Parameters to be passed to the Stored Procedure
	@updateStatement 	varchar(8000), -- To Store the update SQL Statement
	@NullStatement 		varchar(8000), -- To Store Null handling for null allowed columns.
	@procedurename 		varchar(128), -- To store the procedure name
	@WhereClause 		varchar(8000), -- To Store Where clause information for the update statement.
	@DropProcedure 		varchar(1000), --Drop procedure sql statement
	@GrantProcedure 	varchar(1000) 	--To Store Grant execute Procedure SQL Statement
	--TODO add process to do a grant - ex to a passed role

-- Initialize Variables
SET @parameters = ''
SET @updateStatement = ''
SET @NullStatement = ''
SET @WhereClause = ''
SET @DropProcedure = ''

-- Build Parameters, Update and Null Statements

SELECT	@parameters = @parameters + Case When @parameters = '' Then ''
					Else ', ' + Char(13) + Char(10) 
					End + '        @' + + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' ' + 
					DATA_TYPE + 
					Case 
						When CHARACTER_MAXIMUM_LENGTH = -1 Then 
							'(MAX)' 
						When CHARACTER_MAXIMUM_LENGTH is not null Then 
						'(' + Cast(CHARACTER_MAXIMUM_LENGTH as varchar(4)) + ')' 
						Else '' 
					End,
	@updateStatement = @updateStatement + Case When @updateStatement = '' Then ''
					Else ', ' 
					End + Char(13) + Char(10) + '    ' + COLUMN_NAME + ' = @' +
					COLUMN_NAME,
	@NullStatement = @NullStatement + Case When @NullStatement = '' Then '' 
					Else Char(13) + Char(10)
					End + 
					CASE WHEN DATA_TYPE = 'int' OR DATA_TYPE = 'smallint' OR 
						DATA_TYPE = 'tinyint' OR DATA_TYPE = 'real' OR 
						DATA_TYPE = 'float' OR DATA_TYPE = 'decimal' OR 
						DATA_TYPE = 'bit' OR DATA_TYPE = 'numeric' OR DATA_TYPE = 'bigint' Then 
						'If @' + COLUMN_NAME + ' = 0 ' 
					Else 
						'If @' + COLUMN_NAME + ' = '''' ' 
					End + '  SET @' + COLUMN_NAME + ' = NULL '
FROM	
	INFORMATION_SCHEMA.Columns
WHERE	
	table_name = @tableName AND 
	NOT EXISTS(SELECT * 
			FROM 	INFORMATION_SCHEMA.TABLE_CONSTRAINTS JOIN
				INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ON INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.CONSTRAINT_NAME
			WHERE	INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.COLUMN_NAME = INFORMATION_SCHEMA.Columns.COLUMN_NAME AND
				INFORMATION_SCHEMA.TABLE_CONSTRAINTS.table_name = @tableName AND 
				CONSTRAINT_TYPE = 'PRIMARY KEY')

-- Build Parameters and Where Clause with Primary key

SELECT	@parameters = @parameters + Case When @parameters = '' Then ''
					Else ', ' + Char(13) + Char(10) 
					End + '@' + + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' ' + 
					DATA_TYPE + 
					Case When CHARACTER_MAXIMUM_LENGTH is not null Then 
						'(' + Cast(CHARACTER_MAXIMUM_LENGTH as varchar(4)) + ')' 
						Else '' 
					End,
	@WhereClause = @WhereClause + Case When @WhereClause = '' Then ''
					Else ' AND ' + Char(13) + Char(10) 
					End + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' = @' + + INFORMATION_SCHEMA.Columns.COLUMN_NAME
FROM	
	INFORMATION_SCHEMA.Columns,
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS,
	INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE
WHERE 	
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.CONSTRAINT_NAME AND
	INFORMATION_SCHEMA.Columns.Column_name = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.Column_name AND
	INFORMATION_SCHEMA.Columns.table_name = INFORMATION_SCHEMA.TABLE_CONSTRAINTS.TABLE_NAME AND
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS.table_name = @tableName AND 
	CONSTRAINT_TYPE = 'PRIMARY KEY'

-- the following logic can be changed as per your standards. 
SET @procedurename = @ProcName	--'Update'

If @tableFirst = 1 Begin
	-- Use syntax of prefix + TableName + ProcedureType + Suffix
	--	ex.	ContactSelect, uspContactSelect, ContactSelect_usp
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix +  + SubString(@tableName, 4, Len(@tableName))  + @procedurename  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @tableName + @procedurename  + @Suffix
	End
End
Else Begin
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix + @procedurename + SubString(@tableName, 4, Len(@tableName))  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @procedurename + @tableName + @Suffix
	End
End


--Stores DROP Procedure Statement
SET @DropProcedure = 'if exists (select * from dbo.sysobjects where id = object_id(N''[' + @procedurename + ']'') and OBJECTPROPERTY(id, N''IsProcedure'') = 1)' + Char(13) + Char(10) +
				'Drop Procedure [' + @procedurename + ']'

--Stores grant procedure statement
if len(@GrantGroup) > 0 
	SET @GrantProcedure = 'grant execute on [' + @procedurename + '] to ' + @GrantGroup
Else
	SET @GrantProcedure = ''

If @print = 0
Begin
	-- Drop the current procedure.
	Exec (@DropProcedure)
	-- Create the final procedure 
	SET @SQLStatement = 'CREATE PROCEDURE [' + @procedurename + '] ' +  Char(13) + Char(10) + @parameters + Char(13) + Char(10) + 'AS ' + Char(13) + Char(10) +
				@NullStatement + Char(13) + Char(10) + 'Update ' + @tableName + '] ' + Char(13) + Char(10) + 'SET ' + @UpdateStatement + Char(13) + Char(10) +
				'WHERE ' + @WhereClause
	-- Execute the SQL Statement to create the procedure
	--Print @SQLStatement
	Exec (@SQLStatement)

	-- Do the grant
	if len(@GrantProcedure) > 0 Begin
		Exec (@GrantProcedure)
	End	

End
Else
Begin
	--Print the Procedure to Results pane
	Print ''
	Print ''
	Print ''
	Print @DropProcedure
	Print 'Go'
	Print '--- Update Procedure for [' + @tableName + '] ---'
	Print 'CREATE PROCEDURE [' + @procedurename + ']'
	Print @parameters
	Print 'As'
	Print @NullStatement
	Print 'UPDATE [' + @tableName + '] '
	Print 'SET ' + @UpdateStatement
	Print 'WHERE ' + @WhereClause
	Print 'GO'
	Print @GrantProcedure
	Print 'Go'
End
GO
/****** Object:  StoredProcedure [dbo].[aspCreateProcedure_Insert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Stored Procedure dbo.aspCreateProcedure_Insert    Script Date: 7/8/2005 11:16:33 AM ******/
/*
Exec aspCreateProcedure_Insert 'Building', 0
Exec aspCreateProcedure_Insert 'Contact', 1

Exec aspCreateProcedure_Insert 'Contact', 1, 0, 'pre', 'suf', 'CreateName', 'GrantToMtce'

Exec aspCreateProcedure_Insert 'WiaContract.Action', 1, 0, '', '_Insert', '', 'GrantToMtce'

*/
-- =========================================================================
-- 08/05/28 mparsons - added code to handle varchar(MAX) - length is equal to -1 in CHARACTER_MAXIMUM_LENGTH
-- 12/09/13 mparsons - updated to handle tables with dot notation (ex.Policy.Version)
-- =========================================================================
CREATE   Procedure [dbo].[aspCreateProcedure_Insert]
		@tableName 		varchar(128) 
		,@print 		bit 
		,@tableFirst	bit = 1
		,@Prefix		varchar(20) = '' 
		,@Suffix		varchar(20) = '' 
		,@ProcName		varchar(128) = 'Insert' 
		,@GrantGroup		varchar(128) = '' 
AS

-- =============================================================
-- = TODO
-- =	- consider trying to handle nullable fields on input parms 
-- =	  (i.e. default to null, so don't have to be provided)
-- =
-- =============================================================
Declare 
	@SQLStatement 		varchar(8000), --Actual Delete Procedure string
	@parameters 		varchar(8000), -- Parameters to be passed to the Stored Procedure
	@InsertStatement 	varchar(8000), --To store Insert Clause.
	@ValuesStatement 	varchar(8000), -- To store Values Clause
	@NullStatement 		varchar(8000), --To store special handling of null values.
	@procedurename 		varchar(128), -- To store the procedure name
	@DropProcedure 		varchar(1000), --Drop procedure sql statement
	@GrantProcedure 	varchar(1000) 	--To Store Grant execute Procedure SQL Statement
	--TODO add process to do a grant - ex to a passed role
	,@KeyCount			int

-- Initialize Variables
SET @parameters = ''
SET @InsertStatement = ''
SET @ValuesStatement = ''
SET @NullStatement = ''

-- Do check for multiple primary key columns
SELECT @KeyCount = count(*) 
			FROM 	INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
				JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE 
					ON INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.CONSTRAINT_NAME
			WHERE	
-- 				INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.COLUMN_NAME = INFORMATION_SCHEMA.Columns.COLUMN_NAME 
-- 			AND	
				INFORMATION_SCHEMA.TABLE_CONSTRAINTS.table_name = @tableName 
			AND CONSTRAINT_TYPE = 'PRIMARY KEY'

if @KeyCount > 1 begin
	print '******************************************************************'
	print '  Warning requested table has multiple primary keys. '
	print '  You may need to manually add these to the create procedure if  '
	print '  they are not of the autogenerate type!				'
	print '******************************************************************'
end

-- Get Parameters, insert, values and Null statements.

SELECT	@parameters = @parameters + 
		Case When @parameters = '' Then '    ' 
			Else ', ' + Char(13) + Char(10) + '    ' 
			End + '        @' + + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' ' + 
			DATA_TYPE + 
			Case 
				When CHARACTER_MAXIMUM_LENGTH = -1 Then 
					'(MAX)' 
				When CHARACTER_MAXIMUM_LENGTH is not null Then 
					'(' + Cast(CHARACTER_MAXIMUM_LENGTH as varchar(4)) + ')' 
				Else '' 
			End,
	@InsertStatement = @InsertStatement + 
		Case When @InsertStatement = '' Then ''
			Else ', ' 
			End + Char(13) + Char(10) + '    ' +
			COLUMN_NAME,
	@ValuesStatement = @ValuesStatement + Case When @ValuesStatement = '' Then ''
			Else ', ' 
			End + Char(13) + Char(10) + '    @' +
			COLUMN_NAME,
	@NullStatement = @NullStatement + Case When @NullStatement = '' Then '' 
			Else Char(13) + Char(10)
			End + 
			CASE WHEN DATA_TYPE = 'int' OR DATA_TYPE = 'smallint' OR 
				DATA_TYPE = 'tinyint' OR DATA_TYPE = 'real' OR 
				DATA_TYPE = 'float' OR DATA_TYPE = 'decimal' OR 
				DATA_TYPE = 'bit' OR DATA_TYPE = 'numeric' OR DATA_TYPE = 'bigint' Then 
				'If @' + COLUMN_NAME + ' = 0 ' 
			Else 
				'If @' + COLUMN_NAME + ' = '''' ' 
			End + '  SET @' + COLUMN_NAME + ' = NULL '
--  select *
FROM	
	INFORMATION_SCHEMA.Columns
WHERE	
	table_name = @tableName AND 
	NOT EXISTS(SELECT * 
			FROM 	INFORMATION_SCHEMA.TABLE_CONSTRAINTS JOIN
				INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ON INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.CONSTRAINT_NAME
			WHERE	INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.COLUMN_NAME = INFORMATION_SCHEMA.Columns.COLUMN_NAME AND
				INFORMATION_SCHEMA.TABLE_CONSTRAINTS.table_name = @tableName AND 
				CONSTRAINT_TYPE = 'PRIMARY KEY')
				
-- the following logic can be changed as per your standards. In our case tbl is for tables and tlkp is for lookup tables. Needed to remove tbl and tlkp...
SET @procedurename = @ProcName	--'Create'

If @tableFirst = 1 Begin
	-- Use syntax of prefix + TableName + ProcedureType + Suffix
	--	ex.	ContactSelect, uspContactSelect, ContactSelect_usp
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix +  + SubString(@tableName, 4, Len(@tableName))  + @procedurename  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @tableName + @procedurename  + @Suffix
	End
End
Else Begin
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix + @procedurename + SubString(@tableName, 4, Len(@tableName))  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @procedurename + @tableName + @Suffix
	End
End

--Stores DROP Procedure Statement
SET @DropProcedure = 'if exists (select * from dbo.sysobjects where id = object_id(N''[' + @procedurename + ']'') and OBJECTPROPERTY(id, N''IsProcedure'') = 1)' + Char(13) + Char(10) +
				'Drop Procedure [' + @procedurename + ']'

--Stores grant procedure statement
if len(@GrantGroup) > 0 
	SET @GrantProcedure = 'grant execute on [' + @procedurename + '] to ' + @GrantGroup
Else
	SET @GrantProcedure = ''

-- In case you want to create the procedure pass in 0 for @print else pass in 1 and stored procedure will be displayed in results pane.
If @print = 0
Begin
	--print 'Doing drop'
	-- Drop the current procedure.
	Exec (@DropProcedure)
	--print 'Doing create'
	-- Create the final procedure 
	SET @SQLStatement = 'CREATE PROCEDURE [' + @procedurename + '] ' +  Char(13) + Char(10) + @parameters + Char(13) + Char(10) + 'AS' + Char(13) + Char(10) +
				@NullStatement + Char(13) + Char(10) + 'INSERT INTO [' + @tableName + '] (' + @InsertStatement + ')' + Char(13) + Char(10) + 
				'Values (' + @ValuesStatement + ')' + Char(13) + Char(10) + 'select SCOPE_IDENTITY()'
	--print str(len(@SQLStatement)) + @SQLStatement 
	-- Execute the SQL Statement to create the procedure
	Exec(@SQLStatement)

	-- Do the grant
	if len(@GrantProcedure) > 0 Begin
		Exec (@GrantProcedure)
	End	

End
Else
Begin
	--Print the Procedure to Results pane
	Print ''
	Print ''
	Print ''
	Print '--- Insert Procedure for [' + @tableName + '] ---'
	Print @DropProcedure
	Print 'Go'
	Print 'CREATE PROCEDURE [' + @procedurename + ']'
	Print @parameters
	Print 'As'
	Print @NullStatement
	Print 'INSERT INTO [' + @tableName + '] ('
	Print @InsertStatement
	Print ')'
	Print 'Values ('
	Print @ValuesStatement
	Print ')'
	Print ''
	Print 'select SCOPE_IDENTITY() as Id'
	Print 'GO'
	Print @GrantProcedure
	Print 'Go'
End
GO
/****** Object:  StoredProcedure [dbo].[aspCreateProcedure_GetSingle]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Exec aspCreateProcedure_GetSingle 'WiaContract.Action', 1

Exec aspCreateProcedure_GetSingle 'WiaContract.Action', 1, 0, 'pre', '_suf', 'GetSingle', 'GrantToPublic'

Exec aspCreateProcedure_GetSingle 'WiaContract.Action', 1, 0, '', '_Select', '', 'GrantToPublic'
*/
-- =========================================================================
-- 12/09/13 mparsons - updated to handle tables with dot notation (ex.Policy.Version)
-- =========================================================================
CREATE   Procedure [dbo].[aspCreateProcedure_GetSingle] 
		@tableName 		varchar(128) 
		,@print 		bit 
		,@tableFirst	bit = 1
		,@Prefix		varchar(20) = '' 
		,@Suffix		varchar(20) = '' 
		,@ProcName		varchar(128) = 'Get' 
		,@GrantGroup	varchar(128) = '' 
AS

Declare @SQLStatement varchar(8000), 	-- Actual GetSingle Procedure string
	@parameters varchar(8000), 			-- To store parameter list.
	@SelectStatement varchar(8000), 	-- Actual Select Statement that returns result set.
	@WhereStatement varchar(8000), 		-- Where clause to pick the single record
	@procedurename varchar(128), 		-- To store the procedure name
	@DropProcedure 		varchar(1000), -- Drop procedure sql statement
	@GrantProcedure 	varchar(1000) 	-- To Store Grant execute Procedure SQL Statement

SET @parameters = ''
SET @SelectStatement = ''
SET @WhereStatement = ''

--Build parameter list and where clause
SELECT	@parameters = @parameters + Case When @parameters = '' Then ''
					Else ', ' + Char(13) + Char(10) 
					End + '    @' + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' ' + 
					DATA_TYPE + 
					Case When CHARACTER_MAXIMUM_LENGTH is not null Then 
						'(' + Cast(CHARACTER_MAXIMUM_LENGTH as varchar(4)) + ')' 
						Else '' 
					End,
	@WhereStatement = @WhereStatement + Case When @WhereStatement = '' Then ''
					Else ' AND ' + Char(13) + Char(10) 
					End + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' = @' + + INFORMATION_SCHEMA.Columns.COLUMN_NAME
FROM	
	INFORMATION_SCHEMA.Columns,
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS,
	INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE
WHERE 	
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.CONSTRAINT_NAME AND
	INFORMATION_SCHEMA.Columns.Column_name = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.Column_name AND
	INFORMATION_SCHEMA.Columns.table_name = INFORMATION_SCHEMA.TABLE_CONSTRAINTS.TABLE_NAME AND
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS.table_name = @tableName AND 
	CONSTRAINT_TYPE = 'PRIMARY KEY'

--Store column names from the select statement
SELECT	@SelectStatement = @SelectStatement + Case When @SelectStatement = '' Then ''
					Else ', ' + Char(13) + Char(10) 
					End + '    ' + COLUMN_NAME
FROM	INFORMATION_SCHEMA.Columns
WHERE	table_name = @tableName

-- the following logic can be changed as per your standards. 
SET @procedurename = @ProcName	--'GetSingle'

If @tableFirst = 1 Begin
	-- Use syntax of prefix + TableName + ProcedureType + Suffix
	--	ex.	ContactSelect, uspContactSelect, ContactSelect_usp
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix +  + SubString(@tableName, 4, Len(@tableName))  + @procedurename  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @tableName + @procedurename  + @Suffix
	End
End
Else Begin
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix + @procedurename + SubString(@tableName, 4, Len(@tableName))  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @procedurename + @tableName + @Suffix
	End
End

--Stores DROP Procedure Statement
SET @DropProcedure = 'if exists (select * from dbo.sysobjects where id = object_id(N''[' + @procedurename + ']'') and OBJECTPROPERTY(id, N''IsProcedure'') = 1)' + Char(13) + Char(10) +
					'Drop Procedure [' + @procedurename + ']'

--Stores grant procedure statement
if len(@GrantGroup) > 0 
	SET @GrantProcedure = 'grant execute on [' + @procedurename + '] to ' + @GrantGroup
Else
	SET @GrantProcedure = ''

-- In case you want to create the procedure pass in 0 for @print else pass in 1 and stored procedure will be displayed in results pane.
If @print = 0
Begin
	-- Drop the current procedure.
	Exec (@DropProcedure)
	-- Create the final procedure and store it..	
	SET @SQLStatement = 'CREATE PROCEDURE [' + @procedurename + '] ' +  Char(13) + Char(10) + @parameters + Char(13) + Char(10) + ' AS ' + 
				'SELECT ' + @SelectStatement + Char(13) + Char(10) + 
				'FROM [' + @tableName + '] ' + Char(13) + Char(10) +
				'WHERE ' + @WhereStatement
	-- Execute the SQL Statement to create the procedure
	Exec(@SQLStatement)

	-- Do the grant
	if len(@GrantProcedure) > 0 Begin
		Exec (@GrantProcedure)
	End	
End
Else
Begin
	--Print the Procedure to Results pane
	Print ''
	Print ''
	Print ''
	Print '--- Get Single Procedure for [' + @tableName + '] ---'
	Print @DropProcedure
	Print 'Go'
	Print 'CREATE PROCEDURE [' + @procedurename + ']'
	Print @parameters
	Print 'As'
	Print 'SELECT ' + @SelectStatement 
	Print 'FROM [' + @tableName + ']'
	Print 'WHERE ' + @WhereStatement
	Print 'GO'
	Print @GrantProcedure
	Print 'Go'
End
GO
/****** Object:  StoredProcedure [dbo].[aspCreateProcedure_Get]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Exec aspCreateProcedure_Get 'Contact', 1

Exec aspCreateProcedure_Get 'Contact', 1, 0, 'pre', 'suf', 'GetName'

Exec aspCreateProcedure_Get 'WiaContract.Action', 1, 0, '', '_Select', ''
*/
-- =========================================================================
-- 12/09/13 mparsons - updated to handle tables with dot notation (ex.Policy.Version)
-- =========================================================================
CREATE  Procedure [dbo].[aspCreateProcedure_Get] 
		@tableName 		varchar(128) 
		,@print 		bit 
		,@tableFirst	bit = 1
		,@Prefix		varchar(20) = '' 
		,@Suffix		varchar(20) = '' 
		,@ProcName		varchar(128) = 'Select' 

AS

Declare 
	@SQLStatement 		varchar(8000), 	--Actual Get Procedure string
	@SelectStatement 	varchar(8000), 	--Actual Select Statement that returns result set.
	@procedurename 		varchar(128), 	-- To store the procedure name
	@DropProcedure 		varchar(1000), --To Store Drop Procedure SQL Statement
	@GrantProcedure 	varchar(1000) 	--To Store Grant execute Procedure SQL Statement

SET @SelectStatement = ''

-- Get Columns from the table to be displayed.
SELECT @SelectStatement = @SelectStatement + 
				Case When @SelectStatement = '' Then ''  + Char(13) + Char(10) 
					Else ', ' + Char(13) + Char(10) 
				End + '    ' + COLUMN_NAME
FROM INFORMATION_SCHEMA.Columns
WHERE	table_name = @tableName

-- the following logic can be changed as per your standards. In our case tbl is for tables and tlkp is for lookup tables. Needed to remove tbl and tlkp...
SET @procedurename = @ProcName	--'Select'

If @tableFirst = 1 Begin
	-- Use syntax of prefix + TableName + ProcedureType + Suffix
	--	ex.	ContactSelect, uspContactSelect, ContactSelect_usp
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix +  + SubString(@tableName, 4, Len(@tableName))  + @procedurename  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @tableName + @procedurename  + @Suffix
	End
End
Else Begin
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix + @procedurename + SubString(@tableName, 4, Len(@tableName))  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @procedurename + @tableName + @Suffix
	End
End

--Stores DROP Procedure Statement
SET @DropProcedure = 'if exists (select * from dbo.sysobjects where id = object_id(N''[' + @procedurename + ']'') and OBJECTPROPERTY(id, N''IsProcedure'') = 1)' + Char(13) + Char(10) +
				'Drop Procedure [' + @procedurename + ']'

--Stores grant procedure statement
SET @GrantProcedure = 'grant execute on [' + @procedurename + '] to public ' 

-- In case you want to create the procedure pass in 0 for @print else pass in 1 and stored procedure will be displayed in results pane.
If @print = 0
Begin
	-- Drop the current procedure.
	Exec (@DropProcedure)
	-- Create the final procedure and store it..
	SET @SQLStatement = 	
				'CREATE PROCEDURE [' + @procedurename + '] ' +  Char(13) + Char(10) + ' AS ' + Char(13) + Char(10) +
				'SELECT ' + @SelectStatement + Char(13) + Char(10) + 
				'FROM [' + @tableName + '] ' + Char(13) + Char(10) 

	-- Execute the SQL Statement to create the procedure	
	Exec (@SQLStatement)
	-- Do the egrant
	Exec (@GrantProcedure)
End
Else
Begin
	--Print the Procedure to Results pane
	Print ''
	Print ''
	Print ''
	Print '--- Get Procedure for [' + @tableName + '] ---'
	Print @DropProcedure
	Print 'Go'
	Print 'CREATE PROCEDURE [' + @procedurename + ']'
	Print 'As'
	Print 'SELECT ' + @SelectStatement 
	Print 'FROM [' + @tableName + ']'
	Print 'GO'
	Print @GrantProcedure
	Print 'Go'
End
GO
/****** Object:  StoredProcedure [dbo].[aspCreateProcedure_Delete]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Exec aspCreateProcedure_Delete 'Contact', 1

Exec aspCreateProcedure_Delete 'Contact', 1, 0, 'pre', '_suf', 'DeleteName', 'GrantToMtce'

Exec aspCreateProcedure_Delete 'WiaContract.Action', 1, 0, '', '_Delete','', 'GrantToMtce'
*/
-- =========================================================================
-- 12/09/13 mparsons - updated to handle tables with dot notation (ex.Policy.Version)
-- =========================================================================
CREATE  Procedure [dbo].[aspCreateProcedure_Delete]
		@tableName 		varchar(128) 
		,@print 		bit 
		,@tableFirst	bit = 1
		,@Prefix		varchar(20) = '' 
		,@Suffix		varchar(20) = '' 
		,@ProcName		varchar(128) = 'Delete' 
		,@GrantGroup	varchar(128) = '' 
AS

Declare 
	@SQLStatement 		varchar(8000), --Actual Delete Procedure string
	@parameters 		varchar(8000), -- Parameters to be passed to the Stored Procedure
	@deleteStatement 	varchar(8000), -- To Store the Delete SQL Statement
	@procedurename 		varchar(128), -- To store the procedure name
	@DropProcedure 		varchar(1000), --Drop procedure sql statement
	@GrantProcedure 	varchar(1000) 	--To Store Grant execute Procedure SQL Statement

-- Initialize Variables
SET @parameters = ''
SET @deleteStatement = ''

--Get Parameters and Delete Where Clause needed for the Delete Procedure.
SELECT	@parameters = @parameters + 
			Case When @parameters = '' Then ''
					Else ', ' + Char(13) + Char(10) 
					End + '        @' + + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' ' + 
					DATA_TYPE + 
					Case When CHARACTER_MAXIMUM_LENGTH is not null Then 
						'(' + Cast(CHARACTER_MAXIMUM_LENGTH as varchar(4)) + ')' 
						Else '' 
					End,
	@deleteStatement = @deleteStatement + Case When @deleteStatement = '' Then ''
					Else ' AND ' + Char(13) + Char(10) 
					End + INFORMATION_SCHEMA.Columns.COLUMN_NAME + ' = @' + + INFORMATION_SCHEMA.Columns.COLUMN_NAME
FROM	
	INFORMATION_SCHEMA.Columns,
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS,
	INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE
WHERE 	INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.CONSTRAINT_NAME AND
	INFORMATION_SCHEMA.Columns.Column_name = INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE.Column_name AND
	INFORMATION_SCHEMA.Columns.table_name = INFORMATION_SCHEMA.TABLE_CONSTRAINTS.TABLE_NAME AND
	INFORMATION_SCHEMA.TABLE_CONSTRAINTS.table_name = @tableName AND 
	CONSTRAINT_TYPE = 'PRIMARY KEY'

-- the following logic can be changed as per your standards. 
SET @procedurename = @ProcName	--'Delete'

If @tableFirst = 1 Begin
	-- Use syntax of prefix + TableName + ProcedureType + Suffix
	--	ex.	ContactSelect, uspContactSelect, ContactSelect_usp
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix +  + SubString(@tableName, 4, Len(@tableName))  + @procedurename  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @tableName + @procedurename  + @Suffix
	End
End
Else Begin
	If Left(@tableName, 3) = 'tbl' Begin
		SET @procedurename = @Prefix + @procedurename + SubString(@tableName, 4, Len(@tableName))  + @Suffix
	End
	Else Begin
		-- In case none of the above standards are followed then just get the table name.
		SET @procedurename = @Prefix + @procedurename + @tableName + @Suffix
	End
End


--Stores DROP Procedure Statement
SET @DropProcedure = 'if exists (select * from dbo.sysobjects where id = object_id(N''[dbo].[' + @procedurename + ']'') and OBJECTPROPERTY(id, N''IsProcedure'') = 1)' + Char(13) + Char(10) +
				'Drop Procedure [' + @procedurename + ']'

--Stores grant procedure statement
if len(@GrantGroup) > 0 
	SET @GrantProcedure = 'grant execute on [' + @procedurename + ']  to ' + @GrantGroup
Else
	SET @GrantProcedure = ''

-- In case you want to create the procedure pass in 0 for @print else pass in 1 and stored procedure will be displayed in results pane.
If @print = 0
Begin
	-- Create the final procedure and store it..
	Exec (@DropProcedure)
	SET @SQLStatement = 'CREATE PROCEDURE [' + @procedurename + '] ' +  Char(13) + Char(10) + @parameters + Char(13) + Char(10) + ' AS ' + 
				 + Char(13) + Char(10) + ' Delete FROM [' + @tableName + '] ' + ' WHERE ' + @deleteStatement + Char(13) + Char(10) 

	-- Execute the SQL Statement to create the procedure
	--Print @SQLStatement
	Exec (@SQLStatement)

	-- Do the grant
	if len(@GrantProcedure) > 0 Begin
		Exec (@GrantProcedure)
	End	
End
Else
Begin
	--Print the Procedure to Results pane
	Print ''
	Print ''
	Print ''
	Print '--- Delete Procedure for [' + @tableName + '] ---'
	Print @DropProcedure
	Print 'GO'
	Print 'CREATE PROCEDURE [' + @procedurename + ']'
	Print @parameters
	Print 'As'
	Print 'DELETE FROM [' + @tableName + ']'
	Print 'WHERE ' + @deleteStatement
	Print 'GO'
	Print @GrantProcedure
	Print 'Go'
End
GO
/****** Object:  Table [dbo].[CareerCluster]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CareerCluster](
	[Id] [int] NOT NULL,
	[CareerCluster] [nvarchar](255) NOT NULL,
	[CisFileNum] [char](6) NULL,
	[IsHighGrowth] [bit] NULL,
	[IsActive] [bit] NULL,
	[NaicSect] [char](2) NULL,
	[ShortName] [varchar](25) NULL,
	[HighGrowthName] [varchar](75) NULL,
	[IsIlPathway] [bit] NULL,
	[IlPathwayName] [varchar](75) NULL,
	[prefix] [varchar](15) NULL,
	[Description] [nvarchar](255) NULL,
	[IlPathwayChannel] [varchar](75) NULL,
	[IlPathwayReportOrder] [int] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_CareerCluster] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.RatingType]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.RatingType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Type] [varchar](50) NULL,
	[Identifier] [varchar](500) NULL,
	[Description] [varchar](200) NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_RatingType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.PathwaysEducationLevel]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.PathwaysEducationLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[Description] [varchar](500) NULL,
	[IsPathwaysLevel] [bit] NULL,
	[AlignmentUrl] [varchar](150) NULL,
	[SortOrder] [int] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_PathwaysEducationLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.Language]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.Language](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[IsPathwaysLanguage] [bit] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.Language] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.AudienceType]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.AudienceType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[WarehouseTotal] [int] NOT NULL,
 CONSTRAINT [PK_ResourceAudienceType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.AlignmentType]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.AlignmentType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](50) NULL,
	[Title] [varchar](50) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.AlignmentType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.AccessRights]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.AccessRights](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.AccessRights] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceUrl] [varchar](500) NOT NULL,
	[ViewCount] [int] NULL,
	[FavoriteCount] [int] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[IsActive] [bit] NULL,
	[HasPathwayGradeLevel] [bit] NULL,
 CONSTRAINT [PK_Resource] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Resource_HasPathwayGradeLevel] ON [dbo].[Resource] 
(
	[HasPathwayGradeLevel] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource_ResourceUrl] ON [dbo].[Resource] 
(
	[ResourceUrl] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[RatingTypeInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Create RatingType record
-- =============================================
CREATE PROCEDURE [dbo].[RatingTypeInsert]
	@Type varchar(50),
	@Identifier varchar(500),
	@Description varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO RatingType ([Type], Identifier, [Description], Created)
	VALUES (@Type, @Identifier, @Description, GETDATE())
	
	SELECT @@IDENTITY AS Id
END
GO
/****** Object:  StoredProcedure [dbo].[RatingTypeGet]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Get RatingType
-- =============================================
CREATE PROCEDURE [dbo].[RatingTypeGet]
	@Id int,
	@Type varchar(50),
	@Identifier varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @Id = 0 SET @Id = NULL
	
	SELECT Id, [Type], Identifier, [Description], Created
	FROM RatingType
	WHERE (Id = @Id OR @Id IS NULL) AND
		([Type] = @Type OR @Type IS NULL) AND
		(Identifier = @Identifier OR @Identifier IS NULL)
END
GO
/****** Object:  Table [dbo].[PublisherSummary]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PublisherSummary](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Publisher] [varchar](200) NULL,
	[IsActive] [bit] NULL,
	[ResourceTotal] [int] NULL,
	[Note] [varchar](500) NULL,
 CONSTRAINT [PK_PublisherSummary] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[PublisherSearch]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*


DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @totalRows int
--
set @SortOrder = '[ResourceTotal] desc, Publisher'

-- blind search 
set @Filter = ''
set @Filter = ' Publisher like ''%free%'' ' 

set @StartPageIndex = 1
set @PageSize = 55

EXECUTE @RC = PublisherSearch
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/


CREATE PROCEDURE [dbo].[PublisherSearch]
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@lastRow int
      ,@minRows int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@Sql2            varchar(200)
      ,@DefaultFilter   varchar(1000)
      ,@OrderBy         varchar(100)
-- =================================

Set @debugLevel = 4

Set @DefaultFilter= ' (IsActive = 1) '
if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by Publisher '
--===================================================
-- Calculate the range
--===================================================      
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
SET @lastRow =  @StartPageIndex + @PageSize

-- =================================

  if len(isnull(@Filter,'')) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
        
     set @Filter =  @Filter + ' AND ' + @DefaultFilter
     end
  else begin
    set @Filter =     ' where ' + @DefaultFilter
    end

  print '@Filter len: '  +  convert(varchar,len(@Filter))

  set @SQL = 'SELECT Distinct    
   pub.[Publisher] ,pub.[ResourceTotal] FROM
   (SELECT 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
      [Publisher] ,[ResourceTotal]
  FROM [dbo].[PublisherSummary]  ' 
        + @Filter + ' 
   ) as DerivedTableName
       Inner join [dbo].[PublisherSummary] pub on DerivedTableName.[Publisher] = pub.[Publisher]
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' ' 
+ @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  exec (@SQL)
  
  --===============================
  DECLARE @TempItems TABLE
(
   RowsFound int
)


set @Sql2= 'SELECT count(*) FROM [dbo].[PublisherSummary]  '
        + @Filter + ' '

 print @Sql2
 INSERT INTO @TempItems (RowsFound)
  exec (@Sql2)
  
  select @TotalRows= RowsFound from @TempItems
GO
/****** Object:  Table [dbo].[Publish.Pending]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Publish.Pending](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[ResourceVersionId] [uniqueidentifier] NULL,
	[DocId] [varchar](500) NULL,
	[Reason] [varchar](100) NOT NULL,
	[IsPublished] [bit] NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NOT NULL,
	[PublishedDate] [datetime] NULL,
	[LrEnvelope] [varchar](max) NULL,
 CONSTRAINT [PK_Publish.Pending] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ConditionOfUse]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ConditionOfUse](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Summary] [varchar](50) NULL,
	[Title] [varchar](100) NULL,
	[Description] [varchar](800) NULL,
	[Url] [varchar](200) NULL,
	[IconUrl] [varchar](200) NULL,
	[ConditionOfUseCategory] [int] NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_ConditionOfUse] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Codes.SecretQuestion]    Script Date: 12/14/2012 10:55:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Codes.SecretQuestion](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
 CONSTRAINT [PK_ResourceSecretQuestion] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Patron]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](50) NOT NULL,
	[Password] [varchar](50) NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[Email] [varchar](100) NULL,
	[SecretQuestionId] [int] NULL,
	[SecretAnswer] [varchar](50) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedId] [int] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[workNetId] [int] NULL,
 CONSTRAINT [PK_Patron] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Patron_RowId] ON [dbo].[Patron] 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Patron_Username] ON [dbo].[Patron] 
(
	[UserName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Pathway]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Pathway](
	[Id] [int] NOT NULL,
	[Pathway] [varchar](50) NULL,
	[Created] [datetime] NULL,
	[CreatedBy] [varchar](75) NULL,
	[LastUpdated] [datetime] NULL,
	[UpdatedBy] [varchar](75) NULL,
 CONSTRAINT [PK_Pathway] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Comment]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Comment](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Comment] [varchar](max) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Resource.Comment] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[StandardBody.Topic]    Script Date: 12/14/2012 10:55:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[StandardBody.Topic](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StandardBodyId] [int] NOT NULL,
	[TopicParentId] [int] NULL,
	[Title] [varchar](200) NOT NULL,
	[Url] [varchar](200) NULL,
	[Code] [varchar](50) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_StandardBody.Subject] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[StandardBody.Standard]    Script Date: 12/14/2012 10:55:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[StandardBody.Standard](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ParentId] [int] NULL,
	[StandardSubjectId] [int] NULL,
	[StandardCode] [varchar](100) NULL,
	[Standard] [varchar](max) NULL,
	[StandardUrl] [varchar](200) NULL,
	[GradeLevel] [varchar](50) NULL,
	[Category] [varchar](200) NULL,
	[SubCategory] [varchar](200) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Standard] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[StandardBody.Node]    Script Date: 12/14/2012 10:55:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[StandardBody.Node](
	[Id] [int] NOT NULL,
	[ParentId] [int] NULL,
	[LevelType] [varchar](50) NULL,
	[NotationCode] [varchar](50) NULL,
	[Description] [varchar](max) NULL,
	[CCSSUrl] [varchar](200) NULL,
	[AltUrl] [varchar](200) NULL,
	[StandardGuid] [varchar](50) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Standard.TopicLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[StandardBody]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[StandardBody](
	[Id] [int] NOT NULL,
	[Title] [varchar](75) NULL,
	[ShortName] [varchar](25) NULL,
	[Url] [varchar](200) NULL,
	[Description] [varchar](max) NULL,
	[WarehouseTotal] [int] NULL,
 CONSTRAINT [PK_Codes.StandardType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Staging.EducationLevel]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Staging.EducationLevel](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[Name] [varchar](100) NULL,
	[Value] [varchar](300) NULL,
	[Imported] [datetime] NULL,
 CONSTRAINT [PK_Staging.EducationLevel] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_ResourceId] ON [dbo].[Staging.EducationLevel] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Sort.SpecialCharacter]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Sort.SpecialCharacter](
	[Id] [float] NULL,
	[Character] [nvarchar](10) NULL,
	[EntityNbr] [nvarchar](10) NULL,
	[EntityName] [nvarchar](10) NULL,
	[Description] [nvarchar](255) NULL,
	[IsDrop] [bit] NOT NULL,
	[IsReplace] [bit] NOT NULL,
	[ReplaceWith] [nvarchar](10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ServerDatabaseTables]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServerDatabaseTables](
	[ServerName] [nvarchar](128) NOT NULL,
	[DatabaseName] [nvarchar](128) NOT NULL,
	[tableName] [nvarchar](128) NOT NULL,
	[tableRowCount] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.KeywordCSV]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.KeywordCSV](
	[ResourceId] [uniqueidentifier] NOT NULL,
	[OriginalValue] [varchar](max) NULL,
	[KeywordsIdx]  AS (CONVERT([nvarchar](400),[OriginalValue],0)),
 CONSTRAINT [PK_Resource.Keyword] PRIMARY KEY CLUSTERED 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE FULLTEXT INDEX ON [dbo].[Resource.KeywordCSV](
[OriginalValue] LANGUAGE [English])
KEY INDEX [PK_Resource.Keyword]ON ([FTCatalog], FILEGROUP [PRIMARY])
WITH (CHANGE_TRACKING = AUTO, STOPLIST = SYSTEM)
GO
/****** Object:  Table [dbo].[Resource.Keyword.SplitRows]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Keyword.SplitRows](
	[RowId] [uniqueidentifier] NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Keyword] [varchar](900) NULL,
	[CreatedById] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Keyword.RowsToSplit]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Keyword.RowsToSplit](
	[RowId] [uniqueidentifier] NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Keyword] [varchar](900) NULL,
	[CreatedById] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Search]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Search](
	[ResourceId] [uniqueidentifier] NULL,
	[ResourceVersionId] [uniqueidentifier] NOT NULL,
	[SortTitle] [varchar](300) NULL,
	[Description] [varchar](max) NULL,
	[Subject] [varchar](900) NULL,
	[Keywords] [varchar](900) NULL,
	[Publisher] [varchar](200) NULL,
 CONSTRAINT [PK_Resource.Search] PRIMARY KEY CLUSTERED 
(
	[ResourceVersionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Search_Subject] ON [dbo].[Resource.Search] 
(
	[Subject] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Search_Title_Publisher] ON [dbo].[Resource.Search] 
(
	[SortTitle] ASC,
	[Publisher] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.SubjectSplit2]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.SubjectSplit2](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Subject] [varchar](900) NULL,
 CONSTRAINT [PK_Resource.SubjectSplit2] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE FULLTEXT INDEX ON [dbo].[Resource.SubjectSplit2](
[Subject] LANGUAGE [English])
KEY INDEX [PK_Resource.SubjectSplit2]ON ([FTCatalog_Subject], FILEGROUP [PRIMARY])
WITH (CHANGE_TRACKING = AUTO, STOPLIST = SYSTEM)
GO
/****** Object:  Table [dbo].[Resource.SubjectCsv]    Script Date: 12/14/2012 10:55:23 ******/
SET ARITHABORT ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
SET ARITHABORT ON
GO
CREATE TABLE [dbo].[Resource.SubjectCsv](
	[ResourceId] [uniqueidentifier] NOT NULL,
	[SubjectCsv] [varchar](max) NULL,
	[SubjectsIdx]  AS (CONVERT([nvarchar](400),[SubjectCsv],0)),
 CONSTRAINT [PK_Resource.Subject] PRIMARY KEY CLUSTERED 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
CREATE NONCLUSTERED INDEX [IX_Resource.SubjectsIdx] ON [dbo].[Resource.SubjectCsv] 
(
	[SubjectsIdx] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.Subject_20121030]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Subject_20121030](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Subject] [varchar](900) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Subject.SplitRows]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Subject.SplitRows](
	[RowId] [uniqueidentifier] NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Subject] [varchar](900) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Subject.RowsToSplit]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Subject.RowsToSplit](
	[RowId] [uniqueidentifier] NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Subject] [varchar](900) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Version_121022]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Version_121022](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[DocId] [varchar](500) NULL,
	[Title] [varchar](300) NOT NULL,
	[Description] [varchar](max) NULL,
	[Publisher] [varchar](200) NULL,
	[Creator] [varchar](200) NULL,
	[Rights] [varchar](700) NULL,
	[AccessRights] [varchar](100) NULL,
	[Modified] [datetime] NULL,
	[Submitter] [varchar](100) NULL,
	[Imported] [datetime] NULL,
	[Created] [datetime] NULL,
	[TypicalLearningTime] [varchar](50) NULL,
	[IsSkeletonFromParadata] [bit] NULL,
	[IsActive] [bit] NULL,
	[Requirements] [varchar](200) NULL,
	[Subjects] [varchar](900) NULL,
	[Keywords] [varchar](900) NULL,
 CONSTRAINT [PK_Resource.Version_121022] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionSelect]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/30/2012
-- Description:	Select ResourceVersion rows
-- =============================================
CREATE PROCEDURE [dbo].[Resource.VersionSelect]
	@Filter varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @sql varchar(max)
	SET @sql = 'SELECT vers.RowId, 
	base.RowId AS ResourceId,
	base.ResourceUrl,
	base.ViewCount,
	base.FavoriteCount,
	vers.DocId,
	vers.Title,
	vers.[Description],
	isnull(vers.Publisher,''Unknown'') AS Publisher,
	isnull(vers.Creator,''Unknown'') AS Creator,
	isnull(vers.Rights,''Unknown'') AS Rights,
	isnull(vers.AccessRights,''Unknown'') AS AccessRights,
	vers.Modified,
	vers.Submitter,
	isnull(vers.Imported, vers.Modified) AS Imported,
	vers.Created,
	isnull(vers.TypicalLearningTime,''Unknown'') AS TypicalLearningTime,
	vers.IsSkeletonFromParadata,
	isnull(rsub.subjects,'''') AS Subjects,
	isnull(edList.EducationLevels,'''') AS EducationLevels,
	''TBD'' AS Keywords,
	isnull(langList.LanguageList,'''') AS LanguageList,
	isnull(typesList.ResourceTypesList,'''') AS ResourceTypesList
FROM [Resource] base
INNER JOIN [Resource.Version] vers on base.RowId = vers.ResourceId
LEFT JOIN [dbo].[Resource.SubjectsCsvList] rsub on base.RowId = rsub.ResourceId
LEFT JOIN [dbo].[Resource.EducationLevelsList] edList on base.RowId = edList.ResourceId
LEFT JOIN [dbo].[Resource.LanguagesList] langList on base.RowId = langList.ResourceId
LEFT JOIN [dbo].[Resource.ResourceTypesList] typesList ON base.RowId = typesList.ResourceId
 ' + @Filter
 
	EXEC(@sql)
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.PropertySelect]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Create date: 6/16/2012
-- Description:	Select one or more name/value pairs for a resource
-- =============================================
CREATE PROCEDURE [dbo].[Resource.PropertySelect]
	@filter varchar(4000)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @sql varchar(4500)
	SET @sql = 'SELECT rp.RowId, ResourceId, PropertyTypeId, rpt.Title As [Name], [Value] FROM [Resource.Property] rp Inner join [Codes.ResPropertyType] rpt on rp.PropertyTypeId = rpt.Id ' + @filter

	PRINT @sql
	EXEC(@sql)
END
GO
/****** Object:  StoredProcedure [dbo].[ResourceSelect]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 6/5/2012
-- Description:	Select resources
-- 2012-07-02 jgrimmer Added SubmitterRowId and Created fields
-- 2012-08-30 jgrimmer Dropped fields moved to [Resource.Version] table.
-- 2012-09-21 jgrimmer Added Created and LastUpdated fields
-- =============================================
CREATE PROCEDURE [dbo].[ResourceSelect]
	@filter varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @sql varchar(max)
	SET @sql = 'SELECT RowId, ResourceUrl, ViewCount, FavoriteCount, Created, LastUpdated
FROM [Resource]
' + @filter

	PRINT @sql
	EXEC(@sql)
END
GO
/****** Object:  StoredProcedure [dbo].[ResourceInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 6/5/2012
-- Description:	Insert a resource row
-- 2012-07-02 jgrimmer - Added @SubmitterRowId, @Created
-- 2012-08-24 jgrimmer - Added @TypicalLearningTime
-- 2012-08-30 jgrimmer - Dropped fields found in [Resource.Version] table
-- 2012-09-21 jgrimmer - Added Created and LastUpdated dates
-- =============================================
CREATE PROCEDURE [dbo].[ResourceInsert]
	@ResourceUrl varchar(500),
	@ViewCount int,
	@FavoriteCount int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @NewId uniqueidentifier
	set @NewId= NEWID()
	IF @ViewCount IS NULL SET @ViewCount = 0
	IF @FavoriteCount IS NULL SET @FavoriteCount =0

	INSERT INTO [Resource] (RowId, ResourceUrl, ViewCount, FavoriteCount, Created, LastUpdated)
	VALUES (@NewId, @ResourceUrl, @ViewCount, @FavoriteCount, GETDATE(), GETDATE())

	select @NewId as Id	
END
GO
/****** Object:  StoredProcedure [dbo].[ResourceGet]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
declare @Id varchar(50)
set @Id = 'AD95FAD2-FC7B-48EE-8F51-E6904F7A9589'
set @Id = 'd9fe9bb9-f719-43f3-b3e6-1272b1684488'
--set @Id = 'e0219864-cb78-4146-b043-4e6476e3933e'
exec [ResourceGet]  @Id, '',''

[ResourceGet]  '', 'http://www.carcam.org/docs/surveyresults.pdf',''

*/


/* =============================================
-- Author:		Jerome Grimmer
-- Create date: 6/5/2012
-- Description:	Get a resource
	Note: should not do a get just by resourceUrl as can have duplicates by submitter
-- modifications
-- 12-06-15 mparsons added get by @ResourceUrl
-- 12-06-29 jgrimmer added get by @SubmitterRowId
-- 12-06-29 jgrimmer added SubmitterRowId and Created fields
-- 12-08-30 jgrimmer split fields between [Resource] and [Resource.Version] tables.
--					 modified so it gets a single row.
-- 12-09-21 jgrimmer added Created and LastUpdated fields
-- =============================================
*/
CREATE PROCEDURE [dbo].[ResourceGet]
	@RowId uniqueidentifier
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT distinct
		base.RowId, 
		base.ResourceUrl, 
		base.ViewCount,
		base.FavoriteCount,
		base.Created,
		base.LastUpdated
	
	FROM [Resource] base
	WHERE base.RowId = @RowId
	
END
GO
/****** Object:  StoredProcedure [dbo].[ResourceEducationLevel_SearchCounts]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT [RowId]
      ,[ResourceId]
      ,[ResourceTypeId]
      ,[OriginalType]
  FROM [dbo].[Resource.ResourceType] base
  inner join [Codes.ResourceType] crt on base.ResourceTypeId = crt.Id
  
SELECT crt.Title,  SortOrder      ,Count(*) As RecordCount
  FROM [dbo].[Resource.ResourceType] base
  inner join [Codes.ResourceType] crt on base.ResourceTypeId = crt.Id
  group by crt.Title,  SortOrder
  
  
  Order by crt.SortOrder
  
GO


-- ===========================================================
DECLARE @RC int,@Filter varchar(5000)

set @Filter = ' where lr.Title like ''%manu%'' OR lr.Description like
''%manu%''  '

set @Filter = ' where ( (lr.Title like ''%Energy%'' OR lr.[Description] like ''%Energy%'' OR lrp.Value like ''%Energy%'') OR (lr.Title like ''%Finance%'' OR lr.[Description] like ''%Finance%'' OR lrp.Value like ''%Finance%'') OR (lr.Title like ''%Health Science%'' OR lr.[Description] like ''%Health Science%'' OR lrp.Value like ''%Health Science%'') ) AND (lrp.Value in (''high school'',''Higher Education'')) '

--set @Filter = @Filter + ' AND (edList.Level in (''secondary'')) '

EXECUTE @RC = ResourceEducationLevel_SearchCounts  @Filter

*/

/* =============================================
Description:      Resource Education search - returns group by count, typically using the same filter as for the resource search; shown on narrowing filters
  
------------------------------------------------------
Modifications
12-07-10 mparsons - new
=============================================

*/

CREATE PROCEDURE [dbo].[ResourceEducationLevel_SearchCounts]
		@Filter           varchar(5000)
As

SET NOCOUNT ON;
-- paging
DECLARE
      @debugLevel      int
      ,@SQL             varchar(5000)
      ,@GroupBy         varchar(200)

-- =================================

Set @debugLevel = 4

set @GroupBy = ' group by edList.PathwaysEducationLevelId  '

-- =================================

CREATE TABLE #tempWorkTable(
      PathwaysEducationLevelId int,
      RecordCount	int
)

-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
  set @SQL = 'SELECT edList.PathwaysEducationLevelId, Count(*) As RecordCount 
		FROM dbo.Resource lr
        Left JOIN dbo.[Resource.Property] lrp ON lr.RowId = lrp.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.RowId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId  '
        + @Filter

  set @SQL = @SQL + ' ' + @GroupBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (PathwaysEducationLevelId,RecordCount)
  exec (@SQL)
  
  
SELECT rel.PathwaysEducationLevelId As Id, 
codes.Title, 
codes.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
RecordCount 
FROM #tempWorkTable rel
INNER JOIN dbo.[Codes.PathwaysEducationLevel] codes ON rel.PathwaysEducationLevelId = codes.Id
where codes.IsPathwaysLevel= 1
order by codes.SortOrder, codes.Title

-- =================================
GO
/****** Object:  StoredProcedure [dbo].[ResourceDelete]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/24/2012
-- Description:	Delete a resource
-- =============================================
CREATE PROCEDURE [dbo].[ResourceDelete]
	@RowId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DELETE FROM [Resource]
    WHERE RowId = @RowId
END
GO
/****** Object:  Table [dbo].[Resource.Standard]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Standard](
	[RowID] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[StandardId] [int] NULL,
	[OriginalValue] [varchar](200) NULL,
	[StandardUrl] [varchar](200) NULL,
	[AlignedById] [int] NULL,
	[DegreeOfAlignment] [int] NULL,
 CONSTRAINT [PK_Resource.StandardAlignment] PRIMARY KEY CLUSTERED 
(
	[RowID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Version]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Version](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[DocId] [varchar](500) NULL,
	[Title] [varchar](300) NOT NULL,
	[Description] [varchar](max) NULL,
	[Publisher] [varchar](200) NULL,
	[Creator] [varchar](200) NULL,
	[Rights] [varchar](700) NULL,
	[AccessRights] [varchar](100) NULL,
	[Modified] [datetime] NULL,
	[Submitter] [varchar](100) NULL,
	[Imported] [datetime] NULL,
	[Created] [datetime] NULL,
	[TypicalLearningTime] [varchar](50) NULL,
	[IsSkeletonFromParadata] [bit] NULL,
	[IsActive] [bit] NULL,
	[Requirements] [varchar](200) NULL,
	[Subjects] [varchar](900) NULL,
	[Keywords] [varchar](900) NULL,
	[SortTitle] [varchar](300) NULL,
 CONSTRAINT [PK_Resource.Version] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Version_IsActive] ON [dbo].[Resource.Version] 
(
	[IsActive] DESC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Version_Publisher] ON [dbo].[Resource.Version] 
(
	[Publisher] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Version_ResourceId] ON [dbo].[Resource.Version] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Version_subjects] ON [dbo].[Resource.Version] 
(
	[Subjects] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_ResourceVersion_Title] ON [dbo].[Resource.Version] 
(
	[Title] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE FULLTEXT INDEX ON [dbo].[Resource.Version](
[AccessRights] LANGUAGE [English], 
[Description] LANGUAGE [English], 
[Publisher] LANGUAGE [English], 
[Title] LANGUAGE [English])
KEY INDEX [PK_Resource.Version]ON ([FTCatalog], FILEGROUP [PRIMARY])
WITH (CHANGE_TRACKING = AUTO, STOPLIST = SYSTEM)
GO
/****** Object:  Table [dbo].[Resource.Subject]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Subject](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Subject] [varchar](900) NULL,
 CONSTRAINT [PK_Resource.SubjectSplit] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Subject_ResId] ON [dbo].[Resource.Subject] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_SubjectSplit_Subject] ON [dbo].[Resource.Subject] 
(
	[Subject] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.Language]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Language](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[LanguageId] [int] NULL,
	[OriginalLanguage] [varchar](100) NULL,
 CONSTRAINT [PK_ResourceLanguage] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Language_ResourceId] ON [dbo].[Resource.Language] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.Keyword]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Keyword](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[Keyword] [varchar](900) NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Resource.KeywordSplit] PRIMARY KEY NONCLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE CLUSTERED INDEX [IX_Resource.Keyword_ResourceId] ON [dbo].[Resource.Keyword] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.Keyword_Keyword] ON [dbo].[Resource.Keyword] 
(
	[Keyword] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.RatingSummary]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Resource.RatingSummary](
	[ResourceId] [uniqueidentifier] NOT NULL,
	[RatingTypeId] [int] NOT NULL,
	[RatingCount] [int] NULL,
	[RatingTotal] [int] NULL,
	[RatingAverage] [decimal](5, 2) NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Resource.RatingSummary] PRIMARY KEY CLUSTERED 
(
	[ResourceId] ASC,
	[RatingTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.Rating]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Rating](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[RatingById] [int] NULL,
	[RatingValue] [tinyint] NULL,
	[RatingTypeId] [int] NULL,
	[Comment] [varchar](200) NULL,
 CONSTRAINT [PK_Resource_Rating] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Resource.Property]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Property](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[Name] [varchar](100) NULL,
	[Value] [varchar](300) NULL,
	[PropertyTypeId] [int] NULL,
	[Imported] [datetime] NULL,
 CONSTRAINT [PK_ResourceProperty] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_ResourceId] ON [dbo].[Resource.Property] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_ResourceProperty_PropertyTypeId] ON [dbo].[Resource.Property] 
(
	[PropertyTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_ResourceProperty_PTypeIdValue] ON [dbo].[Resource.Property] 
(
	[PropertyTypeId] ASC,
	[Value] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[Resource.PathwaySelect]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.PathwaySelect] ''
*/
CREATE PROCEDURE [dbo].[Resource.PathwaySelect]
    @ResourceId uniqueidentifier
As
SELECT 
	base.Id, base.IlPathwayName As Title
--    ,ResourceId
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as HasCluster
FROM [dbo].CareerCluster base
Left Join [Resource.Pathway] rpw on base.Id = rpw.PathwayId
		and rpw.ResourceId = @ResourceId
where IsIlPathway = 1

Order by base.IlPathwayName
GO
/****** Object:  Table [dbo].[Resource.ResourceType]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.ResourceType](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[ResourceTypeId] [int] NULL,
	[OriginalType] [varchar](100) NULL,
 CONSTRAINT [PK_Resource_ResourceType] PRIMARY KEY NONCLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE CLUSTERED INDEX [IX_Resource.ResourceId_Type] ON [dbo].[Resource.ResourceType] 
(
	[ResourceId] ASC,
	[ResourceTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Resource.ResourceType_Id] ON [dbo].[Resource.ResourceType] 
(
	[ResourceTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[ResourceUpdate]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 6/5/2012
-- Description:	Update Resource
-- 2012-07-02 jgrimmer - Added SubmitterRowId, Imported, and Created
-- 2012-08-24 jgrimmer - Added TypicalLearningTime
-- 2012-09-21 jgrimmer - Removed fields moved to ResourceVersion and added Created and LastUpdated fields
-- =============================================
CREATE PROCEDURE [dbo].[ResourceUpdate]
	@RowId uniqueidentifier, 
	@ResourceUrl varchar(500),
	@ViewCount int,
	@FavoriteCount int
AS
--	@ResourceUrl varchar(500),
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	UPDATE [Resource]
	SET ResourceUrl = @ResourceUrl,
		ViewCount = @ViewCount,
		FavoriteCount = @FavoriteCount,
		LastUpdated = GETDATE()
	WHERE RowId = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[ResourceType_SearchCounts]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT [RowId]
      ,[ResourceId]
      ,[ResourceTypeId]
      ,[OriginalType]
  FROM [dbo].[Resource.ResourceType] base
  inner join [Codes.ResourceType] crt on base.ResourceTypeId = crt.Id
  
SELECT crt.Title,  SortOrder      ,Count(*) As RecordCount
  FROM [dbo].[Resource.ResourceType] base
  inner join [Codes.ResourceType] crt on base.ResourceTypeId = crt.Id
  group by crt.Title,  SortOrder
  
  
  Order by crt.SortOrder
  
GO


-- ===========================================================
DECLARE @RC int,@Filter varchar(5000)

set @Filter = ' where lr.Title like ''%manu%'' OR lr.Description like
''%manu%''  '

set @Filter = ' where ( (lr.Title like ''%Energy%'' OR lr.[Description] like ''%Energy%'' OR lrp.Value like ''%Energy%'') OR (lr.Title like ''%Finance%'' OR lr.[Description] like ''%Finance%'' OR lrp.Value like ''%Finance%'') OR (lr.Title like ''%Health Science%'' OR lr.[Description] like ''%Health Science%'' OR lrp.Value like ''%Health Science%'') ) AND (lrp.Value in (''high school'',''Higher Education'')) '

--set @Filter = @Filter + ' AND (edList.Level in (''secondary'')) '
set @Filter = ''
EXECUTE @RC = ResourceType_SearchCounts  @Filter

*/

/* =============================================
      Description:      Resource Type search - returns group by count, typically using the same filter as for the research search
  
------------------------------------------------------
Modifications
12-06-29 mparsons - new
=============================================

*/

CREATE PROCEDURE [dbo].[ResourceType_SearchCounts]
		@Filter           varchar(5000)
As

SET NOCOUNT ON;
-- paging
DECLARE
      @debugLevel      int
      ,@SQL             varchar(5000)
      ,@GroupBy         varchar(200)

-- =================================

Set @debugLevel = 4

set @GroupBy = ' group by rrt.ResourceTypeId  '

-- =================================

CREATE TABLE #tempWorkTable(
      ResourceTypeId int,
      RecordCount	int
)

-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
--        Left JOIN dbo.[EducationLevel] edList ON lr.RowId = edList.ResourceId 
  set @SQL = 'SELECT rrt.ResourceTypeId, Count(*) As RecordCount 
		FROM dbo.Resource lr
        INNER JOIN dbo.[Resource.Property] lrp ON lr.RowId = lrp.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.RowId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId  '
        + @Filter

  set @SQL = @SQL + ' ' + @GroupBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (ResourceTypeId,RecordCount)
  exec (@SQL)
  
  
SELECT rrt.ResourceTypeId As Id, 
crt.Title, 
crt.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
RecordCount 
FROM #tempWorkTable rrt
Inner Join dbo.[Codes.ResourceType] crt on rrt.ResourceTypeId = crt.Id
order by crt.SortOrder, crt.Title

-- =================================
GO
/****** Object:  StoredProcedure [dbo].[StandardBody.NodeInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[StandardBody.NodeInsert]
            @ParentId int, 
            @LevelType varchar(50), 
            @NotationCode varchar(50), 
            @Description varchar(MAX), 
            @CCSSUrl varchar(200), 
            @AltUrl varchar(200), 
            @StandardGuid varchar(50)
As
If @ParentId = 0   SET @ParentId = NULL 
If @NotationCode = ''   SET @NotationCode = NULL 
If @Description = ''   SET @Description = NULL 
If @CCSSUrl = ''   SET @CCSSUrl = NULL 
If @AltUrl = ''   SET @AltUrl = NULL 
If @StandardGuid = ''   SET @StandardGuid = NULL 

INSERT INTO [StandardBody.Node] (

    ParentId, 
    LevelType, 
    NotationCode, 
    Description, 
    CCSSUrl, 
    AltUrl, 
    StandardGuid
)
Values (

    @ParentId, 
    @LevelType, 
    @NotationCode, 
    @Description, 
    @CCSSUrl, 
    @AltUrl, 
    @StandardGuid
)
 
select SCOPE_IDENTITY() as Id
GO
/****** Object:  StoredProcedure [dbo].[CodeTable_Select]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
GetCodeValues "Gender", "IntegerValue" ,"en"

[CodeTable_Select] "GridPageSize", "IntegerValue" ,"en"

[P_VOS_GET_CODES] "Ethnicity", "IntegerValue" ,"es"
*/

-- =============================================
-- CodeTable_Select
-- Description:	copied [P_VOS_GET_CODES] to replicate processing
-- =============================================
CREATE PROCEDURE [dbo].[CodeTable_Select] 
			@Code varchar(50),
			@Sort varchar(20),
			@Language	varchar(10)
AS
BEGIN
	SET NOCOUNT ON;
	
SELECT *	
FROM [codeTable]
Where CodeName = @Code 
AND LanguageCode = @Language
And IsActive = 1
Order by 
	CASE @Sort 
		WHEN 'CodeName' THEN CodeName 
		WHEN 'StringValue' THEN StringValue 
		WHEN 'Description' Then Description
	END, 
	CASE @Sort 
		WHEN 'NumericValue' THEN NumericValue
	END,
	CASE @Sort 
		WHEN 'Id' THEN Id
		WHEN 'IntegerValue' THEN IntegerValue 
		WHEN 'SortOrder' THEN SortOrder
	END,
	CASE @Sort
		WHEN 'Created' THEN Created
		WHEN 'Modified' THEN Modified
	END

END
GO
/****** Object:  Table [dbo].[Resource.IntendedAudience]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.IntendedAudience](
	[RowID] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[AudienceId] [int] NULL,
	[OriginalAudience] [varchar](50) NOT NULL,
 CONSTRAINT [PK_IntendedAudience] PRIMARY KEY CLUSTERED 
(
	[RowID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Resource.IntendedAudience_ResourceId] ON [dbo].[Resource.IntendedAudience] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.Format]    Script Date: 12/14/2012 10:55:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.Format](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[OriginalValue] [varchar](200) NULL,
	[CodeId] [int] NULL,
 CONSTRAINT [PK_Resource.Format] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_ResourceFormat_CodeId] ON [dbo].[Resource.Format] 
(
	[CodeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_ResourceFormat_ResourceId] ON [dbo].[Resource.Format] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Resource.EducationLevel]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Resource.EducationLevel](
	[RowId] [uniqueidentifier] NOT NULL,
	[ResourceId] [uniqueidentifier] NULL,
	[PathwaysEducationLevelId] [int] NULL,
	[OriginalLevel] [varchar](100) NULL,
 CONSTRAINT [PK_EducationLevel] PRIMARY KEY NONCLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE CLUSTERED INDEX [IX_Resource.EducationLevel_ResourceId] ON [dbo].[Resource.EducationLevel] 
(
	[ResourceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_ResourcePathwaysEducationLevelId] ON [dbo].[Resource.EducationLevel] 
(
	[PathwaysEducationLevelId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[Map.Rules_Load]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/31/2012
-- Description:	Load all map rules from Map.Rules table
-- =============================================
CREATE PROCEDURE [dbo].[Map.Rules_Load]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT rules.Id, ruletype.Title AS PropertyType, PropertyTypeId, OriginalValue, IsRegex, IsCaseSensitive, ImportWithoutTranslation,
		DoNotImport, MappedValue, Sequence, IsActive, Created, CreatedBy, LastUpdated, LastUpdatedBy,
		CASE
			WHEN rules.PropertyTypeId = 1 AND rules.MappedValue = audience.Title THEN audience.Id
			WHEN rules.PropertyTypeId = 2 AND rules.MappedValue = education.Title THEN education.Id
			WHEN rules.PropertyTypeId = 3 AND rules.MappedValue = format.Title THEN format.Id
			WHEN rules.PropertyTypeId = 7 AND rules.MappedValue = [type].Title THEN [type].Id
			ELSE NULL
		END AS MappedId
	FROM dbo.[Map.Rules] rules
	INNER JOIN [Codes.ResPropertyType] ruletype ON rules.PropertyTypeId = ruletype.Id
	LEFT JOIN [Codes.AudienceType] audience ON rules.MappedValue = audience.Title 
		AND rules.PropertyTypeId = 1
	LEFT JOIN [Codes.PathwaysEducationLevel] education ON rules.MappedValue = education.Title 
		AND rules.PropertyTypeId = 2
	LEFT JOIN [Codes.ResourceFormat] format ON rules.MappedValue = format.Title
		AND rules.PropertyTypeId = 3
	LEFT JOIN [Codes.ResourceType] [type] ON rules.MappedValue = [type].Title
		AND rules.PropertyTypeId = 7
END
GO
/****** Object:  Table [dbo].[Resource.Cluster]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Resource.Cluster](
	[ResourceId] [uniqueidentifier] NOT NULL,
	[ClusterId] [int] NOT NULL,
 CONSTRAINT [PK_Resource.Pathway] PRIMARY KEY CLUSTERED 
(
	[ResourceId] ASC,
	[ClusterId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Patron.Library]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron.Library](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NULL,
	[Title] [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedId] [int] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Patron.Library] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Patron.Library_PatronId] ON [dbo].[Patron.Library] 
(
	[UserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Patron.ExternalAccount]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron.ExternalAccount](
	[PatronId] [int] NULL,
	[Id] [int] NOT NULL,
	[Account] [varchar](100) NULL,
	[LoginId] [varchar](100) NULL,
	[Password] [varchar](50) NULL,
	[Token] [varchar](50) NULL,
 CONSTRAINT [PK_Patron.ExternalAccount] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Patron.Action]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron.Action](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PatronId] [int] NULL,
	[ActionType] [varchar](50) NULL,
	[ActionRowId] [uniqueidentifier] NOT NULL,
	[Comment] [varchar](500) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Patron.Action] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE CLUSTERED INDEX [IX_Patron.Action_Patron] ON [dbo].[Patron.Action] 
(
	[PatronId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Patron.Action_ActionRowId] ON [dbo].[Patron.Action] 
(
	[ActionRowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[Codes.ResPropertyType_Lookup]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 09/04/2012
-- Description:	Lookup a Resource Property Type by name
-- =============================================
CREATE PROCEDURE [dbo].[Codes.ResPropertyType_Lookup]
	@Title varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT Id, Title
    FROM [Codes.ResPropertyType]
    WHERE Title = @Title
END
GO
/****** Object:  StoredProcedure [dbo].[PatronUpdate]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--- Update Procedure for [Patron] ---
CREATE PROCEDURE [dbo].[PatronUpdate]
		@Id int,
        @UserName varchar(50), 
        @Password varchar(50), 
        @FirstName varchar(50), 
        @LastName varchar(50), 
        @Email varchar(100), 
        @SecretQuestionId int, 
        @SecretAnswer varchar(50), 
        @workNetId int 

As
If @UserName = ''   SET @UserName = NULL 
If @Password = ''   SET @Password = NULL 
If @FirstName = ''   SET @FirstName = NULL 
If @LastName = ''   SET @LastName = NULL 
If @Email = ''   SET @Email = NULL 
If @SecretQuestionId = 0   SET @SecretQuestionId = NULL 
If @SecretAnswer = ''   SET @SecretAnswer = NULL 
If @workNetId = 0 SET @workNetId = NULL

UPDATE [Patron] 
SET 
    UserName = @UserName, 
    Password = @Password, 
    FirstName = @FirstName, 
    LastName = @LastName, 
    Email = @Email, 
    SecretQuestionId = @SecretQuestionId, 
    SecretAnswer = @SecretAnswer, 
	workNetId = @workNetId
WHERE Id = @Id
GO
/****** Object:  StoredProcedure [dbo].[PatronSelect]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[PatronSelect]
As
SELECT 
    Id, 
    UserName, 
    Password, 
    FirstName, 
    LastName, 
    Email, 
    SecretQuestionId, 
    SecretAnswer, 
    Created, 
    LastUpdated, 
    LastUpdatedId, 
    RowId
FROM [Patron]
GO
/****** Object:  StoredProcedure [dbo].[PatronInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[PatronInsert]
            @UserName varchar(50), 
            @Password varchar(50), 
            @FirstName varchar(50), 
            @LastName varchar(50), 
            @Email varchar(100), 
            @SecretQuestionId int, 
            @SecretAnswer varchar(50), 
            @workNetId int
As
If @UserName = ''   SET @UserName = NULL 
If @Password = ''   SET @Password = NULL 
If @FirstName = ''   SET @FirstName = NULL 
If @LastName = ''   SET @LastName = NULL 
If @Email = ''   SET @Email = NULL 
If @SecretQuestionId = 0   SET @SecretQuestionId = NULL 
If @SecretAnswer = ''   SET @SecretAnswer = NULL 
If @workNetId = 0 SET @workNetId = NULL
INSERT INTO [Patron] (

    UserName, 
    Password, 
    FirstName, 
    LastName, 
    Email, 
    SecretQuestionId, 
    SecretAnswer, 
    workNetId
)
Values (

    @UserName, 
    @Password, 
    @FirstName, 
    @LastName, 
    @Email, 
    @SecretQuestionId, 
    @SecretAnswer, 
    @workNetId
)
 
select SCOPE_IDENTITY() as Id
GO
/****** Object:  StoredProcedure [dbo].[PatronGet]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
PatronGet 'IllinoisPathways','77BAE02B-9E76-4877-A90C-BFFFE9B3464E'
*/
CREATE PROCEDURE [dbo].[PatronGet]
		@Id int

As

SELECT 
    Id, 
    UserName,  
    FirstName, 
    LastName, 
    Email, 
    SecretQuestionId, 
    SecretAnswer, 
    Created, 
    LastUpdated, 
    LastUpdatedId
FROM [Patron]

WHERE	Id = @Id
GO
/****** Object:  StoredProcedure [dbo].[PatronAuthorize]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
PatronAuthorize 'IllinoisPathways','77BAE02B-9E76-4877-A90C-BFFFE9B3464E'
*/
CREATE PROCEDURE [dbo].[PatronAuthorize]
		@UserName varchar(50),
		@Password varchar(50)

As

if NOT exists( SELECT * FROM [Patron] WHERE UserName = @UserName AND Password = @Password ) begin
                print '�internal test message'
                RAISERROR(' Invalid Username or Password ', 18, 1)    
                RETURN -1 
                End


SELECT 
    Id, 
    UserName,  
    FirstName, 
    Password,
    LastName, 
    Email, 
    SecretQuestionId, 
    SecretAnswer, 
    Created, 
    LastUpdated, 
    LastUpdatedId
FROM [Patron]

WHERE	UserName = @UserName AND
		Password = @Password
GO
/****** Object:  Table [dbo].[Patron.SearchFilter]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron.SearchFilter](
	[RowId] [uniqueidentifier] NOT NULL,
	[UserId] [int] NOT NULL,
	[Title] [varchar](100) NOT NULL,
	[SQL] [varchar](1000) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Patron.SearchFilter] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Patron.Profile]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron.Profile](
	[UserId] [int] NOT NULL,
	[MainPhone] [varchar](15) NOT NULL,
	[JobTitle] [varchar](50) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedId] [int] NULL,
 CONSTRAINT [PK_Patron.Profile] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Patron.Note]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron.Note](
	[RowId] [uniqueidentifier] NOT NULL,
	[UserId] [int] NOT NULL,
	[Title] [varchar](100) NOT NULL,
	[Category] [varchar](50) NULL,
	[Description] [varchar](max) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Patron.Note] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Patron.Note_UserId] ON [dbo].[Patron.Note] 
(
	[UserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[CareerClusterSelect]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
CareerClusterSelect 0, ''

CareerClusterSelect 11, ''

*/
-- =============================================
-- Author:		Michael Parsons
-- get list of IL Pathways career clusters
-- Modifications
-- 
-- =============================================
CREATE PROCEDURE [dbo].[CareerClusterSelect]
	@ClusterId		      int,
  @IlPathwayChannel  varchar(50)
AS
BEGIN
	SET NOCOUNT ON;
  If @ClusterId = 0				      SET @ClusterId = null
  If @IlPathwayChannel = ''			SET @IlPathwayChannel = null
  SELECT 
      [Id]
      ,IlPathwayName As Title
      ,IlPathwayName + ' (' + convert(varchar, isnull(WareHouseTotal,0)) + ')' As FormattedTitle
      ,[prefix], [Description]
      ,IlPathwayChannel

    FROM [CareerCluster]
  Where 
  (IsActive = 1 and IsIlPathway = 1)
  And (Id = @ClusterId		or @ClusterId is null)
  And (IlPathwayChannel = @IlPathwayChannel		or @IlPathwayChannel is null)
  Order by IlPathwayName
END
GO
/****** Object:  StoredProcedure [dbo].[AuditReport_Insert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/2/2012
-- Description:	Create an Audit Report record
-- =============================================
CREATE PROCEDURE [dbo].[AuditReport_Insert]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO AuditReport (Created)
	VALUES (getdate())

	SELECT @@IDENTITY AS ReportId
END
GO
/****** Object:  StoredProcedure [dbo].[AuditReport.Detail_Insert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/2/2012
-- Description:	Create a detail record for the audit report
-- =============================================
CREATE PROCEDURE [dbo].[AuditReport.Detail_Insert]
	@ReportId int, @FileName varchar(100), @DocID varchar(100),
	@URI varchar(500), @MessageType char(1), @MessageRouting varchar(2),
	@Message varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [AuditReport.Detail] (ReportId, [Filename], DocID, URI, MessageType,
		MessageRouting, Message)
	VALUES (@ReportId, @FileName, @DocID, @URI, @MessageType, @MessageRouting, @Message)
END
GO
/****** Object:  StoredProcedure [dbo].[aspAllDatabaseTableCounts]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- raw select without any joins - for updates
/*
exec aspAllDatabaseTableCounts null, null, 10
exec aspAllDatabaseTableCounts 'Vos_DB', 'base table', 15

exec aspAllDatabaseTableCounts 'LearningRegistryCache_Dev_20120928', 'base table', 15

*/
-- =========================================================
-- = Display row count for all tables in passed database 
-- = or all databases if @DbName is null
-- =
-- = NOTE:
-- = place in master database to make available from all databases 
-- =========================================================
CREATE PROCEDURE [dbo].[aspAllDatabaseTableCounts]
	@DbName		varchar(50) = null,
	@TypeFilter	varchar(25) = null,
	@Debug 		int = 0
   	with recompile
As
--@TypeFilter can be:
--	'Base Table'
--	View
--  NULL
declare
    @msg            char(255),
	@tableFetch_cnt	int,
	@tableRowCount		int,
	@tableNbr		int,
	@Table			varchar(75),
	@fetch_cnt		int,
	@DatabaseCnt	int,
	@DatabaseNbr	int,
	@CountSql		varchar(800),
	@SelectSql		varchar(800),
	@InsertSql		varchar(800),
	@TablesSql		varchar(800),
	@db				varchar(75),
	@AltOwner		varchar(25),
	@ServerName		varchar(50)
	,@EntityFilter nvarchar(25) 

set @DatabaseNbr = 0
set @tableNbr = 0

set @ServerName = @@Servername

set nocount on
set @AltOwner = 'dbo.'

if (@TypeFilter is null) 
	set @entityFilter = null
else begin
	set @entityFilter = lower(@TypeFilter) 
end

create table #tmpDbTables (
  Table_Name     nvarchar(128) NOT NULL
)
create table #ServerDatabaseTables (
  ServerName 	nvarchar(128) NOT NULL,
  DatabaseName 	nvarchar(128) NOT NULL,
  tableName     nvarchar(128) NOT NULL,
  tableRowCount    int         
)

IF Not EXISTS (SELECT name, type from sysobjects where type = 'U' and name = N'ServerDatabaseTables') begin 
	print 'create ServerDatabaseTables'
	create table ServerDatabaseTables (
	  ServerName 	nvarchar(128) NOT NULL,
	  DatabaseName 	nvarchar(128) NOT NULL,
	  tableName     nvarchar(128) NOT NULL,
	  tableRowCount    int         
	)
	end
declare curDatabase CURSOR FOR
	-- Get Databases

	SELECT 
		Name As DatabaseName
	FROM 
		master.dbo.sysdatabases
	WHERE 	name NOT IN 
		(
		 'master', 'model', 'tempdb', 'msdb', 
		 'distribution', 'pubs', 'northwind'
		)
		AND DATABASEPROPERTY(name, 'IsOffline') = 0 
		AND DATABASEPROPERTY(name, 'IsSuspect') = 0 
		And Name = @DbName or @DbName is null
	ORDER BY 
		DB_NAME(dbid)

open  curDatabase
fetch next from curDatabase 
		into @db

WHILE @@FETCH_STATUS = 0 Begin
	set @DatabaseNbr = @DatabaseNbr + 1
  	set @msg = str(@DatabaseNbr) + '. Database = ' + @db 	
  	if @Debug > 0 print @msg

	-- Process each table in  the database =====================================
 	truncate table #tmpDbTables	
--					+ 'WHERE lower(Table_Type) = ''base table'' AND Table_Name <> ''dtproperties'' '
-- 	set @TablesSql 	= 'Insert #tmpDbTables SELECT Table_Name FROM ' + @db + '.Information_Schema.Tables ' 
-- 					+ 'WHERE Table_Name <> ''dtproperties'' '
-- 					+ 'And (lower(Table_Type) Like ' + @entityFilter + ' or ' + @entityFilter + 'is null)'
	set @TablesSql 	= 'SELECT Table_Name FROM ' + @db + '.Information_Schema.Tables ' 
					+ 'WHERE Table_Name <> ''dtproperties'' '

	if (@EntityFilter is not null) Begin
		set @TablesSql = @TablesSql 
					+ 'And (lower(Table_Type) = ''' + @entityFilter + ''')'
	End

  	if @Debug > 10 Begin
		print @TablesSql
		exec(@TablesSql)			
	End

	-- Add the insert statement
	set @TablesSql = 'Insert #tmpDbTables ' + @TablesSql 

	exec(@TablesSql)	

	declare curLocal CURSOR FOR
		-- Get tables
		SELECT Table_Name 
		FROM 
			#tmpDbTables

	open  curLocal
	fetch next from curLocal 
			into @Table

	WHILE @@FETCH_STATUS = 0 Begin
		set @tableNbr = @tableNbr + 1
	  	set @msg = '    ' + str(@tableNbr) + '. Table = ' + @Table 	
	  	if @Debug > 0 print @msg	

		if 1 = 1 begin
			set @InsertSql = 'Insert #ServerDatabaseTables Select ''' + @ServerName + ''', ''' + @db + ''' As DatabaseName,  ''' + @Table + ''' As TableName, count(*) As [' + @Table + '_Count] from ' + @db + '.' + @AltOwner + '[' + @Table + ']'
			if (@Debug > 9) 
				print @InsertSql				
			exec(@InsertSql)
			end
		else begin
			set @CountSql = 'Select ''' + @db + ''' As DatabaseName,  ''' + @Table + ''' As TableName, count(*) As [' + @Table + '_Count] from ' + @AltOwner + @Table 
		--	set @CountSql = 'Select ' + @Table + ' As TableName, @tableRowCount = count(*)  from ' + @Table 
			
		-- 	select @tableRowCount = exec(@CountSql)
			exec(@CountSql)
		end
	
		/* Get next row                                    */
		fetch next from curLocal 
			into @Table
	
	   	set @fetch_cnt = @@rowcount
	
	end /* while */
	
	close curLocal
	deallocate curLocal

	-- Now display counts
--	select * from #ServerDatabaseTables order by tableName
	
	-- drop temp table
-- 	truncate table #ServerDatabaseTables


	-- =========================================================================
	/* Get next database                                    */
	fetch next from curDatabase 
		into @db

   	set @fetch_cnt = @@rowcount

end /* while */

close curDatabase
deallocate curDatabase

set nocount off
-- Now display counts
	if @DbName is null begin
		Delete ServerDatabaseTables Where ServerName = @ServerName
		Insert ServerDatabaseTables select * from #ServerDatabaseTables order by ServerName, DatabaseName, tableName
		End
	Else Begin
		Delete ServerDatabaseTables Where ServerName = @ServerName And  DatabaseName = @DbName
		Insert ServerDatabaseTables select * from #ServerDatabaseTables order by ServerName, DatabaseName, tableName
		End

	select * from #ServerDatabaseTables order by ServerName, DatabaseName, tableName

-- drop temp table
drop table #ServerDatabaseTables
drop table #tmpDbTables
-- drop temp table
-- drop table #tmpDbCnt
GO
/****** Object:  StoredProcedure [dbo].[aspGenerateColumnDef]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--*** need to update to handle varchar(max)!!!

-- =========================================================================
-- generate columns in a format for use by the dictionary program
-- Loops through all tables
--	- add a filter to retrieve a subset
-- raw select without any joins - for updates
-- Outputs to a local table called _Dictionary
-- 05/03/02 mparsons - added column desc
-- 06/10/27 mparsons - removed column description as the latter doesn't exist under ss2005
-- 08/05/21 mparsons - added code to handle varchar(MAX) - length is equal to -1 in syscolumns
-- 10/11/10 mparsons - added code to handle table names containing a period
-- =========================================================================
/*	
	drop table _Dictionary
 aspGenerateColumnDef @TableFilter = NULL, @TypeFilter='table', @Debug=8

 aspGenerateColumnDef @TableFilter = 'bus%', @TypeFilter='table'
*/
CREATE     PROCEDURE [dbo].[aspGenerateColumnDef]
	@TableFilter	varchar(50) = null,
	@TypeFilter		varchar(25) = null,
	@Debug 			int = 0
   	with recompile
As

Declare 
	@tablename 	nvarchar(128), 
	@entityType nvarchar(25), 
	@EntityFilter nvarchar(25), 
	@flags 		int , 
	@orderby 	nvarchar(10),
	@flags2 	int ,
	@AllColumns int,
    @msg        char(255),
	@fetch_cnt	int,
	@objid 		int

-- Set following defaults
set @flags 		= 0 
set @orderby 	= null
set @flags2 	= 0
set @AllColumns	= 1

IF EXISTS (SELECT name, type from sysobjects where type = 'U' and name = N'#genColDef') begin 
	drop table #genColDef
	end

-- Create work table
create table #genColDef
(
	tableName        	nvarchar(128)   COLLATE database_default NOT NULL,
	col_id           	int             NOT NULL,
	colName     		nvarchar(128)   COLLATE database_default NOT NULL,
	datatype     		nvarchar(30)   	COLLATE database_default NOT NULL,
	col_precScale		nvarchar(50)	NULL,
	col_null         	bit           	NOT NULL,  /* status & 8 */
	DefaultValue      	nvarchar(257)  	COLLATE database_default NULL
   ,col_identity    	bit               /* status & 128 */

   ,col_desc			nvarchar(250)	NULL
   ,entityType			nvarchar(25)    NULL	
   ,CreatedDate			datetime        NOT NULL CONSTRAINT DF_genColDef_CreatedDate DEFAULT (getdate())

)

if (@TypeFilter is null) 
	set @entityFilter = null
else begin
	set @entityFilter = '%' + @TypeFilter + '%' 
end

-- ********************************************************************
-- * - declare cursor for loop thru table
-- ********************************************************************
declare curLocal CURSOR FOR
	-- Get tables
	SELECT 
	--	*,
	-- 	Table_Schema, 
	 	Table_Name 
		,Case When Table_Type = 'BASE TABLE' Then 'table'
			  When Table_Type = 'VIEW' Then 'view'
		 else Table_Type
		 end As EntityType
	FROM 
		Information_Schema.Tables 
	WHERE 
-- 		lower(Table_Type) = 'base table' 
--  	AND 
		Table_Name <> 'dtproperties'
-- 	AND Table_Name Like 'HD07%'
	And (Table_Name Like @TableFilter or @TableFilter is null)
	And (Table_Type Like @entityFilter or @entityFilter is null)
	Order by Table_Name

open  curLocal
fetch next from curLocal into @tablename, @entityType
WHILE @@FETCH_STATUS = 0 Begin
	--set @tablename = '[' + @tablename + ']'
	select @objid = object_id('[' + @tablename + ']')
	--select object_id('[program.unit]')

	if @Debug > 5 begin
		print 'next: ' + @tablename
		print '@objid: ' + convert(varchar,@objid)
		end

	Insert #genColDef 
	select
		@tablename, 
		c.colid, 
		c.name, 
		st.name As DataType,
--          	case 
-- 				when bt.name in (N'nchar', N'nvarchar') 
-- 				then c.length/2 
-- 				else c.length end As Length,

		PrecScale = 
			case when (st.name in (N'decimal',N'numeric') )
				 	then cast(c.xprec as varchar(3)) + ', ' + cast(c.xscale  as varchar(3))
				 when c.length = -1
				 	then 'MAX'
				 when st.name in (N'nchar', N'nvarchar') 
				 	then cast(c.length/2  as varchar(4))
				 else cast(c.length  as varchar(4)) end,

		-- Nullable
		convert(bit, ColumnProperty(@objid, c.name, N'AllowsNull')) As AllowNulls
		,IsNull(cn.text,'') As DefaultValue
		-- Identity
			,case 
				when (@flags & 0x40000000 = 0) 
				then convert(bit, ColumnProperty(@objid, c.name, N'IsIdentity')) 
				else 0 
			end As IdentityType
-- 			,ColumnProperty(@objid, c.name, N'Precision') As TypePrecision
-- 			,ColumnProperty(@objid, c.name, N'Scale')	 As Scale

		--,convert(nvarchar(250),sp.value)
		,'TBD'
		,@entityType
		,getdate()
-- 
-- 	select * 
	from 
		dbo.syscolumns c
--where c.name = 'description'
		-- NonDRI Default and Rule filters
		left outer join dbo.sysobjects d on d.id = c.cdefault
		left outer join dbo.sysobjects r on r.id = c.domain
		-- Fully derived data type name
		join dbo.systypes st on st.xusertype = c.xusertype
		-- Physical base data type name
		join dbo.systypes bt on bt.xusertype = c.xtype
		-- DRIDefault text, if it's only one row.
		left outer join dbo.syscomments t on t.id = c.cdefault and t.colid = 1
				and not exists (select * from dbo.syscomments where id = c.cdefault and colid = 2)
		left outer join dbo.syscomments 	cn on t.id is not null and cn.id = t.id
		-- Any description for the column
		-- mp - sysproperties doesn't exist under ss2005
--		left outer join dbo.sysproperties 	sp 
--			on  c.id = sp.id and c.colid = sp.smallid and sp.name = 'MS_Description'
	where 
		c.id = @objid
	order by 
		c.colid

	/* Get next row                                    */
	fetch next from curLocal into @tablename, @entityType

   	set @fetch_cnt = @@rowcount

end /* while */

close curLocal
deallocate curLocal
-- Now display columns

IF EXISTS (SELECT name, type from sysobjects where type = 'U' and name = N'_Dictionary') begin 
--	select 'exists'
	delete from _Dictionary
	Insert _Dictionary select * from #genColDef 
	end
else begin
--	select 'not found'
	select * Into _Dictionary from #genColDef order by tableName, col_id

	end
IF EXISTS (SELECT name, type from sysobjects where type = 'U' and name = N'_DictTable') begin 
	-- only add new tables
	Insert _DictTable 
		select distinct tablename, tablename + '- TBD' As Description, 1 As IsActive, 1 As ReportGroup, 1 As ReportOrder, 1 As Synchronize, getdate() As Created
		from _Dictionary 
		Where (tablename not like '_d%') and tablename not in (select tablename from _DictTable)
	end
else begin
--	select 'not found'
	select distinct tablename, tablename + '- TBD' As Description, 1 As IsActive, 1 As ReportGroup, 1 As ReportOrder, 1 As Synchronize, getdate() As Created  into _DictTable from _Dictionary 

	end

select * From _Dictionary order by tableName, col_id
-- drop temp table
drop table #genColDef
GO
/****** Object:  StoredProcedure [dbo].[aspCreateProcedures]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

exec aspCreateProcedures 1,1,1,1,1,'|WorkNetGroupPrivilege|',1,'public'

exec aspCreateProcedures 1,1,1,1,1,'|GroupTeamMember|',1,'public'

exec aspCreateProcedures 1,1,1,1,1,'|Contact|',1,'public'
exec aspCreateProcedures 1,1,1,1,1,'|Organization|',1,'public'
exec aspCreateProcedures 1,1,1,1,1,'|Apartment|',0,'public'

exec aspCreateProcedures 1,1,1,1,1,'|SiteLandlord|',0,'public'

Exec aspCreateProcedure_Insert 'Building', 0
Exec aspCreateProcedure_Update 'Building', 0

Exec aspCreateProcedure_Get 'Contact', 1
Exec aspCreateProcedure_GetSingle 'Contact', 1

Exec aspCreateProcedure_Insert 'Contact', 0
Exec aspCreateProcedure_Update 'Contact', 0
Exec aspCreateProcedure_Delete 'Contact', 1
*/

Create   PROCEDURE [dbo].[aspCreateProcedures] 
	@insertProc 	bit,
	@updateProc 	bit,
	@selectProc 		bit,
	@getSingleProc 	bit,
	@deleteProc 	bit,
	@tables 		varchar(2000),
	@printtoFile 	bit
	,@DefaultRole varchar(50) = 'public'
AS
/* 
	Usage:
		aspCreateProcedures
				@insertProc 	  1 to create an insert proc, 0 to skip,
				@updateProc 	  1 to create an update proc, 0 to skip,
				@selectProc 		1 to create a select proc, 0 to skip,
				@getSingleProc 	1 to create a getSingle proc, 0 to skip,
				@deleteProc 	  1 to create a delete proc, 0 to skip,
				@tables 		    list of tables, blank for all
				@printtoFile 	  1 to preview the SQL, 0 to actually create
				@DefaultRole	  default role (grants execute to this role

	User Can pass in multiple table names separated by |. The following cursor will get 
	the right table names and then run procedures for each tables. 

	EX: 
		exec aspCreateProcedures 0,0,1,0,0,'|Contact|Account|', 0	
	Would create: get only for Account and Contact

	If creating for full database just pass in '' for @tables.

	TODO:
	- consider supplying parms to dictate naming format (ex for usp prefix, suffix, etc.)
*/
Declare
	@Prefix				varchar(10)
	,@Suffix			varchar(10)
	,@SelectProcName		varchar(50) 
	,@GetSingleProcName	varchar(50) 
	,@CreateProcName	varchar(50) 
	,@UpdateProcName	varchar(50) 
	,@DeleteProcName	varchar(50) 
	,@GetSingleGrantRole	varchar(50) 
	,@CreateGrantRole	varchar(50) 
	,@UpdateGrantRole	varchar(50) 
	,@DeleteGrantRole	varchar(50) 
	,@tableFirst		bit

-- Set defaults for the current database /application 
set @tableFirst 	= 1		-- 1 to place table name before the procedure type (ContactInsert), 0 for after (InsertContact)
set @Prefix 		= ''	-- use to add a prefix to the procedure name )
set @Suffix 		= ''	-- use to add a suffix to the procedure name
-- Default procedure names
set @SelectProcName 	= 'Select' 
set @CreateProcName = 'Insert'
set @UpdateProcName = 'Update'
set @DeleteProcName = 'Delete'
set @GetSingleProcName 	= 'Get' 

-- Default grant role (can have multiplies, comma separated) 
set @CreateGrantRole = @DefaultRole	--'Maintenance'
set @UpdateGrantRole = @DefaultRole	--'Maintenance'
set @DeleteGrantRole = @DefaultRole	--'Maintenance'
set @GetSingleGrantRole = 'Public' 

Declare curTables CURSOR
FOR
	SELECT TABLE_NAME
	FROM INFORMATION_SCHEMA.TABLES 
	WHERE 
		TABLE_TYPE = 'BASE TABLE' 
	AND
		(CharIndex('|' + TABLE_NAME + '|', @tables) > 0 OR
		LTrim(RTrim(@tables)) = '')

Open curTables
Declare @Table_name varchar(128)
FETCH NEXT FROM curTables INTO @table_name

WHILE @@FETCH_STATUS = 0
Begin
	-- Check if insert procedure needs to be created. 
	If @insertProc = 1
		Exec aspCreateProcedure_Insert @table_name, @printtoFile, @tableFirst, @Prefix, @Suffix, @CreateProcName, @CreateGrantRole

	-- Check if update procedure needs to be created. 
	If @updateProc = 1
		Exec aspCreateProcedure_Update @table_name, @printtoFile, @tableFirst, @Prefix, @Suffix, @UpdateProcName, @UpdateGrantRole

	-- Check if get procedure needs to be created. 
	If @SelectProc = 1
		Exec aspCreateProcedure_Get @table_name, @printtoFile, @tableFirst, @Prefix, @Suffix, @SelectProcName
			 
	-- Check if get single procedure needs to be created. 
	If @getSingleProc = 1
		Exec aspCreateProcedure_GetSingle @table_name, @printtoFile, @tableFirst, @Prefix, @Suffix, @GetSingleProcName, @GetSingleGrantRole

	-- Check if delete procedure needs to be created. 
	If @deleteProc = 1
		Exec aspCreateProcedure_Delete @table_name, @printtoFile, @tableFirst, @Prefix, @Suffix, @DeleteProcName, @DeleteGrantRole

	FETCH NEXT FROM curTables INTO @table_name
End
Close curTables
Deallocate curTables
GO
/****** Object:  StoredProcedure [dbo].[Codes.RatingTypeInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Create RatingType record
-- =============================================
CREATE PROCEDURE [dbo].[Codes.RatingTypeInsert]
	@Type varchar(50),
	@Identifier varchar(500),
	@Description varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [Codes.RatingType] ([Type], Identifier, [Description], Created)
	VALUES (@Type, @Identifier, @Description, GETDATE())
	
	SELECT @@IDENTITY AS Id
END
GO
/****** Object:  StoredProcedure [dbo].[Codes.RatingTypeGet]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Get RatingType
-- =============================================
CREATE PROCEDURE [dbo].[Codes.RatingTypeGet]
	@Id int,
	@Type varchar(50),
	@Identifier varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @Id = 0 SET @Id = NULL
	
	SELECT Id, [Type], Identifier, [Description], Created
	FROM [Codes.RatingType]
	WHERE (Id = @Id OR @Id IS NULL) AND
		([Type] = @Type OR @Type IS NULL) AND
		(Identifier = @Identifier OR @Identifier IS NULL)
END
GO
/****** Object:  StoredProcedure [dbo].[Map.PathwayRules_Load]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 09/09/2012
-- Description:	Load Pathway map rules
-- =============================================
CREATE PROCEDURE [dbo].[Map.PathwayRules_Load]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT rules.Id, 'Cluster' AS PropertyType, 0 AS PropertyTypeId, OriginalValue, IsRegex, IsCaseSensitive,
		'False' AS ImportWithoutTranslation, 'False' AS DoNotImport, MappedValue, Sequence, IsActive, 
		rules.Created, rules.CreatedBy, rules.LastUpdated, LastUpdatedBy, Pathway.Id AS MappedId
	FROM [dbo].[Map.PathwayRules] rules
	LEFT JOIN Pathway ON rules.MappedValue = Pathway.Pathway
END
GO
/****** Object:  StoredProcedure [dbo].[Codes_ResourceType_Select]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Create date: 6/16/2012
-- Description:	Select one or more name/value pairs for a resource
-- =============================================
Create PROCEDURE [dbo].[Codes_ResourceType_Select]

AS
BEGIN
SELECT [Id]
      ,[Title]

  FROM [dbo].[Codes.ResourceType]
  order by       
  [SortOrder], [Title]


END
GO
/****** Object:  StoredProcedure [dbo].[Codes_EducationLevel_Select]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Create date: 7/02/2012
-- Description:	Select [Codes.EducationLevel]
-- =============================================
CREATE PROCEDURE [dbo].[Codes_EducationLevel_Select]

AS
BEGIN
SELECT [Id]
      ,[Title]
      ,[Title] + ' (' + isnull(convert(varchar,WareHouseTotal),0) + ')' As FormattedTitle
      ,isnull(WareHouseTotal,0) As WareHouseTotal
      ,[Description]
      ,[IsPathwaysLevel]
  FROM [dbo].[Codes.PathwaysEducationLevel]
  where [IsPathwaysLevel]= 1
  order by SortOrder
END
GO
/****** Object:  View [dbo].[IntendedAudienceCounts]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT [IntendedAudience]
      ,[RecordCount]
  FROM [LRCache_120621a].[dbo].[IntendedAudienceCounts]
  order by IntendedAudience
GO



*/
CREATE VIEW [dbo].[IntendedAudienceCounts]
AS
SELECT Top 100 Percent
	case 
		when code.Title = 'educator' then 'Educator'
		when code.Title = 'student' then 'Student'
		else 'Other' end As IntendedAudience

, COUNT(*) As RecordCount
  FROM [dbo].[Resource.IntendedAudience] base
  inner join dbo.[Codes.AudienceType] code on base.AudienceId = code.Id
group by code.Title
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "IntendedAudience"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 114
               Right = 214
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Codes.AudienceType"
            Begin Extent = 
               Top = 6
               Left = 252
               Bottom = 84
               Right = 419
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 12
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'IntendedAudienceCounts'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'IntendedAudienceCounts'
GO
/****** Object:  Table [dbo].[Patron.LibraryResource]    Script Date: 12/14/2012 10:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Patron.LibraryResource](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PatronLibraryId] [int] NULL,
	[ResourceId] [uniqueidentifier] NOT NULL,
	[Comment] [varchar](500) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedId] [int] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Patron.LibraryResource] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_Patron.LibraryResource_PatronLibraryId] ON [dbo].[Patron.LibraryResource] 
(
	[PatronLibraryId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[Resource.ClusterSelect_SelectedCodes]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.ClusterSelect_SelectedCodes] ''
*/
CREATE PROCEDURE [dbo].[Resource.ClusterSelect_SelectedCodes]
    @ResourceId uniqueidentifier
As
SELECT 
	base.Id, base.IlPathwayName As Title
--    ,ResourceId
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as HasCluster	
FROM [dbo].CareerCluster base
Left Join [Resource.Cluster] rpw on base.Id = rpw.ClusterId
		and rpw.ResourceId = @ResourceId
where IsIlPathway = 1

Order by base.IlPathwayName
GO
/****** Object:  StoredProcedure [dbo].[Resource.ClusterSelect]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.ClusterSelect] ''
*/
CREATE PROCEDURE [dbo].[Resource.ClusterSelect]
    @ResourceId uniqueidentifier
As
SELECT base.[ResourceId]
      ,base.[ClusterId], cc.IlPathwayName As Cluster
  FROM [dbo].[Resource.Cluster] base
  inner join CareerCluster cc on base.ClusterId = cc.Id
where base.ResourceId = @ResourceId  
Order by cc.IlPathwayName
GO
/****** Object:  StoredProcedure [dbo].[Resource.ClusterInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@ClusterId int
DECLARE @PropertyName varchar(100), @Value varchar(500)

set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @ClusterId = 1


EXECUTE @RC = [.[dbo].[Resource.ClusterInsert] 
   @ResourceId
  ,@ClusterId
GO


*/
Create PROCEDURE [dbo].[Resource.ClusterInsert]
            @ResourceId varchar(36), 
            @ClusterId int

As
if len(rtrim(@ResourceId)) = 0	Set @ResourceId = NULL
If @ClusterId = 0				SET @ClusterId = NULL 

if @ClusterId is null OR @ResourceId is null begin
	print 'Resource.ClusterInsert Error: Incomplete parameters were provided'
	RAISERROR('Resource.ClusterInsert Error: incomplete parameters were provided. Require Source @ResourceId, and @ClusterId', 18, 1)    
	RETURN -1 
	end
	
	
INSERT INTO [dbo].[Resource.Cluster]
           ([ResourceId]
           ,[ClusterId])
Values (
	@ResourceId, 
	@ClusterId
)
GO
/****** Object:  StoredProcedure [dbo].[Resource.ClusterGet]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 09/13/2012
-- Description:	Get a Resource.Cluster row
-- =============================================
CREATE PROCEDURE [dbo].[Resource.ClusterGet]
	@ResourceId uniqueidentifier,
	@ClusterId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT ResourceId, ClusterId
	FROM [Resource.Cluster]
	WHERE ResourceId = @ResourceId AND ClusterId = @ClusterId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.ClusterDelete]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.ClusterDelete]
        @ResourceId uniqueidentifier,
        @ClusterId int
        
As
DELETE FROM [Resource.Cluster] 
WHERE ClusterId = @ClusterId AND 
ResourceId = @ResourceId
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_Import]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Exec CodeTables_UpdateWarehouseTotals 10

DECLARE @OriginalValue varchar(500)

set @OriginalValue = '15  - 17'
--set @OriginalValue = Replace(@OriginalValue, ' - ', '-')
set @OriginalValue = Replace(@OriginalValue, ' ', '')
select @OriginalValue

SELECT [Id]
      ,[Title]

  FROM [dbo].[Codes.PathwaysEducationLevel]
GO

select * from [dbo].[Audit.EducationLevel_Orphan]


SELECT    Id, PropertyTypeId, OriginalValue,  MappedValue
FROM         [Map.Rules]
WHERE     (PropertyTypeId = 2)
ORDER BY OriginalValue

SELECT    map.Id, map.PropertyTypeId, map.OriginalValue,  map.MappedValue
FROM         [Map.Rules] map
inner join [Codes.PathwaysEducationLevel] codes on map.MappedValue = codes.Title
WHERE     (map.PropertyTypeId = 2)
ORDER BY map.OriginalValue


--===============
SELECT [ResourceId] ,[OriginalValue]

  FROM [dbo].[Audit.EducationLevel_Orphan]
  where MappingType = 'Map.EducationLevel'

--======================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@OriginalValue varchar(500)
EXECUTE [dbo].[Resource.EducationLevel_ImportResProperty] 
SELECT 
@ResourceId=[ResourceId] ,@OriginalValue=[OriginalValue]

  FROM [dbo].[Audit.EducationLevel_Orphan]
  where MappingType = 'Map.EducationLevel'
  
--======================================================

SELECT top 1000
[ResourceId]
      ,[Name]
      ,[Value]
      ,[PropertyTypeId]
      ,[Imported]
  FROM [dbo].[Resource.Property]
  where PropertyTypeId = 2 AND Value = 'High School'
  order by 1

B773208E-FF0B-49CA-A416-000030A2138D
5360B642-B3B7-4CD7-B6E1-0000C3F499B8
33E8A821-C0F2-42CE-B7E6-0002D78CA861
0A62FF63-FC37-4DDD-8688-0007A01A6C04

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@OriginalValue varchar(500)
, @totalRows  int

set @ResourceId = '5360B642-B3B7-4CD7-B6E1-0000C3F499B8'
set @OriginalValue = 'Summer School'
set @OriginalValue = '&gt;1'

EXECUTE @RC = [dbo].[Resource.EducationLevel_Import]
   @ResourceId
  ,@OriginalValue, '', @totalRows OUTPUT
  
  select  @totalRows
  


*/
/*
Notes:
- may need to use a passed schema to help with mapping

*/
CREATE PROCEDURE [dbo].[Resource.EducationLevel_Import]
            @ResourceId     varchar(40), 
            @OriginalValue  varchar(500),
            @Schema         varchar(50)
            ,@TotalRows     int OUTPUT

As
begin 
declare 
  @PathwaysEducationLevelId int,
  @RecordCount int
  
  set @TotalRows = 0
  set @PathwaysEducationLevelId = 0
  
If @OriginalValue = '' begin
  print 'no value provided'
  return -1
  end              
set @OriginalValue = Replace(@OriginalValue, '- ', '-')  
set @OriginalValue = Replace(@OriginalValue, ' -', '-')  
set @OriginalValue = Replace(@OriginalValue, '1-U', '1+') 
set @OriginalValue = Replace(@OriginalValue, 'U-U', '0-18') 
set @OriginalValue = Replace(@OriginalValue, '&gt;', '>')  
set @OriginalValue = Replace(@OriginalValue, '&lt;', '1-')  
set @OriginalValue = Replace(@OriginalValue, '> ', '>') 
set @OriginalValue = Replace(@OriginalValue, '>1', '1+') 
set @OriginalValue = Replace(@OriginalValue, '>2', '2+') 
set @OriginalValue = Replace(@OriginalValue, '>3', '3+') 
set @OriginalValue = Replace(@OriginalValue, '>4', '4+') 
set @OriginalValue = Replace(@OriginalValue, '>5', '5+') 
set @OriginalValue = Replace(@OriginalValue, '>6', '6+') 
set @OriginalValue = Replace(@OriginalValue, '>7', '7+')
set @OriginalValue = Replace(@OriginalValue, '>8', '8+')
set @OriginalValue = Replace(@OriginalValue, '>9', '9+')
set @OriginalValue = Replace(@OriginalValue, '>10', '10+') 
set @OriginalValue = Replace(@OriginalValue, '>11', '11+') 
set @OriginalValue = Replace(@OriginalValue, '>12', '12+') 
set @OriginalValue = Replace(@OriginalValue, '>13', '13+') 
set @OriginalValue = Replace(@OriginalValue, '>14', '14+') 
set @OriginalValue = Replace(@OriginalValue, '>15', '15+') 
set @OriginalValue = Replace(@OriginalValue, '>16', '16+') 
set @OriginalValue = Replace(@OriginalValue, '>17', '17+') 
set @OriginalValue = Replace(@OriginalValue, '>18', '18+') 
set @OriginalValue = Replace(@OriginalValue, '>19', '19+') 
set @OriginalValue = Replace(@OriginalValue, '>20', '20+') 

set @OriginalValue = Replace(@OriginalValue, '03-', '3-') 
set @OriginalValue = Replace(@OriginalValue, '04-', '4-') 
set @OriginalValue = Replace(@OriginalValue, '05-', '5-') 
set @OriginalValue = Replace(@OriginalValue, '06-', '6-') 
set @OriginalValue = Replace(@OriginalValue, '07-', '7-') 
set @OriginalValue = Replace(@OriginalValue, '08-', '8-') 
set @OriginalValue = Replace(@OriginalValue, '09-', '9-') 

set @OriginalValue = Replace(@OriginalValue, '-U', '+') 
set @OriginalValue = Replace(@OriginalValue, '-+', '+') 

set @OriginalValue = Replace(@OriginalValue, '13-19', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-20', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-90', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-99', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-9999', '13+') 
set @OriginalValue = Replace(@OriginalValue, '13-U', '13+') 

set @OriginalValue = Replace(@OriginalValue, '14-19', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-20', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-90', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-99', '14+') 
set @OriginalValue = Replace(@OriginalValue, '14-9999', '14+') 

set @OriginalValue = Replace(@OriginalValue, '15-19', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-20', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-90', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-99', '15+') 
set @OriginalValue = Replace(@OriginalValue, '15-9999', '15+') 

set @OriginalValue = Replace(@OriginalValue, '16-19', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-20', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-90', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-99', '16+') 
set @OriginalValue = Replace(@OriginalValue, '16-9999', '16+') 

set @OriginalValue = Replace(@OriginalValue, '17-19', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-20', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-90', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-99', '17+') 
set @OriginalValue = Replace(@OriginalValue, '17-9999', '17+') 

set @OriginalValue = Replace(@OriginalValue, '18-18', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-20', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-90', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-99', '18+') 
set @OriginalValue = Replace(@OriginalValue, '18-9999', '18+') 

set @OriginalValue = Replace(@OriginalValue, '19-19', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-20', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-90', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-99', '19+') 
set @OriginalValue = Replace(@OriginalValue, '19-9999', '19+') 

set @OriginalValue = Replace(@OriginalValue, '20-20', '20+') 
set @OriginalValue = Replace(@OriginalValue, '20-90', '20+') 
set @OriginalValue = Replace(@OriginalValue, '20-99', '20+') 
set @OriginalValue = Replace(@OriginalValue, '20-9999', '20+') 


set @OriginalValue = Replace(@OriginalValue, '21-90', '21+') 
set @OriginalValue = Replace(@OriginalValue, '21-99', '21+') 
set @OriginalValue = Replace(@OriginalValue, '21-9999', '21+') 

set @OriginalValue = Replace(@OriginalValue, '0-3', '1+') 
set @OriginalValue = Replace(@OriginalValue, '0-16', '1+') 

set @OriginalValue = Replace(@OriginalValue, 'Nov-', '11-') 
set @OriginalValue = Replace(@OriginalValue, 'Dec-', '12-') 
set @OriginalValue = Replace(@OriginalValue, 'Oct-', '10-') 
set @OriginalValue = Replace(@OriginalValue, 'Sep-', '9-') 

set @OriginalValue = Replace(@OriginalValue, 'U-', '1-') 
-- ======================================================
 -- so first check if mapping exists
select @RecordCount = isnull(Count(*),0)
  FROM [Map.EducationLevel] map 
  inner join [dbo].[Codes.PathwaysEducationLevel] codes on map.MappedValue = codes.[Title]
 where map.OriginalValue  = @OriginalValue
 
If @RecordCount is null OR @RecordCount = 0	begin 
  --no mapping, write to exceptions table and return
  print 'no mapping, writing to exceptions table: ' + @OriginalValue
  INSERT INTO [dbo].[Audit.EducationLevel_Orphan]
           ([RowId]
           ,[ResourceId]
  --         ,[MappingType]
           ,[OriginalValue])
     VALUES
           (newId()
           ,@ResourceId
   --        ,'Map.EducationLevel'
           ,@OriginalValue)

  return -1
  end
-- ======================================================
--mapping exists, need to handle already in target table 
--print 'doing insert'
  INSERT INTO [Resource.EducationLevel]
  (
	  RowId,
	  ResourceId, 
	  PathwaysEducationLevelId,
	  OriginalLevel
  )
  
select newId(), @ResourceId, isnull(codes.id,0), @OriginalValue
  FROM [Map.EducationLevel] map 
  inner join [dbo].[Codes.PathwaysEducationLevel] codes on map.MappedValue = codes.[Title]
  left join [dbo].[Resource.EducationLevel] red on @ResourceId = red.ResourceId and red.[PathwaysEducationLevelId] = codes.id
    
 where map.OriginalValue  = @OriginalValue
 and red.RowId is null

set @TotalRows = @@rowcount

end
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_Get]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Get a record from [Resource.EducationLevel]
-- =============================================
CREATE PROCEDURE [dbo].[Resource.EducationLevel_Get]
	@RowId uniqueidentifier,
	@ResourceId uniqueidentifier,
	@OriginalValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @RowId = '00000000-0000-0000-0000-000000000000' SET @RowId = NULL
	IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
	IF @OriginalValue = '' SET @OriginalValue = NULL

	SELECT RowId, ResourceId, OriginalLevel AS OriginalValue, PathwaysEducationLevelId AS CodeId,
		cpel.Title AS MappedValue
	FROM [Resource.EducationLevel] rel
	INNER JOIN [Codes.PathwaysEducationLevel] cpel ON rel.PathwaysEducationLevelId = cpel.Id
	WHERE   (RowId = @RowId OR @RowId IS NULL)
		AND (ResourceId = @ResourceId OR @ResourceId IS NULL)
		AND (OriginalLevel = @OriginalValue OR @OriginalValue IS NULL)
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevelDelete]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.EducationLevelDelete]
        @ResourceId uniqueidentifier,
        @PathwaysEducationLevelId int
As
DELETE FROM [Resource.EducationLevel]
WHERE ResourceId = @ResourceId AND 
PathwaysEducationLevelId = @PathwaysEducationLevelId
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_Update]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Update a [Resource.EducationLevel] Row
-- =============================================
CREATE PROCEDURE [dbo].[Resource.EducationLevel_Update] 
	@RowId uniqueidentifier,
	@CodeId int,
	@MappedValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CodeId = 0 BEGIN
		SELECT @CodeId = id
		FROM [Codes.AudienceType]
		WHERE Title = @MappedValue
	END

	UPDATE [Resource.EducationLevel]
	SET PathwaysEducationLevelId = @CodeId
	WHERE RowId = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_RemoveDuplicates]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select count(*) from [Resource]
go
select count(*) from [Resource.EducationLevel]
go
select * from [Resource.EducationLevel]
where convert(varchar(36),resourceId) = '815B5114-90D4-4FFF-A9FC-1F2B7C7299E0'
or  convert(varchar(36),resourceId) = '9BA129DD-3C6B-4D2F-84E1-2FBF008B9C22'
ORDER BY ResourceId, PathwaysEducationLevelId


UPDATE [dbo].[Resource.EducationLevel]
   SET [PathwaysEducationLevelId] = 6
   
--  select count(*) from [dbo].[Resource.EducationLevel]
 WHERE PathwaysEducationLevelId= 7 AND [OriginalLevel] = 'Informal Education'
GO


EXECUTE [dbo].[Resource.EducationLevel_RemoveDuplicates] 0, 200


*/

CREATE PROCEDURE [dbo].[Resource.EducationLevel_RemoveDuplicates]
            @MaxRecords int
            ,@interval int

As
begin 
          
Declare 
@ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@PathwaysEducationLevelId int
,@PrevResourceId uniqueidentifier
,@PrevEducationLevelId int
,@cntr int
,@dupsCntr int
--,@interval int
,@totalRows int
,@debugLevel int

--set @interval= 25
set @cntr= 0
set @dupsCntr = 0
set @PrevEducationLevelId = 0
set @PrevResourceId= NULL
set @debugLevel= 10

select 'started',  getdate(), 'remember hard coding top 25000!!!'
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT distinct    TOP 25000 base.RowId, base.ResourceId, base.PathwaysEducationLevelId
        FROM          [Resource.EducationLevel] AS base 
        INNER JOIN
          (SELECT     ResourceId, PathwaysEducationLevelId, COUNT(*) AS DupCount
          FROM          [Resource.EducationLevel]
          GROUP BY ResourceId, PathwaysEducationLevelId
          HAVING      (COUNT(*) > 1)) AS dupEds ON base.ResourceId = dupEds.ResourceId
      ORDER BY base.ResourceId, base.PathwaysEducationLevelId
 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @PathwaysEducationLevelId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
		  
 --   if @cntr < 50 print '-- ' + convert(varchar(50),@ResourceId) + ' / ' + @OriginalValue 
    if @ResourceId = @PrevResourceId AND @PathwaysEducationLevelId = @PrevEducationLevelId begin
      --delete dup
      set @dupsCntr = @dupsCntr + 1
      if ((@dupsCntr / @interval) * @interval) = @dupsCntr 
        print '@@ deleting dup @ResourceId/@PathwaysEducationLevelId ' + convert(varchar(50), @ResourceId )+ ' - ' + convert(varchar, @PathwaysEducationLevelId) + '  #' + convert(varchar, @dupsCntr)
        
      DELETE FROM [dbo].[Resource.EducationLevel]
      WHERE RowId= @RowId
      end
      
    set @PrevResourceId=@ResourceId
    Set @PrevEducationLevelId = @PathwaysEducationLevelId 
	 
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @PathwaysEducationLevelId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  select 'Duplicated deleted count: ' + convert(varchar, @dupsCntr)
  
  
end
GO
/****** Object:  View [dbo].[Resource.EducationLevelsSummary]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT top 1000
 [ResourceId]
      ,[EducationLevel]
  FROM [dbo].[Resource.EducationLevelsSummary]
where len([EducationLevels] ) > 0

*/
CREATE VIEW [dbo].[Resource.EducationLevelsSummary]
AS

SELECT [RowId]
      ,[ResourceId]
      ,[PathwaysEducationLevelId]
      ,pel.Title  As [EducationLevel]
      ,[OriginalLevel]
  FROM [dbo].[Resource.EducationLevel] base
  inner join [Codes.PathwaysEducationLevel] pel on base.PathwaysEducationLevelId = pel.Id
GO
/****** Object:  View [dbo].[Resource.EducationLevelsList]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT top 1000
 [ResourceId]
      ,[EducationLevels]
  FROM [dbo].[Resource.EducationLevelsList]
where len([EducationLevels] ) > 0

*/
CREATE VIEW [dbo].[Resource.EducationLevelsList]
AS
SELECT     TOP (100) PERCENT 
base.[RowId] As ResourceId,
    CASE
          WHEN EducationLevels IS NULL THEN NULL
          WHEN len(EducationLevels) = 0 THEN NULL
          ELSE left(EducationLevels,len(EducationLevels)-1)
    END AS EducationLevels

FROM [dbo].[Resource] base
CROSS APPLY (
    --SELECT distinct EducationLevel  + ', '
    --FROM [Resource.EducationLevel] list
    --WHERE base.RowId = list.ResourceId 
    --and (EducationLevel is not null AND len(EducationLevel) > 0)
    -- soon
    SELECT distinct pel.Title  + ', '
    FROM [Resource.EducationLevel] list
    inner join [Codes.PathwaysEducationLevel] pel on list.PathwaysEducationLevelId = pel.Id
    WHERE base.RowId = list.ResourceId 
    and (list.PathwaysEducationLevelId is not null AND list.PathwaysEducationLevelId > 0)
	and pel.IsPathwaysLevel = 1
   -- Order by 1
    FOR XML Path('') 
    ) D (EducationLevels)
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevelSelect]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.EducationLevelSelect] '9B184F11-B032-4CDB-993D-00109FDCDF68'
*/
Create PROCEDURE [dbo].[Resource.EducationLevelSelect]
    @ResourceId uniqueidentifier
As
SELECT distinct
	code.Id, code.Title, code.SortOrder
   -- ,ResourceId
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.PathwaysEducationLevel] code
Left Join [Resource.EducationLevel] rpw on code.Id = rpw.PathwaysEducationLevelId
		and rpw.ResourceId = @ResourceId
where IsPathwaysLevel = 1

Order by code.SortOrder
GO
/****** Object:  StoredProcedure [dbo].[Resource.FormatUpdate]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.FormatUpdate]
	@RowId uniqueidentifier,
	@CodeId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [Resource.Format]
    SET CodeId = @CodeId
    WHERE RowId = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.FormatSelect]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.FormatSelect]
	@ResourceId uniqueidentifier, @CodeId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @CodeId = 0 SET @CodeId = NULL
    IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
    
    SELECT RowId, ResourceId, OriginalValue, CodeId
    FROM [Resource.Format]
    WHERE (ResourceId = @ResourceId OR @ResourceId IS NULL) AND
		(CodeId = @CodeId OR @CodeId IS NULL)
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.FormatInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.FormatInsert]
	@ResourceId uniqueidentifier,
	@ResourceFormatId int,
	@OriginalValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    
declare @NewId uniqueidentifier
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit   --????
, @ErrorMsg varchar(100)

	if @OriginalValue = '' set @OriginalValue = NULL
	If @ResourceFormatId = -1		SET @SuppressOutput = 1
  else set @SuppressOutput  = 0
	If @ResourceFormatId < 1		SET @ResourceFormatId = NULL 
	
	If @OriginalValue is NULL and @ResourceFormatId is null begin
    print 'no values were provided'
    return -1
    end  

  set @IsDuplicate= 0
	SET @NewId = NEWID()
	PRINT '@NewId: ' + convert(varchar(50),@NewId)
	set @ErrorMsg = ''
	
-- ==================================================================
if @ResourceFormatId is null begin
	print 'insert via Format'
	 -- so first check if mapping exists
	SELECT @ResourceFormatId = isnull(base.id,0)
  FROM [dbo].[Codes.ResourceFormat] base
  inner join [dbo].[Map.ResourceFormat] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @ResourceFormatId is null OR @ResourceFormatId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceId] FROM [dbo].[Audit.ResourceFormat_Orphan] 
    where [ResourceId]= @ResourceId and [OriginalValue] = @OriginalValue) begin
      set @ErrorMsg = 'No mapping was found for parameter, writing to audit table'
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.ResourceFormat_Orphan]
           ([RowId]
           ,[ResourceId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      set @ErrorMsg = 'No mapping was found for parameter, the value already exists in audit table'
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate, @ErrorMsg
    end
  end
	
if @ResourceFormatId > 0 begin
  print '[ResourceFormatId] = ' + convert(varchar, @ResourceFormatId)

  -- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.Format] base
	where base.[ResourceId] = @ResourceId
	And base.[CodeId] = @ResourceFormatId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  print 'found duplicate'
	  set @ErrorMsg = 'The resource format already exists for this resource'
	  end
	else begin
    INSERT INTO [dbo].[Resource.Format]
	    ([RowId]
	    ,[ResourceId]
	    ,[CodeId]
	    ,OriginalValue)

    select
	    @NewId,
	    @ResourceId, 
	    @ResourceFormatId, 
	    @OriginalValue
    end

  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As sDuplicate, @ErrorMsg As [Message]    
  end
  
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.FormatGet]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.FormatGet]
	@RowId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT RowId, ResourceId, OriginalValue, CodeId
	FROM [Resource.Format]
	WHERE RowId = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.FormatDelete]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.FormatDelete]
        @ResourceId uniqueidentifier,
        @CodeId int
As
DELETE FROM [Resource.Format]
WHERE ResourceId = @ResourceId  
AND CodeId = @CodeId
GO
/****** Object:  StoredProcedure [dbo].[Resource.Format_SelectedCodes]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.ResourceFormat_SelectedCodes] ''9B184F11-B032-4CDB-993D-00109FDCDF68''
*/
Create PROCEDURE [dbo].[Resource.Format_SelectedCodes]
    @ResourceId uniqueidentifier
As
SELECT distinct
	code.Id, code.Title
   -- ,ResourceId
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.ResourceFormat] code
Left Join [Resource.Format] rpw on code.Id = rpw.CodeId
		and rpw.ResourceId = @ResourceId
Order by 2
GO
/****** Object:  StoredProcedure [dbo].[zzDatabaseReset]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 9/21/2012
-- Description:	Clear Resource and Report database - start over
-- =============================================
CREATE PROCEDURE [dbo].[zzDatabaseReset]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    TRUNCATE TABLE [AuditReport.Detail]
    TRUNCATE TABLE [AuditReport]
    TRUNCATE TABLE [Resource.Cluster]
    TRUNCATE TABLE [Resource.EducationLevel]
    TRUNCATE TABLE [Resource.Format]
    TRUNCATE TABLE [Resource.IntendedAudience]
    TRUNCATE TABLE [Resource.Keyword]
    TRUNCATE TABLE [Resource.Language]
    TRUNCATE TABLE [Resource.Property]
    TRUNCATE TABLE [Resource.Rating]
    TRUNCATE TABLE [Resource.RatingSummary]
    TRUNCATE TABLE [Resource.ResourceType]
    TRUNCATE TABLE [Resource.Version]
    TRUNCATE TABLE [Resource.Subject]
    DELETE FROM Resource
END
GO
/****** Object:  View [dbo].[Resource_PropertiesSummary]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Resource_PropertiesSummary]
AS
SELECT     TOP (100) PERCENT 
dbo.Resource.RowId, 
dbo.Resource.ResourceUrl, 
rpt.Title AS PropertyType, 
dbo.[Resource.Property].PropertyTypeId, 
dbo.[Resource.Property].Value
FROM         
	dbo.[Resource.Property] 
	INNER JOIN dbo.[Codes.ResPropertyType] rpt ON dbo.[Resource.Property].PropertyTypeId = rpt.Id 
	INNER JOIN dbo.Resource ON dbo.[Resource.Property].ResourceId = dbo.Resource.RowId
ORDER BY 
	dbo.Resource.ResourceUrl, 
	PropertyType, 
	dbo.[Resource.Property].Value
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[41] 4[22] 2[19] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "Resource.Property"
            Begin Extent = 
               Top = 20
               Left = 281
               Bottom = 190
               Right = 482
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Codes.ResPropertyType"
            Begin Extent = 
               Top = 81
               Left = 580
               Bottom = 204
               Right = 740
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Resource"
            Begin Extent = 
               Top = 11
               Left = 7
               Bottom = 194
               Right = 247
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 2355
         Width = 1500
         Width = 1500
         Width = 2730
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 3735
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Resource_PropertiesSummary'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Resource_PropertiesSummary'
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionUpdate]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/30/2012
-- Description:	Update a Resource Version
-- =============================================
CREATE PROCEDURE [dbo].[Resource.VersionUpdate]
	@RowId uniqueidentifier,
	@ResourceId uniqueidentifier,
	@DocId varchar(500),
	@Title varchar(200),
	@Description varchar(max),
	@Publisher varchar(100),
	@Creator varchar(100),
	@Rights varchar(500),
	@AccessRights varchar(100),
	@Modified datetime,
	@Submitter varchar(100),
	@Imported datetime,
	@Created datetime,
	@TypicalLearningTime varchar(50),
	@IsSkeletonFromParadata bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @Description = '' SET @Description = NULL
	IF @Publisher = '' SET @Publisher = NULL
	IF @Creator = '' SET @Creator = NULL
	IF @Rights = '' SET @Rights = NULL
	IF @AccessRights = '' SET @AccessRights = NULL
	IF @Submitter = '' SET @Submitter = NULL
	IF @TypicalLearningTime = '' SET @TypicalLearningTime = NULL

	UPDATE [Resource.Version]
	SET ResourceId = @ResourceId,
		DocId = @DocId,
		Title = @Title,
		[Description] = @Description,
		Publisher = @Publisher,
		Creator = @Creator,
		Rights = @Rights,
		AccessRights = @AccessRights,
		Modified = @Modified,
		Submitter = @Submitter,
		Imported = @Imported,
		Created = @Created,
		TypicalLearningTime = @TypicalLearningTime,
		IsSkeletonFromParadata = @IsSkeletonFromParadata
	WHERE RowId = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.RatingSummaryUpdate]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Update Paradata Rating Summary Record
-- =============================================
CREATE PROCEDURE [dbo].[Resource.RatingSummaryUpdate]
	@ResourceId uniqueidentifier,
	@RatingTypeId int,
	@RatingCount int,
	@RatingTotal int,
	@RatingAverage decimal(5,2)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [Resource.RatingSummary]
    SET RatingCount = @RatingCount,
		RatingTotal = @RatingTotal,
		RatingAverage = @RatingAverage,
		LastUpdated = GETDATE()
	WHERE ResourceId = @ResourceId AND RatingTypeId = @RatingTypeId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.RatingSummaryInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 8/22/2012
-- Description:	Create Paradata Rating Summary row
-- =============================================
CREATE PROCEDURE [dbo].[Resource.RatingSummaryInsert]
	@ResourceId uniqueidentifier,
	@RatingTypeId int,
	@RatingCount int,
	@RatingTotal int,
	@RatingAverage decimal(5,2)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [Resource.RatingSummary] 
		(ResourceId, RatingTypeId, RatingCount, RatingTotal, RatingAverage, 
		 LastUpdated)
	VALUES (@ResourceId, @RatingTypeId, @RatingCount, @RatingTotal, @RatingAverage,
		GETDATE())
		
	SELECT @ResourceId AS RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.RatingSummaryGet]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Retrieve Rating Summary
-- =============================================
CREATE PROCEDURE [dbo].[Resource.RatingSummaryGet]
	@ResourceId uniqueidentifier,
	@RatingTypeId int,
	@Type varchar(50),
	@Identifier varchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
	IF @Type = '' SET @Type = NULL
	
	SELECT ResourceId, RatingTypeId, RatingCount, RatingTotal, RatingAverage,
		LastUpdated, [Type], [Identifier]
	FROM [Resource.RatingSummary] prs
	INNER JOIN [Codes.RatingType] rt ON prs.RatingTypeId = rt.Id
	WHERE (ResourceId = @ResourceId OR @ResourceId IS NULL) AND
		([Type] = @Type OR @Type IS NULL) AND
		(Identifier = @Identifier OR @Identifier IS NULL)
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.RatingSummaryDelete]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/22/2012
-- Description:	Delete Paradata Rating Summary records
-- =============================================
CREATE PROCEDURE [dbo].[Resource.RatingSummaryDelete]
	@ResourceId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Initialization
	
	DELETE FROM [Resource.RatingSummary]
	WHERE ResourceId = @ResourceId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceUpdate]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.IntendedAudienceUpdate]
	@RowId uniqueidentifier,
	@AudienceId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE [Resource.IntendedAudience]
    SET AudienceId = @AudienceId
    WHERE RowID = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceSelect]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.IntendedAudienceSelect]
	@ResourceId uniqueidentifier
	--@AudienceId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   -- IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
    --IF @AudienceId = 0 SET @AudienceId = NULL
    
    SELECT RowId, ResourceId, AudienceId, OriginalAudience
    FROM [Resource.IntendedAudience]
    WHERE (ResourceId = @ResourceId)
    --AND	(AudienceId = @AudienceId OR @AudienceId IS NULL)
END
GO
/****** Object:  View [dbo].[Resource.IntendedAudienceList]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT top 1000
 [ResourceId]
      ,[AudienceList]
  FROM [dbo].[Resource.IntendedAudienceList]
where AudienceList is not null &&  len([AudienceList] ) > 0

*/
CREATE VIEW [dbo].[Resource.IntendedAudienceList]
AS
SELECT  TOP (100) PERCENT 
  base.[RowId] As ResourceId,
  CASE
        WHEN ItemsList IS NULL THEN NULL
        WHEN len(ItemsList) = 0 THEN NULL
        ELSE left(ItemsList,len(ItemsList)-1)
  END AS AudienceList

FROM [dbo].[Resource] base
CROSS APPLY (
    SELECT distinct Title  + ', '
    FROM [Resource.IntendedAudience] list
    inner join [Codes.AudienceType] pel on list.[AudienceId] = pel.Id
    WHERE base.RowId = list.ResourceId 
    and (list.[AudienceId] is not null AND list.[AudienceId] > 0)

    FOR XML Path('') 
    ) D (ItemsList)
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.IntendedAudienceInsert]
	@ResourceId uniqueidentifier,
	@AudienceId int,
	@OriginalAudience varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowId uniqueidentifier
    SET @RowId = NEWID()
    IF @AudienceId = 0 SET @AudienceId = NULL
    INSERT INTO [Resource.IntendedAudience] (RowID, ResourceId, AudienceId, OriginalAudience)
    VALUES (@RowId, @ResourceId, @AudienceId, @OriginalAudience)
    
    SELECT @RowId AS RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceGet]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.IntendedAudienceGet]
	@RowId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT RowID, ResourceId, AudienceId, OriginalAudience
    FROM [Resource.IntendedAudience]
    WHERE RowID = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudienceDelete]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.IntendedAudienceDelete]
        @ResourceId uniqueidentifier,
        @AudienceId int
As
DELETE FROM [Resource.IntendedAudience]
WHERE ResourceId = @ResourceId  
AND AudienceId = @AudienceId
GO
/****** Object:  StoredProcedure [dbo].[Resource.IntendedAudience_SelectedCodes]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.IntendedAudience_SelectedCodes] ''9B184F11-B032-4CDB-993D-00109FDCDF68''
*/
CREATE PROCEDURE [dbo].[Resource.IntendedAudience_SelectedCodes]
    @ResourceId uniqueidentifier
As
SELECT distinct
	code.Id, code.Title
   -- ,ResourceId
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.AudienceType] code
Left Join [Resource.IntendedAudience] rpw on code.Id = rpw.AudienceId
		and rpw.ResourceId = @ResourceId
Order by 2
GO
/****** Object:  View [dbo].[Resource.KeywordsCsvList]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT top 200 ResourceId
      ,[Keywords]
  FROM [dbo].[Resource.KeywordsCsvList]
  where 
  ResourceId= '0987D8FA-5E7D-4C28-8423-000064517B67'
OR  
  ResourceId= 'D15CA074-EEB2-4BC7-AAA9-0007771B3A77'
  


SELECT top 200 ResourceId
      ,[Keywords]
  FROM [dbo].[Resource.KeywordsCsvList]
  where len(Keywords) > 0
  order by 1
  
SELECT count(*)
  FROM [dbo].[Resource.KeywordsCsvList]

*/
Create VIEW [dbo].[Resource.KeywordsCsvList]
AS
SELECT     TOP (100) PERCENT 
base.[RowId] As ResourceId,
    CASE
          WHEN Keywords IS NULL THEN ''
          WHEN len(Keywords) = 0 THEN ''
          ELSE left(Keywords,len(Keywords)-1)
    END AS Keywords

FROM [dbo].[Resource] base

CROSS APPLY (
    SELECT child.Keyword  + ', '
   -- ,child.ResourceId
    FROM dbo.[Resource.Keyword] child   
    WHERE base.RowId = child.ResourceId
    FOR XML Path('') ) D (Keywords)
GO
/****** Object:  StoredProcedure [dbo].[Resource.KeywordInsertUpdate]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.KeywordInsertUpdate]
	@ResourceId uniqueidentifier,
	@OriginalValue varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Look to see if Resource.Keyword row exists
    DECLARE @RowId uniqueidentifier
    SELECT @RowId = ResourceId
    FROM [Resource.Keyword]
    WHERE ResourceId = @ResourceId

	IF @RowId IS NULL BEGIN
		-- Does not exist, insert new row
	    INSERT INTO [Resource.Keyword] (ResourceId, OriginalValue)
		VALUES (@ResourceId, @OriginalValue)
    END ELSE BEGIN
		-- Exists, update existing row
		UPDATE [Resource.Keyword]
		SET OriginalValue = @OriginalValue
		WHERE ResourceId = @ResourceId
    END
    
    SELECT @ResourceId AS RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.KeywordInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.KeywordInsert]
	@ResourceId uniqueidentifier,
	@OriginalValue varchar(100),
	@CreatedById int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowId uniqueidentifier
    SET @RowId = NEWID()
    IF @OriginalValue = '' SET @OriginalValue = NULL
    
    INSERT INTO [Resource.Keyword] (RowId, ResourceId, Keyword, CreatedById)
    VALUES (@RowId, @ResourceId, @OriginalValue, @CreatedById)
    
    SELECT @RowId AS RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.KeywordGet]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.KeywordGet]
	@ResourceId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT ResourceId, OriginalValue
    FROM [Resource.Keyword]
    WHERE ResourceId = @ResourceId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.Language_Import]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*


-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier, @LanguageId int, @OriginalValue varchar(100),@TotalRows     int

set @LanguageId= 0
set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @OriginalValue = 'Syllabus'

set @ResourceId = 'c73542af-bdaf-4043-be18-417d5a68e6be'
set @OriginalValue = 'Image/jpg2'

EXECUTE @RC = [dbo].[Resource.Language_Import] 
   @ResourceId, @LanguageId
  ,@OriginalValue, @totalRows OUTPUT

GO


*/
/* =============================================
Description:      [Resource.Language_Import]
------------------------------------------------------
Modifications

=============================================

*/
Create PROCEDURE [dbo].[Resource.Language_Import]
          @ResourceId     uniqueidentifier, 
          @LanguageId	    int,
          @OriginalValue  varchar(100)
          ,@TotalRows     int OUTPUT

As
declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit

if @OriginalValue = '' set @OriginalValue = NULL
If @LanguageId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @LanguageId < 1		SET @LanguageId = NULL 
  
If @OriginalValue is NULL and @LanguageId is null begin
  print 'no values provided'
  return -1
  end    

set @IsDuplicate= 0
set @TotalRows= 0

-- ==================================================================
if @LanguageId is null begin
	print 'insert via Language'
	 -- so first check if mapping exists
	SELECT @LanguageId = isnull(base.id,0)
  FROM [dbo].[Codes.Language] base
  inner join [dbo].[Map.Language] mapper on base.Id = mapper.[LanguageId]
  where mapper.LRValue = @OriginalValue
   
	If @LanguageId is null OR @LanguageId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceId] FROM [dbo].[Audit.Language_Orphan] 
    where [ResourceId]= @ResourceId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.Language_Orphan]
           ([RowId]
           ,[ResourceId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @LanguageId > 0 begin
  print '[LanguageId] = ' + convert(varchar, @LanguageId)

  set @NewId= NEWID()
  print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.Language] base
	where base.[ResourceId] = @ResourceId
	And base.[LanguageId] = @LanguageId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.Language]
	    ([RowId]
	    ,[ResourceId]
	    ,[LanguageId]
	    ,OriginalLanguage)

    select
	    @NewId,
	    @ResourceId, 
	    @LanguageId, 
	    @OriginalValue
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.Format_Import]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*


-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier, @ResourceFormatId int, @OriginalValue varchar(100),@TotalRows     int

set @ResourceFormatId= 0
set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @OriginalValue = 'Syllabus'

set @ResourceId = 'c73542af-bdaf-4043-be18-417d5a68e6be'
set @OriginalValue = 'Image/jpg2'

EXECUTE @RC = [dbo].[Resource.Format_Import] 
   @ResourceId, @ResourceFormatId
  ,@OriginalValue, @totalRows OUTPUT

GO


*/
/* =============================================
Description:      [Resource.Format_Import]
------------------------------------------------------
Modifications

=============================================

*/
CREATE PROCEDURE [dbo].[Resource.Format_Import]
          @ResourceId     uniqueidentifier, 
          @ResourceFormatId	    int,
          @OriginalValue  varchar(100)
          ,@TotalRows     int OUTPUT

As
declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit

if @OriginalValue = '' set @OriginalValue = NULL
If @ResourceFormatId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @ResourceFormatId < 1		SET @ResourceFormatId = NULL 
  
If @OriginalValue is NULL and @ResourceFormatId is null begin
  print 'no values provided'
  return -1
  end    

set @IsDuplicate= 0
set @TotalRows= 0

-- ==================================================================
if @ResourceFormatId is null begin
	print 'insert via Format'
	 -- so first check if mapping exists
	SELECT @ResourceFormatId = isnull(base.id,0)
  FROM [dbo].[Codes.ResourceFormat] base
  inner join [dbo].[Map.ResourceFormat] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @ResourceFormatId is null OR @ResourceFormatId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceId] FROM [dbo].[Audit.ResourceFormat_Orphan] 
    where [ResourceId]= @ResourceId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.ResourceFormat_Orphan]
           ([RowId]
           ,[ResourceId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @ResourceFormatId > 0 begin
  print '[FormatId] = ' + convert(varchar, @ResourceFormatId)

  set @NewId= NEWID()
  print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.Format] base
	where base.[ResourceId] = @ResourceId
	And base.[CodeId] = @ResourceFormatId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.Format]
	    ([RowId]
	    ,[ResourceId]
	    ,[CodeId]
	    ,OriginalValue)

    select
	    @NewId,
	    @ResourceId, 
	    @ResourceFormatId, 
	    @OriginalValue
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end
GO
/****** Object:  View [dbo].[Resource.LanguagesList]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT top 1000
 [ResourceId]
      ,[LanguageList]
  FROM [dbo].[Resource.LanguagesList]
where LanguageList is not null &&  len([LanguageList] ) > 0

*/
CREATE VIEW [dbo].[Resource.LanguagesList]
AS
SELECT     TOP (100) PERCENT 
  base.[RowId] As ResourceId,
  CASE
        WHEN ItemsList IS NULL THEN NULL
        WHEN len(ItemsList) = 0 THEN NULL
        ELSE left(ItemsList,len(ItemsList)-1)
  END AS LanguageList
/* using [Resource.Language]*/
FROM [dbo].[Resource] base
CROSS APPLY (
    SELECT distinct codes.Title  + ', '
    FROM [Resource.Language] list
    inner join [Codes.Language] codes on list.LanguageId = codes.Id
    WHERE base.RowId = list.ResourceId 
    and (codes.Title is not null AND len(codes.Title) > 0)

    FOR XML Path('') 
    ) D (ItemsList)
    
/* using [Resource.Property]
FROM [dbo].[Resource] base 
CROSS APPLY
  (SELECT DISTINCT [Value] + ', '
    FROM          [Resource.Property] list
    WHERE      base.RowId = list.ResourceId
    AND list.[PropertyTypeId]= 4 
    AND ([Value] IS NOT NULL AND len([Value]) > 0 )
         FOR XML Path('')) D (ItemsList)

*/
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Resource.LanguagesList'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Resource.LanguagesList'
GO
/****** Object:  View [dbo].[Resource.SubjectsList_RP]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Resource.SubjectsList_RP]
AS
SELECT     TOP (100) PERCENT 
dbo.[Resource.Property].ResourceId, 
rpt.Title, 
dbo.[Resource.Property].Value AS [Subject]
FROM         dbo.[Resource.Property] 
INNER JOIN dbo.[Codes.ResPropertyType] rpt ON dbo.[Resource.Property].PropertyTypeId = rpt.Id
WHERE     (rpt.Title = 'subject')
ORDER BY dbo.[Resource.Property].ResourceId, Subject
GO
/****** Object:  View [dbo].[Resource.SubjectsCsvList]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT top 200 ResourceId
      ,[Subjects]
  FROM [dbo].[Resource.SubjectsCsvList]
  where ResourceId= '43CC85A8-8EDE-4F2E-ABC1-536D20E7D93C'


SELECT top 200 ResourceId
      ,[Subjects]
  FROM [dbo].[Resource.SubjectsCsvList]
  where len(Subjects) > 0
  order by 1
  
SELECT count(*)
  FROM [dbo].[Resource.SubjectsCsvList]

*/
CREATE VIEW [dbo].[Resource.SubjectsCsvList]
AS
SELECT     TOP (100) PERCENT 
base.[RowId] As ResourceId,
    CASE
          WHEN Subjects IS NULL THEN ''
          WHEN len(Subjects) = 0 THEN ''
          ELSE left(Subjects,len(Subjects)-1)
    END AS Subjects

FROM [dbo].[Resource] base

CROSS APPLY (
    SELECT rprop.Subject  + ', '
   -- ,rprop.ResourceId
    FROM dbo.[Resource.Subject] rprop   
    WHERE base.RowId = rprop.ResourceId
    FOR XML Path('') ) D (Subjects)
GO
/****** Object:  StoredProcedure [dbo].[Resource.SubjectInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.SubjectInsert]
	@ResourceId uniqueidentifier,
	@SubjectCsv varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
    INSERT INTO [Resource.Subject] (ResourceId, SubjectCsv)
    VALUES (@ResourceId, @SubjectCsv)
    
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.SubjectGet]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.SubjectGet]
	@ResourceId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT ResourceId, SubjectCsv
    FROM [Resource.Subject]
    WHERE ResourceId = @ResourceId
END
GO
/****** Object:  View [dbo].[Resource.ResourceTypesList]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT top 1000
 [ResourceId]
      ,[ResourceTypesList]
  FROM [dbo].[Resource.ResourceTypesList]
where 
ResourceId= '01ed5910-9965-4938-8c9a-c2eaebe62cda'
ItemsList is not null AND len([ItemsList] ) > 0


&lt;li&gt;Reference&lt;/li&gt
*/
CREATE VIEW [dbo].[Resource.ResourceTypesList]
AS
SELECT     TOP (100) PERCENT 
	base.[RowId] As ResourceId,
    CASE
          WHEN ItemsList IS NULL THEN NULL
          WHEN len(ItemsList) = 0 THEN NULL
          --ELSE ItemsList
          ELSE left(ItemsList,len(ItemsList)-1)
    END AS ResourceTypesList

FROM [dbo].[Resource] base
CROSS APPLY (
    --SELECT distinct '<li>' + codes.Title  + '</li> '
    SELECT distinct codes.Title  + ', '
    FROM [Resource.ResourceType] list
    Inner Join dbo.[Codes.ResourceType] codes on list.ResourceTypeId = codes.Id 
    WHERE base.RowId = list.ResourceId 

    FOR XML Path('') 
    ) D (ItemsList)
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeSelect]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.ResourceTypeSelect]
	@RowId uniqueidentifier,
	@ResourceId uniqueidentifier,
	@ResourceTypeId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	IF @RowId = '00000000-0000-0000-0000-000000000000' SET @RowId = NULL
	IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
	IF @ResourceTypeId = 0 SET @ResourceTypeId = NULL

    SELECT RowId, ResourceId, ResourceTypeId, OriginalType
    FROM [Resource.ResourceType]
    WHERE (RowId = @RowId OR @RowId IS NULL) AND
		(ResourceId = @ResourceId OR @ResourceId IS NULL) AND
		(ResourceTypeId = @ResourceTypeId OR @ResourceTypeId IS NULL)
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*


-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier, @ResourceTypeId int, @OriginalValue varchar(100),@TotalRows     int

set @ResourceTypeId= 0
set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @OriginalValue = 'Syllabus'

set @ResourceId = 'c73542af-bdaf-4043-be18-417d5a68e6be'
set @OriginalValue = 'Image/jpg2'



EXECUTE @RC = [dbo].[Resource.ResourceTypeInsert] 
   @ResourceId, @ResourceTypeId
  ,@OriginalValue
  --, @totalRows OUTPUT

GO


*/
/* =============================================
Description:      [Resource.ResourceTypeInsert]
------------------------------------------------------
Modifications
12-09-19 mparsons - added duplicates check (multiple inputs can map to same output)
=============================================

*/
CREATE PROCEDURE [dbo].[Resource.ResourceTypeInsert]
          @ResourceId uniqueidentifier, 
          @ResourceTypeId	int,
          @OriginalValue varchar(100)
         -- ,@TotalRows     int OUTPUT

As

declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit
, @ErrorMsg varchar(100)

if @OriginalValue = '' set @OriginalValue = NULL
If @ResourceTypeId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @ResourceTypeId < 1		SET @ResourceTypeId = NULL 
  
If @OriginalValue is NULL and @ResourceTypeId is null begin
  print 'no values provided'
  return -1
  end    


set @IsDuplicate= 0
--set @TotalRows= 0
	set @ErrorMsg = ''
-- ==================================================================
if @ResourceTypeId is null begin
	print 'insert via ResourceType'
	 -- so first check if mapping exists
	SELECT @ResourceTypeId = isnull(base.id,0)
  FROM [dbo].[Codes.ResourceType] base
  inner join [dbo].[Map.ResourceType] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @ResourceTypeId is null OR @ResourceTypeId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceId] FROM [dbo].[Audit.ResourceType_Orphan] 
    where [ResourceId]= @ResourceId and [OriginalValue] = @OriginalValue) begin
    set @ErrorMsg = 'No mapping was found for parameter, writing to audit table'
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.ResourceType_Orphan]
           ([RowId]
           ,[ResourceId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      set @ErrorMsg = 'No mapping was found for parameter, the value already exists in audit table'
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate, @ErrorMsg
    end
	end

if @ResourceTypeId > 0 begin
  print '[ResourceTypeId] = ' + convert(varchar, @ResourceTypeId)

  set @NewId= NEWID()
  print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.ResourceType] base
	where base.[ResourceId] = @ResourceId
	And base.[ResourceTypeId] = @ResourceTypeId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.ResourceType]
	    ([RowId]
	    ,[ResourceId]
	    ,[ResourceTypeId]
	    ,[OriginalType])

    select
	    @NewId,
	    @ResourceId, 
	    @ResourceTypeId, 
	    @OriginalValue
    end
  --set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As sDuplicate, @ErrorMsg As [Message]    
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeImport]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*


-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier, @ResourceTypeId int, @OriginalValue varchar(100),@TotalRows     int

set @ResourceTypeId= 0
set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @OriginalValue = 'Syllabus'

set @ResourceId = 'c73542af-bdaf-4043-be18-417d5a68e6be'
set @OriginalValue = 'Image/jpg2'



EXECUTE @RC = [dbo].[Resource.ResourceTypeImport] 
   @ResourceId, @ResourceTypeId
  ,@OriginalValue, @totalRows OUTPUT

GO


*/
/* =============================================
Description:      [Resource.ResourceTypeImport]
------------------------------------------------------
Modifications
12-09-19 mparsons - added duplicates check (multiple inputs can map to same output)
=============================================

*/
Create PROCEDURE [dbo].[Resource.ResourceTypeImport]
          @ResourceId uniqueidentifier, 
          @ResourceTypeId	int,
          @OriginalValue varchar(100)
          ,@TotalRows     int OUTPUT

As
declare @NewId uniqueidentifier
, @mapperId int
, @exists uniqueidentifier
, @IsDuplicate bit
, @RecordCount int
, @SuppressOutput bit

if @OriginalValue = '' set @OriginalValue = NULL
If @ResourceTypeId = -1		SET @SuppressOutput = 1
else set @SuppressOutput  = 0
If @ResourceTypeId < 1		SET @ResourceTypeId = NULL 
  
If @OriginalValue is NULL and @ResourceTypeId is null begin
  print 'no values provided'
  return -1
  end    

set @IsDuplicate= 0
set @TotalRows= 0

-- ==================================================================
if @ResourceTypeId is null begin
	print 'insert via ResourceType'
	 -- so first check if mapping exists
	SELECT @ResourceTypeId = isnull(base.id,0)
  FROM [dbo].[Codes.ResourceType] base
  inner join [dbo].[Map.ResourceType] mapper on base.Id = mapper.[CodeId]
  where mapper.LRValue = @OriginalValue
   
	If @ResourceTypeId is null OR @ResourceTypeId = 0	begin	
    --no mapping, write to exceptions table and return
    -- when called from interface, may need real message?
    if NOT exists(SELECT [ResourceId] FROM [dbo].[Audit.ResourceType_Orphan] 
    where [ResourceId]= @ResourceId and [OriginalValue] = @OriginalValue) begin
      print '@@ no mapping, writing to audit table: ' + @OriginalValue
      INSERT INTO [dbo].[Audit.ResourceType_Orphan]
           ([RowId]
           ,[ResourceId]
           ,[OriginalValue])
      VALUES
           (newId()
           ,@ResourceId
           ,@OriginalValue)
      
      end    
    else begin
      print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
      end

    --return -1
    if @SuppressOutput = 0
      select '' as Id, 0 As IsDuplicate
    end
	end

if @ResourceTypeId > 0 begin
  print '[ResourceTypeId] = ' + convert(varchar, @ResourceTypeId)

  set @NewId= NEWID()
  print '@NewId: ' + convert(varchar(50), @NewId)

-- exists check for dups, or allow fail on dup
  select @exists = base.[RowId]
	from [dbo].[Resource.ResourceType] base
	where base.[ResourceId] = @ResourceId
	And base.[ResourceTypeId] = @ResourceTypeId
	
	if @exists is not NULL AND @exists != '00000000-0000-0000-0000-000000000000' begin
	  set @NewId= @exists
	  set @IsDuplicate= 1
	  print 'found duplicate'
	end
	else begin
    INSERT INTO [dbo].[Resource.ResourceType]
	    ([RowId]
	    ,[ResourceId]
	    ,[ResourceTypeId]
	    ,[OriginalType])

    select
	    @NewId,
	    @ResourceId, 
	    @ResourceTypeId, 
	    @OriginalValue
    end
  set @TotalRows = @@rowcount
  if @SuppressOutput = 0    
    select @NewId as Id, @IsDuplicate As IsDuplicate    
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeGet]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.ResourceTypeGet]
	@RowId uniqueidentifier,
	@ResourceId uniqueidentifier,
	@CodeId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @RowId = '00000000-0000-0000-0000-000000000000' SET @RowId = NULL
	IF @ResourceId = '00000000-0000-0000-0000-000000000000' SET @ResourceId = NULL
	IF @CodeId = '' SET @CodeId = NULL

	SELECT RowId, ResourceId, OriginalType AS OriginalValue, ResourceTypeId AS CodeId,
		crt.Title AS MappedValue
	FROM [Resource.ResourceType] rrt
	INNER JOIN [Codes.ResourceType] crt ON rrt.ResourceTypeId = crt.Id
	WHERE   (RowId = @RowId OR @RowId IS NULL)
		AND (ResourceId = @ResourceId OR @ResourceId IS NULL)
		AND (ResourceTypeId = @CodeId OR @CodeId IS NULL)

END
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceTypeDelete]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[Resource.ResourceTypeDelete]
        @ResourceId uniqueidentifier,
        @ResourceTypeId int
As
DELETE FROM [Resource.ResourceType]
WHERE ResourceId = @ResourceId  
AND ResourceTypeId = @ResourceTypeId
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceType_SelectedCodes]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Resource.ResourceType_SelectedCodes] ''9B184F11-B032-4CDB-993D-00109FDCDF68''
*/
CREATE PROCEDURE [dbo].[Resource.ResourceType_SelectedCodes]
    @ResourceId uniqueidentifier
As
SELECT distinct
	code.Id, code.Title
   -- ,ResourceId
	,CASE
		WHEN rpw.ResourceId IS NOT NULL THEN 'true'
		ELSE 'false'
	END as IsSelected
FROM [dbo].[Codes.ResourceType] code
Left Join [Resource.ResourceType] rpw on code.Id = rpw.ResourceTypeId
		and rpw.ResourceId = @ResourceId
Order by 2
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceType_Insert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Insert record into [Resource.ResourceType] table
-- =============================================
CREATE PROCEDURE [dbo].[Resource.ResourceType_Insert]
	@ResourceId uniqueidentifier,
	@OriginalValue varchar(100),
	@CodeId int,
	@MappedValue varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CodeId = 0 BEGIN
		SELECT @CodeId = Id
		FROM [Codes.ResourceType]
		WHERE Title = @MappedValue
	END
	
	IF @CodeId = 0 SET @CodeId = NULL

	DECLARE @RowId uniqueidentifier
	SET @RowId = NEWID()
	INSERT INTO [Resource.ResourceType] (RowId, ResourceId, ResourceTypeId, OriginalType)
	VALUES (@RowId, @ResourceId, @CodeId, @OriginalValue)

	SELECT @RowId AS RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.ResourceType_FixUnknownTypes]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Exec CodeTables_UpdateWarehouseTotals 10

select [MappingType], OriginalValue from [dbo].[Audit.ResourceType_Orphan]



EXECUTE [dbo].[Resource.ResourceType_FixUnknownTypes] 25


*/

Create PROCEDURE [dbo].[Resource.ResourceType_FixUnknownTypes]
            @MaxRecords int

As
begin 
          
Declare 
@ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@OriginalValue varchar(200)
,@cntr int
,@totalRows int
,@ResourceTypeId	int


set @cntr= 0
set @ResourceTypeId = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
    select base.RowId, base.ResourceId, base.[OriginalType]
      FROM [dbo].[Resource.ResourceType] base
      left join [Map.ResourceType] map on base.[OriginalType] = map.LRValue
      left join [dbo].[Codes.ResourceType] codes on map.[CodeId] = codes.Id
      --left join [dbo].[Resource.ResourceType] rtype on base.ResourceId = rtype.ResourceId and rtype.[ResourceTypeId] = codes.id
    where [ResourceTypeId] = 18
    -- and rtype.ResourceId is  null
 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @OriginalValue
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
		  
 --   if @cntr < 50 print '-- ' + convert(varchar(50),@ResourceId) + ' / ' + @OriginalValue 
    
	  SELECT @ResourceTypeId = isnull(base.id,0)
    FROM [dbo].[Codes.ResourceType] base
    inner join [dbo].[Map.ResourceType] mapper on base.Id = mapper.[CodeId]
    where mapper.LRValue = @OriginalValue		  
		  
	  If @ResourceTypeId is null OR @ResourceTypeId = 0	begin	
	    --no mapping, check if exists in audit
	    if NOT exists(SELECT [ResourceId] FROM [dbo].[Audit.ResourceType_Orphan] 
      where [ResourceId]= @ResourceId and [OriginalValue] = @OriginalValue) begin
        print '@@ no mapping, writing to audit table: ' + @OriginalValue
        INSERT INTO [dbo].[Audit.ResourceType_Orphan]
             ([RowId]
             ,[ResourceId]
             ,[OriginalValue])
        VALUES
             (newId()
             ,@ResourceId
             ,@OriginalValue)
        
        end    
      else begin
        print '@@ no mapping, ALREADY IN audit table: ' + @OriginalValue
        end
      end
	   else begin
	    --do update
	    print '** updating value: ' + @OriginalValue + ' to type id: ' + convert(varchar,@ResourceTypeId)
      UPDATE [dbo].[Resource.ResourceType]
         SET [ResourceTypeId] = @ResourceTypeId
       WHERE RowId= @RowId
       	  
	    end

		
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @OriginalValue
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.StandardSelect]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.StandardSelect]
    @ResourceId uniqueidentifier
As
SELECT 
    RowID, 
    ResourceId, 
    StandardId, 
    ss.StandardUrl,
    ss.Standard,
    OriginalValue
FROM [Resource.Standard] base
inner join [Standardbody.Standard] ss on base.StandardId = ss.Id
WHERE RowID = @ResourceId
Order by ss.StandardUrl
GO
/****** Object:  StoredProcedure [dbo].[Resource.StandardInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.StandardInsert]
            @ResourceId uniqueidentifier, 
            @StandardId int, 
            @OriginalValue varchar(200)
As
If @ResourceId = ''   SET @ResourceId = NULL 
If @StandardId = 0   SET @StandardId = NULL 
If @OriginalValue = ''   SET @OriginalValue = NULL 

declare @newId as uniqueidentifier
set @newId= newId()

INSERT INTO [Resource.Standard] (
    RowId,
    ResourceId, 
    StandardId, 
    OriginalValue
)
Values (
    @newId,
    @ResourceId, 
    @StandardId, 
    @OriginalValue
)
 
select @newId as Id
GO
/****** Object:  StoredProcedure [dbo].[Resource.StandardGet]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.StandardGet]
    @RowID uniqueidentifier
As
SELECT     base.RowID, 
    base.ResourceId, 
    base.StandardId, 
    ss.StandardUrl,
    ss.Standard,
    base.OriginalValue
FROM [Resource.Standard] base
left join [Standardbody.Standard] ss on base.StandardId = ss.Id
WHERE RowID = @RowID
GO
/****** Object:  StoredProcedure [dbo].[Resource.StandardDelete]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.StandardDelete]
        @RowID uniqueidentifier
As
DELETE FROM [Resource.Standard]
WHERE RowID = @RowID
GO
/****** Object:  StoredProcedure [dbo].[Resource.SubjectUpdate]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Resource.SubjectUpdate]
	@ResourceId uniqueidentifier,
	@SubjectCsv varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE [Resource.Subject]
	SET SubjectCsv=@SubjectCsv
	WHERE ResourceId = @ResourceId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionDelete]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 09/11/2012
-- Description:	Delete a version of a resource
-- =============================================
CREATE PROCEDURE [dbo].[Resource.VersionDelete]
	@RowId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE FROM [Resource.Version]
	WHERE RowId = @RowId
END
GO
/****** Object:  View [dbo].[Resource.Version_Summary]    Script Date: 12/14/2012 10:55:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
-- images
-- 46 sec, for 19000 using all 
--title, res, desc, pub: 43 s, 8540 rows
--title, desc: 47 s, 7109 rows
--title, res, desc: 29 s, 8535 rows
--res: 1 s, 1541 rows
-- added index on title and pub
--title, pub: 3 s, 721 rows
--title, res, pub: 16 s, 2166 rows
--title, res: 3 s, 2152 rows

SELECT [ResourceUrl]
      ,[ResourceId]
      ,[ResourceVersionId]

      ,[Title]
      ,[Description]
      ,[Publisher]
      --,[Creator]
      --,[Rights]
      --,[AccessRights]
      --,[TypicalLearningTime]
      ,[Modified]
      --,[Submitter]

  FROM [dbo].[Resource.Version_Summary]
  where 
 -- MegaSearchField like '%image%'
  --or 
  title like  '%www.freesound.org%'
  --OR ResourceUrl like  '%www.freesound.org%'
  --OR Description like  '%oercommons%'
  OR Publisher like  '%www.freesound.org%'
  --127
  OR Subjects like  '%image%'
  OR Keywords like  '%image%' 
  order by 1
GO

--683
SELECT 
[ResourceId]
      ,[Title]
      ,[Description]
  FROM [dbo].[Resource.Version]
  where 
  title like  '%image%'
  OR Description like  '%image%'
  OR Publisher like  '%image%'
  --7136
  order by 2

*/
/*
Resource.Version_Summary - summary of key resource tables. 
        Should only be used by a search. Not for returning to code
        WARNING - changing view may require recreation of the Resource_Version_Summary_ClusteredIndex.sql (or at least doing a rebuild!!!!
*/
CREATE VIEW [dbo].[Resource.Version_Summary] WITH SCHEMABINDING AS

SELECT 
      lr.ResourceUrl
      ,base.[ResourceId]
      ,base.RowId as ResourceVersionId
      ,base.[Title]
      ,base.[Description]
      ,base.[Publisher]
      ,base.[Creator]
      ,base.[Rights]
      ,base.[AccessRights]
      ,base.[TypicalLearningTime]
      ,base.[Modified]
      ,base.[Submitter]
      ,base.Keywords
      ,base.Subjects
      ,base.SortTitle
    --  ,base.[Imported]
    --  ,base.[Created]
    --  ,base.[IsActive]
      --      ,lr.ResourceUrl + isnull(base.[Title],'') + isnull(base.[Description],'') + isnull(base.[Publisher],'') + isnull(base.Subjects,'') + isnull(base.Keywords,'')
      --+ isnull(base.[Creator],'')
      --+ isnull(base.[Rights],'')
      --+ isnull(base.[AccessRights],'') As MegaSearchField
--224166, 42s, then 36s, 10s after index on IsActive 
--355903, 6s without where!!
--2s with just   HasPathwayGradeLevel  
--9s with both HasPathwayGradeLevel  and isActive
--    SELECT count(*)      
  FROM [dbo].[Resource.Version] base
  Inner JOIN dbo.[Resource] lr ON lr.RowId = base.ResourceId
  where lr.HasPathwayGradeLevel=1 
  AND base.[IsActive]= 1 
  AND lr.[IsActive]= 1
GO
/****** Object:  StoredProcedure [dbo].[Resource.Version_Get]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
declare @Id varchar(50)
set @Id = 'AD95FAD2-FC7B-48EE-8F51-E6904F7A9589'
set @Id = 'd9fe9bb9-f719-43f3-b3e6-1272b1684488'
--set @Id = 'e0219864-cb78-4146-b043-4e6476e3933e'
exec [Resource.Version_Get]  @Id, '',''

[Resource.Version_Get]  '', 'http://www.carcam.org/docs/surveyresults.pdf',''

*/


/* =============================================
-- Description:	Get a resource version for display
-- 12-09-02 mparsons added 
-- =============================================
*/
Create PROCEDURE [dbo].[Resource.Version_Get]
	@RowId varchar(36)
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT distinct
		base.RowId, 
		res.ResourceUrl, 
		--res.Source, --TBD
		base.DocId,
		base.Title, 
		base.[Description], 
		isnull(base.Publisher, 'Unknown') As Publisher,
		isnull(base.Creator, 'Unknown') As Creator,
		isnull(base.Rights, 'Unknown') As Rights,
		isnull(base.AccessRights, 'Unknown') As AccessRights,
		isnull(base.TypicalLearningTime, '') As TypicalLearningTime,
		base.Modified, 
		base.Submitter, 
		
		isnull(base.Imported, base.Modified) As Imported
		
	
	FROM [Resource.Version] base		
	inner join [Resource] res on base.ResourceId = res.RowId
        
	WHERE (base.RowId = @RowId)
	
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.PropertyInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
declare @PropertyName varchar(100),@NewId uniqueidentifier
set @NewId= NEWID()
set @PropertyName = 'subject'

Select
	@NewId,
    '@ResourceId', 
    @PropertyName, 
    '@Value', 
    rpt.Id	--PropertyTypeId
from [Resource.Property] base    
left Join [Codes.ResPropertyType] rpt on @PropertyName = rpt.Title

8B5D62B9-CCBF-4E01-8177-DB746540F397

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@PropertyTypeId int
DECLARE @PropertyName varchar(100), @Value varchar(500)

set @ResourceId = '7F1427AF-ABB8-4CCD-AC00-000BB5EE7C30'
set @PropertyTypeId = 0
set @PropertyName = 'subjecterr'
set @Value = 'test2'

EXECUTE @RC = [LearningRegistryCache2].[dbo].[Resource.PropertyInsert] 
   @ResourceId
  ,@PropertyTypeId
  ,@PropertyName
  ,@Value
GO


*/
CREATE PROCEDURE [dbo].[Resource.PropertyInsert]
            @ResourceId uniqueidentifier, 
            @PropertyTypeId int,
            @PropertyName varchar(100), 
            @Value varchar(500)

As
if @PropertyName is null OR LEN(@PropertyName) = 0 set @PropertyName = 'other'
If @PropertyTypeId = 0		SET @PropertyTypeId = NULL 
  
declare @NewId uniqueidentifier
set @NewId= NEWID()
print '@NewId: ' + convert(varchar(50), @NewId)

if @PropertyTypeId is null begin
	print 'insert via PropertyName'
	select @PropertyTypeId = isnull(id,0) from  [Codes.ResPropertyType]  rpt 
	where rpt.Title = @PropertyName
	
	If @PropertyTypeId is null OR @PropertyTypeId = 0	begin	
		SET @PropertyTypeId = 8 
		print 'the property name was not found: ' + @PropertyName
		end
	end
else begin
	print 'insert via @PropertyTypeId'
	end
	
	
	INSERT INTO [Resource.Property]
	(
		RowId,
		ResourceId, 
		PropertyTypeId,
		Value
	)
	Values (
		@NewId,
		@ResourceId, 
		@PropertyTypeId, 
		@Value
	)

--)
 
select @NewId as Id
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionInsert]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/30/2012
-- Description:	Insert a ResourceVersion record
-- =============================================
CREATE PROCEDURE [dbo].[Resource.VersionInsert]
	@ResourceId uniqueidentifier,
	@DocId varchar(500),
	@Title varchar(200),
	@Description varchar(max),
	@Publisher varchar(100),
	@Creator varchar(100),
	@Rights varchar(500),
	@AccessRights varchar(100),
	@Modified datetime,
	@Submitter varchar(100),
	@Created datetime,
	@TypicalLearningTime varchar(50),
	@IsSkeletonFromParadata bit
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @Publisher = '' SET @Publisher = NULL
	IF @Creator = '' SET @Creator = NULL
	IF @Rights = '' SET @Rights = NULL
	IF @AccessRights = '' SET @AccessRights = NULL
	IF @Submitter = '' SET @Submitter = NULL
	IF @TypicalLearningTime = '' SET @TypicalLearningTime = NULL
	
	DECLARE @NewId uniqueidentifier
	SET @NewId = NEWID()
	
	INSERT INTO [Resource.Version] (RowId, ResourceId, DocId, Title, [Description],
		Publisher, Creator, Rights, AccessRights, Modified, Submitter, Imported, Created,
		TypicalLearningTime, IsSkeletonFromParadata)
	VALUES (@NewId, @ResourceId, @DocId, @Title, @Description, 
		@Publisher, @Creator, @Rights, @AccessRights, @Modified, @Submitter, GETDATE(),	@Created, 
		@TypicalLearningTime, @IsSkeletonFromParadata)
END
GO
/****** Object:  StoredProcedure [dbo].[Resource_Search2]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--WHERE ID BETWEEN @startRowIndex AND (@startRowIndex + @maximumRows) - 1
--ROW_NUMBER()
/*

  SELECT 
  --distinct count(*)
  distinct ROW_NUMBER() As Id, lr.ResourceId, lr.ResourceVersionId, lr.Title  
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN [Resource.Cluster] rcl ON lr.ResourceId = rcl.ResourceId 
        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        --Left JOIN dbo.[Resource.Keyword] lrkey ON lr.ResourceId = lrkey.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevel] edList ON lr.ResourceId = edList.ResourceId  
WHERE ID BETWEEN 100 AND 200


DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @totalRows int, @OutputRelTables bit
--
set @SortOrder = ''
-- OR lr.[Description] like ''%Finance%'' OR lr.[Description] like ''%Manufacturing%'' 
 
-- blind search 
set @Filter = ''
set @Filter = ' Where (edList.PathwaysEducationLevelId in (3,4,5,6)) ' 
set @Filter = ' Where (rcl.ClusterId = 1 ) ' 
set @OutputRelTables = 1
set @StartPageIndex = 4
set @PageSize = 55

EXECUTE @RC = Resource_Search2
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @OutputRelTables  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/



CREATE PROCEDURE [dbo].[Resource_Search2]
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@OutputRelTables bit
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@lastRow int
      ,@minRows int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@TopClause       varchar(100)
      ,@DefaultFilter   varchar(1000)
      ,@OrderBy         varchar(100)
-- =================================

Set @debugLevel = 4
Set @TopClause= ''
--actually the following is implied in the view (and IsPathwayLevel)
Set @DefaultFilter= ' Where (edList.PathwaysEducationLevelId in (3,4,5,6)) ' 
if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by lr.Title '
--===================================================
-- Calculate the range
--===================================================      
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
SET @lastRow =  @StartPageIndex + @PageSize

--
if len(isnull(@Filter,'')) = 0 begin
   Set @TopClause= ' TOP 8000 '
   Set @OutputRelTables = 0 
   end
else if @minRows < 1000   begin 
  set @TopClause= ' TOP 8000 '   
  end   
--
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
--                 Left JOIN dbo.[Resource.Property] lrp ON lr.ResourceId = lrp.ResourceId 
--Left JOIN [Resource.EducationLevelsSummary] edList ON lr.ResourceId = edList.ResourceId 
 


  set @SQL = '  
SELECT Distinct    
    RowNumber,
    lr.ResourceId,
    lr.ResourceVersionId As RowId,
    lr.ResourceVersionId,
    lr.ResourceUrl,
     CASE
      WHEN lr.Title IS NULL THEN ''No Title''
      WHEN len(lr.Title) = 0 THEN ''No Title''
      ELSE lr.Title
    END AS Title,
    [Description],
    isnull(Publisher,''Unknown'') As Publisher,
    rtrim(ltrim(isnull(Creator,''''))) As Creator,

    replace(isnull(rsub.SubjectCsv, ''''), ''","'', '', '') As Subjects,
    edList.EducationLevels,    
    Rights,
    AccessRights
FROM
   (SELECT 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
        lr.ResourceId, lr.Title  
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN [Resource.Cluster] rcl ON lr.ResourceId = rcl.ResourceId 
        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevel] edList ON lr.ResourceId = edList.ResourceId  
        ' 
        + @Filter + ' 
   ) as DerivedTableName
       Inner join [dbo].[Resource.Version_Summary] lr on DerivedTableName.ResourceId = lr.ResourceId
    Left JOIN dbo.[Resource.Subject] rsub ON lr.ResourceId = rsub.ResourceId 
    Left Join [dbo].[Resource.EducationLevelsList] edList on lr.ResourceId = edList.ResourceId


WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' ' 


  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  exec (@SQL)
  --===============================
DECLARE @TempItems TABLE
(
   ID int IDENTITY,
   ResourceId uniqueidentifier
)

INSERT INTO @TempItems (ResourceId)
SELECT distinct lr.ResourceId 
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN [Resource.Cluster] rcl ON lr.ResourceId = rcl.ResourceId 
        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevel] edList ON lr.ResourceId = edList.ResourceId 
        Where (rcl.ClusterId > 1 )
        
select @TotalRows= count(*) from @TempItems 

select @TotalRows
GO
/****** Object:  StoredProcedure [dbo].[Resource_Search_FT]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT distinct lr.RowId, lr.Title  FROM dbo.Resource lr
        Left JOIN dbo.[Resource.Property] lrp ON lr.RowId = lrp.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.RowId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId   
        where  (FREETEXT(lr.[Description], ' Manufacturing Research and Development ') or FREETEXT(lr.Title, ' Manufacturing Research and Development ') ) 
        UNION SELECT distinct lr.RowId, lr.Title  FROM dbo.Resource lr
        Left JOIN dbo.[Resource.Property] lrp ON lr.RowId = lrp.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.RowId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.RowId = edList.ResourceId   
        where  (lrp.PropertyTypeId = 6 and FREETEXT(lrp.Value, ' Manufacturing Research and Development ') )   
        Order by lr.Title 

        
2 sec
-- ===========================================================
DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000),@Keywords        varchar(1000)
DECLARE @StartPageIndex int, @PageSize int, @totalRows int, @OutputRelTables bit
--
set @Filter = ''
set @SortOrder = ''
set @Keywords =  ''

set @Filter = ' where (edList.PathwaysEducationLevelId in (4,5,6) )  '

set @Keywords =  ' Manufacturing Research Development '

set @OutputRelTables = 1 
set @StartPageIndex = 3
set @PageSize = 25

EXECUTE @RC = Resource_Search_FT
     @Filter, @Keywords, @SortOrder, @StartPageIndex  ,@PageSize, @OutputRelTables  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/

/* =============================================
  Description:      Resource search using full text catalog
  Uses custom paging to only return enough rows for one page
     Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @totalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
12-07-30 mparsons - new, now uses full text catalogs
12-09-05 mparsons - convert to use Resource.Version_Summary
=============================================

*/

CREATE PROCEDURE [dbo].[Resource_Search_FT]
	@Filter           varchar(5000)
	,@Keywords        varchar(1000)
	,@SortOrder       varchar(100)
	,@StartPageIndex  int
	,@PageSize        int
	,@OutputRelTables bit
	,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@debugLevel      int
      ,@FTFilter1        varchar(5000)
      ,@FTFilter2        varchar(5000)
      ,@SQL             varchar(8000)
      ,@OrderBy         varchar(100)
      ,@And             varchar(15)
-- =================================

Set @debugLevel = 4
if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by lr.Title '

-- =================================

CREATE TABLE #tempWorkTable(
      RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
      ResourceId        [uniqueidentifier],
      ResourceVersionId [uniqueidentifier],
      Title             varchar(200)
)

-- =================================

  if len(@Filter) > 0 begin
     set @And= ' AND '
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end
  else if len(@Keywords) > 0 begin
    set @Filter = ' where '
    set @And= ''
    end
  print '@Filter len: '  +  convert(varchar,len(@Filter))
       
       --     or FREETEXT(lrkey.KeywordsIdx, ''' + @Keywords + ''') 
       
  if len(@Keywords) > 0 begin
     set @FTFilter1 = @And + 
     ' (FREETEXT(lr.[Title], ''' + @Keywords + ''') 
     --or FREETEXT(lr.Description, ''' + @Keywords + ''') 
     or FREETEXT(lr.Publisher, ''' + @Keywords + ''') 
     or FREETEXT(lr.ResourceUrl, ''' + @Keywords + ''') 
    -- or FREETEXT(lrs.SubjectsIdx, ''' + @Keywords + ''') 
    -- or FREETEXT(lrkey.OriginalValue, ''' + @Keywords + ''') 
     ) '
     set @FTFilter2 = @And + ' (lrp.PropertyTypeId = 6 and FREETEXT(lrp.Value, ''' + @Keywords + ''') ) ' 
     
       set @SQL = 'SELECT distinct lr.ResourceId, lr.ResourceVersionId, lr.Title  
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        Left JOIN dbo.[Resource.Keyword] lrkey ON lr.ResourceId = lrkey.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.ResourceId = edList.ResourceId  '
        + @Filter
        + @FTFilter1
        --+ 'UNION '
        --+'SELECT distinct lr.ResourceId, lr.ResourceVersionId, lr.Title  
        --FROM [dbo].[Resource.Version_Summary] lr
        --Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        --Left JOIN dbo.[Resource.Keyword] lrkey ON lr.ResourceId = lrkey.ResourceId 
        --Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        --Left JOIN [Resource.EducationLevelsSummary] edList ON lr.ResourceId = edList.ResourceId  '
        --+ @Filter   
       -- + @FTFilter2
     end
else begin
  set @SQL = 'SELECT distinct lr.ResourceId, lr.ResourceVersionId, lr.Title  
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        Left JOIN dbo.[Resource.Keyword] lrkey ON lr.ResourceId = lrkey.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.ResourceId = edList.ResourceId  '
        + @Filter
	end     

--         

  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (ResourceId, ResourceVersionId, Title)
  exec (@SQL)
    SELECT @totalRows = @@ROWCOUNT
-- =================================
  --print 'rows: ' + convert(varchar, @@ROWCOUNT)

-- =================================

print 'added to temp table: ' + convert(varchar,@totalRows)

-- Get the total rows
--SELECT @totalRows = COUNT(RowNumber) FROM #tempWorkTable
print 'rows = ' + str(@totalRows)

if @StartPageIndex < 1        set @StartPageIndex = 1

-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- =================================
--SELECT Distinct TOP (@PageSize)
SELECT Distinct    
	
    RowNumber,
    lr.ResourceId,
    lr.ResourceVersionId As RowId,
    lr.ResourceVersionId,
    lr.ResourceUrl,
    --DocId,
    CASE
      WHEN lr.Title IS NULL THEN 'No Title'
      WHEN len(lr.Title) = 0 THEN 'No Title'
      ELSE lr.Title
    END AS Title,
    [Description],
    isnull(Publisher,'Unknown') As Publisher,
    isnull(Creator,'Unknown') As Creator,

--    CASE
--          WHEN Subjects IS NULL THEN ''
--          WHEN len(Subjects) = 0 THEN ''
--          ELSE left(Subjects,len(Subjects)-1)
--    END AS Subjects,
    rsub.Subjects,
    edList.EducationLevels,    
   --'' As EducationLevels,
    Rights,
    AccessRights,
    Modified

From #tempWorkTable
    Inner join [dbo].[Resource.Version_Summary] lr on #tempWorkTable.ResourceId = lr.ResourceId
    Inner Join [dbo].[Resource.SubjectsCsvList] rsub on #tempWorkTable.ResourceId = rsub.ResourceId
    Left Join [dbo].[Resource.EducationLevelsList] edList on #tempWorkTable.ResourceId = edList.ResourceId


WHERE RowNumber > @first_id
order by RowNumber 

if @OutputRelTables = 1 begin
	--=====================================
	CREATE TABLE #edWorkTable(
		  PathwaysEducationLevelId int,
		  RecordCount	int
	)
	--			
	INSERT INTO #edWorkTable (PathwaysEducationLevelId,RecordCount)
	SELECT rel.PathwaysEducationLevelId, Count(*) As RecordCount 
	FROM #tempWorkTable work
	Inner JOIN [Resource.EducationLevelsSummary] rel ON work.ResourceId = rel.ResourceId 
	group by rel.PathwaysEducationLevelId
	--			
	SELECT rel.PathwaysEducationLevelId As Id, codes.Title, 
	codes.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
	RecordCount 
	FROM #edWorkTable rel
	INNER JOIN dbo.[Codes.PathwaysEducationLevel] codes ON rel.PathwaysEducationLevelId = codes.Id
	where codes.IsPathwaysLevel= 1
	order by codes.SortOrder, codes.Title

	--			
	--=====================================
	CREATE TABLE #rtWorkTable(
		  ResourceTypeId int,
		  RecordCount	int
	)	
	INSERT INTO #rtWorkTable (ResourceTypeId,RecordCount)
	SELECT rel.ResourceTypeId, Count(*) As RecordCount 
	FROM #tempWorkTable work
	Inner JOIN [Resource.ResourceType] rel ON work.ResourceId = rel.ResourceId 
	group by rel.ResourceTypeId
	--			
	SELECT rrt.ResourceTypeId As Id, 
	crt.Title, 
	crt.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
	RecordCount 
	FROM #rtWorkTable rrt
	Inner Join dbo.[Codes.ResourceType] crt on rrt.ResourceTypeId = crt.Id
	order by crt.SortOrder, crt.Title
	end
GO
/****** Object:  StoredProcedure [dbo].[Resource_Search]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT distinct lr.ResourceId, lr.ResourceVersionId, lr.Title  
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevelsSummary] edList ON lr.ResourceId = edList.ResourceId   
        where  ( lr.[MegaSearchField] like '%image%' )   Order by lr.Title 

SELECT COUNT(*) FROM [dbo].[Resource.Version_Summary]

SELECT COUNT(RowId) FROM [dbo].[Resource]

select top 1000 * from [dbo].[Resource.Version_Summary]

 --set @Filter = '  ( (Title like ''%Agriculture, Food, and Natural Resources%'' OR [Description] like ''%Agriculture, Food, and Natural Resources%'' OR lrp.Value like ''%Agriculture, Food, and Natural Resources%'') OR (Title like ''%Energy%'' OR [Description] like ''%Energy%'' OR lrp.Value like ''%Energy%'') OR (Title like ''%Finance%'' OR [Description] like ''%Finance%'' OR lrp.Value like ''%Finance%'') OR (Title like ''%Health Science%'' OR [Description] like ''%Health Science%'' OR lrp.Value like ''%Health Science%'') OR (Title like ''%Information Technology%'' OR [Description] like ''%Information Technology%'' OR lrp.Value like ''%Information Technology%'') OR (Title like ''%Manufacturing%'' OR [Description] like ''%Manufacturing%'' OR lrp.Value like ''%Manufacturing%'') OR (Title like ''%Research and Development%'' OR [Description] like ''%Research and Development%'' OR lrp.Value like ''%Research and Development%'') OR (Title like ''%Transportation, Distribution and Logistics%'' OR [Description] like ''%Transportation, Distribution and Logistics%'' OR lrp.Value like ''%Transportation, Distribution and Logistics%'') )  AND (lrp.Value in (''high school'',''Higher Education'')) ' 


set @Filter = ' where ( (lr.Title like ''%Energy%'' OR lr.[Description] like ''%Energy%'' OR lrp.Value like ''%Energy%'') OR (lr.Title like ''%Finance%'' OR lr.[Description] like ''%Finance%'' OR lrp.Value like ''%Finance%'') OR (lr.Title like ''%Health Science%'' OR lr.[Description] like ''%Health Science%'' OR lrp.Value like ''%Health Science%'') ) AND (lrp.Value in (''high school'',''Higher Education'')) '

2 sec
-- ===========================================================
set @Filter = ' where lr.Title like ''%manu%'' OR lr.Description like ''%manu%''  '

--set @Filter = ' where ((lr.Title like ''%Energy%'' OR [Description] like ''%Energy%'' OR lrp.Value like ''%Energy%'') OR (lr.Title like ''%Finance%'' OR [Description] like ''%Finance%'' OR lrp.Value like ''%Finance%''))  '

--set @Filter = ' where ((lr.Title like ''%Energy%'' OR [Description] like ''%Energy%'' OR lrp.Value like ''%Energy%'') OR (lr.Title like ''%Finance%'' OR [Description] like ''%Finance%'' OR lrp.Value like ''%Finance%''))  '

--set @Filter = @Filter + ' AND (edList.Level in (''secondary'')) '


set @Filter = ' where  ( (lr.Title like ''%Finance%'' OR lr.[Description] like ''%Finance%'' OR lrs.SubjectCsv like ''%Finance%'') OR (lr.Title like ''%Manufacturing%'' OR lr.[Description] like ''%Manufacturing%'' OR lrs.SubjectCsv like ''%Manufacturing%'')   ) '

 AND (edList.PathwaysEducationLevelId in (3,4,5,6))

AND (edList.PathwaysEducationLevelId in (''4'',''5'',''6'') ) 

lr.Title like ''%www.oercommons%'' OR lr.[Description] like ''%www.oercommons%'' OR lr.[Publisher] like ''%www.oercommons%'' OR lr.[ResourceUrl] like ''%www.oercommons%'' OR lrp.Value like ''%www.oercommons%'') 

set @Filter = ' where  ( lr.MegaSearchField like ''%194.95.207.89%'' 
OR lr.[MegaSearchField] like ''%image%'' ) ' 
set @Filter = ' where  ( (lr.Title like ''%Finance%''
OR lrs.SubjectsIdx like ''%Finance%'' OR lrkey.KeywordsIdx like ''%Finance%'') 
OR (lr.Title like ''%Manufacturing%'' 
OR lrs.SubjectsIdx like ''%Manufacturing%''  OR lrkey.KeywordsIdx like ''%Manufacturing%'')   ) '
-- or lrkey.OriginalValue like ''%Manufacturing%'')  

set @Filter = ' Where (edList.PathwaysEducationLevelId in (3,4,5,6)) ' 
set @Filter = @Filter + ' AND (rcl.ClusterId = 1 ) ' 
set @Filter = @Filter + ' AND (lr.Creator = ''serc.carleton.edu'' ) ' 
--set @Filter = @Filter + ' AND (lrs.SubjectCsv like ''%Habitats%'' ) ' 
--set @Filter = @Filter + ' AND (rcl.ClusterId in (1,2,6,8,11,13,16) ) ' 


--set @Filter = @Filter + ' OR FREETEXT(lrs.SubjectCsv, ''physic'') '
set @Filter = @Filter + ' OR lrs.SubjectsIdx like ''%physic%'' '

set @Filter = ' where  (lr.Title like ''a %'' OR lr.[Description] like ''a %'' OR lr.[ResourceUrl] like ''a %'' OR lrs.Subject like ''a %'' OR lr.Keywords like ''a %'') '
-- OR lr.[Description] like ''%Finance%'' OR lr.[Description] like ''%Manufacturing%'' 
 

--=====================================================
DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @totalRows int, @OutputRelTables bit
--
set @SortOrder = ''

-- blind search 
set @Filter = ''
set @Filter = ' Where (edList.PathwaysEducationLevelId in (3,4,5,6)) ' 
set @Filter = ' Where (rcl.ClusterId > 1 ) ' 

set @Filter = ' where (lr.Title like ''%agriculture%''  
              OR lr.ResourceUrl like ''%uri_hu%''   
              OR lr.Subjects like ''%agriculture%''   
              OR lr.Description like ''%agriculture%'') And lrl.LanguageId = 1 '
              
set @Filter = ''              
set @OutputRelTables = 0
set @StartPageIndex = 1
set @PageSize = 55

EXECUTE @RC = Resource_Search
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @OutputRelTables  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/

/* =============================================
      Description:      Resource search
  Uses custom paging to only return enough rows for one page
     Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @totalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
12-06-11 mparsons - new
12-09-05 mparsons - convert to use Resource.Version_Summary
12-10-02 mparsons - tuning
12-10-12 mparsons - add code to minimize impact of blind searches. Use TOP 1000 if no custom filter
12-10-23 jgrimmer - Modified to use new SortTitle field instead of Title field as the default sort field.
=============================================

*/

CREATE PROCEDURE [dbo].[Resource_Search]
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@OutputRelTables bit
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@minRows         int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@TopClause       varchar(100)
      ,@DefaultFilter   varchar(1000)
      ,@OrderBy         varchar(100)
      ,@UsingCodeTableValues bit

-- =================================

Set @UsingCodeTableValues = 0
Set @debugLevel = 4
Set @TopClause= ''
--actually the following is implied in the view (and IsPathwayLevel)
Set @DefaultFilter= ' Where (edList.PathwaysEducationLevelId in (3,4,5,6)) ' 
if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by lr.SortTitle '

--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1
SET @minRows =  @StartPageIndex + @PageSize


if len(isnull(@Filter,'')) = 0 begin
   --Set @TopClause= ' TOP 25000 '
   --MP - actually, just use code table directly!!
   --Set @OutputRelTables = 0 
   Set @UsingCodeTableValues = 1
   end
else if @minRows < 1000   begin 
  set @TopClause= ' TOP 25000 '   
  end   
  
-- =================================
CREATE TABLE #tempWorkTable(
      RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
      ResourceId        [uniqueidentifier],
      ResourceVersionId [uniqueidentifier],
      Title             varchar(200)
)

-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
-- Left JOIN dbo.[Resource.Property] lrp ON lr.ResourceId = lrp.ResourceId 
--Left JOIN [Resource.EducationLevelsSummary] edList ON lr.ResourceId = edList.ResourceId 
 
  set @SQL = 'SELECT distinct ' + @TopClause + ' lr.ResourceId, lr.ResourceVersionId, lr.SortTitle  
        FROM [dbo].[Resource.Version_Summary] lr
        Left JOIN [Resource.Cluster] rcl ON lr.ResourceId = rcl.ResourceId 
        Left JOIN dbo.[Resource.Subject] lrs ON lr.ResourceId = lrs.ResourceId 
        Left JOIN dbo.[Resource.Language] lrl ON lr.ResourceId = lrl.ResourceId 
        Left JOIN dbo.[Resource.Keyword] lrkey ON lr.ResourceId = lrkey.ResourceId 
        Left JOIN dbo.[Resource.ResourceType] rrt ON lr.ResourceId = rrt.ResourceId 
        Left JOIN [Resource.EducationLevel] edList ON lr.ResourceId = edList.ResourceId  '
        + @Filter

  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (ResourceId, ResourceVersionId, Title)
  exec (@SQL)
  --print 'rows: ' + convert(varchar, @@ROWCOUNT)
  SELECT @totalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@totalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Get the total rows - skipping a expensive
--SELECT @totalRows = COUNT(RowNumber) FROM #tempWorkTable
--print 'rows = ' + str(@totalRows)


-- Calculate the range
--===================================================
--SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
--IF @StartPageIndex < 1        SET @StartPageIndex = 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- =================================
--SELECT Distinct TOP (@PageSize)
SELECT Distinct    
    RowNumber,
    lr.ResourceId,
    lr.ResourceVersionId As RowId,
    lr.ResourceVersionId,
    lr.ResourceUrl,
    --DocId,
    CASE
      WHEN lr.Title IS NULL THEN 'No Title'
      WHEN len(lr.Title) = 0 THEN 'No Title'
      ELSE lr.Title
    END AS Title,
    lr.SortTitle,
    [Description],
    isnull(Publisher,'Unknown') As Publisher,
    rtrim(ltrim(isnull(Creator,''))) As Creator,

    --Subjects,
    --replace(isnull(lr.Subjects, ''), '","', ', ') As Subjects,
    replace(isnull(rsub.Subjects, ''), '","', ', ') As Subjects,
    --replace(isnull(rsub.SubjectCsv, ''), '","', ', ') As Subjects,
    edList.EducationLevels,    
   --'' As EducationLevels,
    Rights,
    AccessRights
   -- ,Modified
		,isnull(audienceList.AudienceList,'') As AudienceList
		
From #tempWorkTable
    Inner join [dbo].[Resource.Version_Summary] lr on #tempWorkTable.ResourceId = lr.ResourceId
    Inner Join [dbo].[Resource.SubjectsCsvList] rsub on lr.ResourceId = rsub.ResourceId
    --Left JOIN dbo.[Resource.SubjectCsv] rsub ON lr.ResourceId = rsub.ResourceId 
    Left Join [dbo].[Resource.EducationLevelsList] edList on lr.ResourceId = edList.ResourceId
    Left Join [dbo].[Resource.IntendedAudienceList] audienceList on lr.ResourceId = audienceList.ResourceId

WHERE RowNumber > @first_id
order by RowNumber 

if @OutputRelTables = 1 begin
	--==============================================================================================
	if @UsingCodeTableValues = 0 begin
	  CREATE TABLE #edWorkTable(
		    PathwaysEducationLevelId int,
		    RecordCount	int
	  )
	  --			
	  INSERT INTO #edWorkTable (PathwaysEducationLevelId,RecordCount)
	  SELECT rel.PathwaysEducationLevelId, Count(*) As RecordCount 
	  FROM #tempWorkTable work
	  Inner JOIN [Resource.EducationLevelsSummary] rel ON work.ResourceId = rel.ResourceId 
	  group by rel.PathwaysEducationLevelId
	  --			
	  SELECT rel.PathwaysEducationLevelId As Id, codes.Title, 
	  codes.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
	  RecordCount 
	  FROM #edWorkTable rel
	  INNER JOIN dbo.[Codes.PathwaysEducationLevel] codes ON rel.PathwaysEducationLevelId = codes.Id
	  where codes.IsPathwaysLevel= 1
	  order by codes.SortOrder, codes.Title
	  end
	else begin
  	SELECT codes.[Id]
      ,codes.[Title]
	    ,codes.Title + '  (' + convert(varchar,isnull(WarehouseTotal,0)) + ')' As FormattedTitle  
	   ,WarehouseTotal  
    FROM [dbo].[Codes.PathwaysEducationLevel] codes
    where codes.IsPathwaysLevel= 1 AND isnull(WarehouseTotal,0) > 0
    order by SortOrder, codes.Title
	  end
	--			
	--=====================================
	if @UsingCodeTableValues = 0 begin
	  CREATE TABLE #rtWorkTable(
		    ResourceTypeId int,
		    RecordCount	int
	  )	
	  INSERT INTO #rtWorkTable (ResourceTypeId,RecordCount)
	  SELECT rel.ResourceTypeId, Count(*) As RecordCount 
	  FROM #tempWorkTable work
	  Inner JOIN [Resource.ResourceType] rel ON work.ResourceId = rel.ResourceId 
	  group by rel.ResourceTypeId
	  --			
	  SELECT rrt.ResourceTypeId As Id, 
	  crt.Title, 
	  crt.Title + '  (' + convert(varchar,RecordCount) + ')' As FormattedTitle,   
	  RecordCount 
	  FROM #rtWorkTable rrt
	  Inner Join dbo.[Codes.ResourceType] crt on rrt.ResourceTypeId = crt.Id
	  order by crt.SortOrder, crt.Title
	  end
	else begin
  	SELECT [Id]
      ,[Title]
	    ,Title + '  (' + convert(varchar,isnull(WarehouseTotal,0)) + ')' As FormattedTitle  
	   ,WarehouseTotal  
    FROM [dbo].[Codes.ResourceType]
    where isnull(WarehouseTotal,0) > 0
    order by SortOrder, Title
	  end
  	
	end
GO
/****** Object:  StoredProcedure [dbo].[Resource.VersionGet]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 08/30/2012
-- Description:	Get Resource info from ResourceVersion (and other tables/views)
-- =============================================
CREATE PROCEDURE [dbo].[Resource.VersionGet]
	@RowId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT vers.RowId,
		base.ResourceUrl,
		base.ViewCount,
		base.FavoriteCount,
		vers.DocId,
		vers.Title,
		vers.[Description],
		ISNULL(vers.Publisher,'Unknown') AS Publisher,
		ISNULL(vers.Creator,'Unknown') AS Creator,
		ISNULL(vers.Rights,'Unknown') AS Rights,
		ISNULL(vers.AccessRights,'Unknown') AS AccessRights,
		vers.Modified,
		vers.Submitter,
		ISNULL(vers.Imported, vers.Modified) AS Imported,
		vers.Created,
		ISNULL(vers.TypicalLearningTime, 'Unknown') AS TypicalLearningTime,
		vers.IsSkeletonFromParadata,
		ISNULL(rsub.Subjects, '') AS Subjects,
		ISNULL(edList.EducationLevels,'') AS EducationLevels,
		'TBD' AS Keywords,
		ISNULL(langList.LanguageList,'') AS LanguageList,
		ISNULL(typesList.ResourceTypesList,'') AS ResourceTypesList
	FROM [Resource.Version] vers
	INNER JOIN [Resource] base ON vers.ResourceId = base.RowId
	LEFT JOIN [dbo].[Resource.SubjectsCsvList] rsub on base.RowId = rsub.ResourceId
	LEFT JOIN [dbo].[Resource.EducationLevelsList] edList on base.RowId = edList.ResourceId
	LEFT JOIN [dbo].[Resource.LanguagesList] langList on base.RowId = edList.ResourceId
	LEFT JOIN [dbo].[Resource.ResourceTypesList] typesList on base.RowId = typesList.ResourceId
	WHERE vers.RowId = @RowId
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.Version_Display]    Script Date: 12/14/2012 10:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select top 10 * from [Resource.Version]

exec [Resource.Version_Display] '063438CA-9FF4-42B9-A511-000028286F04'

[Resource.Version_Display]  '261F947B-25D4-4976-9A0C-00007994619C'

*/


/* ============================================================
-- Description:	Get a resource version for display
-- 12-09-02 mparsons - added 
-- 12-10-10 mparsons - changed to use Resource.Subject, added Keywords
-- ============================================================
*/
CREATE PROCEDURE [dbo].[Resource.Version_Display]
	@RowId varchar(36)
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT distinct
		base.RowId, 
		base.ResourceId,
		res.ResourceUrl, 
		--res.Source, --TBD
		base.DocId,
		base.Title, 
		base.[Description], 
		isnull(base.Publisher, 'Unknown') As Publisher,
		isnull(base.Creator, 'Unknown') As Creator,
		isnull(base.Rights, 'Unknown') As Rights,
		isnull(base.AccessRights, 'Unknown') As AccessRights,
		isnull(base.TypicalLearningTime, '') As TypicalLearningTime,
		base.Modified, 
		base.Submitter, 
		
		isnull(base.Imported, base.Modified) As Imported
		
		--,isnull(rsub.Subjects, '') As Subjects
		,replace(isnull(rsub.SubjectCsv, ''), '","', ', ') As Subjects
		,replace(isnull(rkwd.OriginalValue, ''), '","', ', ') As Keywords
		
		,isnull(edList.EducationLevels,'') As EducationLevels
		,'TBD' As Keywords
		,isnull(langList.LanguageList,'') As LanguageList
		,isnull(typesList.ResourceTypesList,'') As ResourceTypesList
		,isnull(audienceList.AudienceList,'') As AudienceList
			
	FROM [Resource.Version] base		
	inner join [Resource] res on base.ResourceId = res.RowId
	Left Join [dbo].[Resource.SubjectCsv] rsub on res.RowId = rsub.ResourceId
	--Left Join [dbo].[Resource.SubjectsCsvList] rsub on res.RowId = rsub.ResourceId
	
	Left Join [dbo].[Resource.KeywordCsv] rkwd on res.RowId = rkwd.ResourceId
	--Left Join [dbo].[Resource.Keyword] rkwd on res.RowId = rkwd.ResourceId
    Left Join [dbo].[Resource.EducationLevelsList] edList on res.RowId = edList.ResourceId
    Left Join [dbo].[Resource.LanguagesList] langList on res.RowId = langList.ResourceId
    Left Join [dbo].[Resource.IntendedAudienceList] audienceList on res.RowId = audienceList.ResourceId
    Left Join [dbo].[Resource.ResourceTypesList] typesList on res.RowId = typesList.ResourceId
        
	WHERE (base.RowId = @RowId)
	
END
GO
/****** Object:  StoredProcedure [dbo].[Resource.Language_ImportResProperty]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select [MappingType], LRValue from [dbo].[Audit.Language_Orphan]



EXECUTE [dbo].[Resource.Language_ImportResProperty] 1000


*/

CREATE PROCEDURE [dbo].[Resource.Language_ImportResProperty]
            @MaxRecords int
As
begin 
          
Declare @ResourceId uniqueidentifier
,@Value varchar(200)
,@cntr int
,@totalRows int
set @cntr= 0
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
    select base.ResourceId, base.Value
      FROM [dbo].[Resource.Property] base
      left join [Map.Language] map            on base.Value = map.LRValue
      --left join [dbo].[Codes.Language] codes  on map.LanguageId = codes.Id
      left join [dbo].[Resource.Language] red on base.ResourceId = red.ResourceId and red.[LanguageId] = map.LanguageId
    where base.[PropertyTypeId]= 4
     and red.ResourceId is  null
 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @ResourceId, @Value
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.Language_Import] 
        @ResourceId,
        -1, @Value, @totalRows OUTPUT
		
		FETCH NEXT FROM thisCursor INTO @ResourceId, @Value
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.Language_ImportFromMappingOrphan]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
UPDATE [dbo].[Audit.Language_Orphan]
   SET[FoundMapping] = 0
      ,[IsActive] = 1
      
      
      
select [MappingType], OriginalValue from [dbo].[Audit.Language_Orphan]



EXECUTE [dbo].[Resource.Language_ImportFromMappingOrphan] 3


*/
/*
Attempt to import Resource.Language from the Audit.Language_Orphan table
this would be run on demand after attempted cleanups of the mapping
We also need a process to permanently ignore some mappings
*/
Create PROCEDURE [dbo].[Resource.Language_ImportFromMappingOrphan]
            @MaxRecords int

As
begin 
          
Declare @ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@Value varchar(200)
,@MappedCodeId int
,@cntr int
,@existsCntr int
,@totalRows int

set @cntr = 0
set @existsCntr = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
	SELECT base.RowId, base.[ResourceId], base.[OriginalValue] As Value, isnull(map.LanguageId, 0)

  FROM [dbo].[Audit.Language_Orphan] base
  Inner join [Map.Language] map on base.[OriginalValue] = map.LRValue
  Inner join [dbo].[Codes.Language] codes on map.[LanguageId] = codes.Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  --?? if not tried before, but don't want to all. actually ok, as we are doing a join
  -- still we want to be able to ignore stuff that won't be mapped
  -- maybe if the create date and last run date are X days apart, set the ignore flag

 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value, @MappedCodeId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  if @MaxRecords > 0 AND @cntr < 25  
	    print ' ==> ' +@Value

	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.Language_Import] 
        @ResourceId, @MappedCodeId,
        @Value, @totalRows OUTPUT
        
		--if map was successful, either delete or at least mark
		if @totalRows > 0 begin
		  print 'appeared to be mapped, now mark/delete'
		  UPDATE [dbo].[Map.Language_Orphan]
        SET [LastRerunDate] = getdate()
        ,[FoundMapping] = 1
      WHERE [RowId] = @RowId
		  end
		else begin
		-- check if a entry already exists for the value (ie current results in a duplicate)
		
		  select @existsCntr = isnull(count(*),0)
        FROM [Map.Language] map 
        inner join [dbo].[Codes.Language] codes on map.[LanguageId] = codes.Id
        inner join [dbo].[Resource.Language] red 
              on @ResourceId = red.ResourceId 
              and red.[LanguageId] = codes.id
         where map.LRValue  = @Value
         group by red.ResourceId
         
    	if @existsCntr > 0 begin
		    print 'the ed level already exists, mark it'
		    UPDATE [dbo].[Audit.Language_Orphan]
          SET [LastRerunDate] = getdate()
          ,[FoundMapping] = 1
        WHERE [RowId] = @RowId
		    end
		  else begin	
	      print 'not mapped, update rundate????'
	      UPDATE [dbo].[Audit.Language_Orphan]
          SET [LastRerunDate] = getdate()
        WHERE [RowId] = @RowId
	      end
  		end
		
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value, @MappedCodeId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.Format_ImportFromMappingOrphan]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
UPDATE [dbo].[Audit.ResourceFormat_Orphan]
   SET[FoundMapping] = 0
      ,[IsActive] = 1
      
      
      
select [MappingType], OriginalValue from [dbo].[Audit.ResourceFormat_Orphan]



EXECUTE [dbo].[Resource.Format_ImportFromMappingOrphan] 3


*/
/*
Attempt to import Resource.Format from the Audit.ResourceFormat_Orphan table
this would be run on demand after attempted cleanups of the mapping
We also need a process to permanently ignore some mappings
*/
Create PROCEDURE [dbo].[Resource.Format_ImportFromMappingOrphan]
            @MaxRecords int

As
begin 
          
Declare @ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@Value varchar(200)
,@MappedCodeId int
,@cntr int
,@existsCntr int
,@totalRows int

set @cntr = 0
set @existsCntr = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
	SELECT base.RowId, base.[ResourceId], base.[OriginalValue] As Value, isnull(map.CodeId, 0)

  FROM [dbo].[Audit.ResourceFormat_Orphan] base
  Inner join [Map.ResourceFormat] map on base.[OriginalValue] = map.LRValue
  Inner join [dbo].[Codes.ResourceFormat] codes on map.CodeId = codes.Id
  where 
      (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  --?? if not tried before, but don't want to do all. actually ok, as we are doing a join
  -- still we want to be able to ignore stuff that won't be mapped
  -- maybe if the create date and last run date are X days apart, set the ignore flag

 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value, @MappedCodeId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  if @MaxRecords > 0 AND @cntr < 25  
	    print ' ==> ' +@Value

	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.Format_Import] 
        @ResourceId, @MappedCodeId,
        @Value, @totalRows OUTPUT
        
		--if map was successful, either delete or at least mark
		if @totalRows > 0 begin
		  print 'appeared to be mapped, now mark/delete'
		  UPDATE [dbo].[Audit.ResourceFormat_Orphan]
        SET [LastRerunDate] = getdate()
        ,[FoundMapping] = 1
      WHERE [RowId] = @RowId
		  end
		else begin
		-- check if a entry already exists for the value (ie current results in a duplicate)
		
		  select @existsCntr = isnull(count(*),0)
        FROM [Map.ResourceFormat] map 
        inner join [dbo].[Codes.ResourceFormat] codes on map.[CodeId] = codes.Id
        inner join [dbo].[Resource.Format] red 
              on @ResourceId = red.ResourceId 
              and red.[CodeId] = codes.id
         where map.LRValue  = @Value
         group by red.ResourceId
         
    	if @existsCntr > 0 begin
		    print 'the ed level already exists, mark it'
		    UPDATE [dbo].[Audit.ResourceFormat_Orphan]
          SET [LastRerunDate] = getdate()
          ,[FoundMapping] = 1
        WHERE [RowId] = @RowId
		    end
		  else begin	
	      print 'not mapped, update rundate????'
	      UPDATE [dbo].[Audit.ResourceFormat_Orphan]
          SET [LastRerunDate] = getdate()
        WHERE [RowId] = @RowId
	      end
  		end
		
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value, @MappedCodeId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevelInsert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

-- ====================================================================
DECLARE @RC int, @ResourceId uniqueidentifier,@PathwaysEducationLevelId int
DECLARE @OriginalValue varchar(500)

set @ResourceId = '987b71d5-9ba8-4703-b885-a80564ed30f1'
set @PathwaysEducationLevelId = 6
set @OriginalValue = ''

EXECUTE @RC = [dbo].[Resource.EducationLevelInsert] 
   @ResourceId
  ,@PathwaysEducationLevelId
  ,@OriginalValue



*/
/*
modifications
12-11-05 mparsons - need to remove unknown grade level when inserting actual gl
*/
CREATE PROCEDURE [dbo].[Resource.EducationLevelInsert]
            @ResourceId     varchar(40),
            @PathwaysEducationLevelId int,
            @OriginalValue varchar(100)
           

As
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  If @PathwaysEducationLevelId = 0		    SET @PathwaysEducationLevelId = NULL 
  If @OriginalValue = ''  SET @OriginalValue = NULL 

	DECLARE @NewId uniqueidentifier
	,  @RecordCount int
	,  @totalRows int
	,  @DoUnknownCheck bit
	
	SET @NewId = NEWID()
	Set @DoUnknownCheck= 1

  If @OriginalValue is NULL and @PathwaysEducationLevelId is null begin
    print 'no values provided'
    return -1
    end    
  
  if @PathwaysEducationLevelId is null begin
	  print 'insert via OriginalValue - using import proc'  
  		
	    -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.EducationLevel_Import] 
        @ResourceId,
        @OriginalValue, '', @totalRows OUTPUT
        
    SELECT '' AS RowId
	  end
  else begin

    --should ensure doesn't already exist
    select @RecordCount = isnull(Count(*),0)
    FROM [dbo].[Resource.EducationLevel] rel 
    where rel.ResourceId  = @ResourceId AND rel.PathwaysEducationLevelId = @PathwaysEducationLevelId 	
    If @RecordCount is null OR @RecordCount = 0	begin	
    	  print 'insert via @PathwaysEducationLevelId'
      INSERT INTO [Resource.EducationLevel]
      (
	      RowId,
	      ResourceId, 
	      PathwaysEducationLevelId,
	      OriginalLevel
      )
	    Values (
		    @NewId,
		    @ResourceId, 
		    @PathwaysEducationLevelId, 
		    @OriginalValue
	    )
	    SELECT @NewId AS RowId
	    
	    if @DoUnknownCheck = 1 begin
	      select @RecordCount = isnull(Count(*),0)
        FROM [dbo].[Resource.EducationLevel] rel 
        where rel.ResourceId  = @ResourceId 
        
        if @RecordCount > 1 begin
          --delete unknown
          print 'Deleting UNKNOWN entry'
          DELETE FROM [dbo].[Resource.EducationLevel]
          where ResourceId  = @ResourceId AND PathwaysEducationLevelId = 7 	
          end
	      end
	      
	    end
    else begin
    	  print 'Duplicate PathwaysEducationLevelId'
      SELECT '' AS RowId
      end
    END
End
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_Insert]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 7/3/2012
-- Description:	Insert row into [Resource.EducationLevel] table
-- =============================================
CREATE PROCEDURE [dbo].[Resource.EducationLevel_Insert]
	@ResourceId uniqueidentifier, 
            @PathwaysEducationLevelId int,
            @OriginalValue varchar(100)
           

As
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  If @PathwaysEducationLevelId = 0		    SET @PathwaysEducationLevelId = NULL 
  If @OriginalValue = ''  SET @OriginalValue = NULL 

	DECLARE @NewId uniqueidentifier
	,  @RecordCount int
	,  @totalRows int
	,  @DoUnknownCheck bit
	
	SET @NewId = NEWID()
	Set @DoUnknownCheck= 1

  If @OriginalValue is NULL and @PathwaysEducationLevelId is null begin
    print 'no values provided'
    return -1
    end    
  
  if @PathwaysEducationLevelId is null begin
	  print 'insert via OriginalValue - using import proc'  
  		
	    -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.EducationLevel_Import] 
        @ResourceId,
        @OriginalValue, '', @totalRows OUTPUT
        
    SELECT '' AS RowId
	  end
  else begin
	  print 'insert via @PathwaysEducationLevelId'
    --should ensure doesn't already exist
    select @RecordCount = isnull(Count(*),0)
    FROM [dbo].[Resource.EducationLevel] rel 
    where rel.ResourceId  = @ResourceId AND rel.PathwaysEducationLevelId = @PathwaysEducationLevelId 	
    If @RecordCount is null OR @RecordCount = 0	begin	
      INSERT INTO [Resource.EducationLevel]
      (
	      RowId,
	      ResourceId, 
	      PathwaysEducationLevelId,
	      OriginalLevel
      )
	    Values (
		    @NewId,
		    @ResourceId, 
		    @PathwaysEducationLevelId, 
		    @OriginalValue
	    )
	    SELECT @NewId AS RowId
	    
	    if @DoUnknownCheck = 1 begin
	      select @RecordCount = isnull(Count(*),0)
        FROM [dbo].[Resource.EducationLevel] rel 
        where rel.ResourceId  = @ResourceId 
        
        if @RecordCount > 1 begin
          --delete unknown
          DELETE FROM [dbo].[Resource.EducationLevel]
          where ResourceId  = @ResourceId AND PathwaysEducationLevelId = 7 	
          end
	      end
	      
	    end
    else begin
      SELECT '' AS RowId
      end
    END
End
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_ImportResProperty]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select [MappingType], OriginalValue from [dbo].[Audit.EducationLevel_Orphan]



EXECUTE [dbo].[Resource.EducationLevel_ImportResProperty] 1


*/

CREATE PROCEDURE [dbo].[Resource.EducationLevel_ImportResProperty]
            @MaxRecords int

As
begin 
          
Declare @ResourceId uniqueidentifier
,@Value varchar(200)
,@cntr int
,@totalRows int
set @cntr= 0
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
    select base.ResourceId, base.Value
      FROM [dbo].[Resource.Property] base
      left join [Map.EducationLevel] map on base.Value = map.OriginalValue
      left join [dbo].[Codes.PathwaysEducationLevel] codes on map.MappedValue = codes.[Title]
      left join [dbo].[Resource.EducationLevel] red on base.ResourceId = red.ResourceId and red.[PathwaysEducationLevelId] = codes.id
    where base.[PropertyTypeId]= 2
     and red.ResourceId is  null
 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @ResourceId, @Value
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.EducationLevel_Import] 
        @ResourceId,
        @Value, '', @totalRows OUTPUT
		
		FETCH NEXT FROM thisCursor INTO @ResourceId, @Value
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.EducationLevel_ImportFromMappingOrphan]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
UPDATE [dbo].[Mapping.Orphan]
   SET[FoundMapping] = 0
      ,[IsActive] = 1
      
      
      
select [MappingType], OriginalValue from [dbo].[Mapping.Orphan]



EXECUTE [dbo].[Resource.EducationLevel_ImportFromMappingOrphan] 0


*/
/*
Attempt to import Resource.EducationLevel from the Mapping.Orphan table
this would be run on demand after attempted cleanups of the mapping
We also need a process to permanently ignore some mappings
*/
create PROCEDURE [dbo].[Resource.EducationLevel_ImportFromMappingOrphan]
            @MaxRecords int

As
begin 
          
Declare @ResourceId uniqueidentifier
,@RowId uniqueidentifier
,@Value varchar(200)
,@cntr int
,@existsCntr int
,@totalRows int

set @cntr = 0
set @existsCntr = 0

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
	SELECT base.RowId, base.[ResourceId], base.[OriginalValue] As Value

  FROM [dbo].[Mapping.Orphan] base
  Inner join [Map.EducationLevel] map on base.[OriginalValue] = map.OriginalValue
  Inner join [dbo].[Codes.PathwaysEducationLevel] codes on map.MappedValue = codes.[Title]
  --left join [dbo].[Resource.EducationLevel] red on base.ResourceId = red.ResourceId and red.[PathwaysEducationLevelId] = codes.id
  where [MappingType]= 'Map.EducationLevel'
  --and red.ResourceId is  null
  And (base.IsActive is null OR base.IsActive = 1)
  And (base.[FoundMapping] is null OR base.[FoundMapping] = 0)
  --?? if not tried before, but don't want to all. actually ok, as we are doing a join
  -- still we want to be able to ignore stuff that won't be mapped
  -- maybe if the create date and last run date are X days apart, set the ignore flag

 
	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
	  if @MaxRecords > 0 AND @cntr < 25  
	    print ' ==> ' +@Value

	  -- not sure what to use for schema here
    EXECUTE [dbo].[Resource.EducationLevel_Import] 
        @ResourceId,
        @Value, '', @totalRows OUTPUT
        
		--if map was successful, either delete or at least mark
		if @totalRows > 0 begin
		  print 'appeared to be mapped, now mark/delete'
		  UPDATE [dbo].[Mapping.Orphan]
        SET [LastRerunDate] = getdate()
        ,[FoundMapping] = 1
      WHERE [RowId] = @RowId
		  end
		else begin
		-- check if a entry already exists for the value (ie current results in a duplicate)
		
		  select @existsCntr = isnull(count(*),0)
        FROM [Map.EducationLevel] map 
        inner join [dbo].[Codes.PathwaysEducationLevel] codes on map.MappedValue = codes.[Title]
        inner join [dbo].[Resource.EducationLevel] red 
              on @ResourceId = red.ResourceId 
              and red.[PathwaysEducationLevelId] = codes.id
         where map.OriginalValue  = @Value
         group by red.ResourceId
         
    	if @existsCntr > 0 begin
		    print 'the ed level already exists, mark it'
		    UPDATE [dbo].[Mapping.Orphan]
          SET [LastRerunDate] = getdate()
          ,[FoundMapping] = 1
        WHERE [RowId] = @RowId
		    end
		  else begin	
	      print 'not mapped, update rundate????'
	      UPDATE [dbo].[Mapping.Orphan]
          SET [LastRerunDate] = getdate()
        WHERE [RowId] = @RowId
	      end
  		end
		
		FETCH NEXT FROM thisCursor INTO @RowId, @ResourceId, @Value
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.Cluster_PopulateFromMapping]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select count(*) from [Resource]
go

SELECT top 1000
 base.[ResourceId]
      ,[ClusterId]
      ,[ResourceUrl]
      ,[Title]
      ,[Description]
      ,[Keywords]
      ,[Subjects]
  FROM [Resource.Version_Summary] base
  Left join [dbo].[Resource.Cluster] rclu 
          on base.ResourceId = rclu.ResourceId And rclu.[ClusterId] = 91
where rclu.[ClusterId] is not null
  
  
GO

UPDATE [dbo].[Map.CareerCluster]
   SET [IsActive] = 0
 WHERE Id < 72
GO




EXECUTE [dbo].[Resource.Cluster_PopulateFromMapping] 0, 91
go
EXECUTE [dbo].[Resource.Cluster_PopulateFromMapping] 0, 1

*/

/*
Map clusters 

Notes
- should join to resource version to only target resources already in the pathway
- add a date or means to only target recent additions rather than the whole database
*/
Create PROCEDURE [dbo].[Resource.Cluster_PopulateFromMapping]
            @MaxRecords int
            ,@clusterId int

As
begin 
          
Declare 
@MapId int
,@MappedClusterId int
,@FilterValue varchar(200)
,@Filter varchar(200)
,@cntr int
--,@clusterId int
,@interval int
,@debugLevel int
,@affectedCount int
,@totalCount int
set @interval= 25
set @cntr= 0
--set @clusterId = 91
set @debugLevel= 10
set @affectedCount= 0
set @totalCount= 0

-- ===============================================
select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT  FilterValue, MappedClusterId, Id
      FROM   [Map.CareerCluster]
      where IsActive= 1 
      AND (MappedClusterId = @clusterId or @clusterId = 0)

	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @FilterValue, @MappedClusterId, @MapId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
		  
    select @cntr As Cntr,convert(varchar, @MappedClusterId) As ClusterId,@FilterValue	As Filter
    print convert(varchar, @cntr) + '. Cluster/Filter: ' + convert(varchar, @MappedClusterId) + ' - ' + @FilterValue		
		set @Filter = '%' + ltrim(rtrim(@FilterValue)) + '%'
		
    -- === via title =======================================================  		
    INSERT INTO [dbo].[Resource.Cluster]
               ([ResourceId]
               ,[ClusterId])
    SELECT distinct lrs.ResourceId,  @MappedClusterId
    FROM dbo.[Resource.Version_Summary] lrs 
    left join [dbo].[Resource.Cluster] rc on lrs.ResourceId = rc.ResourceId AND rc.ClusterId = @MappedClusterId
    where rc.[ClusterId] is null
    And (lrs.Title like @Filter 
       --  OR lrs.[Description] like @Filter
         OR lrs.Subjects like @Filter
         OR lrs.Keywords like @Filter
         )
    set @affectedCount = @@rowcount
    if @affectedCount is not null AND @affectedCount > 0 begin
      set @totalCount= @totalCount + @affectedCount
      print '-> match found for cluster using filter. Count: '  
              + convert(varchar, @affectedCount)  + '. #' 
              + convert(varchar, @MappedClusterId) + ' - ' + @Filter
      --if ((@dupsCntr / @interval) * @interval) = @dupsCntr 
      
      end

    -- todo - once run, could arbitrarily set to false?
    --      - probably only useful for initial runs, as in prod will run regularly against new records
    
    
    -- === via subjects =======================================================    
    --INSERT INTO [dbo].[Resource.Cluster]
    --           ([ResourceId]
    --           ,[ClusterId])
    --SELECT distinct lrs.ResourceId,  @MappedClusterId
    --FROM dbo.[Resource.Subject] lrs 
    --left join [dbo].[Resource.Cluster] rc on lrs.ResourceId = rc.ResourceId AND rc.ClusterId = @MappedClusterId
    --where rc.[ClusterId] is null
    --And lrs.SubjectsIdx like @Filter
    --if @@rowcount > 0 print '&& match found on subjects'
  	 
  	-- === via keywords =======================================================
   -- INSERT INTO [dbo].[Resource.Cluster]
   --            ([ResourceId]
   --            ,[ClusterId])
   -- SELECT distinct lrs.ResourceId,  @MappedClusterId
   -- FROM dbo.[Resource.Keyword] lrs 
   -- left join [dbo].[Resource.Cluster] rc on lrs.ResourceId = rc.ResourceId AND rc.ClusterId = @MappedClusterId
   -- where rc.[ClusterId] is null
   -- And lrs.KeywordsIdx like @Filter
  	--if @@rowcount > 0 print '&& match found on keywords'
  	 
		FETCH NEXT FROM thisCursor INTO @FilterValue, @MappedClusterId, @MapId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  select 'Clusters created: ' + convert(varchar, @totalCount)
  
  
end
GO
/****** Object:  StoredProcedure [dbo].[Resource.Cluster_PopulateEnergy]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
select count(*) from [Resource]
go

SELECT top 1000
 base.[ResourceId]
      ,[ClusterId]
      ,[ResourceUrl]
      ,[Title]
      ,[Description]
      ,[Keywords]
      ,[Subjects]
  FROM [Resource.Version_Summary] base
  Left join [dbo].[Resource.Cluster] rclu 
          on base.ResourceId = rclu.ResourceId And rclu.[ClusterId] = 91
where rclu.[ClusterId] is not null
  
  
GO




EXECUTE [dbo].[Resource.Cluster_PopulateEnergy] 100, 91
go
EXECUTE [dbo].[Resource.Cluster_PopulateEnergy] 100, 1

*/

/*
Map clusters 

Notes
- should join to resource version to only target resources already in the pathway
- add a date or means to only target recent additions rather than the whole database
*/
CREATE PROCEDURE [dbo].[Resource.Cluster_PopulateEnergy]
            @MaxRecords int
            ,@clusterId int

As
begin 
          
Declare 
@MappedClusterId int
,@OriginalValue varchar(200)
,@Filter varchar(200)
,@cntr int
--,@clusterId int
--,@interval int
,@debugLevel int

--set @interval= 25
set @cntr= 0
set @clusterId = 91
set @debugLevel= 10

select 'started',  getdate()
	-- Loop thru and call proc
	DECLARE thisCursor CURSOR FOR
      SELECT  OriginalValue, MappedClusterId
      FROM         [Map.CareerCluster]
      where IsActive= 1 AND (MappedClusterId = @clusterId or @clusterId = 0)

	OPEN thisCursor
	FETCH NEXT FROM thisCursor INTO @OriginalValue, @MappedClusterId
	WHILE @@FETCH_STATUS = 0 BEGIN
	  set @cntr = @cntr+ 1
	  if @MaxRecords > 0 AND @cntr > @MaxRecords begin
		  print '### Early exit based on @MaxRecords = ' + convert(varchar, @MaxRecords)
		  select 'exiting',  getdate()
		  set @cntr = @cntr - 1
		  BREAK
		  End	  
		  
		set @Filter = '%' + ltrim(rtrim(@OriginalValue)) + '%'
		
    -- === via title =======================================================  		
    INSERT INTO [dbo].[Resource.Cluster]
               ([ResourceId]
               ,[ClusterId])
    SELECT distinct lrs.ResourceId,  @MappedClusterId
    FROM dbo.[Resource.Version_Summary] lrs 
    left join [dbo].[Resource.Cluster] rc on lrs.ResourceId = rc.ResourceId AND rc.ClusterId = @MappedClusterId
    where rc.[ClusterId] is null
    And (lrs.Title like @Filter 
         OR lrs.[Description] like @Filter
         OR lrs.Subjects like @Filter
         OR lrs.Keywords like @Filter
         )
    if @@rowcount > 0 print '&& match found on title'

    -- === via subjects =======================================================    
    --INSERT INTO [dbo].[Resource.Cluster]
    --           ([ResourceId]
    --           ,[ClusterId])
    --SELECT distinct lrs.ResourceId,  @MappedClusterId
    --FROM dbo.[Resource.Subject] lrs 
    --left join [dbo].[Resource.Cluster] rc on lrs.ResourceId = rc.ResourceId AND rc.ClusterId = @MappedClusterId
    --where rc.[ClusterId] is null
    --And lrs.SubjectsIdx like @Filter
    --if @@rowcount > 0 print '&& match found on subjects'
  	 
  	-- === via keywords =======================================================
   -- INSERT INTO [dbo].[Resource.Cluster]
   --            ([ResourceId]
   --            ,[ClusterId])
   -- SELECT distinct lrs.ResourceId,  @MappedClusterId
   -- FROM dbo.[Resource.Keyword] lrs 
   -- left join [dbo].[Resource.Cluster] rc on lrs.ResourceId = rc.ResourceId AND rc.ClusterId = @MappedClusterId
   -- where rc.[ClusterId] is null
   -- And lrs.KeywordsIdx like @Filter
  	--if @@rowcount > 0 print '&& match found on keywords'
  	 
		FETCH NEXT FROM thisCursor INTO @OriginalValue, @MappedClusterId
	END
	CLOSE thisCursor
	DEALLOCATE thisCursor
	select 'completed',  getdate()
  select 'processed records: ' + convert(varchar, @cntr)
  
  
end
GO
/****** Object:  StoredProcedure [dbo].[CodeTables_UpdateWarehouseTotals]    Script Date: 12/14/2012 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Exec CodeTables_UpdateWarehouseTotals 10
*/
-- =========================================================================
-- 12/07/30 mparsons - 
-- =========================================================================
CREATE  Procedure [dbo].[CodeTables_UpdateWarehouseTotals]
    @debugLevel int = 0

AS
--declare @debugLevel int
-- ==========================================================
print 'updating Codes.ResourceType ...'
UPDATE [dbo].[Codes.ResourceType]
   SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal      
FROM [dbo].[Codes.ResourceType] codes
Inner join ( 
SELECT [ResourceTypeId] ,count(*) AS wareHouseTotal
  FROM [dbo].[Resource.ResourceType] base
  inner join [Resource.Version_Summary] rvs on base.ResourceId = rvs.ResourceId
    group by [ResourceTypeId]
    ) base on codes.Id = base.[ResourceTypeId]
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0)) 

-- ==========================================================
print 'updating [Codes.ResourceTypeCategory] ...'
UPDATE [dbo].[Codes.ResourceTypeCategory]
   SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.[Category], base.WarehouseTotal      
FROM [dbo].[Codes.ResourceTypeCategory] codes
Inner join ( 
SELECT [CategoryId] ,sum(wareHouseTotal) As wareHouseTotal
  FROM [dbo].[Codes.ResourceType]
    group by [CategoryId]
    ) base on codes.Id = base.[CategoryId]
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0)) 

-- ==========================================================
print 'updating Codes.PathwaysEducationLevel ...'
UPDATE [dbo].[Codes.PathwaysEducationLevel]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.PathwaysEducationLevel] codes
Inner join ( 
SELECT [PathwaysEducationLevelId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.EducationLevel] base
  inner join [Resource.Version_Summary] rvs on base.ResourceId = rvs.ResourceId
  group by [PathwaysEducationLevelId]
    ) base on codes.Id = base.PathwaysEducationLevelId

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
if @debugLevel > 8  begin  
  select * from [dbo].[Codes.PathwaysEducationLevel]
  end
-- ==========================================================
print 'updating Codes.IntendedAudience ...'
UPDATE [dbo].[Codes.AudienceType]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.AudienceType] codes
Inner join ( 
SELECT [AudienceId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.IntendedAudience] base
  inner join [Resource.Version_Summary] rvs on base.ResourceId = rvs.ResourceId
  group by [AudienceId]
    ) base on codes.Id = base.[AudienceId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
-- ==========================================================
print 'updating Codes.Language  ...'
UPDATE [dbo].[Codes.Language]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.Language] codes
Inner join ( 
SELECT [LanguageId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Language] base
  inner join [Resource.Version_Summary] rvs on base.ResourceId = rvs.ResourceId
  group by [LanguageId]
    ) base on codes.Id = base.[LanguageId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
    
-- ==========================================================
print 'updating Codes.ResourceFormat ...'
UPDATE [dbo].[Codes.ResourceFormat]
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.Title, base.WarehouseTotal  
FROM [dbo].[Codes.ResourceFormat] codes
Inner join ( 
SELECT [CodeId],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Format] base
  inner join [Resource.Version_Summary] rvs on base.ResourceId = rvs.ResourceId
  group by [CodeId]
    ) base on codes.Id = base.[CodeId]

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
/*    
SELECT [Value],count(*) AS wareHouseTotal
  FROM [dbo].[Resource.Property]
    where [PropertyTypeId]= 3
      group by [Value]

SELECT [Id]
      ,[Title]
      ,[WarehouseTotal]
  FROM [.[dbo].[Codes.ResourceFormat]
GO


*/
-- ==========================================================
print 'updating CareerClusters ...'
UPDATE [dbo].CareerCluster
SET [WarehouseTotal] = base.WarehouseTotal
-- select codes.IlPathwayName, base.WarehouseTotal  
FROM [dbo].CareerCluster codes
Inner join ( 
SELECT ClusterId,count(*) AS WarehouseTotal
  FROM [dbo].[Resource.Cluster] base
  inner join [Resource.Version_Summary] rvs on base.ResourceId = rvs.ResourceId
  group by ClusterId
    ) base on codes.Id = base.ClusterId

print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))
-- ==========================================================
print 'updating Publishers ...'
-- updates
UPDATE [dbo].[PublisherSummary]
   SET [ResourceTotal] = totals.ResourcesCount
from [dbo].[PublisherSummary] ps
inner join (
 SELECT base.[Publisher], count(*) As ResourcesCount
  FROM [dbo].[Resource.Version_Summary] base
  inner join [dbo].[PublisherSummary] existing on base.[Publisher] = existing.[Publisher]
  group by base.[Publisher]
 -- Order by 2 desc
  ) totals on ps.Publisher = totals.Publisher
print 'Updated = ' + convert(varchar, isnull(@@rowcount,0))


-- inserts
INSERT INTO [dbo].[PublisherSummary]
           ([Publisher],[IsActive],[ResourceTotal])
SELECT base.[Publisher], 1,count(*) As Resources
  FROM [dbo].[Resource.Version_Summary] base
  left join [dbo].[PublisherSummary] existing on base.[Publisher] = existing.[Publisher]
  where existing.[Publisher] is null
  group by base.[Publisher]
  order by 3 desc
  
print 'Insert = ' + convert(varchar, isnull(@@rowcount,0))  

--handle delete of publishers, or mark of inactive  
/*
UPDATE [dbo].[PublisherSummary]
   SET IsActive = 0
--    select count(*)
from [dbo].[PublisherSummary] ps
inner join (
 SELECT distinct rv.[Publisher], lr.IsActive
 --, lr.ResourceUrl
  FROM [dbo].[Resource.Version] rv  
  Inner JOIN dbo.[Resource] lr ON lr.RowId = rv.ResourceId
  inner join [dbo].[PublisherSummary] existing on rv.[Publisher] = existing.[Publisher]
  Where existing.IsActive = 1 AND lr.IsActive = 0

  ) totals on ps.Publisher = totals.Publisher
  
  
Inner join [dbo].[Resource.Version] rv  ON ps.Publisher = rv.Publisher
Inner JOIN dbo.[Resource] lr ON lr.RowId = rv.ResourceId
Where ps.IsActive = 1 AND lr.IsActive = 0
*/
-- ==========================================================
GO
/****** Object:  Default [DF_ApplicationLog_CreatedDate]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[ApplicationLog] ADD  CONSTRAINT [DF_ApplicationLog_CreatedDate]  DEFAULT (getdate()) FOR [CreatedDate]
GO
/****** Object:  Default [DF_Audit.EducationLevel_Orphan_RowId]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.EducationLevel_Orphan] ADD  CONSTRAINT [DF_Audit.EducationLevel_Orphan_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Audit.EducationLevel_Orphan_FoundMapping]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.EducationLevel_Orphan] ADD  CONSTRAINT [DF_Audit.EducationLevel_Orphan_FoundMapping]  DEFAULT ((0)) FOR [FoundMapping]
GO
/****** Object:  Default [DF_Audit.EducationLevel_Orphan_FoundMapping1]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.EducationLevel_Orphan] ADD  CONSTRAINT [DF_Audit.EducationLevel_Orphan_FoundMapping1]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Audit.EducationLevel_Orphan_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.EducationLevel_Orphan] ADD  CONSTRAINT [DF_Audit.EducationLevel_Orphan_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Audit.Language_Orphan_RowId]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.Language_Orphan] ADD  CONSTRAINT [DF_Audit.Language_Orphan_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Audit.Language_Orphan_FoundMapping]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.Language_Orphan] ADD  CONSTRAINT [DF_Audit.Language_Orphan_FoundMapping]  DEFAULT ((0)) FOR [FoundMapping]
GO
/****** Object:  Default [DF_Audit.Language_Orphan_IsActive]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.Language_Orphan] ADD  CONSTRAINT [DF_Audit.Language_Orphan_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Audit.Language_Orphan_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.Language_Orphan] ADD  CONSTRAINT [DF_Audit.Language_Orphan_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Audit.ResourceFormat_Orphan_RowId]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceFormat_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceFormat_Orphan_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Audit.ResourceFormat_Orphan_FoundMapping]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceFormat_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceFormat_Orphan_FoundMapping]  DEFAULT ((0)) FOR [FoundMapping]
GO
/****** Object:  Default [DF_Audit.ResourceFormat_Orphan_FoundMapping1]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceFormat_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceFormat_Orphan_FoundMapping1]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Audit.ResourceFormat_Orphan_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceFormat_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceFormat_Orphan_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Audit.ResourceType_Orphan_RowId]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceType_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceType_Orphan_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Audit.ResourceType_Orphan_FoundMapping]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceType_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceType_Orphan_FoundMapping]  DEFAULT ((0)) FOR [FoundMapping]
GO
/****** Object:  Default [DF_Audit.ResourceType_Orphan_FoundMapping1]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceType_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceType_Orphan_FoundMapping1]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Audit.ResourceType_Orphan_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Audit.ResourceType_Orphan] ADD  CONSTRAINT [DF_Audit.ResourceType_Orphan_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_CareerCluster_IsHighGrowth]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CareerCluster] ADD  CONSTRAINT [DF_CareerCluster_IsHighGrowth]  DEFAULT ((0)) FOR [IsHighGrowth]
GO
/****** Object:  Default [DF_CareerCluster_IsActive]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CareerCluster] ADD  CONSTRAINT [DF_CareerCluster_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_CareerCluster_IsHighGrowth1]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CareerCluster] ADD  CONSTRAINT [DF_CareerCluster_IsHighGrowth1]  DEFAULT ((0)) FOR [IsIlPathway]
GO
/****** Object:  Default [DF_Codes.AlignmentType_WarehouseTotal]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Codes.AlignmentType] ADD  CONSTRAINT [DF_Codes.AlignmentType_WarehouseTotal]  DEFAULT ((0)) FOR [WarehouseTotal]
GO
/****** Object:  Default [DF_Codes.Language_IsPathwaysLanguage]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Codes.Language] ADD  CONSTRAINT [DF_Codes.Language_IsPathwaysLanguage]  DEFAULT ((0)) FOR [IsPathwaysLanguage]
GO
/****** Object:  Default [DF_Codes.PathwaysEducationLevel_IsPathwaysLevel]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Codes.PathwaysEducationLevel] ADD  CONSTRAINT [DF_Codes.PathwaysEducationLevel_IsPathwaysLevel]  DEFAULT ((1)) FOR [IsPathwaysLevel]
GO
/****** Object:  Default [DF_Codes.PathwaysEducationLevel_SortOrder]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Codes.PathwaysEducationLevel] ADD  CONSTRAINT [DF_Codes.PathwaysEducationLevel_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO
/****** Object:  Default [DF_RatingType_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Codes.RatingType] ADD  CONSTRAINT [DF_RatingType_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Codes.ResourceType_SortOrder]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Codes.ResourceType] ADD  CONSTRAINT [DF_Codes.ResourceType_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO
/****** Object:  Default [DF_Codes.ResourceTypeCategory_SortOrder]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Codes.ResourceTypeCategory] ADD  CONSTRAINT [DF_Codes.ResourceTypeCategory_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO
/****** Object:  Default [DF_CodeTable_LanguageCode_1]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CodeTable] ADD  CONSTRAINT [DF_CodeTable_LanguageCode_1]  DEFAULT ('en') FOR [LanguageCode]
GO
/****** Object:  Default [DF_CodeTable_SortOrder]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CodeTable] ADD  CONSTRAINT [DF_CodeTable_SortOrder]  DEFAULT ((0)) FOR [SortOrder]
GO
/****** Object:  Default [DF_CodeTable_IsActive]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CodeTable] ADD  CONSTRAINT [DF_CodeTable_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_CodeTable_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CodeTable] ADD  CONSTRAINT [DF_CodeTable_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_CodeTable_Modified]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[CodeTable] ADD  CONSTRAINT [DF_CodeTable_Modified]  DEFAULT (getdate()) FOR [Modified]
GO
/****** Object:  Default [DF_Library_RowId]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Library] ADD  CONSTRAINT [DF_Library_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Library_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Library] ADD  CONSTRAINT [DF_Library_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Library_LastUpdated]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Library] ADD  CONSTRAINT [DF_Library_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Library.Resource_RowId]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Library.Resource] ADD  CONSTRAINT [DF_Library.Resource_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Library.Resource_Created]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Library.Resource] ADD  CONSTRAINT [DF_Library.Resource_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Library.Resource_LastUpdated]    Script Date: 12/14/2012 10:55:21 ******/
ALTER TABLE [dbo].[Library.Resource] ADD  CONSTRAINT [DF_Library.Resource_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Map.CareerCluster_IsActive]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.CareerCluster] ADD  CONSTRAINT [DF_Map.CareerCluster_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Map.CareerCluster_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.CareerCluster] ADD  CONSTRAINT [DF_Map.CareerCluster_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Map.CareerCluster_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.CareerCluster] ADD  CONSTRAINT [DF_Map.CareerCluster_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Map.Rules_IsRegex]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_IsRegex]  DEFAULT ((0)) FOR [IsRegex]
GO
/****** Object:  Default [DF_Map.Rules_IsCaseSensitive]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_IsCaseSensitive]  DEFAULT ((0)) FOR [IsCaseSensitive]
GO
/****** Object:  Default [DF_Map.Rules_ImportWithoutTranslation]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_ImportWithoutTranslation]  DEFAULT ((0)) FOR [ImportWithoutTranslation]
GO
/****** Object:  Default [DF_Map.Rules_DoNotImport]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_DoNotImport]  DEFAULT ((0)) FOR [DoNotImport]
GO
/****** Object:  Default [DF_Map.Rules_Sequence]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_Sequence]  DEFAULT ((10)) FOR [Sequence]
GO
/****** Object:  Default [DF_Map.Rules_IsActive]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Map.Rules_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Map.Rules_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Map.Rules] ADD  CONSTRAINT [DF_Map.Rules_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Pathway_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Pathway] ADD  CONSTRAINT [DF_Pathway_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Pathway_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Pathway] ADD  CONSTRAINT [DF_Pathway_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Patron_Password]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron] ADD  CONSTRAINT [DF_Patron_Password]  DEFAULT (newid()) FOR [Password]
GO
/****** Object:  Default [DF_Patron_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron] ADD  CONSTRAINT [DF_Patron_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Patron_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron] ADD  CONSTRAINT [DF_Patron_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Patron_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron] ADD  CONSTRAINT [DF_Patron_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Patron.Action_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Action] ADD  CONSTRAINT [DF_Patron.Action_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Patron.Action_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Action] ADD  CONSTRAINT [DF_Patron.Action_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Patron.Action_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Action] ADD  CONSTRAINT [DF_Patron.Action_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Patron.Library_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Library] ADD  CONSTRAINT [DF_Patron.Library_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Patron.Library_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Library] ADD  CONSTRAINT [DF_Patron.Library_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Patron.Library_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Library] ADD  CONSTRAINT [DF_Patron.Library_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Patron.LibraryResource_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.LibraryResource] ADD  CONSTRAINT [DF_Patron.LibraryResource_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Patron.LibraryResource_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.LibraryResource] ADD  CONSTRAINT [DF_Patron.LibraryResource_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Patron.LibraryResource_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.LibraryResource] ADD  CONSTRAINT [DF_Patron.LibraryResource_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Patron.Note_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Note] ADD  CONSTRAINT [DF_Patron.Note_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Patron.Note_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Note] ADD  CONSTRAINT [DF_Patron.Note_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Patron.Note_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Note] ADD  CONSTRAINT [DF_Patron.Note_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Patron.Profile_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Profile] ADD  CONSTRAINT [DF_Patron.Profile_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Patron.Profile_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Profile] ADD  CONSTRAINT [DF_Patron.Profile_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Patron.SearchFilter_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.SearchFilter] ADD  CONSTRAINT [DF_Patron.SearchFilter_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Patron.SearchFilter_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.SearchFilter] ADD  CONSTRAINT [DF_Patron.SearchFilter_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Patron.SearchFilter_LastUpdated]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.SearchFilter] ADD  CONSTRAINT [DF_Patron.SearchFilter_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO
/****** Object:  Default [DF_Publish.Pending_IsPublished]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Publish.Pending] ADD  CONSTRAINT [DF_Publish.Pending_IsPublished]  DEFAULT ((0)) FOR [IsPublished]
GO
/****** Object:  Default [DF_Publish.Pending_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Publish.Pending] ADD  CONSTRAINT [DF_Publish.Pending_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_PublisherSummary_IsActive]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[PublisherSummary] ADD  CONSTRAINT [DF_PublisherSummary_IsActive]  DEFAULT ((0)) FOR [IsActive]
GO
/****** Object:  Default [DF_Resource_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource] ADD  CONSTRAINT [DF_Resource_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Resource_IsActive]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource] ADD  CONSTRAINT [DF_Resource_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Resource.Comment_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource.Comment] ADD  CONSTRAINT [DF_Resource.Comment_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Resource.Comment_Created]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource.Comment] ADD  CONSTRAINT [DF_Resource.Comment_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_Resource.EducationLevel_RowId]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource.EducationLevel] ADD  CONSTRAINT [DF_Resource.EducationLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Resource.Property_RowId]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Property] ADD  CONSTRAINT [DF_Resource.Property_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Resource.Property_Imported]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Property] ADD  CONSTRAINT [DF_Resource.Property_Imported]  DEFAULT (getdate()) FOR [Imported]
GO
/****** Object:  Default [DF_Resource.ResourceType_RowId]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.ResourceType] ADD  CONSTRAINT [DF_Resource.ResourceType_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Resource.StandardAlignment_RowID]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Standard] ADD  CONSTRAINT [DF_Resource.StandardAlignment_RowID]  DEFAULT (newid()) FOR [RowID]
GO
/****** Object:  Default [DF_Resource.Version_RowId]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Version] ADD  CONSTRAINT [DF_Resource.Version_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Resource.Version_Imported]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Version] ADD  CONSTRAINT [DF_Resource.Version_Imported]  DEFAULT (getdate()) FOR [Imported]
GO
/****** Object:  Default [DF_Resource.Version_IsActive]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Version] ADD  CONSTRAINT [DF_Resource.Version_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Resource.Version_121022_RowId]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Version_121022] ADD  CONSTRAINT [DF_Resource.Version_121022_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Resource.Version_121022_Imported]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Version_121022] ADD  CONSTRAINT [DF_Resource.Version_121022_Imported]  DEFAULT (getdate()) FOR [Imported]
GO
/****** Object:  Default [DF_Resource.Version_121022_IsActive]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Version_121022] ADD  CONSTRAINT [DF_Resource.Version_121022_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
/****** Object:  Default [DF_Staging.EducationLevel_RowId]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Staging.EducationLevel] ADD  CONSTRAINT [DF_Staging.EducationLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO
/****** Object:  Default [DF_Staging.EducationLevel_Imported]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Staging.EducationLevel] ADD  CONSTRAINT [DF_Staging.EducationLevel_Imported]  DEFAULT (getdate()) FOR [Imported]
GO
/****** Object:  ForeignKey [FK_Patron.Action_Patron]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Action]  WITH CHECK ADD  CONSTRAINT [FK_Patron.Action_Patron] FOREIGN KEY([PatronId])
REFERENCES [dbo].[Patron] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Patron.Action] CHECK CONSTRAINT [FK_Patron.Action_Patron]
GO
/****** Object:  ForeignKey [FK_Patron.ExternalAccount_Patron]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.ExternalAccount]  WITH CHECK ADD  CONSTRAINT [FK_Patron.ExternalAccount_Patron] FOREIGN KEY([PatronId])
REFERENCES [dbo].[Patron] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Patron.ExternalAccount] CHECK CONSTRAINT [FK_Patron.ExternalAccount_Patron]
GO
/****** Object:  ForeignKey [FK_Patron.Library_Patron]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Library]  WITH CHECK ADD  CONSTRAINT [FK_Patron.Library_Patron] FOREIGN KEY([UserId])
REFERENCES [dbo].[Patron] ([Id])
GO
ALTER TABLE [dbo].[Patron.Library] CHECK CONSTRAINT [FK_Patron.Library_Patron]
GO
/****** Object:  ForeignKey [FK_Patron.LibraryResource_Patron.Library]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.LibraryResource]  WITH CHECK ADD  CONSTRAINT [FK_Patron.LibraryResource_Patron.Library] FOREIGN KEY([PatronLibraryId])
REFERENCES [dbo].[Patron.Library] ([Id])
GO
ALTER TABLE [dbo].[Patron.LibraryResource] CHECK CONSTRAINT [FK_Patron.LibraryResource_Patron.Library]
GO
/****** Object:  ForeignKey [FK_Patron.LibraryResource_Resource]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.LibraryResource]  WITH CHECK ADD  CONSTRAINT [FK_Patron.LibraryResource_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Patron.LibraryResource] CHECK CONSTRAINT [FK_Patron.LibraryResource_Resource]
GO
/****** Object:  ForeignKey [FK_Patron.Note_Patron]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Note]  WITH CHECK ADD  CONSTRAINT [FK_Patron.Note_Patron] FOREIGN KEY([UserId])
REFERENCES [dbo].[Patron] ([Id])
GO
ALTER TABLE [dbo].[Patron.Note] CHECK CONSTRAINT [FK_Patron.Note_Patron]
GO
/****** Object:  ForeignKey [FK_Patron.Profile_Patron]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.Profile]  WITH CHECK ADD  CONSTRAINT [FK_Patron.Profile_Patron] FOREIGN KEY([UserId])
REFERENCES [dbo].[Patron] ([Id])
GO
ALTER TABLE [dbo].[Patron.Profile] CHECK CONSTRAINT [FK_Patron.Profile_Patron]
GO
/****** Object:  ForeignKey [FK_Patron.SearchFilter_Patron]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Patron.SearchFilter]  WITH CHECK ADD  CONSTRAINT [FK_Patron.SearchFilter_Patron] FOREIGN KEY([UserId])
REFERENCES [dbo].[Patron] ([Id])
GO
ALTER TABLE [dbo].[Patron.SearchFilter] CHECK CONSTRAINT [FK_Patron.SearchFilter_Patron]
GO
/****** Object:  ForeignKey [FK_Resource_Pathway_Resource]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource.Cluster]  WITH CHECK ADD  CONSTRAINT [FK_Resource_Pathway_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Cluster] CHECK CONSTRAINT [FK_Resource_Pathway_Resource]
GO
/****** Object:  ForeignKey [FK_ResourceCluster_Cluster]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource.Cluster]  WITH CHECK ADD  CONSTRAINT [FK_ResourceCluster_Cluster] FOREIGN KEY([ClusterId])
REFERENCES [dbo].[CareerCluster] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Cluster] CHECK CONSTRAINT [FK_ResourceCluster_Cluster]
GO
/****** Object:  ForeignKey [FK_Resource.EducationLevel_Codes.PathwaysEducationLevel]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource.EducationLevel]  WITH CHECK ADD  CONSTRAINT [FK_Resource.EducationLevel_Codes.PathwaysEducationLevel] FOREIGN KEY([PathwaysEducationLevelId])
REFERENCES [dbo].[Codes.PathwaysEducationLevel] ([Id])
GO
ALTER TABLE [dbo].[Resource.EducationLevel] CHECK CONSTRAINT [FK_Resource.EducationLevel_Codes.PathwaysEducationLevel]
GO
/****** Object:  ForeignKey [FK_Resource.EducationLevel_Resource]    Script Date: 12/14/2012 10:55:22 ******/
ALTER TABLE [dbo].[Resource.EducationLevel]  WITH CHECK ADD  CONSTRAINT [FK_Resource.EducationLevel_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.EducationLevel] CHECK CONSTRAINT [FK_Resource.EducationLevel_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.Format_Codes.ResourceFormat]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Format]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Format_Codes.ResourceFormat] FOREIGN KEY([CodeId])
REFERENCES [dbo].[Codes.ResourceFormat] ([Id])
GO
ALTER TABLE [dbo].[Resource.Format] CHECK CONSTRAINT [FK_Resource.Format_Codes.ResourceFormat]
GO
/****** Object:  ForeignKey [FK_Resource.Format_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Format]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Format_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Format] CHECK CONSTRAINT [FK_Resource.Format_Resource]
GO
/****** Object:  ForeignKey [FK_IntendedAudience_CodesAudienceType]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.IntendedAudience]  WITH CHECK ADD  CONSTRAINT [FK_IntendedAudience_CodesAudienceType] FOREIGN KEY([AudienceId])
REFERENCES [dbo].[Codes.AudienceType] ([Id])
GO
ALTER TABLE [dbo].[Resource.IntendedAudience] CHECK CONSTRAINT [FK_IntendedAudience_CodesAudienceType]
GO
/****** Object:  ForeignKey [FK_Resource.IntendedAudience_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.IntendedAudience]  WITH CHECK ADD  CONSTRAINT [FK_Resource.IntendedAudience_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.IntendedAudience] CHECK CONSTRAINT [FK_Resource.IntendedAudience_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.Keyword_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Keyword]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Keyword_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Keyword] CHECK CONSTRAINT [FK_Resource.Keyword_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.Language_Codes.Language]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Language]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Language_Codes.Language] FOREIGN KEY([LanguageId])
REFERENCES [dbo].[Codes.Language] ([Id])
GO
ALTER TABLE [dbo].[Resource.Language] CHECK CONSTRAINT [FK_Resource.Language_Codes.Language]
GO
/****** Object:  ForeignKey [FK_Resource.Language_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Language]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Language_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Language] CHECK CONSTRAINT [FK_Resource.Language_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.Property_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Property]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Property_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Property] CHECK CONSTRAINT [FK_Resource.Property_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.Rating_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Rating]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Rating_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Rating] CHECK CONSTRAINT [FK_Resource.Rating_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.RatingSummary_Codes.RatingType]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.RatingSummary]  WITH CHECK ADD  CONSTRAINT [FK_Resource.RatingSummary_Codes.RatingType] FOREIGN KEY([RatingTypeId])
REFERENCES [dbo].[Codes.RatingType] ([Id])
GO
ALTER TABLE [dbo].[Resource.RatingSummary] CHECK CONSTRAINT [FK_Resource.RatingSummary_Codes.RatingType]
GO
/****** Object:  ForeignKey [FK_Resource.RatingSummary_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.RatingSummary]  WITH CHECK ADD  CONSTRAINT [FK_Resource.RatingSummary_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.RatingSummary] CHECK CONSTRAINT [FK_Resource.RatingSummary_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.ResourceType_Codes.ResourceType]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.ResourceType]  WITH CHECK ADD  CONSTRAINT [FK_Resource.ResourceType_Codes.ResourceType] FOREIGN KEY([ResourceTypeId])
REFERENCES [dbo].[Codes.ResourceType] ([Id])
GO
ALTER TABLE [dbo].[Resource.ResourceType] CHECK CONSTRAINT [FK_Resource.ResourceType_Codes.ResourceType]
GO
/****** Object:  ForeignKey [FK_Resource.ResourceType_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.ResourceType]  WITH CHECK ADD  CONSTRAINT [FK_Resource.ResourceType_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.ResourceType] CHECK CONSTRAINT [FK_Resource.ResourceType_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.StandardAlignment_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Standard]  WITH CHECK ADD  CONSTRAINT [FK_Resource.StandardAlignment_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Standard] CHECK CONSTRAINT [FK_Resource.StandardAlignment_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.StandardAlignment_Standard]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Standard]  WITH CHECK ADD  CONSTRAINT [FK_Resource.StandardAlignment_Standard] FOREIGN KEY([StandardId])
REFERENCES [dbo].[StandardBody.Standard] ([Id])
GO
ALTER TABLE [dbo].[Resource.Standard] CHECK CONSTRAINT [FK_Resource.StandardAlignment_Standard]
GO
/****** Object:  ForeignKey [FK_Resource.Subject_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Subject]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Subject_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Subject] CHECK CONSTRAINT [FK_Resource.Subject_Resource]
GO
/****** Object:  ForeignKey [FK_Resource.Version_Resource]    Script Date: 12/14/2012 10:55:23 ******/
ALTER TABLE [dbo].[Resource.Version]  WITH CHECK ADD  CONSTRAINT [FK_Resource.Version_Resource] FOREIGN KEY([ResourceId])
REFERENCES [dbo].[Resource] ([RowId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Resource.Version] CHECK CONSTRAINT [FK_Resource.Version_Resource]
GO
GRANT SELECT ON [dbo].[IntendedAudienceCounts] TO [public] AS [dbo]
GO
GRANT SELECT ON [dbo].[Resource.EducationLevelsList] TO [public] AS [dbo]
GO
GRANT SELECT ON [dbo].[Resource.KeywordsCsvList] TO [public] AS [dbo]
GO
GRANT SELECT ON [dbo].[Resource.SubjectsCsvList] TO [public] AS [dbo]
GO
GRANT SELECT ON [dbo].[Resource.SubjectsList_RP] TO [public] AS [dbo]
GO
GRANT SELECT ON [dbo].[Resource.Version_Summary] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[aspAllDatabaseTableCounts] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[CareerClusterSelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Codes.ResPropertyType_Lookup] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Codes_EducationLevel_Select] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Codes_ResourceType_Select] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[CodeTable_Select] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Map.PathwayRules_Load] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Map.Rules_Load] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[PatronAuthorize] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[PatronGet] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[PatronInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[PatronSelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[PatronUpdate] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[PublisherSearch] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Cluster_PopulateEnergy] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Cluster_PopulateFromMapping] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ClusterDelete] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ClusterInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ClusterSelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ClusterSelect_SelectedCodes] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevel_Import] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevel_ImportFromMappingOrphan] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevel_ImportResProperty] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevel_Insert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevel_RemoveDuplicates] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevelDelete] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevelInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.EducationLevelSelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Format_Import] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Format_ImportFromMappingOrphan] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Format_SelectedCodes] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.FormatInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.IntendedAudience_SelectedCodes] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.IntendedAudienceDelete] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.IntendedAudienceSelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.KeywordGet] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.KeywordInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.KeywordInsertUpdate] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Language_Import] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Language_ImportFromMappingOrphan] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Language_ImportResProperty] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.PathwaySelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.PropertyInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ResourceType_FixUnknownTypes] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ResourceType_SelectedCodes] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ResourceTypeImport] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.ResourceTypeInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.StandardDelete] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.StandardGet] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.StandardInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.StandardSelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Version_Display] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.Version_Get] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.VersionDelete] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.VersionGet] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.VersionInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.VersionSelect] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource.VersionUpdate] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource_Search] TO [lrReader] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource_Search] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource_Search] TO [workNetReader] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource_Search_FT] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[Resource_Search_FT] TO [workNetReader] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[ResourceEducationLevel_SearchCounts] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[ResourceGet] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[ResourceInsert] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[ResourceType_SearchCounts] TO [public] AS [dbo]
GO
GRANT EXECUTE ON [dbo].[StandardBody.NodeInsert] TO [public] AS [dbo]
GO
