
use isleContent
go

/* =============================================
Description: Content_RelatedContentSummary, convenience view for listing all child content for a content item.
typically it will be filtered for documents.
	Documents: TypeId= 40  


  ------------------------------------------------------
Modifications
14-09-11 mparsons - added 

*/

Create VIEW [dbo].[Content_RelatedContentSummary]
AS

SELECT        
	Parent.Id, 
	Parent.TypeId, ParentContentType.Title as ParentType,
	Parent.Title AS Parent, 
	Parent.StatusId AS ParentStatusId, 
	Parent.ParentId, 

	RelatedContent.Id AS ChildId, 
	RelatedContent.TypeId As RelatedTypeId, RelatedContentType.Title as RelatedType,
	RelatedContent.Title, 
	RelatedContent.Summary, 
	RelatedContent.StatusId, 
	RelatedContent.PrivilegeTypeId, 
	RelatedContentType.Title AS RelatedContentType

FROM dbo.[Content] AS Parent 
INNER JOIN dbo.[Content] AS RelatedContent ON Parent.Id = RelatedContent.ParentId 
INNER JOIN dbo.ContentType as ParentContentType ON Parent.TypeId = ParentContentType.Id 
INNER JOIN dbo.ContentType AS RelatedContentType ON RelatedContent.TypeId = RelatedContentType.Id

WHERE    
	(Parent.IsActive = 1)
AND (RelatedContent.IsActive = 1)


go
grant select on [Content_RelatedContentSummary] to public
go
