USE [IsleContent]
GO

/****** Object:  View [dbo].[Resource.AccessRights]    Script Date: 1/21/2014 10:45:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


Create VIEW [dbo].[Resource.AccessRights] AS
SELECT [Id]
      ,[ResourceIntId]
      ,[AccessRightsId]
	  ,Created
  FROM [Isle_IOER].[dbo].[Resource.Version]
  where [AccessRightsId] is not null 
  AND [AccessRightsId]> 0
  --and [ResourceIntId] is null

go
grant select on [Resource.AccessRights] to public
GO


