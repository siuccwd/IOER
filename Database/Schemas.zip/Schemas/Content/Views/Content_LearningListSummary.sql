
--declare @userId int
--set @userId = 2

/*
USE [IsleContent]
GO

SELECT [Id]
      ,[Title]
      ,[PartnerTypeId]
      ,[PartnerUserId]
      ,[PartnerType]
      ,[Summary]
      ,[ImageUrl]
      ,[OrgId]
      ,[StatusId]
      ,[IsPublished]
      ,[ResourceIntId]
      ,[Created]
      ,[CreatedById]
      ,[LastUpdated]
      ,[LastUpdatedById]
  FROM [dbo].[Content_LearningListSummary]
where partnerUserid = 2



*/

CREATE VIEW [dbo].[Content_LearningListSummary] AS

SELECT        distinct
	base.Id, 
	base.Title, 

	4 as PartnerTypeId, base.CreatedById as PartnerUserId, 'Author' as PartnerType,

	base.Summary, 
	base.ImageUrl, 
	base.OrgId, 
	base.StatusId, 
	base.IsPublished, 
	base.ResourceIntId, 
	base.Created, 
	base.CreatedById, 
	base.LastUpdated, 
	base.LastUpdatedById
	
FROM dbo.[Content] base
WHERE        
	(base.TypeId = 50)
--and (base.CreatedById = @userId OR (cp.UserId = @userId and cp.PartnerTypeId > 0))

union

SELECT        distinct
	base.Id, 
	base.Title, 

	cp.PartnerTypeId, cp.UserId as PartnerUserId, cpt.Title as PartnerType,

	base.Summary, 
	base.ImageUrl, 
	base.OrgId, 
	base.StatusId, 
	base.IsPublished, 
	base.ResourceIntId, 
	base.Created, 
	base.CreatedById, 
	base.LastUpdated, 
	base.LastUpdatedById
	
FROM dbo.[Content] base
Inner JOIN dbo.[Content.Partner] cp on base.id = cp.ContentId
Inner join dbo.[Codes.ContentPartnerType] cpt  ON cp.PartnerTypeId =  cpt.Id

WHERE        
	(base.TypeId = 50)

go
grant select on [Content_LearningListSummary] to public
go