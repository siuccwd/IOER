USE [IsleContent]
GO

/****** Object:  View [dbo].[Resource.EducationalUse]    Script Date: 1/21/2014 10:45:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


Alter VIEW [dbo].[Resource.EducationalUse] AS
SELECT [Id]
      ,[ResourceIntId]
      ,[EducationUseId] As EducationalUseId
  FROM Isle_IOER.[dbo].[Resource.EducationUse]

go
grant select on [Resource.EducationalUse] to public
GO


