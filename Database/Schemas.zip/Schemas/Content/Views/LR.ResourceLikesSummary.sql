USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.ResourceLikesSummary]    Script Date: 06/20/2013 10:53:46 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[LR.ResourceLikesSummary]'))
DROP VIEW [dbo].[LR.ResourceLikesSummary]
GO

/****** Object:  View [dbo].[LR.ResourceLikesSummary]    Script Date: 06/20/2013 10:53:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
SELECT [ResourceIntId]
      ,[LikeCount]
      ,[DislikeCount]
  FROM [IsleContent].[dbo].[LR.ResourceLikesSummary]
GO


*/
/*
[LR.ResourceLikesSummary] - select LR likes . 
    
*/
CREATE VIEW [dbo].[LR.ResourceLikesSummary] AS

SELECT [ResourceIntId]
      ,[LikeCount]
      ,[DislikeCount]

  FROM Isle_IOER.[dbo].[Resource.LikesSummary]
  where LikeCount> 0 OR DislikeCount > 0


GO


