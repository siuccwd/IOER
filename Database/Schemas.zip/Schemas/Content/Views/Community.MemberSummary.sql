USE [IsleContent]
GO

/****** Object:  View [dbo].[Community.MemberSummary]    Script Date: 2/5/2014 11:11:32 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[Community.MemberSummary]'))
DROP VIEW [dbo].[Community.MemberSummary]
GO


/****** Object:  View [dbo].[Community_MemberSummary]    Script Date: 2/5/2014 11:11:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

USE [IsleContent]
GO

SELECT [Id]
      ,[CommunityId]      ,[Community]      ,[CommunityOrgId]
      ,[UserId]
      ,[FirstName]      ,[LastName]      ,[FullName]      ,[SortName]
      ,[Email]
      ,[UserOrganization]      ,[UserOrganizationId]
      ,[MemberTypeId]      ,[MemberType]
      ,[ImageUrl]      ,[UserProfileUrl]
      ,[IsAnOrgMbr]      ,[OrgMemberTypeId]      ,[OrgMemberType]
      ,[Created]
  FROM [dbo].[Community.MemberSummary]
GO

/LearningList/2207/http://localhost:2012/Content/2207/Illinois_Pathways-Health_Science_Curriculum

*/

Create VIEW [dbo].[Community.MemberSummary]
AS

SELECT        
	base.Id, 
	base.CommunityId, 
	parent.Title AS Community, 
	isnull(parent.OrgId, 0) As CommunityOrgId,
	orgMbr.Organization As CommunityOrganization,
	base.UserId, 
	acct.FirstName,  acct.LastName, acct.FullName, acct.SortName,
	acct.Email, 
	isnull(acct.Organization, 'None') As UserOrganization,
	isnull(acct.OrganizationId, 0) As UserOrgId,
	base.MemberTypeId, 
	code.Title AS MemberType, 
	acct.ImageUrl, acct.UserProfileUrl, 
	
	case when orgMbr.OrgId is not null then 1 else 0 end as IsAnOrgMbr,
	isnull(orgMbr.OrgMemberTypeId, 0) As [OrgMemberTypeId],
	isnull(orgMbr.OrgMemberType, '') As [OrgMemberType],
	base.Created
	--,base.CreatedById, 
	--base.LastUpdated, 
	--base.LastUpdatedById

FROM dbo.[Community.Member] base
INNER JOIN dbo.[Codes.LibraryMemberType] code	ON base.MemberTypeId = code.Id 
INNER JOIN dbo.[LR.PatronOrgSummary] acct		ON base.UserId = acct.UserId
INNER JOIN dbo.Community parent					ON base.CommunityId = parent.Id
Left Join [Gateway.Org_MemberSummary] orgMbr	ON parent.OrgId = orgMbr.OrgId AND orgMbr.UserId = base.UserId

GO
grant select on [Community.MemberSummary] to public
go
