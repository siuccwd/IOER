USE [IsleContent]
GO

/****** Object:  View [dbo].[Resource.GroupType]    Script Date: 1/21/2014 10:45:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[Resource.GroupType] AS
SELECT [Id]
      ,[ResourceIntId]
      ,[GroupTypeId]
      ,[Created]
      ,[CreatedById]
  FROM Isle_IOER.[dbo].[Resource.GroupType]

go
grant select on [Resource.GroupType] to public
GO


