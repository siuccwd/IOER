USE [IsleContent]
GO

/****** Object:  View [dbo].[Gateway.OrgSummary]    Script Date: 05/02/2013 13:38:09 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[Gateway.OrgSummary]'))
DROP VIEW [dbo].[Gateway.OrgSummary]
GO

/****** Object:  View [dbo].[Gateway.OrgSummary]    Script Date: 05/02/2013 13:38:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
SELECT [id]
      ,[Name]
      ,[OrgTypeId]
      ,[OrgType]
      ,[parentId]

      ,base.[IsActive]
      ,[MainPhone],[MainExtension],[Fax],[TTY]
      ,[WebSite],[Email]
      ,[LogoUrl]
      ,[Address],[Address2],[City],[State],[Zipcode]
      ,base.[Created]      ,base.[CreatedById]
      ,[LastUpdated]      ,[LastUpdatedById]
  FROM [IsleContent].[dbo].[Gateway.OrgSummary]
GO



*/

/*
[Gateway.OrgSummary] - select org summary . 
    
*/
Create VIEW [dbo].[Gateway.OrgSummary] AS

SELECT [id]
      ,[Name]
      ,[OrgTypeId]
      ,[OrgType]
      ,[parentId],[ParentOrganization]
      ,[IsActive]
      ,[MainPhone],[MainExtension],[Fax],[TTY]
      ,[WebSite],[Email],[LogoUrl]
      ,[Address],[Address2],[City],[State],[Zipcode]
      ,[Created],[CreatedById]
      ,[LastUpdated],[LastUpdatedById]

  FROM [Gateway].[dbo].[Organization_Summary]


GO
grant select on [Gateway.OrgSummary] to public
go



