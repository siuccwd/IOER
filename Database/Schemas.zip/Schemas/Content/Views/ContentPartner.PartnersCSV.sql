USE [IsleContent]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


Create VIEW [dbo].[ContentPartner.PartnersCSV]
AS 
SELECT ContentId, LEFT(Partners, LEN(Partners) - 1) AS Partners
FROM (
	SELECT ContentId, (
		SELECT isnull(convert(varchar,itbl.UserId),'')+','
		FROM [Content.Partner] itbl
		WHERE itbl.ContentId = tbl.ContentId
		FOR XML PATH('')) Partners
	FROM [Content.Partner] tbl
	GROUP BY ContentId) otbl

GO


