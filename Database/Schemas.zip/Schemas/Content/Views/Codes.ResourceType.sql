USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[Codes.ResourceType] AS
SELECT [Id]
      ,[Title]
      ,[Description]
      ,[IsIsleItem]
      ,[IsActive]
      ,[SortOrder]
      ,[WarehouseTotal]
      ,[CategoryId]
      ,[OrigTitle]
  FROM Isle_IOER.[dbo].[Codes.ResourceType]
GO


grant select on [Codes.ResourceType] to public
go

