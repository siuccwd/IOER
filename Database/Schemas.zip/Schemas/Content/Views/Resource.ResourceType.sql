USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[Resource.ResourceType] AS
SELECT [RowId]
      ,[ResourceIntId]
      ,[ResourceTypeId]
      ,[Created]
      ,[CreatedById]

  FROM [Isle_IOER].[dbo].[Resource.ResourceType]
GO


grant select on [Resource.ResourceType] to public
go

