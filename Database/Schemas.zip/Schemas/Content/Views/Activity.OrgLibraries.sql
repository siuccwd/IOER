USE [IsleContent]
GO

/****** Object:  View [dbo].[Activity.OrgLibraries]    Script Date: 1/20/2015 9:30:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
SELECT [Activity]
      ,[Event]
      ,count(*) as GroupCount
  FROM [dbo].[ActivityLog]
group by [Activity]
      ,[Event]
Order by [Activity]
      ,[Event]

*/

Create VIEW [dbo].[Activity.OrgLibraries] AS

SELECT base.[Id]
      ,base.[CreatedDate]
      ,base.[ActivityType]
      ,base.[Activity]
      ,base.[Event]
      ,base.[Comment]
      ,base.[TargetUserId]
      ,base.[ActionByUserId]
      ,base.[ActivityObjectId]
		,org.Name
		,obj.Title
  FROM [dbo].[ActivityLog] base
inner join Library obj on base.ActivityObjectId = obj.id
inner join [Gateway.OrgSummary] org on obj.OrgId = org.Id
where Activity = 'Library' 
--OR Activity = 'Collection' ==> diff activity object type

GO
grant select on [Activity.OrgLibraries] to public
go


