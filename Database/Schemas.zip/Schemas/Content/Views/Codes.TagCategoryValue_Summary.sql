USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

  WHERE CategoryId =19
*/
--not site specific
create VIEW [dbo].[Codes.TagCategoryValue_Summary] AS

SELECT [CategoryId]
      ,[Category]
      ,[TagValueId]
      ,[TagRelativeId] As CodeId
      ,[Title]
	  ,Description
  FROM Isle_IOER.[dbo].[Codes.TagCategoryValue_Summary]

GO


grant select on [Codes.TagCategoryValue_Summary] to public
go

