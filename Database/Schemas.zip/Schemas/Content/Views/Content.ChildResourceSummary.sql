USE [IsleContent]
GO


/****** Object:  View [dbo].[Content_DocumentSummary]    Script Date: 12/11/2014 7:53:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [IsleContent]
GO

SELECT [ContentId]
      ,[Title]
	  ,[Created]
      ,[FilePath]
	  ,replace(replace(replace([DocumentUrl], FileName, ''),'/','\'),'\Content', 'F:\Content')  As NewOne
      ,[FileName]
      ,[DocumentPath]
      ,[DocumentUrl]
	  
      ,[DocumentRowId]
      ,[MimeType]
      
  FROM [dbo].[Content.ChildResourceSummary]

where FilePath is null and FileName is not null


SELECT [ContentId]
      ,[ParentId]
      ,[TypeId]
      ,[ContentType]
      ,[Title]
      ,[SortOrder]
      ,[StatusId]
      ,[OrgId]
      ,[Description]
      ,[FilePath]
      ,[FileName]
      ,[DocumentPath]
      ,[DocumentUrl]
	  ,replace(replace(replace([DocumentUrl], FileName, ''),'/','\'),'\Content', 'F:\Content')  As NewOne
      ,[DocumentRowId]
      ,[MimeType]
      ,[Created]
      ,[CreatedById]
      ,[PrivilegeTypeId]
  FROM [dbo].[Content.ChildResourceSummary]
where parentId = 2220




*/
Create VIEW [dbo].[Content.ChildResourceSummary]
AS



SELECT        
	base.Id AS ContentId, 
	base.ParentId,
	base.TypeId, dbo.ContentType.Title AS ContentType, 
	base.Title, 
	base.SortOrder,
	base.StatusId, 
	base.OrgId,
	case 
		when isnull(base.Summary, '') <> '' then base.Summary
		when isnull(base.Description, '') <> '' then base.Description
		else '' end As Description,
	dbo.[Document.Version].FilePath, 
	dbo.[Document.Version].FileName, 
	--probably safer to construct in server side code
	case when isnull(dbo.[Document.Version].FilePath,'') <> '' then
		isnull(dbo.[Document.Version].FilePath,'') + '\' + dbo.[Document.Version].FileName
		else '' end As DocumentPath, 
	base.DocumentUrl, 
	base.DocumentRowId, 
	dbo.[Document.Version].MimeType,

	base.Created
	,base.CreatedById
	,base.PrivilegeTypeId
FROM dbo.[Content] base
INNER JOIN dbo.ContentType              ON base.TypeId = dbo.ContentType.Id 
Left JOIN dbo.[Document.Version] ON base.DocumentRowId = dbo.[Document.Version].RowId
where base.TypeId in (40,41)
GO

grant select on [Content.ChildResourceSummary] to public
go