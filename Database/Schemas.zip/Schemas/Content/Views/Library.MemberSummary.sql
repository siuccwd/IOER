USE [IsleContent]
GO

/****** Object:  View [dbo].[Library.MemberSummary]    Script Date: 2/5/2014 11:11:32 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[Library.MemberSummary]'))
DROP VIEW [dbo].[Library.MemberSummary]
GO


/****** Object:  View [dbo].[Library_MemberSummary]    Script Date: 2/5/2014 11:11:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

SELECT [Id]
      ,[LibraryId]
      ,[Library]
      ,[OrgId]
      ,[UserId]      ,[FullName]      ,[SortName]
	  ,ImageUrl, UserProfileUrl
      ,[Email]
      ,[Organization]      ,[OrganizationId]
      ,[MemberTypeId]      ,[MemberType]
      ,[IsAnOrgMbr]
      ,[OrgMemberTypeId]
      ,[OrgMemberType]
      ,[Created]
      ,[CreatedById]
      ,[LastUpdated]
      ,[LastUpdatedById]
  FROM [dbo].[Library.MemberSummary]
GO



*/

Create VIEW [dbo].[Library.MemberSummary]
AS

SELECT        
	base.Id, 
	base.LibraryId, 
	lib.Title AS Library, lib.OrgId,
	base.UserId, 
	acct.FirstName,  acct.LastName, acct.FullName, acct.SortName,
	acct.Email, 
	isnull(acct.Organization, 'None') As Organization,
	isnull(acct.OrganizationId, 0) As OrganizationId,
	base.MemberTypeId, 
	code.Title AS MemberType, 
	acct.ImageUrl, acct.UserProfileUrl, 
	case when orgMbr.OrgId is not null then 1 else 0 end as IsAnOrgMbr,
	isnull(orgMbr.OrgMemberTypeId, 0) As [OrgMemberTypeId],
	isnull(orgMbr.OrgMemberType, '') As [OrgMemberType],
	base.Created, 
	base.CreatedById, 
	base.LastUpdated, 
	base.LastUpdatedById

FROM            dbo.[Library.Member] base
INNER JOIN dbo.[Codes.LibraryMemberType] code ON base.MemberTypeId = code.Id 
INNER JOIN dbo.[LR.PatronOrgSummary] acct ON base.UserId = acct.UserId
INNER JOIN dbo.Library lib ON base.LibraryId = lib.Id
Left Join [Gateway.Org_MemberSummary] orgMbr on lib.OrgId = orgMbr.OrgId AND orgMbr.UserId = base.UserId

GO
grant select on [Library.MemberSummary] to public
go
