USE [IsleContent]
GO

/****** Object:  View [dbo].[LearningList.MembersSummary]    Script Date: 12/2/2014 3:09:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [IsleContent]
GO

SELECT [ContentId]
      ,[Title]
      ,[TypeId]
      ,[UserId]
      ,[PartnerTypeId]
      ,[PartnerType]
      ,[PartnerCreated]
      ,[PartnerLastUpdated]
      ,[CreatedById]
      ,[LastUpdatedById]
      ,[FirstName]
      ,[LastName]
      ,[Email]
      ,[ImageUrl]
      ,[OrgId]
      ,[Organization]
  FROM [dbo].[LearningList.MembersSummary]
GO



*/
CREATE VIEW [dbo].[LearningList.MembersSummary]
AS
SELECT        
	dbo.[Content.Partner].ContentId, 
	dbo.[Content].Title, 
	dbo.[Content].TypeId, 
	dbo.[Content.Partner].UserId, 
	dbo.[Content.Partner].PartnerTypeId, 
	dbo.[Codes.ContentPartnerType].Title AS PartnerType, 
	dbo.[Content.Partner].Created AS PartnerCreated, 
	dbo.[Content.Partner].LastUpdated AS PartnerLastUpdated, 
	dbo.[Content.Partner].CreatedById, 
	dbo.[Content.Partner].LastUpdatedById, 
	mbr.FirstName, mbr.LastName, 
	mbr.Email, 
	mbr.ImageUrl, 
	mbr.OrganizationId AS OrgId, 
	mbr.Organization

FROM  dbo.[Content] 
INNER JOIN dbo.[Content.Partner] ON dbo.[Content].Id = dbo.[Content.Partner].ContentId 
INNER JOIN dbo.[Codes.ContentPartnerType] ON dbo.[Content.Partner].PartnerTypeId = dbo.[Codes.ContentPartnerType].Id 
INNER JOIN dbo.[LR.PatronOrgSummary] mbr ON dbo.[Content.Partner].UserId = mbr.UserId

GO
grant select on [LearningList.MembersSummary] to public
go