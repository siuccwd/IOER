USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[Resource.Version] AS
SELECT 
[Id]

      --,[DocId]
      ,[Title]
     -- ,[Description]
      ,[Publisher]
      ,[Creator]
      ,[Rights]
      ,[AccessRights]
      ,[Modified]
      ,[Submitter]
      ,[Imported]
      ,[Created]
      ,[TypicalLearningTime]
      ,[IsSkeletonFromParadata]
    --  ,[IsActive]
    --  ,[Requirements]
      ,[SortTitle]
    --  ,[Schema]
      ,[AccessRightsId]
      ,[InteractivityTypeId]
      ,[ResourceIntId]
      
      ,[InteractivityType]
  FROM [Isle_IOER].[dbo].[Resource.Version]
  where [IsActive]= 1
GO


GO
grant select on [Resource.Version] to public
go

