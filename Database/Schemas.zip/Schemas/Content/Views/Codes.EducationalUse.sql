USE [IsleContent]
GO

/****** Object:  View [dbo].[Codes.EducationalUse]    Script Date: 1/21/2014 11:22:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[Codes.EducationalUse] AS
SELECT [Id]
      ,[Title]
      ,[Description]
      ,[IsActive]
      ,[WarehouseTotal]
  FROM Isle_IOER.[dbo].[Codes.EducationalUse]


GO
grant select on [Codes.EducationalUse] to public
go


