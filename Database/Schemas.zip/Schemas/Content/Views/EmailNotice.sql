USE [IsleContent]
GO

/****** Object:  View [dbo].[EmailNotice]    Script Date: 10/29/2014 10:40:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[EmailNotice]
AS
SELECT        id, Title, Category, NoticeCode, Description, Filter, isActive, LanguageCode, FromEmail, CcEmail, BccEmail, Subject, HtmlBody, Created, CreatedBy, LastUpdated, 
                         LastUpdatedBy
FROM            Isle_IOER.dbo.EmailNotice AS EmailNotice_1

GO
