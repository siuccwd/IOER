USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create VIEW [dbo].[Resource.GradeLevel] AS
SELECT [Id]
      ,[ResourceIntId]
      ,[GradeLevelId]
      ,[OriginalLevel]
      ,[Created]
      ,[CreatedById]
      ,[PathwaysEducationLevelId]
  FROM [Isle_IOER].[dbo].[Resource.GradeLevel]
GO


grant select on [Resource.GradeLevel] to public
go

