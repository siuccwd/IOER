USE [IsleContent]
GO

/****** Object:  View [dbo].[LibraryCollection.ResourceCountCSV]    Script Date: 06/14/2013 11:48:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[LibraryCollection.ResourceCountCSV]
AS 
SELECT LibraryId, LEFT(Titles, LEN(Titles) - 1) AS Titles
FROM (
	SELECT LibraryId, (
		SELECT isnull(itbl.Collection,'')+','
		FROM [LibraryCollection.ResourceCount] itbl
		WHERE itbl.LibraryId = tbl.LibraryId
		FOR XML PATH('')) Titles
	FROM [LibraryCollection.ResourceCount] tbl
	GROUP BY LibraryId) otbl
GO
grant select on [LibraryCollection.ResourceCountCSV] to public
go


