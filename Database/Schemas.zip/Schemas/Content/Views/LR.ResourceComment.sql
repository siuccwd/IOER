USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.ResourceComment]    Script Date: 05/16/2013 17:27:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

*/
/*
[LR.ResourceComment] - select LR comments . 
    
*/
Alter VIEW [dbo].[LR.ResourceComment] AS

SELECT [Id]
      ,[ResourceIntId]
      ,[Comment]
      ,[IsActive]
      ,[Created]
      ,[CreatedById]
      ,[CreatedBy]

  FROM Isle_IOER.[dbo].[Resource.Comment]
  where CreatedById is not null and [IsActive] = 1

GO


