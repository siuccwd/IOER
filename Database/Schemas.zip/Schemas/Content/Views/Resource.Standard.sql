USE [IsleContent]
GO

/****** Object:  View [dbo].[Resource.Standard]    Script Date: 05/31/2013 15:20:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

SELECT [Id]
      ,[ResourceIntId]
	  ,[ResourceVersionIntId],[SortTitle],[ResourceSortTitle]
      ,[StandardId],NotationCode
      ,[StandardUrl]
      ,[AlignedById]
      ,[AlignmentTypeCodeId], AlignmentType
      ,[AlignmentDegreeId], AlignmentDegree
      ,[Created]
      ,[CreatedById]
  FROM [dbo].[Resource.Standard]




*/

Alter VIEW [dbo].[Resource.Standard] AS

SELECT base.[Id] As ResourceStandardId
      ,base.[ResourceIntId]
	  ,lr.[ResourceVersionIntId],lr.[Title] As ResourceTitle,lr.[SortTitle] as ResourceSortTitle
      ,base.[StandardId]
      ,base.[StandardUrl]
	  ,stan.NotationCode
	  ,stan.Description
      ,isnull(base.[AlignedById],0)			As [AlignedById]
      ,isnull(base.[AlignmentTypeCodeId],0)	As [AlignmentTypeCodeId], isnull(alt.title,'') As AlignmentType
      ,isnull(base.[AlignmentDegreeId],0)	As [AlignmentDegreeId], isnull(ald.title,'') As AlignmentDegree
      ,base.[Created]
      ,isnull(base.[CreatedById],0) As [CreatedById]
  FROM [Isle_IOER].[dbo].[Resource.Standard] base
  Inner Join [Isle_IOER].[dbo].[StandardBody.Node]		stan	on base.StandardId = stan.id
  Left Join [Isle_IOER].[dbo].[Codes.AlignmentType]		alt		on base.[AlignmentTypeCodeId] = alt.id
  Left Join [Isle_IOER].[dbo].[Codes.AlignmentDegree]	ald		on base.[AlignmentDegreeId] = ald.id
  inner join [LR.ResourceVersion_Summary]				lr		on base.ResourceIntId = lr.ResourceIntId

GO




