USE [IsleContent]
GO

/****** Object:  View [dbo].[System.Process]    Script Date: 10/29/2014 10:25:41 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[System.Process]
AS
SELECT        Id, Code, Title, Description, Created, CreatedBy, LastUpdated, LastUpdatedBy, LastRunDate, StringParameter, IntParameter
FROM            Isle_IOER.dbo.[System.Process]

GO
