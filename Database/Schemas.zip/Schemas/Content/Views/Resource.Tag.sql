USE [IsleContent]
GO

/****** Object:  View [dbo].[Resource.Tag]    Script Date: 9/9/2014 12:05:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[Resource.Tag] AS
SELECT [Id]
      ,[ResourceIntId]
      ,TagValueId
      ,[Created]
      ,[CreatedById]
	  ,OriginalValue

  FROM [Isle_IOER].[dbo].[Resource.Tag]

GO
grant select on [Resource.Tag] to public
go


