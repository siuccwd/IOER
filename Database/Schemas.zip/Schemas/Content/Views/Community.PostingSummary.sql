USE [IsleContent]
GO

/****** Object:  View [dbo].[Community.PostingSummary]    Script Date: 3/6/2014 5:00:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [IsleContent]
GO

SELECT [CommunityId]
      ,[Community]
      ,[CreatedById]
      ,[UserFullName]
      ,[UserImageUrl]
	  ,Id, Created
      ,[Message], PostingStatus
	  ,PostingTypeId, PostingType
      ,[RelatedPostingId]
	  ,ChildPostings
  FROM [dbo].[Community.PostingSummary]
  where CommunityId= 1
  and RelatedPostingId= 0
  order by Created desc




*/

create VIEW [dbo].[Community.PostingSummary]
AS
SELECT        
	post.CommunityId, 
	dbo.Community.Title AS Community, 
	Community.OrgId,
	cp.CreatedById, 
	cp.Created,
	dbo.[LR.PatronOrgSummary].FullName As UserFullName, 
	isnull(dbo.[LR.PatronOrgSummary].ImageUrl, '') As UserImageUrl, 
	cp.Id As Id,
	cp.Id As PostingId,
	cp.PostingTypeId, cpt.Title as PostingType,
	cp.Message, cp.PostingStatus,
	isnull(cp.RelatedPostingId,0) As RelatedPostingId
	,case when isnull(childs.GrpCnt, 0) > 0 then childs.GrpCnt else 0 end As ChildPostings
FROM            
	dbo.Community 
INNER JOIN [Community.PostItem] post	ON dbo.Community.Id = post.CommunityId 
INNER JOIN [Community.Posting] cp		ON post.PostingId = cp.Id 
Inner join [Codes.PostingType] cpt		ON cp.PostingTypeId = cpt.Id
INNER JOIN dbo.[LR.PatronOrgSummary]	ON cp.CreatedById = dbo.[LR.PatronOrgSummary].UserId
Left JOIN (
	select RelatedPostingId, count(*) As GrpCnt from [Community.Posting] where RelatedPostingId is not null  group by RelatedPostingId
	) childs	ON cp.Id = childs.RelatedPostingId 

GO
grant select on [Community.PostingSummary] to public
go
