USE IsleContent
GO

/****** Object:  View [dbo].[Resource.TagSummary]    Script Date: 10/15/2014 5:47:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

SELECT top 1000
	 [ResourceTagId]
      ,base.[ResourceIntId], lr.title
      ,[TagValueId]
      ,[CodeId]
      ,[TagTitle]
      ,[CategoryId]
      ,[CategoryTitle]
      ,base.[created]
  FROM [dbo].[Resource.TagSummary] base
  inner join [dbo].[LR.ResourceVersion_SearchSummary] lr on base.ResourceIntId = lr.ResourceIntId 
  where CategoryTitle = 'Qualify for Jobs'
  and tagtitle = 'Cover Letters'
  order by created desc
GO


*/
CREATE VIEW [dbo].[Resource.TagSummary]
AS
SELECT        
	base.Id AS ResourceTagId, 
	base.ResourceIntId, 
	base.TagValueId, 
	ctv.CodeId, 
    ctv.Title AS TagTitle, 
	ctv.CategoryId, 
	ctv.AliasValues,
	ctc.Title AS CategoryTitle,
	base.created,
	base.CreatedById
FROM [Isle_IOER].[dbo].[Resource.Tag] base
	INNER JOIN [Isle_IOER].[dbo].[Codes.TagValue] ctv ON base.TagValueId = ctv.Id 
	INNER JOIN [Isle_IOER].[dbo].[Codes.TagCategory] ctc ON ctv.CategoryId = ctc.Id



GO


