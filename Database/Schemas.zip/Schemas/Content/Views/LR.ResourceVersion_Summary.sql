USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.ResourceVersion_Summary]    Script Date: 05/16/2013 17:20:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

select top 1000
 * from [LR.ResourceVersion_Summary]
where [ResourceUrl] like '%209.7.195.215%'


*/
/*
[LR.ResourceVersion_Summary] - select conditions of use from IOER database . 
    
*/
Alter VIEW [dbo].[LR.ResourceVersion_Summary] AS
SELECT [ResourceUrl]
      ,[Id]
      ,[ResourceIntId]
      ,[ResourceId]
    --  ,[ResourceVersionId]
      ,[ResourceVersionIntId]
      ,[Title]
      ,[Description]
      ,[Publisher]
      ,[Creator]
      ,[Rights]
      ,[ViewCount]
      ,[FavoriteCount]
      ,[AccessRightsId]
      ,[AccessRights]
      ,[InteractivityTypeId]
      ,[TypicalLearningTime]
      ,[Modified]
      ,[Submitter]
      ,[SortTitle]
	  ,PublishedById
  FROM [Isle_IOER].[dbo].[Resource.Version_Summary]
GO
grant select on [LR.ResourceVersion_Summary] to public
go


