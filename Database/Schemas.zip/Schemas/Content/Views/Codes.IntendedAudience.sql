USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create VIEW [dbo].[Codes.IntendedAudience] AS
SELECT [Id]
      ,[Title]
      ,[IsActive]
      ,[WarehouseTotal]
  FROM [Isle_IOER].[dbo].[Codes.AudienceType]
GO


grant select on [Codes.IntendedAudience] to public
go

