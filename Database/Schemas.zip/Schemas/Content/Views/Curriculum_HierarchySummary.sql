USE [IsleContent]
GO

/****** Object:  View [dbo].[Curriculum_HierarchySummary]    Script Date: 9/12/2014 5:44:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [IsleContent]
GO

SELECT [CurriculumId]
      ,[Curriculum]
      ,[FormattedTitle]
      ,[FormattedFullTitle]
      ,[ModuleId]
      ,[Module]
      ,[ModuleSortOrder]
      ,[UnitId]
      ,[Unit]
      ,[UnitSortOrder]
      ,[LessonId]
      ,[Lesson]
      ,[LessonSortOrder]
      ,[ActivityId]
      ,[Activity]
      ,[ActivitySortOrder]
  FROM [dbo].[Curriculum_HierarchySummary]
GO


*/
ALTER VIEW [dbo].[Curriculum_HierarchySummary]
AS

SELECT        
curriculum.Id As CurriculumId, 
curriculum.Title AS Curriculum, 
Module.Title + ' - ' + Unit.Title + ' - ' + Lesson.Title As FormattedTitle,
'Module: ' + Module.Title + ' - Unit: ' + Unit.Title + ' - Lesson: ' + Lesson.Title As FormattedFullTitle,
Module.Id AS ModuleId, Module.Title AS Module, 
Module.SortOrder AS ModuleSortOrder, 
                         
Unit.Id AS UnitId, Unit.Title AS Unit, 
Unit.SortOrder AS UnitSortOrder, 

Lesson.Id AS LessonId,  Lesson.Title AS Lesson, 
Lesson.SortOrder AS LessonSortOrder,

Activity.Id AS ActivityId,  Activity.Title AS Activity, 
Activity.SortOrder AS ActivitySortOrder

--,dbo.ContentConnector_ChildSummary.ContentId AS ChildContentId,
--dbo.ContentConnector_ChildSummary.ContentType, 
--dbo.ContentConnector_ChildSummary.Title as ResourceTitle, 
--dbo.ContentConnector_ChildSummary.Summary
FROM            
	dbo.[Content] AS curriculum 
	INNER JOIN dbo.[Content] AS Module ON curriculum.Id = Module.ParentId 
	Left JOIN dbo.[Content] AS Unit ON Module.Id = Unit.ParentId AND (Module.TypeId = 52) 
	Left JOIN dbo.[Content] AS Lesson ON Unit.Id = Lesson.ParentId AND (Unit.TypeId = 54) 
	Left JOIN dbo.[Content] AS Activity ON Lesson.Id = Activity.ParentId AND (Lesson.TypeId = 56)
	--Left JOIN dbo.ContentConnector_ChildSummary ON Lesson.Id = dbo.ContentConnector_ChildSummary.ConnectorParentId
WHERE        
	(curriculum.TypeId = 50) 





GO


