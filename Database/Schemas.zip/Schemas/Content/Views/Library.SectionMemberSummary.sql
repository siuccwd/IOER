USE [IsleContent]
GO



/****** Object:  View [dbo].[Library.SectionMemberSummary]    Script Date: 2/5/2014 11:11:32 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[Library.SectionMemberSummary]'))
DROP VIEW [dbo].[Library.SectionMemberSummary]
GO

/****** Object:  View [dbo].[Library.SectionMemberSummary]    Script Date: 2/5/2014 11:11:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[Library.SectionMemberSummary]
AS

SELECT        
	base.Id, 
	ls.LibraryId, 
	dbo.Library.Title AS Library,
	base.LibrarySectionId,
	ls.Title As [Collection],
	base.UserId, 
	acct.FullName, 
	acct.SortName,
	acct.Email, 
	base.MemberTypeId, 
	code.Title AS MemberType, 
	base.Created, 
	base.CreatedById, 
	base.LastUpdated, 
	base.LastUpdatedById

FROM  dbo.[Library.SectionMember] base
INNER JOIN dbo.[Library.Section] ls ON base.LibrarySectionId = ls.Id
INNER JOIN dbo.[Codes.LibraryMemberType] code ON base.MemberTypeId = code.Id 
INNER JOIN dbo.[LR.PatronOrgSummary] acct ON base.UserId = acct.UserId 
INNER JOIN dbo.Library ON ls.LibraryId = dbo.Library.Id

GO
grant select on [Library.MemberSummary] to public
go
