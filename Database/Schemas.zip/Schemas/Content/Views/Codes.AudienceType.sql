USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

alter VIEW [dbo].[Codes.AudienceType] AS
SELECT [Id]
      ,[Title]
      ,[NsdtTitle]
      ,[Description]
      ,[IsPathways]
      ,[IsActive]
      ,[IsPublishingRole]
      ,[WarehouseTotal]
  FROM [Isle_IOER].[dbo].[Codes.AudienceType]
GO


grant select on [Codes.AudienceType] to public
go

