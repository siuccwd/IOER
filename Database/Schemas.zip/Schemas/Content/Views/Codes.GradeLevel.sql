USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[Codes.GradeLevel] AS
SELECT [Id]
      ,[Title]
      ,[NsdlTitle]
      ,[AgeLevel]
      ,[Description]
      ,[IsPathwaysLevel]
      ,[IsK12Level]
      ,[IsActive]
      ,[AlignmentUrl]
      ,[SortOrder]
      ,[WarehouseTotal]
      ,[GradeRange]
      ,[GradeGroup]
      ,[PathwaysEducationLevelId]
  FROM [Isle_IOER].[dbo].[Codes.GradeLevel]
GO


grant select on [Codes.GradeLevel] to public
go

