USE [IsleContent]
GO

/****** Object:  View [dbo].[ContentConnector_ChildSummary]    Script Date: 3/18/2014 6:09:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*



SELECT distinct [ContentConnectorId]
      ,[ConnectorParentId]
      --,[ParentHierarchyFull]
      --,[ParentHierarchy]
      ,[NbrParents]
      ,[ContentId]
      ,base.[ParentId]
      ,base.[TypeId]
	  ,parent.typeId as ParentTypeId
      ,[ContentType]
      ,base.[Title]
      --,[Summary]
      --,[Description]
      ,base.[StatusId]
      ,[ContentStatus]
      --,[PrivilegeTypeId]
      --,[SortOrder]
      --,[ContentPrivilege]      ,[ConditionsOfUseId]      ,[ResourceVersionId]
      --,[ResourceUrl]
      --,[ResourceIntId]
      --,[IsPublished]
      --,[UseRightsUrl]
      --,[IsOrgContentOwner]
      --,[IsActive]
      --,[OrgId]
      --,[DocumentRowId]
      --,[DocumentUrl]
      --,[Created]      ,[CreatedById]      ,[LastUpdated]      ,[LastUpdatedById]
      --,[ApprovedById]      ,[Approved]
      --,[ContentRowId]
      --,[RowId]
  FROM [dbo].[ContentConnector_ChildSummary] base
  inner join [content] parent on base.ConnectorParentId = parent.Id
  order by 1, 2



*/
/* =============================================
Description: Content summary, convenience view for document type content items relates to a parent item
	base.TypeId= 40  


  ------------------------------------------------------
Modifications
14-03-17 mparsons - added 
14-09-03 mparsons - removed join to Curriculum_HierarchySummary. The latter was only handling a lesson parent. Need to handle at multiple levels
*/

ALTER VIEW [dbo].[ContentConnector_ChildSummary]
AS

SELECT     
	cc.Id As ContentConnectorId,
	cc.ParentId As ConnectorParentId,
	--chs.FormattedFullTitle  As ParentHierarchyFull,
	--chs.FormattedTitle As ParentHierarchy,
		'TBD'  As ParentHierarchyFull,
	'TBD' As ParentHierarchy,
	isnull(parentGrp.NbrParents, 0) as NbrParents,
	base.ContentId As ContentId,
	isnull(base.ParentId, 0) As ParentId,
	base.TypeId, dbo.ContentType.Title AS ContentType, 
	isnull(base.Title,'') As Title, 
	isnull(base.Summary,'') As Summary, 
	isnull(base.Description,'') as Description, 
	base.StatusId, dbo.[Codes.ContentStatus].Title AS ContentStatus, 
	case when PrivilegeTypeId is null then 1
	else PrivilegeTypeId end as PrivilegeTypeId,
	isnull(base.SortOrder,10) As SortOrder,
	case when PrivilegeTypeId is null then 'Public'
	else dbo.[Codes.ContentPrivilege].Title end as ContentPrivilege,  
	isnull(ConditionsOfUseId,0) as ConditionsOfUseId, 
	isnull(ResourceVersionId, 0) AS ResourceVersionId,
	base.ResourceUrl,
	base.ResourceIntId,

	isnull(base.IsPublished, 0) As IsPublished, 
	isnull(base.UseRightsUrl,'') as UseRightsUrl,
	isnull(IsOrgContentOwner, 0) as IsOrgContentOwner, 
	isnull(base.IsActive, 1) As IsActive,
	isnull(base.OrgId, 0) as OrgId,
	base.DocumentRowId,   
	isnull(base.DocumentUrl, '') as DocumentUrl,
 
	base.Created, base.CreatedById, 
	base.LastUpdated, base.LastUpdatedById, 
	base.ApprovedById, base.Approved
	,base.ContentRowId 
	,base.ContentRowId As RowId
FROM    dbo.[Content.Connector] cc
INNER JOIN dbo.[ContentSummaryView] base ON cc.ChildId = base.ContentId      
  
  INNER JOIN dbo.[Codes.ContentStatus]    ON base.StatusId = dbo.[Codes.ContentStatus].Id 
  INNER JOIN dbo.ContentType              ON base.TypeId = dbo.ContentType.Id 
  Left JOIN dbo.[Codes.ContentPrivilege]  ON base.PrivilegeTypeId = dbo.[Codes.ContentPrivilege].Id 
  --Inner join Curriculum_HierarchySummary chs on 
		--	(cc.ParentId = chs.ModuleId or 
		--	cc.ParentId = chs.UnitId or 
		--	cc.ParentId = chs.LessonId)
  Left Join (
	select ChildId, count(*) As NbrParents from [Content.Connector] group by ChildId) 
		AS parentGrp on cc.ChildId = parentGrp.ChildId

where base.TypeId= 40  
--order by 1,2

GO


