USE [IsleContent]
GO

Alter VIEW [dbo].[ContentConnector_DistinctStandards]
AS
SELECT 
--[ContentConnectorId]
     [ConnectorParentId]

      ,base.[ContentId]
     -- ,[ParentId]
     -- ,[TypeId]
    --  ,[ContentType]
     -- ,[Title]

	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType]
      ,[StandardUsage]

  FROM [dbo].[ContentConnector_ChildSummary] base
inner join .[dbo].[ContentStandard_Summary] crcCss on base.[ContentId] = crcCss.ContentId
go 
grant select on [ContentConnector_DistinctStandards] to public
go


