USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.Resource.Evaluations]    Script Date: 9/7/2014 4:10:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[LR.Resource.Evaluations] AS
  select distinct  id, [ResourceIntId],Created, [CreatedById], isnull(Score,0) As Score
  --,count(*) as REcounts
  FROM [Isle_IOER].[dbo].[Resource.Evaluation] 

GO
grant select on [LR.Resource.Evaluations] to public
go


