
/*
select distinct TagValueId  
from Library_UniqueTagValues
	where 
		LibraryId	= 0 
	OR	SectionId			= 2	


*/

Alter view Library_UniqueTagValues
as 

	select distinct lsec.LibraryId, lsec.Id As SectionId, res.TagValueId  
	from [dbo].[Resource.Tag] res 
	inner join dbo.[Library.Resource] lres on res.ResourceIntId = lres.ResourceIntId 
	INNER JOIN [dbo].[Library.Section] lsec ON lres.LibrarySectionId = lsec.Id 
go
grant select on Library_UniqueTagValues to public
go
