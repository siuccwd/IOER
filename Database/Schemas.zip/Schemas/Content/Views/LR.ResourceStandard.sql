USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create VIEW [dbo].[LR.ResourceStandard] AS
SELECT [Id]
      ,[ResourceIntId]
      ,[StandardId]
      ,[StandardUrl]
      ,[AlignedById]
      ,[AlignmentTypeCodeId]
      ,[AlignmentDegreeId]
      ,[Created]
      ,[CreatedById]
  FROM [Isle_IOER].[dbo].[Resource.Standard]


GO
grant select on [LR.ResourceStandard] to public
go

