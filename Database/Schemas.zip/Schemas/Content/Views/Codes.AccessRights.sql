USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[Codes.AccessRights] AS
SELECT [Id]
      ,[Title]
      ,[Description]
      ,[IsActive]
      ,[WarehouseTotal]
      ,[SortOrder]
  FROM Isle_IOER.[dbo].[Codes.AccessRights]

GO
grant select on [Codes.AccessRights] to public
go

