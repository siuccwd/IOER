USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.PatronOrgSummary]    Script Date: 04/04/2013 12:55:03 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[LR.PatronOrgSummary]'))
DROP VIEW [dbo].[LR.PatronOrgSummary]
GO


/****** Object:  View [dbo].[LR.PatronOrgSummary]    Script Date: 04/04/2013 12:55:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
SELECT [UserId]
  ,[UserName]
  ,SortName
  ,[FullName]
  ,[OrganizationId]
  ,[Organization]
  ,[FirstName]
  ,[LastName]
  ,[Email],UserProfileUrl, ImageUrl
  ,[JobTitle]
  ,[RoleProfile]
   ,ImageUrl 
	  ,UserRowId
	   ,Created, LastUpdated
  FROM [IsleContent].[dbo].[LR.PatronOrgSummary]
  where OrganizationId = 1
  order by LastName
 

*/
/*
[LR.PatronOrgSummary] - select User summary . 
    
*/
Create VIEW [dbo].[LR.PatronOrgSummary] AS
SELECT base.[Id] As UserId
      ,base.[UserName]
      ,base.[FirstName],base.[LastName], base.[FullName], base.SortName
      ,base.[Email]
      ,base.IsActive,PublishingRole
      ,base.[JobTitle]
      ,base.[RoleProfile]
	  ,base.ImageUrl 
	  ,base.UserProfileUrl
	  ,base.UserRowId
      ,base.[OrganizationId]
      ,case when org.Id is not null then org.Name
        else 'none' end As Organization
        ,base.Created, base.LastUpdated
  FROM [Isle_IOER].[dbo].[Patron_Summary] base
  Left join [Gateway].[dbo].[Organization] org on base.OrganizationId = org.Id
  
GO
grant select on [LR.PatronOrgSummary] to public
go







