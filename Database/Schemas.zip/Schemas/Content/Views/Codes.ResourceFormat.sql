USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[Codes.ResourceFormat] AS
SELECT [Id]
      ,[Title]
      ,[Description]
      ,[IsIsleCode]
      ,[IsActive]
      ,[WarehouseTotal]
      ,[OrigTitle]
  FROM Isle_IOER.[dbo].[Codes.ResourceFormat]
GO


grant select on [Codes.ResourceFormat] to public
go

