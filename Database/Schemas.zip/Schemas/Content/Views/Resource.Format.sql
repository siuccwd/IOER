USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create VIEW [dbo].[Resource.Format] AS
SELECT [RowId]
      ,[ResourceId]
      ,[OriginalValue]
      ,[CodeId]
      ,[Created]
      ,[CreatedById]
      ,[ResourceIntId]
  FROM [Isle_IOER].[dbo].[Resource.Format]
GO


grant select on [Resource.Format] to public
go

