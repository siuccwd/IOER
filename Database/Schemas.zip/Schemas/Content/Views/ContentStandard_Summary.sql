USE [IsleContent]
GO

/****** Object:  View [dbo].[ContentStandard_Summary]    Script Date: 10/2/2014 4:38:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

SELECT [Id]
      ,[ContentIntId]
	  ,[ContentVersionIntId],.[Title],[SortTitle]
      ,[StandardId],NotationCode
      ,[StandardUrl]
      ,[AlignedById]
      ,[AlignmentTypeCodeId]
      ,[AlignmentDegreeId]
      ,[Created]
      ,[CreatedById]
  FROM [dbo].[Content.Standard]


SELECT [ContentStandardId]
      ,[ContentId], base.TypeId, base.ParentId
      ,[StandardId]
      ,[StandardUrl]
      ,[NotationCode]
      ,base.[Description]
      ,base.[Created]
      ,base.[CreatedById]
      ,base.[LastUpdated]
      ,base.[LastUpdatedById]
      ,[AlignmentTypeCodeId]
      ,[AlignmentType]
      ,[UsageTypeId]
      ,[StandardUsage]
  FROM [dbo].[ContentStandard_Summary] base
inner join Content c on base.Contentid = c.id
where base.TypeId = 40
order by ContentId, NotationCode




*/

Create VIEW [dbo].[ContentStandard_Summary] AS

SELECT base.[Id] As ContentStandardId
      ,base.[ContentId], c.TypeId, c.ParentId
      ,base.[StandardId]
      ,stan.[StandardUrl]
	  ,stan.NotationCode
	  ,stan.Description
	  ,base.[Created]
      ,isnull(base.[CreatedById],0)			As [CreatedById]
	  ,base.[LastUpdated]
      ,isnull(base.[LastUpdatedById],0)		As [LastUpdatedById]
      ,isnull(base.[AlignmentTypeCodeId],1)	As [AlignmentTypeCodeId]
	  ,isnull(alt.title,'Teaches') As AlignmentType
      ,isnull(base.[UsageTypeId],0)	As [UsageTypeId], isnull(ald.title,'') As StandardUsage

  FROM [dbo].[Content.Standard] base
  Inner Join Content c on base.ContentId = c.Id
  Inner Join [Isle_IOER].[dbo].[StandardBody.Node]		stan	on base.StandardId = stan.id
  Left Join [Isle_IOER].[dbo].[Codes.AlignmentType]		alt		on base.[AlignmentTypeCodeId] = alt.id
  Left Join [dbo].[Codes.StandardUsage]					ald		on base.UsageTypeId = ald.id



GO


