USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.ResourceVersion_SearchSummary]    Script Date: 6/30/2014 6:42:22 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*


SELECT top 1000
	 [ResourceUrl]
      ,[Id]
      ,[ResourceIntId]
      ,[ResourceVersionIntId]
      ,[Title]
      ,[Description]
	  ,keywords
	  ,Subjects
     -- ,[Publisher]      ,[Creator]      ,[Rights]      ,[ViewCount]      ,[FavoriteCount]
    --  ,[AccessRightsId]      ,[AccessRights]
     -- ,[InteractivityTypeId]      ,[TypicalLearningTime]
     -- ,[Modified]
     -- ,[Submitter]
      ,[SortTitle]
      ,[PublishedById]
  FROM [dbo].[LR.ResourceVersion_SearchSummary]
where 
ResourceIntId = 558
and (
keywords like '%math%'
or Subjects like '%math%'
)


where Subjects like '%technology%'


where [ResourceUrl] like '%209.7.195.215%'


*/
/*
[LR.ResourceVersion_SearchSummary] - select resources with a csv subjects list from IOER database . 
    
*/
Alter VIEW [dbo].[LR.ResourceVersion_SearchSummary] AS
SELECT [ResourceUrl]
      ,base.[Id]
      ,base.[ResourceIntId]
      ,[ResourceVersionIntId]
      ,[Title]
      ,[Description]
      ,[Publisher]
      ,[Creator]
      ,[Rights]
      ,[ViewCount]
      ,[FavoriteCount]
      ,[AccessRightsId],[AccessRights]
      ,[InteractivityTypeId]
      ,[TypicalLearningTime]
      ,[Modified]
      ,[Submitter]
      ,[SortTitle]
	  ,PublishedById
	  ,isnull(subjects.Subjects,'') As Subjects
	  ,isnull(keywords.Keywords,'') As Keywords
  FROM [Isle_IOER].[dbo].[Resource.Version_Summary] base
  Left Join [ISLE_IOER].[dbo].[Resource.TagSubjectsCsvList] subjects on base.ResourceIntId = subjects.ResourceIntId
  Left Join [ISLE_IOER].[dbo].[Resource.KeywordsCsvList] keywords on base.ResourceIntId = keywords.ResourceIntId

GO

grant select on [LR.ResourceVersion_SearchSummary] to public
go


