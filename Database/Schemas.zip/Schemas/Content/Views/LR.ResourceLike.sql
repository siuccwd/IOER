USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.ResourceLikes]    Script Date: 06/20/2013 10:53:46 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[LR.ResourceLike]'))
DROP VIEW [dbo].[LR.ResourceLike]
GO

/****** Object:  View [dbo].[LR.ResourceLike]    Script Date: 06/20/2013 10:53:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
SELECT  [Id]
      ,[ResourceIntId]
      ,[IsLike]
      ,[Created]
      ,[CreatedById]
  FROM [IsleContent].[dbo].[LR.ResourceLike]

SELECT  [Id]
      ,[ResourceIntId]
      ,[IsLike]
      ,[Created]
      ,[CreatedById]
  FROM [IsleContent].[dbo].[LR.ResourceLike]


*/
/*
[LR.ResourceLike] - select LR likes . 
    
*/
CREATE VIEW [dbo].[LR.ResourceLike] AS

SELECT [Id]
      ,[ResourceIntId]
      ,[IsLike]
      ,[Created]
      ,[CreatedById]
      
  FROM Isle_IOER.[dbo].[Resource.Like]

GO


