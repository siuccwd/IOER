


/*
USE [IsleContent]
GO

SELECT 
--distinct 
[Id]
      ,[Title]
      ,[CodeId],CategoryId
  FROM [dbo].[Library.ResourceTagUniqueFilters]
WHERE CategoryId = 19
And (LibraryId	= 1 	OR	SectionId = 0	)
Order by 2


*/

Alter view [Library.ResourceTagUniqueFilters]
as 
Select distinct codes.[TagValueId]  as [Id], codes.Title, codes.CodeId, codes.CategoryId, 
lres.LibraryId, lres.SectionId
FROM dbo.[Codes.TagCategoryValue_Summary] codes
inner join dbo.Library_UniqueTagValues lres on codes.[TagValueId] = lres.[TagValueId] 

go
grant select on [Library.ResourceTagUniqueFilters] to public
go

