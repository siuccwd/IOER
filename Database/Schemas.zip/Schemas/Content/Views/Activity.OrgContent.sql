USE [IsleContent]
GO

/****** Object:  View [dbo].[Activity.OrgContent]    Script Date: 1/20/2015 9:30:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
SELECT [Activity]
      ,[Event]
      ,count(*) as GroupCount
  FROM [dbo].[ActivityLog]
group by [Activity]
      ,[Event]
Order by [Activity]
      ,[Event]

*/

Create VIEW [dbo].[Activity.OrgContent] AS

SELECT base.[Id]
      ,base.[CreatedDate]
      ,base.[ActivityType]
      ,base.[Activity]
      ,base.[Event]
      ,base.[Comment]
      ,base.[TargetUserId]
      ,base.[ActionByUserId]
      ,base.[ActivityObjectId]
		,org.Name
		,obj.Title
  FROM [dbo].[ActivityLog] base
inner join Content obj on base.ActivityObjectId = obj.id
inner join [Gateway.OrgSummary] org on obj.OrgId = org.Id
where Activity in ( 'Content', 'Content Download', 'Learning List', 'Node: Child Node' )



GO
grant select on [Activity.OrgContent] to public
go


