USE [IsleContent]
GO

/****** Object:  View [dbo].[Gateway.OrgSummary]    Script Date: 4/1/2014 5:05:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

SELECT [OrgMbrId]
      ,[OrgId]
      ,[Organization]
      ,[UserId]
      ,[FirstName]
      ,[LastName]
      ,[Email]
      ,[OrgMemberTypeId]
      ,[OrgMemberType]
      ,[MemberAdded]
      ,[BaseOrgId]
      ,[BaseOrganization]
  FROM [dbo].[Gateway.Org_MemberSummary]
GO



*/

/*
[Gateway.Org_MemberSummary] - select org member summary . 
    
*/
Create VIEW [dbo].[Gateway.Org_MemberSummary] AS

SELECT [OrgMbrId]
      ,[OrgId]
      ,[Organization]
      ,[UserId]
      ,[FirstName]
      ,[LastName]
      ,[Email]
      ,[OrgMemberTypeId]
      ,[OrgMemberType]
      ,[MemberAdded]
      ,[BaseOrgId]
      ,[BaseOrganization]
  FROM Gateway.[dbo].[Organization_MemberSummary]
GO

grant select on [Gateway.Org_MemberSummary] to public
GO


