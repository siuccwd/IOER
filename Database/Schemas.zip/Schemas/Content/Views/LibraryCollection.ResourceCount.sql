USE [IsleContent]
GO

/****** Object:  View [dbo].[LibraryCollection.ResourceCount]    Script Date: 06/14/2013 11:48:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
SELECT [LibraryId]
      ,[Library]
      ,[Collection]
      ,[NbrResources]
  FROM [dbo].[LibraryCollection.ResourceCount]
order by 2, 3




*/
Alter VIEW [dbo].[LibraryCollection.ResourceCount]
AS
SELECT     LibraryId, Library, Title + ' (' + CONVERT(varchar(10), NbrResources) + ')' AS [Collection], NbrResources
FROM         (SELECT     l.Id AS LibraryId, l.Title As Library, ls.Title, ISNULL(COUNT(lr.ResourceIntId), 0) AS NbrResources
                       FROM          dbo.Library AS l INNER JOIN
                                              dbo.[Library.Section] AS ls ON l.Id = ls.LibraryId LEFT OUTER JOIN
                                              dbo.[Library.Resource] AS lr ON ls.Id = lr.LibrarySectionId
                       GROUP BY l.Id, l.Title, ls.Title) AS ltbl

GO
grant select on [LibraryCollection.ResourceCount] to public
go
