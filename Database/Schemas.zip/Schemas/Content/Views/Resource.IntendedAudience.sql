USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter VIEW [dbo].[Resource.IntendedAudience] AS
SELECT [RowID]
      ,[AudienceId]
	  ,[AudienceId] As IntendedAudienceId
      ,[CreatedById]
      ,[Created]
      ,[ResourceIntId]
  FROM [Isle_IOER].[dbo].[Resource.IntendedAudience]
GO


grant select on [Resource.IntendedAudience] to public
go

