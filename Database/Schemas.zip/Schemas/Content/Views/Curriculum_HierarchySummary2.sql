USE [IsleContent]
GO

/****** Object:  View [dbo].[Curriculum_HierarchySummary2]    Script Date: 9/12/2014 5:44:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [IsleContent]
GO

SELECT [CurriculumId]
      ,[Curriculum]
      ,[FormattedTitle]
      ,[FormattedFullTitle]
      ,[Level2Id]
      ,[Level2]
      ,[Level2SortOrder]
      ,[Level3Id]
      ,[Level3]
      ,[Level3SortOrder]
      ,[Level4Id]
      ,[Level4]
      ,[Level4SortOrder]
      ,[Level5Id]
      ,[Level5]
      ,[Level5SortOrder]
  FROM [dbo].[Curriculum_HierarchySummary2]
where [CurriculumId] = 2207
order by [Level2SortOrder], Level2Id, [Level3SortOrder], Level3Id, [Level4SortOrder]


*/
Create VIEW [dbo].[Curriculum_HierarchySummary2]
AS

SELECT        
curriculum.Id As CurriculumId, 
curriculum.Title AS Curriculum, 
Level2.Title + ' - ' + isnull(Level3.Title,'') + ' - ' + isnull(Level4.Title,'') As FormattedTitle,
'Level2: ' + Level2.Title + ' - Level3: ' + isnull(Level3.Title,'') + ' - Level4: ' + isnull(Level4.Title,'') As FormattedFullTitle,
Level2.Id AS Level2Id, Level2.Title AS Level2, 
Level2.SortOrder AS Level2SortOrder, 
                         
Level3.Id AS Level3Id, Level3.Title AS Level3, 
Level3.SortOrder AS Level3SortOrder, 

Level4.Id AS Level4Id,  Level4.Title AS Level4, 
Level4.SortOrder AS Level4SortOrder,

Level5.Id AS Level5Id,  Level5.Title AS Level5, 
Level5.SortOrder AS Level5SortOrder

FROM            
	dbo.[Content] AS curriculum 
	Left JOIN dbo.[Content] AS Level2 ON curriculum.Id = Level2.ParentId 
	Left JOIN dbo.[Content] AS Level3 ON Level2.Id = Level3.ParentId AND (Level2.TypeId = 52) 
	Left JOIN dbo.[Content] AS Level4 ON Level3.Id = Level4.ParentId AND (Level3.TypeId = 54) 
	Left JOIN dbo.[Content] AS Level5 ON Level4.Id = Level5.ParentId AND (Level4.TypeId = 56)
	
WHERE        
	(curriculum.TypeId = 50) 





GO


