USE [IsleContent]
GO


/****** Object:  View [dbo].[Content_DocumentSummary]    Script Date: 12/11/2014 7:53:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [IsleContent]
GO

SELECT [ContentId]
      ,[Title]
	  ,[Created]
      ,[FilePath]
	  ,replace(replace(replace([DocumentUrl], FileName, ''),'/','\'),'\Content', 'F:\Content')  As NewOne
      ,[FileName]
      ,[DocumentPath]
      ,[DocumentUrl]
	  
      ,[DocumentRowId]
      ,[MimeType]
      
  FROM [dbo].[Content.DocumentSummary]

where FilePath is null



SELECT [ContentId]
      ,[ParentId]
      ,[TypeId]
      ,[ContentType]
      ,base.[Title]
      ,base.[Summary]
      ,base.[Description]
      ,[StatusId]
      ,[ContentStatus]
      ,[PrivilegeTypeId]
      ,[ContentPrivilege]
      ,[ConditionsOfUseId]
      ,[ConditionsOfUse]
      ,[ConditionsOfUseUrl]
      ,[ConditionsOfUseIconUrl]
      ,[ResourceVersionId]
      ,[ResourceUrl]
      ,[ResourceIntId]
      ,[IsPublished]
      ,[UseRightsUrl]
      ,[IsOrgContentOwner]
      ,[IsActive]
      ,[DocumentUrl]
      ,[DocumentRowId]
      ,[SortOrder]
      ,[Timeframe]
      ,[ImageUrl]
      ,[OrgId]
      ,[Organization]
      ,[ParentOrgId]
      ,[ParentOrganization]
      ,base.[Created]
      ,base.[CreatedById]
      ,[Author]
      ,[AuthorKey]
      ,[OrgKey]
      ,base.[LastUpdated]
      ,base.[LastUpdatedById]
      ,[LastUpdatedBy]

      ,[ContentRowId]

	,dbo.[Document.Version].FilePath, 
	dbo.[Document.Version].FileName, 
	case when isnull(dbo.[Document.Version].FilePath,'') <> '' then
	isnull(dbo.[Document.Version].FilePath,'') + '\' + dbo.[Document.Version].FileName
	else '' end As DocumentPath, 
	--base.DocumentUrl, 
	--base.DocumentRowId, 
	dbo.[Document.Version].MimeType
	--,dbo.[Document.Version].Created

  FROM [dbo].[ContentSummaryView] base
INNER JOIN dbo.[Document.Version] ON base.DocumentRowId = dbo.[Document.Version].RowId



*/
Create VIEW [dbo].[Content.DocumentSummary]
AS



SELECT        
	base.Id AS ContentId, 
	base.ParentId,
	base.TypeId, dbo.ContentType.Title AS ContentType, 
	base.Title, 
	base.SortOrder,
	base.StatusId, 
	base.OrgId,
	case 
		when isnull(base.Summary, '') <> '' then base.Summary
		when isnull(base.Description, '') <> '' then base.Description
		else '' end As Description,
	dbo.[Document.Version].FilePath, 
	dbo.[Document.Version].FileName, 
	case when isnull(dbo.[Document.Version].FilePath,'') <> '' then
		isnull(dbo.[Document.Version].FilePath,'') + '\' + dbo.[Document.Version].FileName
		else '' end As DocumentPath, 
	base.DocumentUrl, 
	base.DocumentRowId, 
	dbo.[Document.Version].MimeType,
	dbo.[Document.Version].Created
	,base.CreatedById
	,base.PrivilegeTypeId
FROM dbo.[Content] base
INNER JOIN dbo.ContentType              ON base.TypeId = dbo.ContentType.Id 
INNER JOIN dbo.[Document.Version] ON base.DocumentRowId = dbo.[Document.Version].RowId

GO

grant select on [Content.DocumentSummary] to public
go