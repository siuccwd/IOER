USE [IsleContent]
GO

/****** Object:  View [dbo].[Content.TagSummary]    Script Date: 11/14/2014 1:31:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

SELECT top 1000
	 [ContentTagId]
      ,[ContentId]
      ,[TagValueId]
      ,[CodeId]
      ,[TagTitle]
      ,[CategoryId]
      ,[CategoryTitle]
      ,[created]
  FROM [dbo].[Content.TagSummary]
  where ContentId= 2207
  order by created desc
GO



*/
Create VIEW [dbo].[Content.TagSummary]
AS
SELECT        
	base.Id AS ContentTagId, 
	base.ContentId, 
	base.TagValueId, 
	ctv.CodeId, 
    ctv.Title AS TagTitle, 
	ctv.CategoryId, 
	ctv.AliasValues,
	ctc.Title AS CategoryTitle,
	base.Created,
	base.CreatedById
FROM [Content.Tag] base
	INNER JOIN [Isle_IOER].[dbo].[Codes.TagValue] ctv ON base.TagValueId = ctv.Id 
	INNER JOIN [Isle_IOER].[dbo].[Codes.TagCategory] ctc ON ctv.CategoryId = ctc.Id




GO

grant select on [Content.TagSummary] to public
go



