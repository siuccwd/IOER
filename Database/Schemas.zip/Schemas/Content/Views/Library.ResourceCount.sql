USE [IsleContent]
GO

/****** Object:  View [dbo].[Library.ResourceCount]    Script Date: 6/21/2014 4:45:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [IsleContent]
GO

SELECT [LibraryId]
      ,[Library]
      ,[LibraryResourceCount]
  FROM [dbo].[Library.ResourceCount]
--where libraryId = 25
order by 3 desc


*/
Create  VIEW [dbo].[Library.ResourceCount] AS

SELECT [LibraryId], Library
      ,sum(NbrResources) As LibraryResourceCount
  FROM [dbo].[LibraryCollection.ResourceCount]
  group by LibraryId, Library
  --order by 3 desc
  

GO


