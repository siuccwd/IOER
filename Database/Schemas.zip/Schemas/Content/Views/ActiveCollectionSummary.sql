USE IsleContent
GO

/****** Object:  View [dbo].[ActiveCollectionSummary]    Script Date: 1/20/2014 4:57:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [IsleContent]
GO

SELECT [LibraryId]
      ,[Library]
      ,[LibraryTypeId]
      ,[Id]
      ,[Collection]
      ,[NbrResources]
      ,[LastUpdated]
  FROM [dbo].[ActiveCollectionSummary]
Order BY LIbrary, Collection



*/
Create VIEW [dbo].[ActiveCollectionSummary] AS
	SELECT 
		lib.Id As LibraryId, lib.Title As Library, 
		LibraryTypeId, lt.Title as LibraryType,
		libsec.Id, libsec.Title As [Collection], 
		libsec.imageUrl,
		isnull(colResCount.ResCount, 0) AS NbrResources, 
		colResUpdated.LastUpdated
	FROM dbo.[Library] lib
	inner join [Library.Type] lt on lib.LibraryTypeId = lt.Id
	INNER JOIN dbo.[Library.Section] libsec on lib.Id = libsec.LibraryId
	Left Join (Select LibrarySectionId, count(*) As ResCount from [Library.Resource] group by LibrarySectionId ) 
		As colResCount on libsec.id = colResCount.LibrarySectionId
	Left Join (Select LibrarySectionId, MAX(Created) As LastUpdated from [Library.Resource] group by LibrarySectionId ) 
		As colResUpdated on libsec.id = colResUpdated.LibrarySectionId

	WHERE lib.IsActive = 1
	
GO
grant select on [ActiveCollectionSummary] to public
go


