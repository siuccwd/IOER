USE [IsleContent]
GO

/****** Object:  View [dbo].[Library.FollowingSummary]    Script Date: 6/20/2014 4:52:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

SELECT [Library]
      ,[LibraryType]
      ,[LibraryId]
      ,[LibraryResourceCount]
      ,[LibrarySectionId]
      ,[LibrarySection]
      ,[LibrarySectionType]
      ,[ResourceIntId]
      ,[DateAddedToCollection]
      ,[libResourceCreatedById]
      ,[Title]
      ,[libraryFollowerId]
      ,[collectionFollowerId]
  FROM [dbo].[Library.FollowingSummary]
GO




*/
/*
[Library.FollowingSummary] - summary of library resource . 
    
*/
CREATE VIEW [dbo].[Library.FollowingSummary] AS

SELECT  distinct      
dbo.[Library.SectionResourceSummary].Library, 
dbo.[Library.SectionResourceSummary].LibraryType, 
dbo.[Library.SectionResourceSummary].LibraryId, 
dbo.[Library.SectionResourceSummary].LibraryResourceCount, 
dbo.[Library.SectionResourceSummary].LibrarySectionId, 
dbo.[Library.SectionResourceSummary].LibrarySection, 
dbo.[Library.SectionResourceSummary].LibrarySectionType, 
dbo.[Library.SectionResourceSummary].ResourceIntId, 
dbo.[Library.SectionResourceSummary].DateAddedToCollection, 
dbo.[Library.SectionResourceSummary].libResourceCreatedById, 
dbo.[Library.SectionResourceSummary].Title, 
dbo.[Library.Subscription].UserId AS libraryFollowerId, 
dbo.[Library.SectionSubscription].UserId AS collectionFollowerId

FROM            
	dbo.[Library.SectionResourceSummary] 
	Left JOIN dbo.[Library.Subscription] ON dbo.[Library.SectionResourceSummary].LibraryId = dbo.[Library.Subscription].LibraryId 
	Left JOIN dbo.[Library.SectionSubscription] ON dbo.[Library.SectionResourceSummary].LibrarySectionId = dbo.[Library.SectionSubscription].SectionId

WHERE        
	(dbo.[Library.SectionResourceSummary].IsActive = 1)
and (dbo.[Library.Subscription].UserId is not null 
	 OR dbo.[Library.SectionSubscription].UserId is not null
	 )

GO
grant select on [Library.FollowingSummary] to public
go


