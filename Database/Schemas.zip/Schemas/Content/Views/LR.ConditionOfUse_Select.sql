USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.ConditionOfUse_Select]    Script Date: 04/03/2013 13:48:10 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[LR.ConditionOfUse_Select]'))
DROP VIEW [dbo].[LR.ConditionOfUse_Select]
GO

USE [IsleContent]
GO

/****** Object:  View [dbo].[LR.ConditionOfUse_Select]    Script Date: 04/03/2013 13:48:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
SELECT [Id]
      ,[Summary]
      ,[Title]
      ,[Description]
      ,[IsActive]
      ,[Url]
      ,[IconUrl]
      ,[ConditionOfUseCategory]
      ,[WarehouseTotal]
  FROM [IsleContent].[dbo].[LR.ConditionOfUse_Select]
GO



*/
/*
[LR.ConditionOfUse_Select] - select conditions of use from IOER database . 
    
*/
Create VIEW [dbo].[LR.ConditionOfUse_Select] AS
SELECT [Id]
      ,[Summary]
      ,[Title]
      ,[Description]
      ,[IsActive]
      ,[Url]
      ,[IconUrl]
      ,[ConditionOfUseCategory]
      ,[WarehouseTotal]
  FROM [Isle_IOER].[dbo].[ConditionOfUse]
GO



