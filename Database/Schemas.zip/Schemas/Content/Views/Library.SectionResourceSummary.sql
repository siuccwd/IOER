USE IsleContent
GO

/****** Object:  View [dbo].[Library.SectionResourceSummary]    Script Date: 03/14/2013 18:04:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
SELECT 
      [LibraryId]
      ,[Library]
      ,[LibraryTypeId]
      ,[LibraryType]
      ,[OrgId]
      ,[IsDiscoverable]
      ,[IsPublic]
	  ,[LibraryResourceCount]
      ,[LibraryCreatedById]
      ,[LibrarySectionId], LibrarySection
      ,[SectionTypeId]
      ,[LibrarySectionType]
      ,[IsDefaultSection]
	  ,IsCollectionPublic
      ,[AreContentsReadOnly]
      ,LibraryResourceId, [ResourceIntId]
      ,DateAddedToCollection
		,ResourceCreated
		,IsActive
  FROM [dbo].[Library.SectionResourceSummary]
where 
ResourceIntId = 446014
--LibrarySectionId= 4




*/
/*
[Library.SectionResourceSummary] - summary of library resource . 
    
*/
Alter VIEW [dbo].[Library.SectionResourceSummary] AS

SELECT      
  libSection.LibraryId, 
  lib.Title AS Library, 
  lib.LibraryTypeId, 
  dbo.[Library.Type].Title AS LibraryType, 
  isnull(lib.OrgId, 0) As OrgId, 
  lib.IsDiscoverable, 
  lib.IsPublic, 
  lib.CreatedById AS LibraryCreatedById, 
  resCnt.[LibraryResourceCount],
  libResource.LibrarySectionId, 
  libSection.SectionTypeId, 
  libSection.Title AS LibrarySection, 
  dbo.[Library.SectionType].Title AS LibrarySectionType, 
  libSection.IsDefaultSection, 
  libSection.IsPublic as IsCollectionPublic, 
  dbo.[Library.SectionType].AreContentsReadOnly,

  libResource.Id As LibraryResourceId,
  libResource.ResourceIntId
  ,libResource.Created as DateAddedToCollection
  ,libResource.CreatedById AS libResourceCreatedById
  ,libResource.IsActive
  ,lr.[Modified] as ResourceCreated
  ,lr.Title
  ,lr.ResourceVersionIntId

FROM  dbo.Library lib
INNER JOIN dbo.[Library.Section] libSection			ON lib.Id = libSection.LibraryId 
INNER JOIN dbo.[Library.Type]						ON lib.LibraryTypeId = dbo.[Library.Type].Id 
INNER JOIN dbo.[Library.SectionType]				ON libSection.SectionTypeId = dbo.[Library.SectionType].Id 
INNER JOIN dbo.[Library.Resource] libResource		ON libSection.Id = libResource.LibrarySectionId
Inner join [dbo].[LR.ResourceVersion_Summary] lr	on libResource.ResourceIntId = lr.ResourceIntId 
Left Join [dbo].[Library.ResourceCount] resCnt		on lib.id = resCnt.LibraryId
--leave it up to usage to determine if a lib can be included
--where [IsDiscoverable]= 1


GO


