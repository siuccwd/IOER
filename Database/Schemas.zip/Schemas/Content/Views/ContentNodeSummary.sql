USE [IsleContent]
GO

/****** Object:  View [dbo].[ContentNodeSummary]    Script Date: 3/18/2014 6:09:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

SELECT [Id]
  ,[ParentId]
      ,[Title]
      ,[ContentTitle]
      ,[Summary]
      ,[FileCnt]
      ,[TypeId]
      ,[ContentType]
      ,[StatusId]
      ,[ContentStatus]
      ,[PrivilegeTypeId]
      ,[SortOrder]
    
      ,[ContentPrivilege]
      ,[IsPublished]
      ,[UseRightsUrl]
      ,[IsOrgContentOwner]
      ,[RowId]
  FROM [dbo].[ContentNodeSummary]

Order by id, parentId




*/
/* =============================================
Description: Content summary, convenience view

  ------------------------------------------------------
Modifications
14-03-17 mparsons - added 
*/

create VIEW [dbo].[ContentNodeSummary]
AS

SELECT     

  base.Id,
  isnull(base.Title,'') As Title, 
  isnull(base.Title,'') + ' (' + dbo.ContentType.Title + ') '   As ContentTitle,
  isnull(base.Summary,'') As Summary, 
 -- isnull(fileGrp.FileCnt,0) As FileCnt,
	base.TypeId, dbo.ContentType.Title AS ContentType, 
  base.StatusId, dbo.[Codes.ContentStatus].Title AS ContentStatus, 
  case when PrivilegeTypeId is null then 1
  else PrivilegeTypeId end as PrivilegeTypeId,
  isnull(base.SortOrder,10) As SortOrder,
  isnull(base.ParentId, 0) As ParentId,
  case when PrivilegeTypeId is null then 'Public'
  else dbo.[Codes.ContentPrivilege].Title end as ContentPrivilege,  
  isnull(base.IsPublished, 0) As IsPublished, 
  isnull(base.UseRightsUrl,'') as UseRightsUrl,
  isnull(IsOrgContentOwner, 0) as IsOrgContentOwner, 

  base.RowId 
FROM   dbo.[Content] base    
  
  INNER JOIN dbo.[Codes.ContentStatus]    ON base.StatusId = dbo.[Codes.ContentStatus].Id 
  INNER JOIN dbo.ContentType              ON base.TypeId = dbo.ContentType.Id 
  Left JOIN dbo.[Codes.ContentPrivilege]  ON base.PrivilegeTypeId = dbo.[Codes.ContentPrivilege].Id
 -- left join (select ConnectorParentid, count(*) as FileCnt from [ContentConnector_ChildSummary] ccs group by ConnectorParentid) fileGrp on base.id = fileGrp.ConnectorParentId
  where base.IsActive= 1 
  AND  base.TypeId in (52,54,56,58,58)


GO
grant select on [ContentNodeSummary] to public
go

