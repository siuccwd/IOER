USE [IsleContent]
GO

/*
USE [IsleContent]
GO

USE [IsleContent]
GO

SELECT [CurriculumId]
      ,[Curriculum]
      ,[StandardParent]
      ,[ContentStandardId]
      ,[StandardId]
      ,[StandardUrl]
      ,[NotationCode]
      ,[Description]
      ,[AlignmentType]
      ,[StandardUsage]
  FROM [dbo].[Curriculum_DocumentsDistinctStandards]
where CurriculumId = 2207



*/

ALTER VIEW [dbo].[Curriculum_DocumentsDistinctStandards]
AS

SELECT distinct 
		[CurriculumId]
      ,[Curriculum]
	   ,'Curriculum' As StandardParent
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType]
      ,[StandardUsage]
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentConnector_DistinctStandards] crcCss on base.[CurriculumId] = crcCss.[ConnectorParentId]

Union 
SELECT [CurriculumId]
      ,[Curriculum]
	   ,'Module' As StandardParent
      --,[ModuleId]
      --,[Module]
      --,[ModuleSortOrder]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType]
      ,[StandardUsage]

  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentConnector_DistinctStandards] crcCss on base.ModuleId = crcCss.[ConnectorParentId]

Union 
SELECT [CurriculumId]
      ,[Curriculum]
	   ,'Unit' As StandardParent
      --,[UnitId]
      --,[Unit]
      --,[UnitSortOrder]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType]
      ,[StandardUsage]
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentConnector_DistinctStandards] crcCss on base.UnitId = crcCss.[ConnectorParentId]

Union 
SELECT [CurriculumId]
      ,[Curriculum]
	   ,'Lesson' As StandardParent
      --,[LessonId]
      --,[Lesson]
      --,[LessonSortOrder]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType]
      ,[StandardUsage]
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentConnector_DistinctStandards] crcCss on base.LessonId = crcCss.[ConnectorParentId]

Union 
SELECT [CurriculumId]
      ,[Curriculum]
	   ,'Activity' As StandardParent
      --,[ActivityId]
      --,[Activity]
      --,[ActivitySortOrder]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType]
      ,[StandardUsage]
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentConnector_DistinctStandards] crcCss on base.ActivityId = crcCss.[ConnectorParentId]

go
grant select on [Curriculum_DocumentsDistinctStandards] to public
go


