USE IsleContent
GO

/****** Object:  View [dbo].[ActiveLibrarySummary]    Script Date: 1/20/2014 4:57:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [IsleContent]
GO

SELECT [Id]
      ,[Title]
      ,[Description]
      ,[LibraryTypeId]
      ,[LibraryType]
      ,[IsDiscoverable]
      ,[IsPublic]
      ,[imageUrl]
      ,[NbrResources]
      ,[LastUpdated]
  FROM [dbo].[ActiveLibrarySummary]
Order by Title


*/
-- moved from Isle_IOER
Alter VIEW [dbo].[ActiveLibrarySummary] AS
	SELECT lib.Id, lib.Title, lib.[Description], 
		LibraryTypeId, lt.Title as LibraryType, 
		IsDiscoverable, 
		lib.PublicAccessLevel,
		lib.OrgAccessLevel,
		lib.AllowJoinRequest, 
		lib.imageUrl,
		isnull(libResCount.ResCount, 0) AS NbrResources, 
		libResUpdated.LastUpdated
	FROM dbo.[Library] lib
	inner join [Library.Type] lt on lib.LibraryTypeId = lt.Id
	Left Join (
		Select ls.LibraryId, count(*) As ResCount from [Library.Resource] lr
		inner join [Library.Section] ls on lr.LibrarySectionId = ls.Id group by ls.LibraryId ) 
			As libResCount on lib.id = libResCount.LibraryId
	Left Join (Select ls.LibraryId, MAX(lr.Created) As LastUpdated from [Library.Resource] lr
		inner join [Library.Section] ls on lr.LibrarySectionId = ls.Id group by ls.LibraryId ) 
			As libResUpdated on lib.id = libResUpdated.LibraryId
	WHERE lib.IsActive = 1


GO
grant select on [ActiveLibrarySummary] to public
go

