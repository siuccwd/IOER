USE [IsleContent]
GO

/****** Object:  View [dbo].[Codes.CareerCluster]    Script Date: 1/21/2014 11:22:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



Alter VIEW [dbo].[Codes.CareerCluster] AS
SELECT [Id]
      ,[Title]
      ,[WarehouseTotal]
	  ,IsActive
  FROM Isle_IOER.[dbo].[Codes.CareerCluster]



GO
grant select on [Codes.CareerCluster] to public
go


