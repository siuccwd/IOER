USE [IsleContent]
GO

/****** Object:  View [dbo].[ContentSummaryView]    Script Date: 1/8/2014 4:45:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

USE [IsleContent]
GO

SELECT [ContentId]
      ,[ParentId]
      ,[TypeId]
      ,[ContentType]
      ,[Title]
      ,[Summary]
      ,[Description]
      ,[StatusId]
      ,[ContentStatus]
      ,[PrivilegeTypeId]
      ,[ContentPrivilege]
      ,[ConditionsOfUseId]
      ,[ConditionsOfUse]
      ,[ConditionsOfUseUrl]
      ,[ConditionsOfUseIconUrl]
      ,[ResourceVersionId]
      ,[ResourceUrl]
      ,[ResourceIntId]
      ,[IsPublished]
      ,[UseRightsUrl]
      ,[IsOrgContentOwner]
      ,[IsActive]
      ,[DocumentUrl]
      ,[DocumentRowId]
      ,[SortOrder]
      ,[OrgId]
      ,[Organization]
      ,[ParentOrgId]
      ,[ParentOrganization]
      ,[Created]
      ,[CreatedById]
      ,[Author]
      ,[AuthorKey]
      ,[OrgKey]
      ,[LastUpdated]
      ,[LastUpdatedById]
      ,[LastUpdatedBy]
      ,[ApprovedById]
      ,[Approved]
      ,[ContentRowId]
  FROM [dbo].[ContentSummaryView]
GO




select * 
FROM [IsleContent].[dbo].[ContentSummaryView]
where OrgKey = 'siuccwd'
And AuthorKey = 'MichaelParsons'
And TypeId = 20


UPDATE [IsleContent].[dbo].[Content]
   SET [IsOrgContentOwner] = 1
 WHERE OrgId > 0
GO

UPDATE [IsleContent].[dbo].[Content]
   SET [IsOrgContentOwner] = 0
 WHERE OrgId is null
GO

*/
/* =============================================
Description: Content summary, convenience view

  ------------------------------------------------------
Modifications
13-04-23 mparsons - added ResourceVersionId
14-01-29 mparsons - added missing IsActive
14-04-07 mparsons - added DocumentUrl, resource url and res int id
14-11-27 mparsons - added lastUpdatedBy, ConditionsOfUse, ConditionsOfUseUrl, ConditionsOfUseIconUrl, Timeframe, ImageUrl

*/

ALTER VIEW [dbo].[ContentSummaryView]
AS
SELECT     
	base.Id As ContentId,
	isnull(base.ParentId, 0) As ParentId,
	base.TypeId, dbo.ContentType.Title AS ContentType, 
	isnull(base.Title,'') As Title, 
	isnull(base.Summary,'') As Summary, 
	isnull(base.Description,'') as Description, 
	base.StatusId, dbo.[Codes.ContentStatus].Title AS ContentStatus, 
	case when PrivilegeTypeId is null then 1
	else PrivilegeTypeId end as PrivilegeTypeId,
  
	case when PrivilegeTypeId is null then 'Public'
	else dbo.[Codes.ContentPrivilege].Title end as ContentPrivilege,  
	isnull(ConditionsOfUseId,0) as ConditionsOfUseId, 
	isnull(cou.[Summary],'') as ConditionsOfUse, 
	isnull(cou.Url,'') as ConditionsOfUseUrl, 
	isnull(cou.IconUrl,'') as ConditionsOfUseIconUrl, 

	isnull(ResourceVersionId, 0) AS ResourceVersionId,
	case when isnull(ResourceVersionId, 0)> 0 then lr.ResourceUrl else '' end as ResourceUrl,
	case when isnull(ResourceVersionId, 0)> 0 then lr.ResourceIntId else 0 end as ResourceIntId,
  
	isnull(base.IsPublished, 0) As IsPublished, 
	isnull(base.UseRightsUrl,'') as UseRightsUrl,
	IsOrgContentOwner, 
	base.IsActive,
	isnull(base.DocumentUrl, '') as DocumentUrl,
	base.DocumentRowId, 
	base.SortOrder,
	base.Timeframe,
	base.ImageUrl,

	isnull(base.OrgId, 0) as OrgId,
	org.Name as Organization,
	org.ParentId ParentOrgId,
	case when org.ParentId > 0 then org.[ParentOrganization]
	else '' end as [ParentOrganization],

	base.Created, base.CreatedById, 
	isnull(author.FullName, '') As Author,
	replace(isnull(author.FullName, ''), ' ','') As AuthorKey,
	replace(isnull(org.Name, ''), ' ','') As OrgKey,
	base.LastUpdated, base.LastUpdatedById, 
	isnull(lastUpdated.FullName, '') As LastUpdatedBy,
	base.ApprovedById, base.Approved
	,base.RowId As ContentRowId 
FROM         
  dbo.[Content] base
  INNER JOIN dbo.[Codes.ContentStatus]    ON base.StatusId = dbo.[Codes.ContentStatus].Id 
  INNER JOIN dbo.ContentType              ON base.TypeId = dbo.ContentType.Id 
  Left JOIN dbo.[Codes.ContentPrivilege]  ON base.PrivilegeTypeId = dbo.[Codes.ContentPrivilege].Id
  Left Join dbo.[LR.PatronOrgSummary] author on base.CreatedById = author.UserId
  Left Join dbo.[LR.PatronOrgSummary] lastUpdated on base.LastUpdatedById = lastUpdated.UserId
  Left Join [Gateway.OrgSummary] org      on base.OrgId = org.Id
  Left join [dbo].[LR.ResourceVersion_Summary] lr	on base.ResourceVersionId = lr.ResourceVersionIntId
  Left Join [LR.ConditionOfUse_Select] cou on base.ConditionsOfUseId = cou.Id
GO


