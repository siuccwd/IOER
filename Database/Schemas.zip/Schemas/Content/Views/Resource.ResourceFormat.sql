USE [IsleContent]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create VIEW [dbo].[Resource.ResourceFormat] AS
SELECT [RowId]
      ,[ResourceIntId]
      ,[CodeId] As ResourceFormatId

      
  FROM [Isle_IOER].[dbo].[Resource.Format]
GO


grant select on [Resource.ResourceFormat] to public
go

