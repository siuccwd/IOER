USE [IsleContent]
GO

/*
USE [IsleContent]
GO

SELECT [CurriculumId]
      ,[Curriculum]
     -- ,[StandardParent]
      ,[StandardId]
      ,[StandardUrl]
      ,[NotationCode]
      ,[Description]
      ,[AlignmentType]
      ,[StandardUsage]
  FROM [dbo].[Curriculum_DistinctStandards]
  where CurriculumId = 2207
  union 
  SELECT [CurriculumId]
      ,[Curriculum]
    --  ,[StandardParent]
      --,[ContentStandardId]
      ,[StandardId]
      ,[StandardUrl]
      ,[NotationCode]
      ,[Description]
      ,[AlignmentType]
      ,[StandardUsage]
  FROM [dbo].[Curriculum_DocumentsDistinctStandards]
where CurriculumId = 2207
order by NotationCode


USE [IsleContent]
GO

SELECT [CurriculumId]
      ,[Curriculum]
      ,[StandardParent]
	  ,ParentId
	        ,[StandardUsage]
      ,[UsageTypeId]
      ,[ContentStandardId]
      ,[StandardId]
      ,[StandardUrl]
      ,[NotationCode]
      ,[Description]
      ,[AlignmentType]

  FROM [dbo].[Curriculum_DistinctStandards]
order by CurriculumId, UsageTypeId




*/

Alter VIEW [dbo].[Curriculum_DistinctStandards]
AS

SELECT distinct 
		[CurriculumId]
      ,[Curriculum]
	  ,'Curriculum' As StandardParent
	  ,0 As ParentId
	  --,[ModuleId]
   --   ,[UnitId]
	  --,[LessonId]
   --   ,[ActivityId]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType], AlignmentTypeCodeId
      ,[StandardUsage]
	  ,UsageTypeId
	  
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentStandard_Summary] crcCss on base.[CurriculumId] = crcCss.ContentId

--Union 
--SELECT distinct 
--		[CurriculumId]
--      ,[Curriculum]
--	  ,'Curriculum Document' As StandardParent
--	  --,[ModuleId]
--   --   ,[UnitId]
--	  --,[LessonId]
--   --   ,[ActivityId]
--	  ,crcCss.[ContentStandardId]
--	  ,crcCss.[StandardId]
--	  ,crcCss.[StandardUrl]
--      ,crcCss.[NotationCode]
--      ,crcCss.[Description]
--	  ,[AlignmentType]
--      ,[StandardUsage]
--	  ,UsageTypeId
	  
--  FROM [dbo].[Curriculum_HierarchySummary] base 
--inner join .[dbo].[ContentStandard_Summary] crcCss on base.[CurriculumId] = crcCss.ContentId and crcCss.TypeId = 40

Union 
SELECT distinct 
		[CurriculumId]
      ,[Curriculum]
	  ,'Module' As StandardParent
      ,[ModuleId]  As ParentId
   --   ,[UnitId]
	  --,[LessonId]
   --   ,[ActivityId]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType], AlignmentTypeCodeId
      ,[StandardUsage]
	  ,UsageTypeId
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentStandard_Summary] crcCss on base.[ModuleId] = crcCss.ContentId

Union 
SELECT distinct 
		[CurriculumId]
      ,[Curriculum]
	  ,'Unit' As StandardParent
   --   ,[ModuleId]
      ,[UnitId]  As ParentId
	  --,[LessonId]
   --   ,[ActivityId]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType], AlignmentTypeCodeId
      ,[StandardUsage]
	  ,UsageTypeId
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentStandard_Summary] crcCss on base.UnitId = crcCss.ContentId

Union 
SELECT distinct 
		[CurriculumId]
      ,[Curriculum]
	  ,'Lesson' As StandardParent
   --   ,[ModuleId]
   --   ,[UnitId]
	  ,[LessonId] As ParentId
   --   ,[ActivityId]
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType], AlignmentTypeCodeId
      ,[StandardUsage]
	  ,UsageTypeId
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentStandard_Summary] crcCss on base.[LessonId] = crcCss.ContentId

Union 
SELECT distinct 
		[CurriculumId]
      ,[Curriculum]
	  ,'Activity' As StandardParent
   --   ,[ModuleId]
   --   ,[UnitId]
	  --,[LessonId]
     ,[ActivityId] As ParentId
	  ,crcCss.[ContentStandardId]
	  ,crcCss.[StandardId]
	  ,crcCss.[StandardUrl]
      ,crcCss.[NotationCode]
      ,crcCss.[Description]
	  ,[AlignmentType], AlignmentTypeCodeId
      ,[StandardUsage]
	  ,UsageTypeId
  FROM [dbo].[Curriculum_HierarchySummary] base 
inner join .[dbo].[ContentStandard_Summary] crcCss on base.ActivityId = crcCss.ContentId


go
grant select on [Curriculum_DistinctStandards] to public
go


