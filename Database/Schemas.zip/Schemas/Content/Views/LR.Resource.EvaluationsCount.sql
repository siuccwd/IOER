USE [IsleContent]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[LR.Resource.EvaluationsCount] AS

SELECT [ResourceIntId]
      ,[EvaluationsCount]
  FROM [Isle_IOER].[dbo].[Resource.EvaluationsCount]

GO
grant select on [LR.Resource.EvaluationsCount] to public
go


