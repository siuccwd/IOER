USE [IsleContent]
GO

/****** Object:  View [dbo].[Library.FollowingList]    Script Date: 6/25/2014 12:07:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*


*/
/*
[Library.FollowingList] - summary of library subscriptions . 
    
*/
CREATE VIEW [dbo].[Library.FollowingList] AS

SELECT    distinct    
	lib.Id, 
	lib.Title, 
	lib.Description, 
	lsrs.LibraryResourceCount,
	lib.LibraryTypeId, 
	lib.PublicAccessLevel, 
	lib.OrgAccessLevel, 
	lib.OrgId, 
	lib.ImageUrl, 
	lsub.UserId, 
	lsub.SubscriptionTypeId

FROM dbo.Library lib 
INNER JOIN 	dbo.[Library.Subscription] lsub	ON lib.Id = lsub.LibraryId
Inner Join dbo.[Library.SectionResourceSummary] lsrs on  lib.Id = lsrs.LibraryId

	
GO


