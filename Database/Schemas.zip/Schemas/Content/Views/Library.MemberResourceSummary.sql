USE [IsleContent]
GO

/****** Object:  View [dbo].[Library.MemberResourceSummary]    Script Date: 6/20/2014 4:52:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

SELECT [Library]
      ,[LibraryType]
      ,[LibraryId]
      ,[LibraryResourceCount]
      ,[LibrarySectionId]
      ,[LibrarySection]
      ,[LibrarySectionType]
      ,[ResourceIntId]
      ,[DateAddedToCollection]
      ,[libResourceCreatedById]
      ,[Title]
      ,[libraryFollowerId]
      ,[collectionFollowerId]
  FROM [dbo].[Library.MemberResourceSummary]
where libraryFollowerId= 2 or collectionFollowerId=2 


*/
/*
[Library.MemberResourceSummary] - summary of library resource for library or section members
NOTE: primary purpose is to filter by a single user 
    
*/
CREATE VIEW [dbo].[Library.MemberResourceSummary] AS

SELECT  distinct      
	base.Library, 
	base.LibraryType, 
	base.LibraryId, 
	base.LibraryResourceCount, 
	base.LibrarySectionId, 
	base.LibrarySection, 
	base.LibrarySectionType, 
	base.ResourceIntId, 
	base.DateAddedToCollection, 
	base.libResourceCreatedById, 
	base.Title, 
	lm.UserId AS libraryFollowerId, 
	lsm.UserId AS collectionFollowerId

FROM            
	dbo.[Library.SectionResourceSummary] base
	Left JOIN dbo.[Library.Member] lm			ON base.LibraryId = lm.LibraryId 
	Left JOIN dbo.[Library.SectionMember] lsm	ON base.LibrarySectionId = lsm.LibrarySectionId

WHERE        
	(base.IsActive = 1)
and (lm.UserId is not null 
	 OR lsm.UserId is not null
	 )

GO
grant select on [Library.MemberResourceSummary] to public
go


