USE [IsleContent]
GO

/****** Object:  View [dbo].[Resource.CareerCluster]    Script Date: 1/21/2014 10:45:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


Create VIEW [dbo].[Resource.CareerCluster] AS
SELECT [Id]
      ,[ResourceIntId]
      ,[ClusterId] As CareerClusterId
  FROM Isle_IOER.[dbo].[Resource.Cluster]

go
grant select on [Resource.CareerCluster] to public
GO


