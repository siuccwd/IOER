-- the alter may not work, try updating the table values, then run the update statements


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Library.Section]
	DROP CONSTRAINT [FK_Library.Section_Codes.PublicAccessLevel]
GO
ALTER TABLE dbo.[Library.Section]
	DROP CONSTRAINT [FK_Library.Section_CodesOrgAccessLevel]
GO
ALTER TABLE dbo.[Codes.LibraryAccessLevel] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Library.Section] ADD CONSTRAINT
	[FK_Library.Section_Codes.PublicAccessLevel] FOREIGN KEY
	(
	PublicAccessLevel
	) REFERENCES dbo.[Codes.LibraryAccessLevel]
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Library.Section] ADD CONSTRAINT
	[FK_Library.Section_CodesOrgAccessLevel] FOREIGN KEY
	(
	OrgAccessLevel
	) REFERENCES dbo.[Codes.LibraryAccessLevel]
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Library.Section] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

USE [IsleContent]
GO

UPDATE [dbo].[Library]
   SET [PublicAccessLevel] = 4
 WHERE [PublicAccessLevel] = 3
GO
UPDATE [dbo].[Library]
   SET [OrgAccessLevel] = 4
 WHERE [OrgAccessLevel] = 3
GO

UPDATE [dbo].[Library]
   SET [PublicAccessLevel] = 3
 WHERE [PublicAccessLevel] = 2
GO
UPDATE [dbo].[Library]
   SET [OrgAccessLevel] = 3
 WHERE [OrgAccessLevel] = 2
GO

UPDATE [dbo].[Library]
   SET [PublicAccessLevel] = 2
 WHERE [PublicAccessLevel] = 1
GO
UPDATE [dbo].[Library]
   SET [OrgAccessLevel] = 2
 WHERE [OrgAccessLevel] = 1
GO


UPDATE [dbo].[Library]
   SET [PublicAccessLevel] = 1
 WHERE IsDiscoverable = 1
GO
UPDATE [dbo].[Library]
   SET [OrgAccessLevel] = 2
 WHERE [OrgAccessLevel] = 1
GO



