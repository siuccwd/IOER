/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Library.Section] ADD
	RowId uniqueidentifier NULL
GO
ALTER TABLE dbo.[Library.Section] ADD CONSTRAINT
	[DF_Library.Section_RowId] DEFAULT newId() FOR RowId
GO
ALTER TABLE dbo.[Library.Section] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

/* set values */
USE [IsleContent]
GO

UPDATE [dbo].[Library.Section]
   SET [RowId] = newId()
GO



