--- Get Single Procedure for [Library.Like] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.LikeGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.LikeGet]
Go

--use to check for existing like
CREATE PROCEDURE [Library.LikeGet]
    @LibraryId int,
	@UserId int
As
SELECT     Id, 
    LibraryId, 
    IsLike, 
    Created, 
    CreatedById
FROM [Library.Like]
WHERE 
	LibraryId = @LibraryId
and CreatedById= @UserId
GO
grant execute on [Library.LikeGet] to Public
Go
