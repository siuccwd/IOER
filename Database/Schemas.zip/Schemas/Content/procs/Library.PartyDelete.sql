 
use IsleContent
go 

 
--- Delete Procedure for [Library.Party] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Library.PartyDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.PartyDelete]
GO
CREATE PROCEDURE [Library.PartyDelete]
        @Id int
As
DELETE FROM [Library.Party]
WHERE Id = @Id
GO
grant execute on [Library.PartyDelete]  to public
Go
