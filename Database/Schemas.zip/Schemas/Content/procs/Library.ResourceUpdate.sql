
 
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.ResourceUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.ResourceUpdate]
Go
--- Update Procedure for [Library.Resource] ---
CREATE PROCEDURE [Library.ResourceUpdate]
        @Id int,
        @Comment varchar(500)
As

If @Comment = ''   SET @Comment = NULL 

UPDATE [Library.Resource] 
SET 
    Comment = @Comment
WHERE Id = @Id
GO
grant execute on [Library.ResourceUpdate] to public
Go