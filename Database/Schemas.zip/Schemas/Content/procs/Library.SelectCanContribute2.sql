use IsleContent 
go

/*

[Library.SelectCanContribute2] 2,1
go
[Library.SelectCanContribute2] 2,0

[Library.SelectCanContribute2] 2,25

*/

/*
Select all libraries/collections where user has contribute access. Includes:
- personal
- libraries where has curate access
- collections where has curate access
- org libraries with implicit access
- members of multiple orgs are not implemented as yet (thru org.member)
Modifications
14-07-23 mparsons - increase @BaseMemberId to 3 (contributors need approval) 
14-08-26 mparsons - remove implicit options, sort personal first
14-11-14 mparsons - add implicit options back
*/

Alter PROCEDURE [Library.SelectCanContribute2]
  @UserId		int
  ,@LibraryId	int
  --,@BaseMemberId int
As
--declare @UserId		int
--set @UserId = 2

declare @BaseMemberId int, @IncludePublicImplicit bit

set @BaseMemberId = 3	--curator
set @IncludePublicImplicit= 0
 if @LibraryId = 0	set @LibraryId = NULL

-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	SortOrder int not null,
	LibraryId int NOT NULL,
	Title varchar(100),
	AccessReason varchar(100),
	LibraryTypeId int ,
	LibraryOrgId int ,
	PublicAccessLevel int ,
	OrgAccessLevel int ,
	MemberTypeId int ,
	UserHasExplicitAccess bit,
	UserNeedsApproval bit
)
--=== explicit first ======================================================================
--personal library
INSERT INTO #tempWorkTable (SortOrder, LibraryId, Title, AccessReason, LibraryTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, UserHasExplicitAccess, UserNeedsApproval)
SELECT distinct
	1
	,base.[Id]	
	,base.[Title], 'Is Personal Lib'	
	,base.LibraryTypeId, isnull(base.OrgId,0), base.PublicAccessLevel, base.OrgAccessLevel
	,4		--admin	
	,1
	,0
  FROM [dbo].[Library] base
  where base.IsActive = 1 
  And (base.Id = @LibraryId OR @LibraryId is null)
  And (base.LibraryTypeId = 1 And base.CreatedById = @UserId)
	
--member library -------------------------
-- note based @BaseMemberId - currently contributors will need approval
INSERT INTO #tempWorkTable (SortOrder, LibraryId, Title, AccessReason, LibraryTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, UserHasExplicitAccess, UserNeedsApproval)
SELECT distinct
	2
	,base.[Id]	
	,base.[Title], 'Is Lib Mbr'	
	,base.LibraryTypeId, isnull(base.OrgId,0), base.PublicAccessLevel, base.OrgAccessLevel
	,mbr.MemberTypeId
	,1
	,0	--case when mbr.MemberTypeId > @BaseMemberId then 0
  FROM [dbo].[Library] base
  inner join [Library.Member] mbr on base.id = mbr.LibraryId
  
  where base.IsActive = 1 
  And (base.Id = @LibraryId OR @LibraryId is null)
  and base.Id not in (select LibraryId from #tempWorkTable)
  And (mbr.UserId = @UserId AND mbr.MemberTypeId >= @BaseMemberId)


--=== implicit access ======================================================================
-- org mbrs
-- lib has OrgId, Org access level is with or without approval
INSERT INTO #tempWorkTable (SortOrder, LibraryId, Title, AccessReason, LibraryTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, UserHasExplicitAccess, UserNeedsApproval)
SELECT distinct
	5
	,base.[Id]	
	,base.[Title], 'Is Org Mbr'	
	,base.LibraryTypeId, isnull(base.OrgId,0), base.PublicAccessLevel, base.OrgAccessLevel
	,2
	,0
	,case when base.OrgAccessLevel = 4 then 0
		when base.OrgAccessLevel = 3 then 1
		else 1 end 
  FROM [dbo].[Library] base
  inner join [Gateway.Org_MemberSummary] mbr on base.OrgId = mbr.OrgId
  
  where base.IsActive = 1 
  And (base.Id = @LibraryId OR @LibraryId is null)
  and (base.OrgAccessLevel > 2)	--mbr contribute with or without approval
  and base.Id not in (select LibraryId from #tempWorkTable)
  And (mbr.OrgId = base.OrgId AND mbr.UserId = @UserId )

--====================================
-- Public access
-- lib has Public access level with or without approval
-- ******* Note may need to place before org where no approval is necessary
if @IncludePublicImplicit= 1 begin
	INSERT INTO #tempWorkTable (SortOrder, LibraryId, Title, AccessReason, LibraryTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, UserHasExplicitAccess, UserNeedsApproval)
	SELECT distinct
		10
		,base.[Id]	
		,base.[Title], 'Has Public Access'	
		,base.LibraryTypeId, isnull(base.OrgId,0), base.PublicAccessLevel, base.OrgAccessLevel
		,2
		,0
		,case when base.PublicAccessLevel = 4 then 0
			when base.PublicAccessLevel = 3 then 1
			else 1 end 
	  FROM [dbo].[Library] base
    
	  where base.IsActive = 1 
	  And (base.Id = @LibraryId OR @LibraryId is null)
	  and (base.PublicAccessLevel > 2)	--public contribute with or without approval
	  and base.Id not in (select LibraryId from #tempWorkTable)
	  end
  --==============================================================
  --future include Library collections

  --==============================================================
  select distinct
  	base.[Id]
	,base.[Title]
	,AccessReason
	,MemberTypeId
	,UserHasExplicitAccess 
	,UserNeedsApproval 
	,base.LibraryTypeId, lt.Title as LibraryType
	,isnull(base.OrgId,0) As OrgId
    ,isnull(org.Name, '') As Organization
	,case when base.PublicAccessLevel > 1 then 1 else 0 end As IsPublic
	,base.IsActive
	,base.PublicAccessLevel
	,base.OrgAccessLevel
	,base.ImageUrl
	,base.Created, base.CreatedById
	,SortOrder

  from #tempWorkTable work
  inner join Library		base	on work.LibraryId = base.Id
  inner join [Library.Type] lt		on base.LibraryTypeId = lt.Id
  left join  [Gateway.OrgSummary] org on base.OrgId = org.Id
  Order by work.SortOrder, Title
GO
grant execute on [Library.SelectCanContribute2] to public 
Go