USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersion_SetToPublished]    Script Date: 04/01/2013 00:14:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DocumentVersion_SetToPublished]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DocumentVersion_SetToPublished]
GO


--- Update Procedure for Document.Version
--- Set document to published. 
--Used to minimize orphans where the doc version needs to be persisted before parent record and then something happens to prevent the parent from being saved
CREATE PROCEDURE [dbo].[DocumentVersion_SetToPublished]
				@RowId varchar(36)
As

UPDATE [Document.Version]
SET 
    Status = 'Published', 
    LastUpdated = getdate()

WHERE RowId = @RowId

GO

grant execute on [DocumentVersion_SetToPublished] to public
go


