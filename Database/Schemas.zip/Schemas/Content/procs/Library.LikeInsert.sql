
 
--- Insert Procedure for [Library.Like] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.LikeInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.LikeInsert]
Go
CREATE PROCEDURE [Library.LikeInsert]
            @LibraryId int, 
            @IsLike bit, 
            @CreatedById int
As

If @CreatedById = 0   SET @CreatedById = NULL 
INSERT INTO [Library.Like] (

    LibraryId, 
    IsLike, 
    CreatedById
)
Values (

    @LibraryId, 
    @IsLike, 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.LikeInsert] to public
Go