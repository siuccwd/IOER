 
--- Get Single Procedure for [Content.History] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Content.HistorySelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Content.HistorySelect]
Go
CREATE PROCEDURE [Content.HistorySelect]
    @ContentId int
As
SELECT     
    h.Id, 
    h.ContentId, 
    h.[Action], 
    h.Description, 
    h.Created, 
    h.CreatedById, usr.FullName As CreatedBy
    
FROM [Content.History] h
Inner Join [Content] c on h.ContentId = c.Id
Left Join [LR.PatronOrgSummary] usr on h.CreatedById = usr.UserId

WHERE ContentId = @ContentId
order by Created DESC, [Action]
 

GO
grant execute on [Content.HistorySelect] to Public
Go