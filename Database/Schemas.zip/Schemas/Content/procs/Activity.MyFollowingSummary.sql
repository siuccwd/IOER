use IsleContent
go
--- Summary Procedure for [Library.Like] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Activity.MyFollowingSummary]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Activity.MyFollowingSummary]
Go
/*
select * from [LR.PatronOrgSummary]

select * from [Library.Subscription] where userId = 2
go
select * from [Library.SectionSubscription] where userId = 2
go

[Activity.MyFollowingSummary] 75, 2
*/
/*
Get summary of activity
*/
CREATE PROCEDURE [Activity.MyFollowingSummary]
    @HistoryDays int
	,@UserId int
As
Declare @LibUrl varchar(200),@CollectionUrl varchar(200),@ContentUrl varchar(200)
,@ResourceUrl varchar(200),@ResImgeUrl varchar(200)
,@CommunityUrl varchar(200),@CommImgeUrl varchar(200),@CommPostingUrl varchar(200)
,@ActorUrl varchar(200),@DefActorImageUrl varchar(200)
,@PdfImageUrl varchar(200),@PPTImageUrl varchar(200),@WordImageUrl varchar(200),@XlxImageUrl varchar(200),@SwfImageUrl  varchar(200)
, @LimitToUser bit

--set @UserId = 2
set @LimitToUser = 0

set @LibUrl = '/Libraries/Library.aspx?id=@lid'
set @LibUrl = '/Library/@lid/@Title'
set @CollectionUrl = '/Libraries/Library.aspx?id=@lid&col=@cid'
--set @ResourceUrl = '/IOER/@rvid/@title'
set @ResourceUrl = '/Resource/@rid/@title'
set @ContentUrl = '/CONTENT/@cid/@title'
set @ResImgeUrl = '//ioer.ilsharedlearning.org/OERThumbs/large/@rid-large.png'
set @PdfImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_pdf_200x150.png'
set @PPTImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_pptx_200x150.png'
set @WordImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_docx_200x150.png'
set @XlxImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_xlsx_200x150.png'
set @SwfImageUrl = '//ioer.ilsharedlearning.org/images/icons/filethumbs/filethumb_swf_200x200.png'
--prob should use guid!
--set @ActorUrl = '/Profiles/default.aspx?id=@uid'
set @ActorUrl = '/Profile/@uid/@Actor'
set @DefActorImageUrl = '/Images/defaultProfileImg.jpg'
--
--
set @CommunityUrl = '/Communities/Community.aspx?id=@cid'
set @CommunityUrl = '/Community/@cid/@Title'
set @CommPostingUrl = '/Community/@cid/@Title?id=@PostintId'
set @CommImgeUrl = '/Images/icons/icon_community_med.png'


-- library comments =========================================================
SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.[CreatedById] As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Commented On' As Activity

	  ,objct.Id as ObjectId
	  ,'Comment' as ObjectType
	  ,'Comment' as ObjectTitle
	  ,objct.Comment as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  ,ObjectGroup.Counts as ObjectCount
	  ,0 as ObjectCount2
	  ,0 As HasObject

	  ,'Library' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(@LibUrl, '@lid', objct.LibraryId) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library.Comment] objct
  inner join (
	select libraryId, count(*) As Counts from dbo.[Library.Comment] group by libraryId) 
	As ObjectGroup on objct.LibraryId = ObjectGroup.LibraryId
  inner join [Library] target on objct.LibraryId = target.Id
  inner join[LR.PatronOrgSummary] crby on objct.CreatedById = crby.UserId
  inner join [Library.Subscription] following on target.id = following.LibraryId
  where 
		(following.UserId = @UserId
		OR (target.LibraryTypeId = 1 AND target.CreatedById  = @UserId))
  AND objct.[Created] >  getdate() - @HistoryDays
  UNION
  -- collection comments =========================================================
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.[CreatedById] As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Commented On' As Activity

	  ,objct.Id as ObjectId
	  ,'Comment' as ObjectType
	  ,'Comment' as ObjectTitle
	  ,objct.Comment as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  ,ObjectGroup.Counts as ObjectCount
	  ,0 as ObjectCount2
	  ,0 As HasObject

	  ,'Collection' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(replace(@CollectionUrl, '@lid', target.LibraryId), '@cid', objct.SectionId) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library.SectionComment] objct
    inner join (
	select SectionId, count(*) As Counts from dbo.[Library.SectionComment] group by SectionId) 
	As ObjectGroup on objct.SectionId = ObjectGroup.SectionId
  inner join [Library.Section] target on objct.SectionId = target.Id
  inner join [Library] lib on target.LibraryId = lib.Id
  inner join[LR.PatronOrgSummary] crby on objct.CreatedById = crby.UserId
  inner join [Library.SectionSubscription] following on target.id = following.SectionId
  where 
		(following.UserId = @UserId
		OR (lib.LibraryTypeId = 1 AND lib.CreatedById  = @UserId))
  AND objct.[Created] >  getdate() - @HistoryDays

  UNION
  --  library Like
  SELECT Distinct
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.[CreatedById] As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
  	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Liked' As Activity

  	  ,objct.Id as ObjectId
	  ,'Like' as ObjectType
	  ,'' as ObjectTitle
	  ,'' as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  ,LikesCrosstab.LikeCounts as ObjectCount
	  ,LikesCrosstab.DislikeCounts as ObjectCount2
	  ,case when HasRating.IsLike is null then 0 else 1 end as HasObject
	  --,isnull(HasRating.IsLike,0) As HasObject

	  ,'Library' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(@LibUrl, '@lid', objct.LibraryId) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library.Like] objct
  --  inner join (
		--select LibraryId, count(*) As Counts from dbo.[Library.Like] ll where ll.IsLike = 1 group by LibraryId) 
		--As ObjectGroup on objct.LibraryId = ObjectGroup.LibraryId
	inner join (
		Select LibraryId, Sum(Case Cast(IsLike As nvarchar(100)) When N'1'   Then 1 Else 0 End ) as [LikeCounts],
		Sum(Case Cast(IsLike As nvarchar(100)) When N'0'   Then 1 Else 0 End ) as [DislikeCounts] From [Library.Like]
		Group By LibraryId
	) As LikesCrosstab on  objct.LibraryId = LikesCrosstab.LibraryId
	left join [dbo].[Library.Like] HasRating  on objct.LibraryId = HasRating.LibraryId And HasRating.CreatedById = @UserId
		
	inner join [Library] target on objct.LibraryId = target.Id
	inner join[LR.PatronOrgSummary] crby on objct.CreatedById = crby.UserId
	inner join [Library.Subscription] following on target.id = following.LibraryId
  where 
		(following.UserId = @UserId
		OR (target.LibraryTypeId = 1 AND target.CreatedById  = @UserId))
  AND objct.[Created] >  getdate() - @HistoryDays
  AND objct.IsLike = 1
  UNION
  -- collection Like =========================================================
  SELECT Distinct
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.[CreatedById] As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
  	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Liked' As Activity

	  ,objct.Id as ObjectId
	  ,'Like' as ObjectType
	  ,'' as ObjectTitle
	  ,'' as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  ,LikesCrosstab.LikeCounts as ObjectCount
	  ,LikesCrosstab.DislikeCounts as ObjectCount2
	  ,case when HasRating.IsLike is null then 0 else 1 end as HasObject
	  --,isnull(HasRating.IsLike,0) As HasObject

	  ,'Collection' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(replace(@CollectionUrl, '@lid', target.LibraryId), '@cid', objct.SectionId) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library.SectionLike] objct
  --  inner join (
		--select SectionId, count(*) As Counts from dbo.[Library.SectionLike] ll where ll.IsLike = 1 group by SectionId) 
		--As ObjectGroup on objct.SectionId = ObjectGroup.SectionId
	inner join (
		Select SectionId, Sum(Case Cast(IsLike As nvarchar(100)) When N'1'   Then 1 Else 0 End ) as LikeCounts,
		Sum(Case Cast(IsLike As nvarchar(100)) When N'0'   Then 1 Else 0 End ) as DislikeCounts From [Library.SectionLike]
		Group By SectionId
	) As LikesCrosstab on  objct.SectionId = LikesCrosstab.SectionId

	left join [dbo].[Library.SectionLike] HasRating  on objct.SectionId = HasRating.SectionId And HasRating.CreatedById = @UserId
	inner join [Library.Section] target on objct.SectionId = target.Id
	inner join [Library] lib on target.LibraryId = lib.Id
	inner join[LR.PatronOrgSummary] crby on objct.CreatedById = crby.UserId
    inner join [Library.SectionSubscription] following on target.id = following.SectionId
  where 
		(following.UserId = @UserId
		OR (lib.LibraryTypeId = 1 AND lib.CreatedById  = @UserId))
  AND objct.[Created] >  getdate() - @HistoryDays
  AND objct.IsLike = 1
  UNION
   --  library follow =========================================================
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.UserId As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.UserId = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Is Following' As Activity

	  ,objct.Id as ObjectId
	  ,'Following' as ObjectType
	  ,'Is Following' as ObjectTitle
	  ,'' as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  ,ObjectGroup.Counts as ObjectCount
	  ,0 as ObjectCount2
	  ,0 As HasObject

	  ,'Library' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(@LibUrl, '@lid', objct.LibraryId) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library.Subscription] objct
  inner join (
	select libraryId, count(*) As Counts from dbo.[Library.Subscription] group by libraryId) 
	As ObjectGroup on objct.LibraryId = ObjectGroup.LibraryId
	inner join [Library] target on objct.LibraryId = target.Id
	inner join[LR.PatronOrgSummary] crby on objct.UserId = crby.UserId
	inner join [Library.Subscription] following on target.id = following.LibraryId
  where 
		(following.UserId = @UserId
		OR (target.LibraryTypeId = 1 AND target.CreatedById  = @UserId))
  AND objct.[Created] >  getdate() - @HistoryDays
  UNION
  -- collection follow =========================================================
  --==> should also include if following library, and collection is not restricted?. really minor though
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.UserId As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.UserId = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Is Following' As Activity

	  ,objct.Id as ObjectId
	  ,'Following' as ObjectType
	  ,'Is Following' as ObjectTitle
	  ,'' as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  ,ObjectGroup.Counts as ObjectCount
	  ,0 as ObjectCount2
	  ,0 As HasObject

	  ,'Collection' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(replace(@CollectionUrl, '@lid', target.LibraryId), '@cid', objct.SectionId) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library.SectionSubscription] objct
    inner join (
	select SectionId, count(*) As Counts from dbo.[Library.SectionSubscription] group by SectionId) 
	As ObjectGroup on objct.SectionId = ObjectGroup.SectionId
	inner join [Library.Section] target on objct.SectionId = target.Id
	inner join [Library] lib on target.LibraryId = lib.Id
	inner join[LR.PatronOrgSummary] crby on objct.UserId = crby.UserId
	inner join [Library.SectionSubscription] following on target.id = following.SectionId
  where 
		(following.UserId = @UserId
		OR (lib.LibraryTypeId = 1 AND lib.CreatedById  = @UserId))
  AND objct.[Created] >  getdate() - @HistoryDays
  UNION
  -- library added resource =========================================================
  -- ==> should check if has access to collection?
  SELECT 
		base.[Created]
      ,convert(varchar(10), base.[Created],120) as [ActivityDay]
      ,base.[CreatedById] As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when base.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Added Resource to' As Activity

	  ,res.ResourceIntId as ObjectId
	  ,'Resource' as ObjectType
	  ,res.Title as ObjectTitle
	  ,res.Description as ObjectText
	  ,replace(replace(replace(@ResourceUrl,  '@rid',res.ResourceIntId), '@title', replace(res.SortTitle, ' ', '_')),'&','') As ObjectUrl
	  ,[Isle_IOER].[dbo].[Resource.GetImageUrl](res.ResourceUrl,res.ResourceIntId) As ObjectImageUrl
  --	  ,case 
		--when Right(rtrim(lower(res.ResourceUrl)), 4) = '.pdf' then @PdfImageUrl
		--when charindex('.ppt',Right(rtrim(lower(res.ResourceUrl)), 5)) > 0 then @PPTImageUrl
		--when charindex('.doc',Right(rtrim(lower(res.ResourceUrl)), 5)) > 0 then @PPTImageUrl
		--when charindex('.xls',Right(rtrim(lower(res.ResourceUrl)), 5)) > 0 then @XlxImageUrl

		--else replace(@ResImgeUrl, '@rid', res.ResourceIntId) end As ObjectImageUrl
	  --,replace(@ResImgeUrl, '@rid', res.ResourceIntId) As ObjectImageUrl

	  ,rls.[LikeCount] as ObjectCount
	  ,rls.[DislikeCount] as ObjectCount2
	  ,case when HasRating.IsLike is null then 0 else 1 end as HasObject

	  ,'Collection' as TargetType
	  ,LibrarySectionId As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(replace(@LibUrl, '@lid', target.LibraryId), '@cid', target.Id) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library.Resource] base
  inner join [Library.Section] target		on base.LibrarySectionId = target.Id
  inner join [Library] lib					on target.LibraryId = lib.Id
  inner join[LR.PatronOrgSummary] crby		on base.CreatedById = crby.UserId
  inner join [LR.ResourceVersion_Summary] res on base.ResourceIntId = res.ResourceIntId
  left join [LR.ResourceLikesSummary] rls	on base.ResourceIntId = rls.ResourceIntId
  left join [dbo].[LR.ResourceLike] HasRating  on base.ResourceIntId = HasRating.[ResourceIntId] And HasRating.CreatedById = @UserId
  
  inner join [Library.Subscription] following on target.id = following.LibraryId
  where 
		(following.UserId = @UserId
		OR (lib.LibraryTypeId = 1 AND lib.CreatedById  = @UserId))
  And base.IsActive = 1
  AND base.[Created] >  getdate() - @HistoryDays

  UNION
  -- comment on resource in library  =========================================================
  -- ==> should check if has access to collection?
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.[CreatedById] As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Commented On' As Activity

	  --object is comment
	  ,objct.Id as ObjectId
	  ,'Comment' as ObjectType
	  ,'Comment on resource' as ObjectTitle
	  ,objct.Comment as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  --exception: likes are for target, not object?
	  ,rls.[LikeCount] as ObjectCount
	  ,rls.[DislikeCount] as ObjectCount2
	  ,case when HasRating.IsLike is null then 0 else 1 end as HasObject

	  --target is resource
	  ,'Resource' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(replace(replace(@ResourceUrl,  '@rid',target.ResourceIntId), '@title', replace(target.SortTitle, ' ', '_')),'&','') As ObjectUrl
	  ,[Isle_IOER].[dbo].[Resource.GetImageUrl](target.ResourceUrl,target.ResourceIntId) As ObjectImageUrl
  -- 	  ,case 
		--when Right(rtrim(lower(target.ResourceUrl)), 4) = '.pdf' then @PdfImageUrl
		--when charindex('.ppt',Right(rtrim(lower(target.ResourceUrl)), 5)) > 0 then @PPTImageUrl
		--when charindex('.doc',Right(rtrim(lower(target.ResourceUrl)), 5)) > 0 then @WordImageUrl
		--when charindex('.xls',Right(rtrim(lower(target.ResourceUrl)), 5)) > 0 then @XlxImageUrl
		--else replace(@ResImgeUrl, '@rid', target.ResourceIntId) end As TargetImageUrl
	  --,replace(@ResImgeUrl, '@rid', res.ResourceIntId) As TargetImageUrl

	FROM dbo.[LR.ResourceComment] objct
  inner join dbo.[Library.Resource] base	on objct.ResourceIntId = base.ResourceIntId
  inner join [Library.Section] ls			on base.LibrarySectionId = ls.Id
  inner join [Library] lib					on ls.LibraryId = lib.Id
  inner join[LR.PatronOrgSummary] crby		on objct.CreatedById = crby.UserId
  inner join [LR.ResourceVersion_Summary] target on base.ResourceIntId = target.ResourceIntId
  left join [LR.ResourceLikesSummary] rls on base.ResourceIntId = rls.ResourceIntId
  left join [dbo].[LR.ResourceLike] HasRating  on base.ResourceIntId = HasRating.[ResourceIntId] And HasRating.CreatedById = @UserId
  
  inner join [Library.Subscription] following on lib.id = following.LibraryId
    where 
		(following.UserId = @UserId
		OR (lib.LibraryTypeId = 1 AND lib.CreatedById  = @UserId))
  AND base.[Created] >  getdate() - @HistoryDays

  UNION
  ----- library add collection =========================================================
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,objct.[CreatedById] As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Added Collection to' As Activity

	  ,objct.Id As ObjectTypeId
	  ,'Collection' as ObjectType
	  ,objct.Title as ObjectTitle
	  ,objct.Description as ObjectText
	  ,replace(replace(@CollectionUrl, '@lid', target.Id), '@cid', objct.Id) As ObjectUrl
	  ,objct.ImageUrl As ObjectImageUrl
	  ,ObjectGroup.Counts as ObjectCount
	  ,0 as ObjectCount2
	  ,0 As HasObject

	  ,'Library' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  ,replace(@LibUrl, '@lid', target.Id) As TargetUrl
	  ,target.ImageUrl As TargetImageUrl

  FROM dbo.[Library] target
  inner join [Library.Section] objct on target.Id = objct.LibraryId
    inner join (
	select libraryId, count(*) As Counts from dbo.[Library.Section] group by libraryId) 
	As ObjectGroup on objct.LibraryId = ObjectGroup.LibraryId
  inner join[LR.PatronOrgSummary] crby on objct.CreatedById = crby.UserId

  inner join [Library.Subscription] following on target.id = following.LibraryId
  where following.UserId = @UserId
  AND objct.[Created] >  getdate() - @HistoryDays
  UNION
  ----- user posts to community =========================================================
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,crby.UserId As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Posted To' As Activity

	 ,objct.Id as ObjectId
	  ,'CommunityPosting' as ObjectType
	  ,'Community Posting' as ObjectTitle
	  ,objct.Message as ObjectText
	  ,'' As ObjectUrl
	  ,'' As ObjectImageUrl
	  ,0 as ObjectCount
	  ,0 as ObjectCount2
	  ,0 As HasObject

	  ,'Community' as TargetType
	  ,target.Id As TargetObjectId
	  ,target.Title as TargetTitle
	  ,target.Description as TargetText
	  --,replace(@CommunityUrl, '@cid', target.Id) As TargetUrl
	  ,replace(replace(@CommunityUrl,  '@cid',target.Id), '@title', replace(target.Title, ' ', '_')) As TargetUrl
	  ,case when target.ImageUrl is null then @CommImgeUrl else target.ImageUrl end As TargetImageUrl

  FROM [LR.PatronOrgSummary] crby
  inner join [dbo].[Community.PostingSummary] objct	on crby.UserId = objct.CreatedById
  inner join [Community] target					on objct.CommunityId = target.Id
  
  inner join [Community.Member] following on target.id = following.CommunityId
  where following.UserId = @UserId
  AND objct.[Created] >  getdate() - @HistoryDays

   UNION
  ----- user published resource =========================================================
  -- where following actor
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,crby.UserId As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.PublishedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Published' As [Action]
	  ,'Published Resource' As Activity

	  ,res.ResourceIntId as ObjectId
	  ,'Resource' as ObjectType
	  ,res.Title as ObjectTitle
	  ,res.Description as ObjectText
	  ,replace(replace(replace(@ResourceUrl,  '@rid',res.ResourceIntId), '@title', replace(res.SortTitle, ' ', '_')),'&','') As ObjectUrl
	  ,[Isle_IOER].[dbo].[Resource.GetImageUrl](res.ResourceUrl,res.ResourceIntId) As ObjectImageUrl
	  ,rls.[LikeCount] as ObjectCount
	  ,rls.[DislikeCount] as ObjectCount2
	  ,case when HasRating.IsLike is null then 0 else 1 end as HasObject

	  ,'' as TargetType
	  ,'' as TargetObjectId
	  ,'' as TargetTitle
	  ,'' as TargetText
	  ,'' as TargetUrl
	  ,'' as TargetImageUrl

  FROM [Person.Following] following 
  Inner  join [LR.PatronOrgSummary]						crby	on following.FollowingUserId = crby.UserId
  inner join [Isle_IOER].[dbo].[Resource.PublishedBy]	objct	on crby.UserId = objct.PublishedById
  inner join [LR.ResourceVersion_Summary]				res		on objct.ResourceIntId = res.ResourceIntId
  left join [LR.ResourceLikesSummary]					rls		on res.ResourceIntId = rls.ResourceIntId
  left join [dbo].[LR.ResourceLike] HasRating					on res.ResourceIntId = HasRating.[ResourceIntId] And HasRating.CreatedById = @UserId

  where following.FollowedByUserId = @UserId
  AND objct.[Created] >  getdate() - @HistoryDays

  
   UNION
  ----- user evaluates a resource - Achieve =========================================================
  SELECT 
		objct.[Created]
      ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
      ,crby.UserId As ActorId
	  ,crby.FullName  As Actor
	  ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	  ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	  ,'Added' As [Action]
	  ,'Evaluated Resource' As Activity

	  --object is evaluation
	 ,objct.ResourceIntId as ObjectId
	  ,'Evaluation' as ObjectType
	  ,target.Title as ObjectTitle
	  ,target.Description as ObjectText
	  --,'Achieve Rubric Evaluation' as ObjectTitle
	  --,'Resource was evaluated with an Overall score of ' + convert(varchar, isnull(objct.Score,0)) as ObjectText		--??probably the overall score?
	  ,replace(replace(replace(@ResourceUrl,  '@rid',target.ResourceIntId), '@title', replace(target.SortTitle, ' ', '_')),'&','') As ObjectUrl
	  ,[Isle_IOER].[dbo].[Resource.GetImageUrl](target.ResourceUrl,target.ResourceIntId) As ObjectImageUrl
	  ,isnull(rls.[LikeCount],0) as ObjectCount
	  ,isnull(rls.[DislikeCount],0) as ObjectCount2
	  ,0 As HasObject

	  ,'Resource' as TargetType
	  ,target.Id As TargetObjectId
	  --,target.Title as TargetTitle
	  ,'Achieve Rubric Evaluation' as TargetTitle
	  --,isnull(target.Description,'') as TargetText
	  ,'Resource was evaluated with an Overall score of ' + convert(varchar, isnull(objct.Score,0)) as TargetText
	  ,[Isle_IOER].[dbo].[Resource.GetImageUrl](target.ResourceUrl,target.ResourceIntId) As TargetUrl
	  --,replace(replace(replace(@ResourceUrl,  '@rid',target.ResourceIntId), '@title', replace(target.SortTitle, ' ', '_')),'&','') As TargetImageUrl
	   ,'' as TargetImageUrl


	FROM [Person.Following] following 
	Inner  join [LR.PatronOrgSummary]						crby	on following.FollowingUserId = crby.UserId
	inner join [dbo].[LR.Resource.Evaluations]	objct	on crby.UserId = objct.CreatedById
	inner join [LR.ResourceVersion_Summary]		target	on objct.ResourceIntId = target.ResourceIntId
	left join [LR.ResourceLikesSummary]			rls		on objct.ResourceIntId = rls.ResourceIntId
  
    where following.FollowedByUserId = @UserId
  AND objct.[Created] >  getdate() - @HistoryDays
         
  --UNION
  ----- user posts to community that is followed =========================================================
  --SELECT 
		--objct.[Created]
  --    ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
  --    ,crby.UserId As ActorId
	 -- ,crby.FullName  As Actor
	 -- ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrl
	 -- ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
	 -- ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	 -- ,'Added' As [Action]
	 -- ,'Added Posting' As Activity

	 --,objct.Id as ObjectId
	 -- ,'CommunityPosting' as ObjectType
	 -- ,'Community Posting' as ObjectTitle
	 -- ,objct.Message as ObjectText
	 -- ,'' As ObjectUrl
	 -- ,'' As ObjectImageUrl
	 -- ,0 as ObjectCount
	 -- ,0 as ObjectCount2
	 -- ,0 As HasObject

	 -- ,'Community' as TargetType
	 -- ,target.Id As TargetObjectId
	 -- ,target.Title as TargetTitle
	 -- ,target.Description as TargetText
	 -- ,replace(@CommunityUrl, '@cid', target.Id) As TargetUrl
	 -- ,@CommImgeUrl As TargetImageUrl

  --FROM [LR.PatronOrgSummary] crby
  --inner join [dbo].[Community.Posting] objct	on crby.UserId = objct.CreatedById
  --inner join [Community] target					on objct. = target.Id
  --where objct.[Created] >  getdate() - @HistoryDays

  --   UNION
  ------- user authored resource =========================================================
  --SELECT 
		--objct.[Created]
  --    ,convert(varchar(10), objct.[Created],120) as [ActivityDay]
  --    ,crby.UserId As ActorId
	 -- ,crby.FullName  As Actor
	 -- ,case when crby.ImageUrl is null then @DefActorImageUrl else crby.ImageUrl end As ActorImageUrlActorImageUrl
	 -- ,replace(replace(@ActorUrl, '@uid', crby.UserId), '@Actor',crby.FirstName + '_' + crby.LastName)  As ActorUrl
--	  ,case when objct.CreatedById = @UserId then 1 else 0 end as IsMyAction

	 -- ,'Authored' As [Action]
	 -- ,'Authored a Resource' As Activity

	 -- ,objct.Id as ObjectId
	 -- ,'Resource' as ObjectType
	 -- ,objct.Title as ObjectTitle
	 -- ,objct.Description as ObjectText
	 -- ,replace(replace(@ContentUrl,  '@cid',objct.Id), '@title', replace(objct.Title, ' ', '_')) As ObjectUrl
	 -- --would need to check for a version Id and use that to get the image?? or in future may have an upload
	 -- ,'' As ObjectImageUrl
	 -- ,0 as ObjectCount
	 --,0 as ObjectCount2
	 -- ,0 As HasObject

	 -- ,'' as TargetType
	 -- ,'' as TargetObjectId
	 -- ,'' as TargetTitle
	 -- ,'' as TargetText
	 -- ,'' as TargetUrl
	 -- ,'' as TargetImageUrl

  --FROM [LR.PatronOrgSummary] crby
  --inner join [Content] objct on crby.UserId = objct.CreatedById
  --where objct.[Created] >  getdate() - @HistoryDays

  order by  1  desc
GO
grant execute on [Activity.MyFollowingSummary] to public 
Go
 
 
 