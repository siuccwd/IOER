 
 use IsleContent
 go
 

--- Insert Procedure for [Library.Member] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.MemberInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.MemberInsert]
Go
CREATE PROCEDURE [Library.MemberInsert]
            @LibraryId int, 
            @UserId int, 
            @MemberTypeId int,
			@CreatedById int

As
If @LibraryId = 0   SET @LibraryId = NULL 
If @UserId = 0   SET @UserId = NULL 
-- allow zero - for pending
--If @MemberTypeId = 0   SET @MemberTypeId = 1
 
if @LibraryId IS NULL OR @UserId IS NULL begin
	RAISERROR(' Error - LibraryId and UserId are required', 18, 1)   
	return -1
	end

INSERT INTO [Library.Member] (
    LibraryId, 
    UserId, 
    MemberTypeId,
	CreatedById, 
    LastUpdatedById
)
Values (
    @LibraryId, 
    @UserId, 
    @MemberTypeId,
	@CreatedById, 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.MemberInsert] to public
Go
 