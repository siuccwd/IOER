use IsleContent
go
--- Summary Procedure for [Library.Like] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.LikeSummary]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.LikeSummary]
Go
/*
[Library.LikeSummary] 1
*/
/*
Get summary of likes for the library
*/
CREATE PROCEDURE [Library.LikeSummary]
    @LibraryId int
As
SELECT     
    LibraryId, 
     
  	SUM(CASE WHEN IsLike = 0 THEN 1 
			ELSE 0 END) AS DisLikes, 
	SUM(CASE WHEN IsLike = 1 THEN 1 
			ELSE 0 END) AS Likes, 
	SUM(1) AS Total

FROM [Library.Like] base
WHERE LibraryId = @LibraryId
Group By LibraryId

GO
grant execute on [Library.LikeSummary] to public 
Go
 
 
 