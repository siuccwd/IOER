 
--- Delete Procedure for [Library.SectionSubscription] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Library.SectionSubscriptionDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSubscriptionDelete]
GO
CREATE PROCEDURE [Library.SectionSubscriptionDelete]
        @Id int
As
DELETE FROM [Library.SectionSubscription]
WHERE Id = @Id
GO
grant execute on [Library.SectionSubscriptionDelete]  to public
Go
