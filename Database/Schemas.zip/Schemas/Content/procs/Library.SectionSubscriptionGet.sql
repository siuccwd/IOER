 
--- Get Single Procedure for [Library.SectionSubscription] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionSubscriptionGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSubscriptionGet]
Go
/*
[Library.SectionSubscriptionGet] 2, null, 0

[Library.SectionSubscriptionGet] 0, 132, 0

[Library.SectionSubscriptionGet] 0, null, 22

*/
CREATE PROCEDURE [Library.SectionSubscriptionGet]
	@Id int,
	@SectionId int, 
	@UserId int

As
If @Id = 0   SET @Id = NULL 
If @SectionId = 0   SET @SectionId = NULL 
If @UserId = 0   SET @UserId = NULL 


If @Id is null and ( @SectionId is null Or @UserId is null ) begin
	print '[Library.SectionSubscriptionGet] Error: Incomplete parameters were provided'
	RAISERROR('[Library.SectionSubscriptionGet] Error: incomplete parameters were provided. Require: @Id OR (@SectionId and @UserId) ', 18, 1)    
	RETURN -1 
  end

SELECT     
	Id, 
    SectionId, 
	--ParentId is used for generic handling of a subscription 
	SectionId As ParentId,
    UserId, 
    SubscriptionTypeId, 
    PrivilegeId, 
    Created, 
    LastUpdated
FROM [Library.SectionSubscription]
WHERE (Id = @Id or @Id is null)
And (SectionId = @SectionId or @SectionId is null)
And (UserId = @UserId or @UserId is null)

GO
grant execute on [Library.SectionSubscriptionGet] to Public
Go