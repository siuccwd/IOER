USE IsleContent
GO
--- Insert Procedure for [Library.Section] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionInsert]
Go
/*
Insert a Library.Section
Modifications
14-01-09 mparsons - added @ImageUrl
14-01-10 mparsons - added rowId - done explicityly now to facilitate use for the imageUrl.
					Added logic to unset a existing default collection setting if the new one is to be the default
*/
CREATE PROCEDURE [Library.SectionInsert]
            @LibraryId int, 
            @SectionTypeId int, 
            @Title varchar(100),
            @Description varchar(500), 
            @IsDefaultSection bit, 
            @PublicAccessLevel int, 
            @OrgAccessLevel int, 
            @AreContentsReadOnly bit, 
            @ParentId int, 
            @CreatedById int,
			@ImageUrl varchar(200),
			@RowId varchar(50)
As
If @Title = ''			SET @Title = 'Missing - TBD' 
If @Description = ''	SET @Description = NULL 
If @ImageUrl = ''		SET @ImageUrl = NULL 
If @ParentId = 0		SET @ParentId = NULL 
If @CreatedById = 0		SET @CreatedById = NULL 
If @RowId = '' OR @RowId = '00000000-0000-0000-0000-000000000000'  SET @RowId = newId() 

declare @IsPublic bit
-- temp check during transition
if  @PublicAccessLevel = 0 begin
	set @IsPublic= 0
	end
	else begin
	set @IsPublic= 1
	if @OrgAccessLevel = 0
		set @OrgAccessLevel= 2
	end

if @IsDefaultSection = 1 begin
  --unset any existing
  update [Library.Section] set IsDefaultSection = 0 
  WHERE LibraryId = @LibraryId 
  end


INSERT INTO [Library.Section] (

    LibraryId, 
    SectionTypeId, 
    Title,
    Description, 
    ParentId, 
    IsDefaultSection,
	PublicAccessLevel,
	OrgAccessLevel,
	IsPublic,
    AreContentsReadOnly, 
	ImageUrl,
    CreatedById, 
    LastUpdatedById,
	RowId
)
Values (

    @LibraryId, 
    @SectionTypeId, 
    @Title,
    @Description, 
    @ParentId, 
    @IsDefaultSection, 
	@PublicAccessLevel,
	@OrgAccessLevel,
    @IsPublic,
    @AreContentsReadOnly, 
	@ImageUrl,
    @CreatedById, 
    @CreatedById,
	@RowId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.SectionInsert] to public
Go
 
 