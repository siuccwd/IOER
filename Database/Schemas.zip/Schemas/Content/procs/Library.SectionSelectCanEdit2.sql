USE [IsleContent]
GO
/****** Object:  StoredProcedure [dbo].[Library.SectionSelectCanEdit2]    Script Date: 9/10/2014 9:47:32 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Library.SelectCanEdit2] 22,0



[Library.SectionSelectCanEdit2] 73,2

go
[Library.SectionSelectCanEdit2] 43,2

[Library.SectionSelectCanEdit2] 1,2

[Library.SectionSelectCanEdit2] 63,22

*/

/*
Select all collections in library where user has edit access. Includes:
- personal
- libraries where has curate access
- collections where has curate access
- org libraries with implicit access
- members of multiple orgs are not implemented as yet (thru org.member)
Modifications
14-01-20 mparsons - corrected name (from [LibrarySection.SelectCanEdit])
14-02-12 mparsons - made more generic by adding BaseMemberId. Calling will specify the base as editor, contributor, even reader to handle private with members
-----------------------------------------------------------------------------
14-09-10 mparsons - start new version that provides for finer control
*/
Alter PROCEDURE [dbo].[Library.SectionSelectCanEdit2]
	@LibraryId int,
	@UserId int

As

declare @BaseMemberId int, @OrgLibAdminId int
set @BaseMemberId = 3	--editor
set @OrgLibAdminId = 4 -- libAdmin

-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	LibraryId int NOT NULL,
	SectionId int NOT NULL,
	Title varchar(100),
	AccessReason varchar(100),
	SectionTypeId int ,
	LibraryOrgId int ,
	PublicAccessLevel int ,
	OrgAccessLevel int ,
	MemberTypeId int ,
	HasExplicitAccess bit,
	NeedsApproval bit
)

--=== explicit first ======================================================================
--personal library
INSERT INTO #tempWorkTable (LibraryId, SectionId, Title, AccessReason, SectionTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, HasExplicitAccess, NeedsApproval)
SELECT distinct
	base.[Id], ls.Id, ls.[Title], 'Is Personal Lib'	
	,ls.SectionTypeId, isnull(base.OrgId,0), ls.PublicAccessLevel, ls.OrgAccessLevel
	,4		--admin	
	,1		--HasExplicitAccess
	,0		--NeedsApproval
  FROM [dbo].[Library] base
  inner join [Library.Section] ls on base.id = ls.LibraryId
  where base.IsActive = 1  
  And (base.Id = @LibraryId )
  And (base.LibraryTypeId = 1 And base.CreatedById = @UserId)
	
--member library -------------------------
-- check membership level
-- as of 14-09-01, we do not have interface for setting collection member access, so using library access
INSERT INTO #tempWorkTable (LibraryId, SectionId, Title, AccessReason, SectionTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, HasExplicitAccess, NeedsApproval)
SELECT distinct
	base.[Id], ls.Id,ls.[Title], 'Is Lib Mbr'	
	,ls.SectionTypeId, isnull(base.OrgId,0), ls.PublicAccessLevel, ls.OrgAccessLevel
	,mbr.MemberTypeId
	,1
	,0	--case when mbr.MemberTypeId > @BaseMemberId then 0
  FROM [dbo].[Library] base
  inner join [Library.Section] ls on base.id = ls.LibraryId
  inner join [Library.Member] mbr on base.id = mbr.LibraryId
  --inner join [Library.SectionMember] lsmbr on ls.id = lsmbr.LibrarySectionId

  where base.IsActive = 1 
  And (base.Id = @LibraryId )
  and ls.Id not in (select SectionId from #tempWorkTable)
  And (mbr.UserId = @UserId AND mbr.MemberTypeId >= @BaseMemberId)


--=== implicit access ======================================================================
-- org mbrs
-- check for org mbr with lib admin (not overall admin as we have a specific role for lib admin????)
INSERT INTO #tempWorkTable (LibraryId, SectionId, Title, AccessReason, SectionTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, HasExplicitAccess, NeedsApproval)
SELECT distinct
	base.[Id], ls.Id,ls.[Title], 'Is Org Lib Admin'	
	,ls.SectionTypeId, isnull(base.OrgId,0), ls.PublicAccessLevel, ls.OrgAccessLevel
	,4		--admin	
	,1
	,0	
  FROM [dbo].[Library] base
  inner join [Library.Section] ls on base.id = ls.LibraryId
 inner Join [dbo].[Gateway.Org_MemberSummary] org on base.OrgId = org.[OrgId]
 
  where base.IsActive = 1 and base.orgId is not null
  And (base.Id = @LibraryId )
  and ls.Id not in (select SectionId from #tempWorkTable)
  And (org.UserId = @UserId AND org.[OrgMemberTypeId] = @OrgLibAdminId)
  
--==== return ==========================================================
  select distinct
  	ls.[Id]
	,base.Id as LibraryId
	,base.Title as Library
	,base.Title as LibraryTitle
	,ls.[Title] As [Collection]
	,ls.[Title] As Title
	,AccessReason
	,ls.SectionTypeId, lst.Title As SectionType 
	,ls.[Description]
	,ls.IsDefaultSection
	,ls.IsPublic
	,ls.PublicAccessLevel
	,ls.OrgAccessLevel
	,ls.AreContentsReadOnly
	,ls.ImageUrl

	
	,work.MemberTypeId
	,HasExplicitAccess 
	,NeedsApproval 
	,ls.Created, ls.LastUpdated, ls.CreatedById, ls.LastUpdatedById
	,lsmt.Title as CollectionMemberType
	,base.[OrgId]
	,base.LibraryTypeId

  from #tempWorkTable work
  inner join [Library.Section] ls on work.SectionId = ls.Id
  inner join Library		base	on work.LibraryId = base.Id

  Inner join [Library.SectionType] lst on ls.SectionTypeId = lst.Id
  left join [Library.SectionMember] lsm on ls.id = lsm.LibrarySectionId
  left join [Codes.LibraryMemberType] lsmt on lsm.MemberTypeId = lsmt.Id
  left join [Library.Member] mbr on base.id = mbr.LibraryId

  Order by Title
  --==============================================================

  GO
grant execute on [Library.SectionSelectCanEdit2] to public 
Go
