USE [IsleContent]
GO

/****** Object:  StoredProcedure [dbo].[Library.PurgeOrphanResource]    Script Date: 10/30/2013 4:36:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
SELECT base.[Id]      ,[LibrarySectionId]      ,[ResourceIntId]
  FROM [IsleContent].[dbo].[Library.Resource] base
  left join Isle_IOER.[dbo].[Resource] res on base.ResourceIntId = res.Id
  where res.[ResourceUrl] is null



Exec [Library.PurgeOrphanResource] 
        
*/
/*
--- Purge Procedure for [Library.Resource] ---
-- mods
-- 14-10-10 mparsons - updated to include inactive resources
--					 - check includes where created date not equal to last updated 
--						- for case where a resource could be created as inactive, where an approval is necessary
*/

CREATE PROCEDURE [dbo].[Library.PurgeOrphanResource]
As

DELETE FROM [dbo].[Library.Resource]
  FROM [IsleContent].[dbo].[Library.Resource] base
  left join Isle_IOER.[dbo].[Resource] res on base.ResourceIntId = res.Id
  where res.[ResourceUrl] is null
  or (res.IsActive = 0 and res.Created <> res.LastUpdated)

GO
grant execute on [Library.PurgeOrphanResource] to public
go


