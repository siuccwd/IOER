 
use IsleContent
go 
 
--- Insert Procedure for [Library.Party] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.PartyInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.PartyInsert]
Go
CREATE PROCEDURE [Library.PartyInsert]
            @ParentRowId uniqueidentifier, 
            @RelatedRowId uniqueidentifier
As
If @ParentRowId = ''   SET @ParentRowId = NULL 
If @RelatedRowId = ''   SET @RelatedRowId = NULL 

INSERT INTO [Library.Party] (

    ParentRowId, 
    RelatedRowId
)
Values (

    @ParentRowId, 
    @RelatedRowId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.PartyInsert] to public
Go
 