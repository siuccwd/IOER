use IsleContent
go

 
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.ResourceMove]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.ResourceMove]
Go
/*
SELECT 
    Id, CreatedById, LibrarySectionId,
    ResourceIntId
FROM [Library.Resource]
order by CreatedById, LibrarySectionId

[Library.ResourceMove] 0, 0, 0, 5, 2

[Library.ResourceMove] 5, 0, 0, 5, 2

--dup
[Library.ResourceMove] 14, 0, 0, 1, 2
        
*/

--- Move Procedure for [Library.Resource] ---
CREATE PROCEDURE [Library.ResourceMove]
        @LibraryResourceId		int,
		@SourceLibrarySectionId int,
		@ResourceIntId			int,
        @NewLibrarySectionId	int,
        @CreatedById int

As
If @LibraryResourceId = 0		SET @LibraryResourceId = NULL 
If @ResourceIntId = 0			SET @ResourceIntId = NULL 
If @SourceLibrarySectionId = 0  SET @SourceLibrarySectionId = NULL 
If @NewLibrarySectionId = 0		SET @NewLibrarySectionId = NULL  

if @LibraryResourceId is null AND (@SourceLibrarySectionId is null OR @ResourceIntId is null) begin
  print '[Library.ResourceMove] Error: Incomplete parameters were provided'
	RAISERROR('[Library.ResourceMove] Error: incomplete parameters were provided. Require Source @LibraryResourceId, or  (@SourceLibrarySectionId AND @ResourceIntId)', 18, 1)    
	RETURN -1 
  end

  --check for dups==> doesn't matter, as move to itself is not an error!
if @LibraryResourceId is not null begin
	if exists( SELECT target.ResourceIntId FROM dbo.[Library.Resource] AS base INNER JOIN dbo.[Library.Resource] AS target ON base.ResourceIntId = target.ResourceIntId
			WHERE (target.LibrarySectionId = @NewLibrarySectionId) AND (base.Id = @LibraryResourceId)
		) begin
		print '[Library.ResourceMove] Error: resource already exists in collection'
		RAISERROR('[Library.ResourceMove] Error: resource already exists in collection', 18, 1)    
		RETURN -1 
		end 
	end
else begin
	if exists(SELECT [ResourceIntId] FROM [dbo].[Library.Resource] 
		where [ResourceIntId]= @ResourceIntId and LibrarySectionId = @NewLibrarySectionId) begin
		print '[Library.ResourceMove] Error: resource already exists in collection'
		RAISERROR('[Library.ResourceMove] Error: resource already exists in collection', 18, 1)    
		RETURN -1 
		end 
	end
		  
UPDATE [Library.Resource] 
SET 
    LibrarySectionId = @NewLibrarySectionId,
	Created = GETDATE(),
    CreatedById = @CreatedById
WHERE 
	(Id = @LibraryResourceId OR @LibraryResourceId is null)
AND (ResourceIntId = @ResourceIntId OR @ResourceIntId is null)
AND (LibrarySectionId = @SourceLibrarySectionId OR @SourceLibrarySectionId is null)
GO
grant execute on [Library.ResourceMove] to public
Go
 
 