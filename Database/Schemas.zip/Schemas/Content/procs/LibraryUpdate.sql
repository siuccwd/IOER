use IsleContent
go

if exists (select * from dbo.sysobjects where id = object_id(N'[LibraryUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [LibraryUpdate]
Go

/*
Update a Library
Modifications
14-02-05 mparsons - added Access levels. planning to remove IsPublic
14-08-24 mparsons - added IsActive.
*/
CREATE PROCEDURE [LibraryUpdate]
        @Id int,
        @Title varchar(200), 
        @Description varchar(500), 
        @IsDiscoverable bit, 
        @PublicAccessLevel int, 
        @OrgAccessLevel int, 
        @LastUpdatedById int,
        @ImageUrl varchar(100),
		@AllowJoinRequest bit,
		@IsActive bit

As
If @Description = ''   SET @Description = NULL  
If @LastUpdatedById = 0   SET @LastUpdatedById = NULL 
If @ImageUrl = ''   SET @ImageUrl = NULL 


UPDATE [Library] 
SET 
    Title = @Title, 
    Description = @Description, 
    IsDiscoverable = @IsDiscoverable, 
	PublicAccessLevel = @PublicAccessLevel, 
	OrgAccessLevel = @OrgAccessLevel, 
    AllowJoinRequest = @AllowJoinRequest, 
    ImageUrl = @ImageUrl,
	IsActive = @IsActive,
    LastUpdated = getdate(), 
    LastUpdatedById = @LastUpdatedById
WHERE Id = @Id
GO
grant execute on [LibraryUpdate] to public
Go
 