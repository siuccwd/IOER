use IsleContent
go
--- Summary Procedure for [Library.SectionLike] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionLikeSummary]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionLikeSummary]
Go


/*
[Library.SectionLikeSummary] 2
*/
/*
Get summary of likes for the collection
*/
CREATE PROCEDURE [Library.SectionLikeSummary]
    @SectionId int
As
SELECT     
    SectionId, 
     
  	SUM(CASE WHEN IsLike = 0 THEN 1 
			ELSE 0 END) AS DisLikes, 
	SUM(CASE WHEN IsLike = 1 THEN 1 
			ELSE 0 END) AS Likes, 
	SUM(1) AS Total

FROM [Library.SectionLike] base
WHERE SectionId = @SectionId
Group By SectionId

GO
grant execute on [Library.SectionLikeSummary] to public 
Go
 
 
 