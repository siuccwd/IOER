use IsleContent
go
 
--- Insert Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[LibraryInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [LibraryInsert]
Go
/*
Insert a Library
Modifications
14-01-10 mparsons - added rowId - done explicityly now to facilitate use for the imageUrl
14-02-05 mparsons - added Access levels. planning to remove IsPublic
*/
CREATE PROCEDURE [LibraryInsert]
            @Title varchar(200), 
            @Description varchar(500), 
            @LibraryTypeId int, 
            @IsDiscoverable bit, 
			@PublicAccessLevel int, 
            @OrgAccessLevel int, 
            @CreatedById int,
            @ImageUrl varchar(100),
			@OrgId int,
			@RowId varchar(50)
			,@AllowJoinRequest bit
As
If @CreatedById = 0   SET @CreatedById = NULL 
If @OrgId = 0   SET @OrgId = NULL 
If @ImageUrl = ''   SET @ImageUrl = NULL 
If @RowId = '' OR @RowId = '00000000-0000-0000-0000-000000000000'  SET @RowId = newId() 

--declare @IsPublic bit
---- temp check during transition
--if  @PublicAccessLevel < 2 begin
--	set @IsPublic= 0
--	end
--	else begin
--	set @IsPublic= 1
--	if @OrgAccessLevel = 0
--		set @OrgAccessLevel= 2
--	end

INSERT INTO [Library] (

    Title, 
    Description, 
    LibraryTypeId, 
    IsDiscoverable, 
	PublicAccessLevel,
	OrgAccessLevel,
	OrgId,
    ImageUrl,
    CreatedById, 
    LastUpdatedById,
	RowId
	,AllowJoinRequest
)
Values (

    @Title, 
    @Description, 
    @LibraryTypeId, 
    @IsDiscoverable, 
	@PublicAccessLevel,
	@OrgAccessLevel,
	@OrgId, 
    @ImageUrl,
    @CreatedById,
    @CreatedById,
	@RowId
	,@AllowJoinRequest
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [LibraryInsert] to public
Go
 