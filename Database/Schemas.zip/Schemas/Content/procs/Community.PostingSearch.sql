use IsleContent
go

--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Community.PostingSearch]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Community.PostingSearch]
Go
/*

-- ===========================================================

DECLARE @RC int,@Filter varchar(500), @StartPageIndex int, @PageSize int, @totalRows int,@SortOrder varchar(100)
set @SortOrder = '' 
set @Filter = ' CommunityId = 2 AND createdById = 2 '

set @Filter = ''
set @StartPageIndex = 1
set @PageSize = 25

exec [Community.PostingSearch] @Filter, @SortOrder, @StartPageIndex  ,@PageSize  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/

/* =================================================
= Community.Posting search
=		@StartPageIndex - starting page number. If interface is at 20 when next page is requested, this would be set to 21?
=		@PageSize - number of records on a page
=		@totalRows OUTPUT - total available rows. Used by interface to build a custom pager
= ------------------------------------------------------
= Modifications
= 14-03-06 mparsons - Created 
-- ================================================= */
Create PROCEDURE [dbo].[Community.PostingSearch]
		@Filter				varchar(500)
		,@SortOrder			varchar(500)
		,@StartPageIndex	int
		,@PageSize		    int
		,@TotalRows			int OUTPUT
AS 
DECLARE 
	@first_id			int
	,@startRow		int
	,@debugLevel	int
	,@SQL             varchar(5000)
	,@OrderBy         varchar(100)

	SET NOCOUNT ON;

-- ==========================================================
Set @debugLevel = 4
if len(@SortOrder) > 0
	set @OrderBy = ' Order by ' + @SortOrder
else 
  set @OrderBy = ' Order by cps.Created DESC'
--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

 
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	Id int NOT NULL,
	CreatedById int

)
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter 
     end
	 else begin 
	 set @Filter =     '  '
	 end
 
set @SQL = 'SELECT [Id]  ,[CreatedById]   FROM [dbo].[Community.PostingSummary] cps  '  
	  + @Filter

if charindex( 'order by', lower(@Filter) ) = 0 
	set @SQL = 	@SQL + @OrderBy
if @debugLevel > 3 begin
  print '@SQL len: '  +  convert(varchar,len(@SQL))
	print @SQL
	end
	
INSERT INTO #tempWorkTable (Id, CreatedById)
exec (@sql)
   SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Show the StartPageIndex
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

SELECT     Distinct
		RowNumber,
		[CommunityId]
      ,[Community]
      ,base.[CreatedById]
      ,[UserFullName]
      ,[UserImageUrl]
	  ,base.Id
      ,[Message]
	  ,base.Created
      ,base.[RelatedPostingId]
	  , case when isnull(base.[RelatedPostingId],0) > 0 then 1 else 0 end As HasParentPosting
	  , isnull(replys.TotalPosts,0) As TotalReplys
  
From #tempWorkTable temp
inner join [dbo].[Community.PostingSummary] base on temp.Id = base.Id

    Left Join [LR.PatronOrgSummary] creator on base.CreatedById = creator.Userid
	
	left join (SELECT cp.[RelatedPostingId], count(*) As TotalPosts
		  FROM [Community.Posting] cp group by cp.[RelatedPostingId]) 
		  As replys on base.id = replys.RelatedPostingId

WHERE RowNumber > @first_id 
order by RowNumber		

SET ROWCOUNT 0
Go
grant execute on [Community.PostingSearch] to public 
Go