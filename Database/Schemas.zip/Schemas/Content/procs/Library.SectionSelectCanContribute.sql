USE [IsleContent]
GO

--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionSelectCanContribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSelectCanContribute]
Go
/*
[Library.SectionSelectCanContribute] 45,2
*/

/*
Select all collections in library where user has contribute access. Includes:
- personal
- libraries where has curate access
- collections where has curate access
- org libraries with implicit access
- members of multiple orgs are not implemented as yet (thru org.member)
Modifications
14-01-20 mparsons - corrected name (from [LibrarySection.SelectCanEdit])
14-06-29 mparsons - added (base.PublicAccessLevel >= 3) for library??
*/
CREATE PROCEDURE [Library.SectionSelectCanContribute]
	@LibraryId int,
	@UserId int
As
declare @BaseMemberId int, @AccessLevel int
set @BaseMemberId = 2	--contributor
set @BaseMemberId = 3	--curator
set @AccessLevel = 3	--Contribute with Approval
SELECT distinct
	ls.[Id]
	,base.Id as LibraryId
	,base.Title as Library
	,base.Title as LibraryTitle
	,ls.[Title] As [Collection]
	,ls.[Title] As Title
	,ls.SectionTypeId, lst.Title As SectionType 
	,ls.[Description]
	,ls.IsDefaultSection
	
	,case when ls.PublicAccessLevel > 1 then 1 else 0 end As IsPublic
	,ls.PublicAccessLevel
	,ls.OrgAccessLevel
	,ls.AreContentsReadOnly
	,ls.ImageUrl
	,ls.Created, ls.LastUpdated, ls.CreatedById, ls.LastUpdatedById
	,lsmt.Title as CollectionMemberType
	,base.[OrgId]
	,base.LibraryTypeId


  FROM [dbo].[Library] base
  inner join [Library.Section] ls on base.id = ls.LibraryId
  Inner join [Library.SectionType] lst on ls.SectionTypeId = lst.Id
  left join [Library.SectionMember] lsm on ls.id = lsm.LibrarySectionId
  left join [Codes.LibraryMemberType] lsmt on lsm.MemberTypeId = lsmt.Id
  left join [Library.Member] mbr on base.id = mbr.LibraryId
--all orgs with libraries where user is associated
  left Join (
	Select distinct pos.OrgId ,pos.UserId, pos.Organization
	from [dbo].[Gateway.Org_MemberSummary] pos
	inner join Library orgLib on pos.OrgId = orgLib.OrgId
	) orgLibs on base.OrgId = orgLibs.OrgId

where 
	[IsActive]= 1 
And base.id = @LibraryId
And (
	(base.[CreatedById]= @UserId and LibraryTypeId = 1)
	OR
	(base.PublicAccessLevel >= @AccessLevel)
	OR
	(ls.PublicAccessLevel >= @AccessLevel)
	OR
	(mbr.UserId = @UserId AND mbr.MemberTypeId >= @BaseMemberId)
	OR
	(lsm.UserId = @UserId AND lsm.MemberTypeId >= @BaseMemberId)
	OR
	(orgLibs.UserId = @UserId)
)
Order by ls.Title 

GO
grant execute on [Library.SectionSelectCanContribute] to public 
Go