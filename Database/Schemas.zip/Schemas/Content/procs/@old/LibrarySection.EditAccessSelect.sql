USE [IsleContent]
GO

--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[LibrarySection.SelectCanEdit]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [LibrarySection.SelectCanEdit]
Go
/*
[LibrarySection.SelectCanEdit] 45,22

[LibrarySection.SelectCanEdit] 45,2
*/

CREATE PROCEDURE [LibrarySection.SelectCanEdit]
	@LibraryId int,
	@UserId int
As

declare @OrgId int, @IsOrgMbr bit

--select @OrgId = OrganizationId from [dbo].[LR.PatronOrgSummary] where 


SELECT distinct
	ls.[Id]
	,ls.[Title]
	,ls.ImageUrl
	,lsmt.Title as CollectionMemberType
	,base.[OrgId]
	,ls.[CreatedById]

  FROM [dbo].[Library] base
  inner join [Library.Section] ls on base.id = ls.LibraryId
  left join [Library.SectionMember] lsm on ls.id = lsm.LibrarySectionId
  left join [Codes.LibraryMemberType] lsmt on lsm.MemberTypeId = lsmt.Id
  left join [Library.Member] mbr on base.id = mbr.LibraryId

  left Join (
	Select distinct OrganizationId as OrgId ,pos.UserId, orgLib.Id As LibraryId
	from [dbo].[LR.PatronOrgSummary] pos
	inner join Library orgLib on pos.OrganizationId = orgLib.OrgId
	) orgLibs on base.OrgId = orgLibs.OrgId	
where 
	[IsActive]= 1 And ls.libraryId = @LibraryId
And (
	(base.[CreatedById]= @UserId and LibraryTypeId = 1)
	OR
	(mbr.UserId = @UserId AND mbr.MemberTypeId > 1)
	OR
	(lsm.UserId = @UserId AND lsm.MemberTypeId > 1)
	OR 
	(orgLibs.UserId = @UserId AND orgLibs.LibraryId = @LibraryId)
)
Order by ls.Title 

GO
grant execute on [LibrarySection.SelectCanEdit] to public 
Go