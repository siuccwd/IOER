
--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[LibrarySelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [LibrarySelect]
Go
/*

*/
CREATE PROCEDURE [LibrarySelect]
  @OwnerId int,
  @LibraryTypeId int
As

If @OwnerId = 0   SET @OwnerId = NULL 
If @LibraryTypeId = 0   SET @LibraryTypeId = NULL 

SELECT 
    base.Id, 
    base.Title, 
    base.Description, 
    LibraryTypeId, 
    lt.Title as LibraryType,
    IsDiscoverable, 
    IsPublic, 
    base.ImageUrl, 
    base.Created, base.CreatedById, 
    base.LastUpdated, base.LastUpdatedById
    
FROM [Library] base
inner join [Library.Type] lt on base.LibraryTypeId = lt.Id
where 
    (CreatedById = @OwnerId OR @OwnerId is null)
AND (LibraryTypeId = @LibraryTypeId OR @LibraryTypeId is null)

Order by lt.Title, base.Title

GO
grant execute on [LibrarySelect] to public 
Go