
--- Insert Procedure for [Content.History] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Content.HistoryInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Content.HistoryInsert]
Go
CREATE PROCEDURE [Content.HistoryInsert]
            @ContentId int, 
            @Action varchar(75), 
            @Description varchar(MAX), 
            @CreatedById int
As

If @Action = ''   SET @Action = 'Unknown' 
If @Description = ''   SET @Description = NULL 
If @CreatedById = 0   SET @CreatedById = NULL 

INSERT INTO [Content.History] (

    ContentId, 
    Action, 
    Description, 
    Created, 
    CreatedById
)
Values (

    @ContentId, 
    @Action, 
    @Description, 
    getdate(), 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Content.HistoryInsert] to public
Go
 