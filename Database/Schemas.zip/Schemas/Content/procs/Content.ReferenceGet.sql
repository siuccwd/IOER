 
--- Get Single Procedure for [Content.Reference] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Content.ReferenceGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Content.ReferenceGet]
Go
CREATE PROCEDURE [Content.ReferenceGet]
    @Id int
As
SELECT     Id, 
    ParentId, 
    Title, 
    Author, 
    Publisher, 
    ISBN, 
    ReferenceUrl, AdditionalInfo,
    Created, 
    CreatedById, 
    LastUpdated, 
    LastUpdatedById
FROM [Content.Reference]
WHERE Id = @Id
GO
grant execute on [Content.ReferenceGet] to Public
Go
 