 
 use IsleContent
 go
 
--- Insert Procedure for [Library.Member] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.PartyMemberInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.PartyMemberInsert]
Go

/*
@ParentRowId could be for library or librarySection
*/
CREATE PROCEDURE [Library.PartyMemberInsert]
            @LibraryId int, 
            @UserId int, 
            @MemberTypeId int,
			@ParentRowId uniqueidentifier, 
			@CreatedById int

As
If @LibraryId = 0   SET @LibraryId = NULL 
If @UserId = 0   SET @UserId = NULL 
If @MemberTypeId = 0   SET @MemberTypeId = 1
 
if @LibraryId IS NULL OR @UserId IS NULL begin
	RAISERROR(' Error - LibraryId and UserId are required', 18, 1)   
	return -1
	end
declare @NewId uniqueidentifier, @Id int
set @NewId = newId()

INSERT INTO [Library.Member] (
    LibraryId, 
    UserId, 
    MemberTypeId,
	CreatedById, 
    LastUpdatedById,
	RowId
)
Values (
    @LibraryId, 
    @UserId, 
    @MemberTypeId,
	@CreatedById, 
    @CreatedById,
	@NewId
)
 
set @Id = SCOPE_IDENTITY() 

INSERT INTO [Library.Party] (

    ParentRowId, 
    RelatedRowId
)
Values (

    @ParentRowId, 
    @NewId
)

select @Id As Id, @newId as RelatedRowId
GO
grant execute on [Library.PartyMemberInsert] to public
Go
 