
--- Insert Procedure for [Library.Comment] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.CommentInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.CommentInsert]
Go
CREATE PROCEDURE [Library.CommentInsert]
            @LibraryId int, 
            @Comment varchar(1000), 
            @CreatedById int
As

If @CreatedById = 0   SET @CreatedById = NULL 
INSERT INTO [Library.Comment] (

    LibraryId, 
    Comment, 
    CreatedById
)
Values (

    @LibraryId, 
    @Comment, 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.CommentInsert] to public
Go
 