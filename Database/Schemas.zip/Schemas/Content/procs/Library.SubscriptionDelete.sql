--- Delete Procedure for [Library.Subscription] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Library.SubscriptionDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SubscriptionDelete]
GO
CREATE PROCEDURE [Library.SubscriptionDelete]
        @Id int,
        @LibraryId int, 
        @UserId int
As

If @Id = 0          SET @Id = NULL 
If @LibraryId = 0   SET @LibraryId = NULL 
If @UserId = 0      SET @UserId = NULL 

If @Id = 0 OR ( @LibraryId = 0 And @UserId = 0 ) begin
  RAISERROR('[Library.SubscriptionDelete] - invalid request. Require @Id, OR @LibraryId AND @UserId', 18, 1)  
  return -1
  end

DELETE FROM [Library.Subscription]
WHERE 
    (Id = @Id or @Id is null)
And (LibraryId = @LibraryId or @LibraryId is null)    
And (UserId = @UserId or @UserId is null)

GO
grant execute on [Library.SubscriptionDelete]  to public
Go
