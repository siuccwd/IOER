use IsleContent
go
 
--- Select Procedure for [Library.Comment] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionCommentSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionCommentSelect]
Go

/*
Select all comments for a library
- or do we want to implement paging?
*/
CREATE PROCEDURE [Library.SectionCommentSelect]
    @SectionId int
As
SELECT     
	Id, 
    SectionId, 
    Comment, 
    base.Created, 
    base.CreatedById, 
	pos.Fullname, pos.Firstname, pos.Lastname
FROM [Library.SectionComment] base
inner join [LR.PatronOrgSummary] pos on base.createdById = pos.UserId
WHERE SectionId = @SectionId
Order by base.created desc
GO
grant execute on [Library.SectionCommentSelect] to Public
Go