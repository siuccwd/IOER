USE [IsleContent]
GO
/****** Object:  StoredProcedure [dbo].[Content.UpdateResourceVersionId]    Script Date: 03/20/2013 15:44:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--- Update ResourceVersionId for [Content] ---
-- ====================================================================
--mods
--13-04-23 mparsons - added ResourceVersionId

Create  PROCEDURE [dbo].[Content.UpdateResourceVersionId]
        @Id int,
        @ResourceVersionId int
As

If @ResourceVersionId = 0   SET @ResourceVersionId = NULL 

UPDATE [Content] 
SET 
    ResourceVersionId = @ResourceVersionId,
    LastUpdated = GETDATE()
    
WHERE Id = @Id

go
grant execute on [Content.UpdateResourceVersionId] to public
go

