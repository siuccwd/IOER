
 
--- Insert Procedure for [Library.SectionSubscription] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionSubscriptionInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSubscriptionInsert]
Go
CREATE PROCEDURE [Library.SectionSubscriptionInsert]
            @SectionId int, 
            @UserId int, 
            @SubscriptionTypeId int
As
If @SectionId = 0   SET @SectionId = NULL 
If @UserId = 0   SET @UserId = NULL 
If @SubscriptionTypeId = 0   SET @SubscriptionTypeId = NULL 


INSERT INTO [Library.SectionSubscription] (

    SectionId, 
    UserId, 
    SubscriptionTypeId
)
Values (

    @SectionId, 
    @UserId, 
    @SubscriptionTypeId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.SectionSubscriptionInsert] to public
Go