
--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.UniqueLibrariesForResource]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.UniqueLibrariesForResource]
Go
/*
[Library.UniqueLibrariesForResource] 21632

[Library.UniqueLibrariesForResource] 62959
go
[Library.UniqueLibrariesForResource] 87451

*/
CREATE PROCEDURE [Library.UniqueLibrariesForResource]
  @ResourceIntId int
As

SELECT distinct 
    res.ResourceIntId, lib.Id as LibraryId, ls.Id as CollectionId

FROM [Library.Resource] res
inner join [Library.Section] ls on res.LibrarySectionId = ls.Id 
Inner join Library lib on ls.LibraryId = lib.Id	
where     (res.ResourceIntId = @ResourceIntId)

Order by res.ResourceIntId, lib.Id, ls.Id

GO
grant execute on [Library.UniqueLibrariesForResource] to public 
Go