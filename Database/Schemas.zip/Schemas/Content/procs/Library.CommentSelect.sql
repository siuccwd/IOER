
 use IsleContent
 go
--- Select Procedure for [Library.Comment] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.CommentSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.CommentSelect]
Go

/*
[Library.CommentSelect] 1
*/
/*
Select all comments for a library
- or do we want to implement paging?
*/
CREATE PROCEDURE [Library.CommentSelect]
    @LibraryId int
As
SELECT     Id, 
    LibraryId, 
    Comment, 
	base.Created, 
    base.CreatedById,  
    pos.Fullname, pos.Firstname, pos.Lastname
FROM [Library.Comment] base
inner join [LR.PatronOrgSummary] pos on base.createdById = pos.UserId
WHERE LibraryId = @LibraryId
Order by base.created desc
GO
grant execute on [Library.CommentSelect] to Public
Go