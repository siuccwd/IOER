use IsleContent
go
 
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.ResourceCopy]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.ResourceCopy]
Go
/*
SELECT 
    Id, CreatedById, LibrarySectionId,
    ResourceIntId
FROM [Library.Resource]
order by CreatedById, LibrarySectionId

[Library.ResourceCopy] 0, 0, 391196, 63, 2

[Library.ResourceCopy] 5, 0, 0, 5, 2
        
-dups
[Library.ResourceCopy] 5, 0, 0, 1, 2

[Library.ResourceCopy] 0, 5, 438562, 5, 2

[Library.ResourceCopy] 0, 5, 444654, 4, 2

*/
/*
--- Update Procedure for [Library.Resource] ---
Modifications
14-01-09 mparsons - removing @SourceLibrarySectionId (will physically remove later)
*/
CREATE PROCEDURE [Library.ResourceCopy]
        @LibraryResourceId int,
		@SourceLibrarySectionId int,
		@ResourceIntId int,
        @NewLibrarySectionId int,
        @CreatedById int

As
If @LibraryResourceId = 0		SET @LibraryResourceId = NULL 
If @ResourceIntId = 0			SET @ResourceIntId = NULL 
If @SourceLibrarySectionId = 0  SET @SourceLibrarySectionId = NULL 
If @NewLibrarySectionId = 0		SET @NewLibrarySectionId = NULL 

if (@LibraryResourceId is null AND @ResourceIntId is null) OR @NewLibrarySectionId is null begin
  print '[Library.ResourceCopy] Error: Incomplete parameters were provided'
	RAISERROR('[Library.ResourceCopy] Error: incomplete parameters were provided. Require destination @NewLibrarySectionId, and Source @LibraryResourceId, or  @ResourceIntId', 18, 1)    
	RETURN -1 
  end

  --check for dups
if @LibraryResourceId is not null begin
	if exists( SELECT target.ResourceIntId FROM dbo.[Library.Resource] AS base INNER JOIN dbo.[Library.Resource] AS target ON base.ResourceIntId = target.ResourceIntId
			WHERE (target.LibrarySectionId = @NewLibrarySectionId) AND (base.Id = @LibraryResourceId)
		) begin
		print '[Library.ResourceCopy] Error: resource already exists in collection'
		RAISERROR('[Library.ResourceCopy] Error: resource already exists in collection', 18, 1)    
		RETURN -1 
		end 
	else begin
		SELECT @ResourceIntId = isnull(ResourceIntId,0) FROM [Library.Resource] where Id = @LibraryResourceId
		if (@ResourceIntId is null OR @ResourceIntId =0) begin
		  print '[Library.ResourceCopy] Error: Incomplete parameters were provided'
			RAISERROR('[Library.ResourceCopy] Error: invalid @LibraryResourceId - not found', 18, 1)    
			RETURN -1 
		  end
		end
	end
else begin
	if exists(SELECT [ResourceIntId] FROM [dbo].[Library.Resource] 
		where [ResourceIntId]= @ResourceIntId and LibrarySectionId = @NewLibrarySectionId) begin
		print '[Library.ResourceCopy] Error: resource already exists in collection'
		RAISERROR('[Library.ResourceCopy] Error: resource already exists in collection', 18, 1)    
		RETURN -1 
		end 
	end
		  

INSERT INTO [Library.Resource] (

    LibrarySectionId, 
    ResourceIntId, 
    Created, 
    CreatedById
)
Values (

    @NewLibrarySectionId, 
    @ResourceIntId, 
    getdate(), 
    @CreatedById
)
--SELECT 
--    @NewLibrarySectionId, 
--    ResourceIntId,  
--    getdate(), 
--    @CreatedById
--FROM [Library.Resource]
--where 
--	(Id = @LibraryResourceId OR @LibraryResourceId is null)
--AND (ResourceIntId = @ResourceIntId OR @ResourceIntId is null)

select isnull(SCOPE_IDENTITY(),0) as Id
GO
grant execute on [Library.ResourceCopy] to public
Go
 
 