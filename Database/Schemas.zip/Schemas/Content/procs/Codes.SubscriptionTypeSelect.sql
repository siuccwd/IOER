
--- Get Procedure for [Codes.SubscriptionType] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Codes.SubscriptionTypeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Codes.SubscriptionTypeSelect]
Go
CREATE PROCEDURE [Codes.SubscriptionTypeSelect]
As
SELECT 
    Id, 
    Title
FROM [Codes.SubscriptionType]
where IsActive = 1
Order by Title
GO
grant execute on [Codes.SubscriptionTypeSelect] to public 
Go