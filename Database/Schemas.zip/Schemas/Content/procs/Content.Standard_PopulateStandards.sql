USE [IsleContent]
GO


Create PROCEDURE [dbo].[Content.Standard_PopulateStandards]
INSERT INTO [dbo].[Content.Standard]
           ([ContentId]
           ,[StandardId]
           ,[StandardUrl]
           ,[AlignmentTypeCodeId]
           ,[Created]
           ,[CreatedById])

SELECT c.[Id]
      ,rs.[StandardId]
      ,rs.[StandardUrl]
      ,rs.[AlignmentTypeCodeId]
      ,rs.[Created]
      ,rs.[AlignedById]
  FROM [dbo].[LR.ResourceStandard] rs
  inner join [Content] c on rs.ResourceIntId = c.ResourceIntId
  left join [Content.Standard] cs 
		on c.Id = cs.ContentId and cs.[StandardId] = rs.[StandardId]
		where cs.ContentId is null

go
grant execute on [Content.Standard_PopulateStandards] to public
go

