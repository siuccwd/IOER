
--- Delete Procedure for [Library.Section] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Library.SectionDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionDelete]
GO

/*
[Library.SectionDelete] 186

Delete a collection
Modifications
140309 mparsons - need yo manually delete external collections, if exists
				- only promote if [Library.ExternalSection] in use

*/
CREATE PROCEDURE [Library.SectionDelete]
        @Id int
As

--check for external sections (probably don't need to bother with exits check)
if exists(SELECT Id FROM [Library.ExternalSection] base where base.externalSectionId = @Id ) begin
    print 'external sections found'
    DELETE FROM [Library.ExternalSection] WHERE ExternalSectionId = @Id
    end   

DELETE FROM [Library.Section]
WHERE Id = @Id
GO
grant execute on [Library.SectionDelete]  to public
Go