 
--- Get Procedure for [ContentType] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[ContentTypeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [ContentTypeSelect]
Go
CREATE PROCEDURE [ContentTypeSelect]
As
SELECT 
    Id, 
    Title, 
    Description, 
    HasApproval, 
    MaxVersions, 
    IsActive, 
    Created, 
    RowId
FROM [ContentType]
where IsActive = 1
Order by Title
GO
grant execute on [ContentTypeSelect] to public 
Go
 