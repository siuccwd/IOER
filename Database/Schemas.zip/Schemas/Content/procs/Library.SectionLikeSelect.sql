 use IsleContent
 go

--- Get Procedure for [Library.SectionLike] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionLikeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionLikeSelect]
Go
/*
Get summary of likes for the collection
*/
CREATE PROCEDURE [Library.SectionLikeSelect]
    @SectionId int
As
SELECT     
	Id, 
    SectionId, 
    IsLike, 
    base.Created, 
    base.CreatedById,  
	pos.Fullname, pos.Firstname
FROM [Library.SectionLike] base
inner join [LR.PatronOrgSummary] pos on base.createdById = pos.UserId
WHERE SectionId = @SectionId
GO
grant execute on [Library.SectionLikeSelect] to public 
Go
 
 
 