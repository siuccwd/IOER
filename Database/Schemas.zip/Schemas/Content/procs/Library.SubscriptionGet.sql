use IsleContent
go
 
--- Get Single Procedure for [Library.Subscription] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SubscriptionGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SubscriptionGet]
Go


/*

[Library.SubscriptionGet] 0,25,29
[Library.SubscriptionGet] 0,0,29
[Library.SubscriptionGet] 0,25,0

[Library.SubscriptionGet] 0,0,0
*/
CREATE PROCEDURE [Library.SubscriptionGet]
        @Id int,
        @LibraryId int, 
        @UserId int
As
If @Id = 0          SET @Id = NULL 
If @LibraryId = 0   SET @LibraryId = NULL 
If @UserId = 0      SET @UserId = NULL 

If @Id is null and ( @LibraryId is null Or @UserId is null ) begin
  RAISERROR('[Library.SubscriptionGet] - invalid request. Require @Id, OR @LibraryId AND @UserId', 18, 1)  
  return -1
  end

  
SELECT     
    base.Id, 
    LibraryId, lib.Title as Library,
	--ParentId is used for generic handling of a subscription 
	LibraryId As ParentId,
    UserId, 
    SubscriptionTypeId, cst.Title as SubscriptionType,
    --PrivilegeId As MemberTypeId, 
    base.Created
FROM [Library.Subscription] base
Inner Join dbo.Library lib on base.LibraryId = lib.Id
Inner Join dbo.[Codes.SubscriptionType] cst on base.SubscriptionTypeId = cst.Id
WHERE 
    (base.Id = @Id or @Id is null)
And (LibraryId = @LibraryId or @LibraryId is null)    
And (UserId = @UserId or @UserId is null)

GO
grant execute on [Library.SubscriptionGet] to Public
Go
 
 