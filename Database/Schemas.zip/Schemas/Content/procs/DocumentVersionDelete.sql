USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersionDelete]    Script Date: 04/01/2013 00:13:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[DocumentVersionDelete]
        @RowId uniqueidentifier
As
DELETE FROM [Document.Version]
WHERE RowId = @RowId

GO


