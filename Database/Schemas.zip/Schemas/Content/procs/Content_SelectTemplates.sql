USE [IsleContent]
GO
/****** Object:  StoredProcedure [dbo].[ContentGet]    Script Date: 05/10/2013 20:44:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Content_SelectTemplates]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Content_SelectTemplates]
GO
/*
[Content_SelectTemplates] 3

*/
Create PROCEDURE [dbo].[Content_SelectTemplates]
    @OrgId int
As
declare @ParentOrgId int

SELECT @ParentOrgId = isnull([ParentOrgId],0) FROM [dbo].[ContentSummaryView] where [OrgId] = @OrgId
if @ParentOrgId is null or @ParentOrgId = 0 set @ParentOrgId = @OrgId
 
SELECT [ContentId] as Id
      ,[Title]
     
      
  FROM [IsleContent].[dbo].[ContentSummaryView]
where [TypeId] = 15 
and [ContentStatus] = 'Published'
and ([OrgId] = @OrgId OR [OrgId] = @ParentOrgId)

go 
grant execute on [Content_SelectTemplates] to public
go


