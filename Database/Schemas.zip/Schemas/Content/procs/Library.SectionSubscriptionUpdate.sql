use IsleContent
go

if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionSubscriptionUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSubscriptionUpdate]
Go
--- Update Procedure for [Library.SectionSubscription] ---
CREATE PROCEDURE [Library.SectionSubscriptionUpdate]
		@Id int,
        @SubscriptionTypeId int

As

UPDATE [Library.SectionSubscription] 
SET 
    SubscriptionTypeId = @SubscriptionTypeId, 
    LastUpdated = getdate()
WHERE Id = @Id
GO
grant execute on [Library.SectionSubscriptionUpdate] to public
Go
 
 