USE IsleContent
GO
 
--- Get Single Procedure for [Library.Resource] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.ResourceGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.ResourceGet]
Go

/*
[Library.ResourceGet] 31
*/
CREATE PROCEDURE [Library.ResourceGet]
    @Id int
As
SELECT     
	libres.Id, 
	libres.Id As LibraryResourceId,
    LibrarySectionId, 
    libres.ResourceIntId, 
	lr.ResourceVersionIntId,
	 CASE
      WHEN lr.Title IS NULL THEN 'No Title'
      WHEN len(lr.Title) = 0 THEN 'No Title'
      ELSE lr.Title
    END AS Title,
	lr.ResourceUrl,
	lr.SortTitle,
    Comment, 
    libres.Created, 
    libres.CreatedById, resAddedBy.FullName As CreatedBy, resAddedBy.ImageUrl As CreatedByImageUrl

FROM [Library.Resource] libres
Inner join  [dbo].[lr.ResourceVersion_Summary] lr on libres.ResourceIntId = lr.ResourceIntId
Inner Join [LR.PatronOrgSummary] resAddedBy on libres.CreatedById = resAddedBy.UserId

WHERE libres.Id = @Id

grant execute on [Library.ResourceGet] to Public
Go