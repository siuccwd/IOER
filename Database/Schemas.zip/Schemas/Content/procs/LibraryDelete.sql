
 
--- Delete Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LibraryDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [LibraryDelete]
GO
CREATE PROCEDURE [LibraryDelete]
        @Id int
As
DELETE FROM [Library]
WHERE Id = @Id
GO
grant execute on [LibraryDelete]  to public
Go
