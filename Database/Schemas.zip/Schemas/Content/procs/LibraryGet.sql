use IsleContent
go

--- Get Single Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[LibraryGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [LibraryGet]
Go
/*

[LibraryGet] 1, ''

[LibraryGet] 0, '0ACD2A29-7027-4D5E-95AC-B32632BDD6CF'

[LibraryGet] 0, ''

*/
/*
Modifications
14-08-20 mparsons - added creator and last updated by user
*/
CREATE PROCEDURE [LibraryGet]
    @Id int,
    @RowId varchar(40)
As
if @Id = 0      set @Id= NULL
if @RowId = ''  set @RowId= NULL

If @Id is null and @RowId is null begin
	print '[Library.Get] Error: Incomplete parameters were provided'
	RAISERROR('[Library.Get] Error: incomplete parameters were provided. Require: @Id OR @RowId ) ', 18, 1)    
	RETURN -1 
  end

SELECT     
    base.Id, 
    base.Title, 
    base.Description, 
    LibraryTypeId, lt.Title as LibraryType,
    IsDiscoverable, 
    isnull(base.OrgId,0) As OrgId,
    isnull(org.Name, '') As Organization,
    base.IsActive,
	AllowJoinRequest,
	base.PublicAccessLevel,
	base.OrgAccessLevel,
    base.ImageUrl, 
    base.Created, base.CreatedById, creator.[FullName] as CreatedBy,
    base.LastUpdated, base.LastUpdatedById, lastUpdator.FullName As LastUpdatedBy,
    base.RowId
    
FROM [Library] base
inner join [Library.Type] lt on base.LibraryTypeId = lt.Id
left join [dbo].[Gateway.OrgSummary] org on base.OrgId = org.id
left join [dbo].[LR.PatronOrgSummary] creator on base.CreatedById = creator.UserId
left join [dbo].[LR.PatronOrgSummary] lastUpdator on base.LastUpdatedById = lastUpdator.UserId

WHERE 
    (base.Id = @Id OR @Id is null)
AND (base.RowId = @RowId OR @RowId is null)    

GO
grant execute on [LibraryGet] to Public
Go
 