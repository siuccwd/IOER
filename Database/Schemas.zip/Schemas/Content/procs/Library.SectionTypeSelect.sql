USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[Library.SectionTypeSelect]    Script Date: 03/15/2013 18:5:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
[Library.SectionTypeSelect]

*/
CREATE PROCEDURE [dbo].[Library.SectionTypeSelect]

As

SELECT [Id]
      ,[Title]
      ,[AreContentsReadOnly]
      ,[Decription]
      ,[SectionCode]
      ,[Created]
  FROM [dbo].[Library.SectionType]
  Order by 2
go
grant execute on [Library.SectionTypeSelect] to public 

GO


