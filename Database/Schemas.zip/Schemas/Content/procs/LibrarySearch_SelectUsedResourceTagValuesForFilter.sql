USE [IsleContent]
GO
/****** Object:  StoredProcedure [dbo].[LibrarySearch_SelectUsedResourceTagValuesForFilter]    Script Date: 9/9/2014 9:21:37 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
SELECT [TagValueId]  as [Id], Title, CodeId  FROM dbo.[Codes.TagCategoryValue_Summary] 

LibrarySearch_SelectUsedResourceTagValuesForFilter 18,1,0
go
LibrarySearch_SelectUsedResourceTagValuesForFilter 19,1,0
go

LibrarySearch_SelectUsedResourceTagValuesForFilter 14,0,2
go
LibrarySearch_SelectUsedResourceTagValuesForFilter 8,0,2
go
LibrarySearch_SelectUsedResourceTagValuesForFilter 11,0,2

*/
Create PROCEDURE [dbo].[LibrarySearch_SelectUsedResourceTagValuesForFilter]
		 @CategoryId		int
		,@LibraryId			int
		,@LibrarySectionId  int

As
declare @Sql varchar(500)
SET NOCOUNT ON;
--caller must set square brackets if needed
set @sql = 'Select [TagValueId]  as [Id], Title, CodeId FROM dbo.[Codes.TagCategoryValue_Summary] codes 
WHERE codes.categoryId = ' + convert(varchar,@CategoryId) + ' AND codes.[TagValueId] in (
	select distinct res.TagValueId  
	from [dbo].[Resource.Tag] res 
	inner join dbo.[Library.Resource] lres on res.ResourceIntId = lres.ResourceIntId 
	INNER JOIN [dbo].[Library.Section] lsec ON lres.LibrarySectionId = lsec.Id 
	where 
		lsec.LibraryId	= ' + convert(varchar,@LibraryId) + ' 
	OR	lsec.Id			= ' + convert(varchar,@LibrarySectionId) + '	)
	Order by 2'
	
	print @sql
	exec(@sql)
go
grant execute on [LibrarySearch_SelectUsedResourceTagValuesForFilter] to public
go