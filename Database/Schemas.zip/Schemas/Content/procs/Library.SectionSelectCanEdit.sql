USE [IsleContent]
GO

--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionSelectCanEdit]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSelectCanEdit]
Go
/*
[Library.SectionSelectCanEdit] 63,22

[Library.SectionSelectCanEdit] 43,22
*/

/*
Select all collections in library where user has edit access. Includes:
- personal
- libraries where has curate access
- collections where has curate access
- org libraries with implicit access
- members of multiple orgs are not implemented as yet (thru org.member)
Modifications
14-01-20 mparsons - corrected name (from [LibrarySection.SelectCanEdit])
14-02-12 mparsons - made more generic by adding BaseMemberId. Calling will specify the base as editor, contributor, even reader to handle private with members
-----------------------------------------------------------------------------
14-06-29 mparsons - start new version that provides for finer control
*/
CREATE PROCEDURE [Library.SectionSelectCanEdit]
	@LibraryId int,
	@UserId int
	--,@BaseMemberId int
As
declare @BaseMemberId int
set @BaseMemberId = 3	--editor

SELECT distinct
	ls.[Id]
	,base.Id as LibraryId
	,base.Title as Library
	,base.Title as LibraryTitle
	,ls.[Title] As [Collection]
	,ls.[Title] As Title
	,ls.SectionTypeId, lst.Title As SectionType 
	,ls.[Description]
	,ls.IsDefaultSection
	,ls.IsPublic
	,ls.PublicAccessLevel
	,ls.OrgAccessLevel
	,ls.AreContentsReadOnly
	,ls.ImageUrl
	,ls.Created, ls.LastUpdated, ls.CreatedById, ls.LastUpdatedById
	,lsmt.Title as CollectionMemberType
	,base.[OrgId]
	,base.LibraryTypeId


  FROM [dbo].[Library] base
  inner join [Library.Section] ls on base.id = ls.LibraryId
  Inner join [Library.SectionType] lst on ls.SectionTypeId = lst.Id
  left join [Library.SectionMember] lsm on ls.id = lsm.LibrarySectionId
  left join [Codes.LibraryMemberType] lsmt on lsm.MemberTypeId = lsmt.Id
  left join [Library.Member] mbr on base.id = mbr.LibraryId
--all orgs with libraries where user is associted
  left Join (
	Select distinct OrganizationId as OrgId ,pos.UserId
	from [dbo].[LR.PatronOrgSummary] pos
	inner join Library orgLib on pos.OrganizationId = orgLib.OrgId
	) orgLibs on base.OrgId = orgLibs.OrgId
where 
	[IsActive]= 1 
And base.id = @LibraryId
And (
	(base.[CreatedById]= @UserId and LibraryTypeId = 1)
	OR
	(mbr.UserId = @UserId AND mbr.MemberTypeId >= @BaseMemberId)
	OR
	(lsm.UserId = @UserId AND lsm.MemberTypeId >= @BaseMemberId)
	OR
	(orgLibs.UserId = @UserId)
)
Order by ls.Title 

GO
grant execute on [Library.SectionSelectCanEdit] to public 
Go