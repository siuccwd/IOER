USE IsleContent
GO
/****** Object:  StoredProcedure [dbo].[Library.ResourceSearch]    Script Date: 10/02/2012 09:18:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

--set @Filter = @Filter + ' OR FREETEXT(lrs.SubjectCsv, ''physic'') '
set @Filter = @Filter + ' OR lrs.SubjectsIdx like ''%physic%'' '

set @Filter = ' where  (lr.Title like ''a %'' OR lr.[Description] like ''a %'' OR lr.[ResourceUrl] like ''a %'' OR lrs.Subject like ''a %'' OR lr.Keywords like ''a %'') '
-- OR lr.[Description] like ''%Finance%'' OR lr.[Description] like ''%Manufacturing%'' 
set @Filter = ' where (LibraryTypeId = 1 and lib.LibraryCreatedById = 2) AND ( (lr.Title like ''%mouse%'' OR lr.[Description] like ''%mouse%'' OR lrs.[Subject] like '%mouse%' ) ) '
 
 SELECT distinct lib.LibraryId, lib.LibraryResourceId, lr.SortTitle,lr.SUbjects ,lr.ResourceIntId
        FROM [dbo].[Library.SectionResourceSummary] lib 
        inner join [dbo].[LR.ResourceVersion_SearchSummary] lr on lib.ResourceIntId = lr.ResourceIntId  
		where      
		--(( Subjects like '%Get Work Experience%' ))  
		--AND  
		(lib.LibrarySectionId = 4)   
		
		Order by lr.SortTitle 


--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--
set @SortOrder = ''

-- blind search 
set @Filter = ''
                       
set @Filter = ' where ( lr.id in (select ResourceIntId from [Resource.Language] where LanguageId in (1)) ) AND ( (lr.AccessRightsId in (2,4)) ) AND ( lr.id in (select ResourceIntId from [Resource.Cluster] where ClusterId in (8,11)) )  '


set @filter = ' where   ([IsDiscoverable] = 1 )  '
                     
set @filter = ' where    (LibraryId = 1 and lib.IsActive = 1)'
 set @filter = ' where    (LibrarySectionId = 139 and lib.IsActive = 1)'

set @filter = ' where   (SUbjects like ''%technology%''  )'
set @filter = ' where      (( Subjects like ''%Get Work Experience%'' ))  AND  (lib.LibrarySectionId = 4) '

set @filter = ' where      (( Keywords like ''%michael%'' ))  AND  (lib.LibrarySectionId = 4) '


--set @filter = ' where   ( (LibraryTypeId = 1 and LibraryCreatedById = 2) AND ((lr.id in (select ResourceIntId from (SELECT [ResourceIntId], count(*) As RecCount FROM [dbo].[LR.ResourceStandard] group by [ResourceIntId] ) As ResStandards )) ) )'


set @StartPageIndex = 1
set @PageSize = 55
--set statistics time on       
EXECUTE @RC = [Library.ResourceSearch]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/

/* =============================================
      Description:      Library Resource search
  Uses custom paging to only return enough rows for one page
     Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
13-03-12 mparsons - new

*/

Alter PROCEDURE [dbo].[Library.ResourceSearch]
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@OrderBy         varchar(100)


-- =================================

Set @debugLevel = 4

if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by lr.SortTitle '

--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

 
-- =================================
CREATE TABLE #tempWorkTable(
      RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
      LibraryId int,
      LibraryResourceId    int,
      Title             varchar(200)
)

-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
  set @SQL = 'SELECT lib.LibraryId, lib.LibraryResourceId, lr.SortTitle 
        FROM [dbo].[Library.SectionResourceSummary] lib 
        inner join [dbo].[LR.ResourceVersion_SearchSummary] lr on lib.ResourceIntId = lr.ResourceIntId '
        + @Filter
        
  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (LibraryId, LibraryResourceId, Title)
  exec (@SQL)
  --print 'rows: ' + convert(varchar, @@ROWCOUNT)
  SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Calculate the range
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- =================================
--SELECT Distinct TOP (@PageSize)
SELECT Distinct    
    RowNumber,
    lib.[LibraryId] ,[Library]
    ,lib.[LibraryTypeId]
    ,lib.[LibraryType]
    --,[OrgId]
    ,lib.[IsDiscoverable]
   -- ,lib.[IsPublic]
    ,lib.[LibraryCreatedById]
	,convert(varchar(11),lib.DateAddedToCollection,109) As DateAddedToCollection
	--,convert(varchar(11),lib.DateAddedToCollection,120) As DateAddedToCollection2
    ,lib.[LibrarySectionId], lib.LibrarySection
    ,lib.[SectionTypeId] ,[LibrarySectionType]
    ,lib.[IsDefaultSection]
    ,lib.[AreContentsReadOnly]
    ,lib.LibraryResourceId
    ,lib.[ResourceIntId]
    ,lib.DateAddedToCollection
	,lib.IsActive
	,lib.libResourceCreatedById, resAddedBy.FullName As CreatedBy, resAddedBy.ImageUrl As CreatedByImageUrl
    --,lr.ResourceVersionId As RowId,
    ,lr.ResourceVersionIntId,
    lr.ResourceUrl,
	convert(varchar(11),lr.[Modified],109) As ResourceCreated,
    CASE
      WHEN lr.Title IS NULL THEN 'No Title'
      WHEN len(lr.Title) = 0 THEN 'No Title'
      ELSE lr.Title
    END AS Title
    ,lr.SortTitle
    ,lr.[Description]
    ,isnull(Publisher,'Unknown') As Publisher
    ,rtrim(ltrim(isnull(Creator,''))) As Creator

	,isnull([LikeCount], 0) As [LikeCount]
    ,isnull([DislikeCount], 0) As [DislikeCount]
		,Rights
    ,AccessRights
    ,isnull(UserComments.RecordsCount, 0) As NbrComments
    ,isnull(ResStandards.RecordsCount, 0) As NbrStandards
    ,isnull(evals.EvaluationsCount, 0)    As NbrEvaluations
    
From #tempWorkTable
    Inner join  [dbo].[Library.SectionResourceSummary] lib on #tempWorkTable.LibraryResourceId = lib.LibraryResourceId
    Inner join  [dbo].[lr.ResourceVersion_Summary] lr on lib.ResourceIntId = lr.ResourceIntId
	Inner Join [LR.PatronOrgSummary] resAddedBy on lib.libResourceCreatedById = resAddedBy.UserId

    left Join   [dbo].[LR.ResourceLikesSummary] rlike on lr.ResourceIntId = rlike.ResourceIntId
    
    left join (
		SELECT [ResourceIntId], count(*) as RecordsCount FROM [dbo].[LR.ResourceComment] group by [ResourceIntId]
		) As UserComments on lib.ResourceIntId = UserComments.ResourceIntId

    left join (
		SELECT [ResourceIntId], count(*) as RecordsCount FROM dbo.[LR.ResourceStandard] group by [ResourceIntId]
		) As ResStandards on lib.ResourceIntId = ResStandards.ResourceIntId

    left join [LR.Resource.EvaluationsCount] evals on lib.ResourceIntId = evals.ResourceIntId


WHERE RowNumber > @first_id
order by RowNumber 

go

grant execute on [Library.ResourceSearch] to public
go
