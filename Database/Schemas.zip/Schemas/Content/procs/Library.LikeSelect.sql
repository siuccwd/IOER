 use IsleContent
 go
 --- Get Single Procedure for [Library.Like] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.LikeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.LikeSelect]
Go

/*
select list of like respondants
*/
CREATE PROCEDURE [Library.LikeSelect]
    @LibraryId int
As
SELECT     base.Id, 
    base.LibraryId, 
    IsLike, 
    base.Created, 
    base.CreatedById, 
	pos.Fullname, pos.Firstname
FROM [Library.Like] base
inner join [LR.PatronOrgSummary] pos on base.createdById = pos.UserId
WHERE LibraryId = @LibraryId 

GO
grant execute on [Library.LikeSelect] to Public
Go
