USE [IsleContent]
GO
 
--- Insert Procedure for [Library.Invitation] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.InvitationInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.InvitationInsert]
Go

CREATE PROCEDURE [Library.InvitationInsert]
            @LibraryId int, 
            @InvitationType varchar(50), 
            @PassCode varchar(50), 
            @TargetEmail varchar(150), 
            @TargetUserId int, 
            @Subject varchar(100), 
            @MessageContent varchar(MAX), 
            @EmailNoticeCode varchar(50), 
            @Response varchar(50), 
            @ResponseDate datetime, 
            @ExpiryDate datetime, 
            @DeleteOnResponse bit,  
            @CreatedById int

As

If @InvitationType = ''   SET @InvitationType = 'Personal' 
If @PassCode = ''   SET @PassCode = NULL 
If @TargetEmail = ''   SET @TargetEmail = NULL 
If @TargetUserId = 0   SET @TargetUserId = NULL 
If @Subject = ''   SET @Subject = NULL 
If @MessageContent = ''   SET @MessageContent = NULL 
If @EmailNoticeCode = ''   SET @EmailNoticeCode = NULL 
If @Response = ''   SET @Response = NULL 
If @ResponseDate = ''   SET @ResponseDate = NULL 
If @ExpiryDate = ''   SET @ExpiryDate = NULL 

If @CreatedById = 0   SET @CreatedById = NULL 

INSERT INTO [Library.Invitation] (

    LibraryId, 
    InvitationType, 
    PassCode, 
    TargetEmail, 
    TargetUserId, 
    Subject, 
    MessageContent, 
    EmailNoticeCode, 
    Response, 
    ResponseDate, 
    ExpiryDate, 
    DeleteOnResponse, 
    CreatedById, 
    LastUpdatedById
)
Values (

    @LibraryId, 
    @InvitationType, 
    @PassCode, 
    @TargetEmail, 
    @TargetUserId, 
    @Subject, 
    @MessageContent, 
    @EmailNoticeCode, 
    @Response, 
    @ResponseDate, 
    @ExpiryDate, 
    @DeleteOnResponse, 
    @CreatedById, 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.InvitationInsert] to public
Go
 