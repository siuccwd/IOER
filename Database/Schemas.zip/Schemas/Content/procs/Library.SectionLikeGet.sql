--- Get Single Procedure for [Library.SectionLike] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionLikeGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionLikeGet]
Go

--use to check for existing like
CREATE PROCEDURE [Library.SectionLikeGet]
    @SectionId int,
	@UserId int
As
SELECT     Id, 
    SectionId, 
    IsLike, 
    Created, 
    CreatedById
FROM [Library.SectionLike]
WHERE 
	SectionId = @SectionId
and CreatedById= @UserId
GO
grant execute on [Library.SectionLikeGet] to Public
Go
