 
--- Delete Procedure for [Content.Reference] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Content.ReferenceDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Content.ReferenceDelete]
GO
CREATE PROCEDURE [Content.ReferenceDelete]
        @Id int
As
DELETE FROM [Content.Reference]
WHERE Id = @Id
GO
grant execute on [Content.ReferenceDelete]  to public
Go
