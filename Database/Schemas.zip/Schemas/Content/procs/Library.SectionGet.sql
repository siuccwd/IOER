USE IsleContent
GO
--- Get Single Procedure for [Library.Section] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionGet]
Go
/*

[Library.SectionGet] 0, ''

[Library.SectionGet] 1, ''

[Library.SectionGet] 0, '4FDDEF88-46A8-4C17-AC89-B5FE5EAA69D3'

modifications
14-01-10 mparsons - updated to return rowId
14-01-12 mparsons - updated to optionally retrieve by rowId
14-08-20 mparsons - added creator and last updated by user
*/
CREATE PROCEDURE [Library.SectionGet]
    @Id int,
	@RowId varchar(50)
As
If @Id = 0   SET @Id = NULL 
If @RowId = '' OR @RowId = '00000000-0000-0000-0000-000000000000'  SET @RowId = NULL 

if @Id IS NULL And @RowId is null begin
	RAISERROR(' Error - either Library section Id or Library section RowId are required', 18, 1)   
	return -1
	end
SELECT     
    base.Id, 
    LibraryId, lib.Title As LibraryTitle,
    base.Title,
    SectionTypeId, lst.Title As SectionType ,
    base.Description, 
    ParentId, 
    base.IsDefaultSection, base.IsPublic,
	base.PublicAccessLevel,
	base.OrgAccessLevel,
    base.AreContentsReadOnly, 
    base.ImageUrl, Lib.ImageUrl As LibraryImageUrl,
    base.Created, base.CreatedById, creator.[FullName] as CreatedBy,
    base.LastUpdated, base.LastUpdatedById, lastUpdator.FullName As LastUpdatedBy,
	    base.RowId
    
FROM [Library.Section] base
Inner join [Library] lib on base.LibraryId = lib.Id
Inner join [Library.SectionType] lst on base.SectionTypeId = lst.Id
left join [dbo].[LR.PatronOrgSummary] creator on base.CreatedById = creator.UserId
left join [dbo].[LR.PatronOrgSummary] lastUpdator on base.LastUpdatedById = lastUpdator.UserId

WHERE 
	(base.Id = @Id OR @Id is null)
AND (base.RowId = @RowId or @RowId is null)
GO
grant execute on [Library.SectionGet] to Public
Go
 
 