
 use IsleContent
 go
 
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.MemberUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.MemberUpdate]
Go
--- Update Procedure for [Library.Member] ---
CREATE PROCEDURE [Library.MemberUpdate]
        @Id int, 
        @MemberTypeId int, 
        @LastUpdatedById int
As

If @MemberTypeId = 0   SET @MemberTypeId = 1 

if @Id = 0 OR @LastUpdatedById = 0 begin
	RAISERROR(' Error - LibraryId and UserId are required', 18, 1)   
	return -1
	end
UPDATE [Library.Member] 
SET 
    MemberTypeId = @MemberTypeId, 
    LastUpdated = GETDATE(), 
    LastUpdatedById = @LastUpdatedById
WHERE Id = @Id
GO
grant execute on [Library.MemberUpdate] to public
Go
 