USE [IsleContent]
GO

/****** Object:  StoredProcedure [dbo].[Library.UniqueSectionsForResource]    Script Date: 2/10/2014 12:21:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.UniqueSectionsForResource]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.UniqueSectionsForResource]
Go
/*
[Library.UniqueSectionsForResource] 21632
*/
CREATE PROCEDURE [dbo].[Library.UniqueSectionsForResource]
  @ResourceIntId int
As

SELECT distinct 
    res.ResourceIntId, ls.Id as CollectionId

FROM [Library.Resource] res
inner join [Library.Section] ls on res.LibrarySectionId = ls.Id 

where     (res.ResourceIntId = @ResourceIntId)

Order by res.ResourceIntId, ls.Id

GO
grant execute on [Library.UniqueSectionsForResource] to public 
Go
