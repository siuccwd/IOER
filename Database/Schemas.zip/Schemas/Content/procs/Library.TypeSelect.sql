USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[Library.TypeSelect]    Script Date: 03/15/2013 18:15:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
[Library.TypeSelect]

*/
CREATE PROCEDURE [dbo].[Library.TypeSelect]

As

SELECT [Id]
      ,[Title]
      ,[Description]
      ,[Created]
  FROM [dbo].[Library.Type]
  Order by 2
go
grant execute on [Library.TypeSelect] to public 

GO


