USE [IsleContent]
GO
/****** Object:  StoredProcedure [dbo].[Curriculum.SendFollowerEmail]    Script Date: 10/29/2014 10:21:12 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
DECLARE @sysprocId int, @sysprocLastRun datetime
set @sysprocLastRun= '2014-10-01'

SELECT MIN(sub.UserId) AS UserId, FullName, Email, sub.ContentId, c.Title AS CurriculumTitle, hist.Description
		FROM [Content.Subscription] sub
		INNER JOIN Isle_IOER.dbo.[Patron_Summary] patsum ON sub.UserId = patsum.Id
		INNER JOIN dbo.[Content] c ON sub.ContentId = c.Id
		INNER JOIN dbo.[Content.History] hist ON sub.ContentId = hist.ContentId
		WHERE 
			hist.Created >= @sysprocLastRun 
		--AND patsum.Email NOT IN (SELECT [E-mail Address] FROM BouncedEmails WHERE [Bounce Type] = 'hard')  
		--AND c.StatusId = 5 And c.IsActive = 1
		AND sub.SubscriptionTypeId = 3

		GROUP BY FullName, Email, sub.ContentId, c.Title, hist.Description
		ORDER BY UserId, c.Title, sub.ContentId


[Curriculum.SendFollowerEmail] 'CurriculumNotificationDaily', 2, 10

*/
-- =============================================
-- Description:	Sends email notifications of recent updates to a curriculum
--
-- Debug levels:
-- 10 = Send email to admin address instead of actual recipient.
-- 11 = Same as 10 plus skip the update of the System.Process record
-- 12 = Send *NO* e-mail and skip update of the System.Process record
--
-- =============================================
Alter PROCEDURE [dbo].[Curriculum.SendFollowerEmail]
	@code varchar(50),
	@subscriptionTypeId int,
	@debug int = 1,
	@adminAddress varchar(50) = 'mparsons@siuccwd.com'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Get last run date ============================???
	DECLARE @sysprocId int, @sysprocLastRun datetime
	SELECT @sysprocId = Id, @sysprocLastRun = LastRunDate
	FROM [System.Process]
	WHERE Code = @code
	DECLARE @LastRunDate datetime
	SET @LastRunDate = GETDATE()
	
	-- Get email notice =============================????
	DECLARE @Subject varchar(100), @HtmlBodyTemplate nvarchar(max)
	--SELECT @Subject = [Subject], @HtmlBodyTemplate = HtmlBody
	--FROM EmailNotice
	--WHERE NoticeCode = 'CurriculumNotification'
	
	set @Subject= 'Updates to Curriculum'
	set @HtmlBodyTemplate= '<font face="Arial">Dear @Fullname,<div><br></div><div>This email is to notify you of updates to curricula that you follow. &nbsp;The updates are listed below.</div><div><br></div><div>@UpdateList</div><div><br></div><div>Sincerely,</div><div>The ISLE OER Team</div></font>'


	DECLARE @HtmlBody nvarchar(max), @Data nvarchar(max), @ContentTemplate nvarchar(300), @ResourceTemplate nvarchar(500)
	--SET @ContentTemplate = '<h1>Curriculum: @ContentName</h1><p>Updated: @LastUpdated</p>'
	SET @ContentTemplate = '<h1 style="margin: 0 10px;"><a href="http://ioer.ilsharedlearning.org/curriculum/@ContentId/@ContentName">Curriculum: @ContentName</h1></a>'
	SET @ResourceTemplate = '<p style="margin: 0 10px;">Updated: @LastUpdated</p><p style="margin-left: 25px;">@Description</p><hr>'
	
	DECLARE @UserId int, @FullName varchar(101), @Email varchar(100), @ContentId int, @ContentTitle varchar(200),
		@HoldUserId int, @HoldEmail varchar(100), @HoldContentId int, @Url varchar(200), @Description varchar(max), @LastUpdated varchar(20),
		@FirstTimeThru bit, @DoContentBreak bit, @EmailsSent int, @BatchSize int

	SET @FirstTimeThru = 'True'
	SET @DoContentBreak = 'False'
	SET @EmailsSent = 0
	SET @BatchSize = 2000
	SET @Data = ''		

		--need link to curriculum
		--http://ioer.ilsharedlearning.org/curriculum/5059/ISBE_Grade_3_Model_Math_Curriculum
	-- Loop through subscribers
	PRINT 'Looping through subscribers'
	DECLARE dataCursor CURSOR FOR
		SELECT MIN(sub.UserId) AS UserId, FullName, Email, sub.ContentId, convert(varchar(10),sub.Created, 120) As Updated, c.Title AS CurriculumTitle, hist.Description
		FROM [Content.Subscription] sub
		INNER JOIN Isle_IOER.dbo.[Patron_Summary] patsum ON sub.UserId = patsum.Id
		INNER JOIN dbo.[Content] c ON sub.ContentId = c.Id
		INNER JOIN dbo.[Content.History] hist ON sub.ContentId = hist.ContentId
		WHERE 
			hist.Created >= @sysprocLastRun 
		AND patsum.Email NOT IN (SELECT [E-mail Address] FROM BouncedEmails WHERE [Bounce Type] = 'hard')  
		AND c.StatusId = 5 And c.IsActive = 1
		AND sub.SubscriptionTypeId = @subscriptionTypeId
		GROUP BY FullName, Email, sub.ContentId, convert(varchar(10),sub.Created, 120), c.Title, hist.Description
		ORDER BY UserId, c.Title, sub.ContentId

	OPEN dataCursor

	FETCH NEXT FROM dataCursor INTO @UserId, @FullName, @Email, @ContentId, @LastUpdated, @ContentTitle, @Description
	
	WHILE @@FETCH_STATUS = 0 BEGIN
		PRINT 'next:   ' + convert(varchar,@UserId) + ', title: ' +  @ContentTitle

		-- Do First Record special processing
		IF @FirstTimeThru = 'True' BEGIN
			SET @HtmlBody = @HtmlBodyTemplate
			SET	@HtmlBody = REPLACE(@HtmlBody,'@FullName',IsNull(@FullName,''))
			SET @HoldEmail = @Email
			SET @HoldUserId = @UserId
			SET @Data = @ContentTemplate
			SET @Data = REPLACE(@Data,'@ContentName',IsNull(@ContentTitle,''))
			SET @Data = REPLACE(@Data,'@ContentId',IsNull(@ContentId,''))

			SET @HoldUserId = @UserId
			SET @HoldContentId = @ContentId
			SET @FirstTimeThru = 'False'
		END
		
		-- Do @UserId control break processing
		IF @UserId <> @HoldUserId BEGIN
			SET @DoContentBreak = 'True'
			SET @HtmlBody = REPLACE(@HtmlBody,'@UpdateList',IsNull(@Data,''))

			IF @debug > 11 BEGIN
				PRINT 'Skipping Email for  <'+@HoldEmail+'>: '+@HtmlBody
			END ELSE IF @debug > 9 BEGIN
				PRINT 'Skipping Email for '+@HoldEmail+'> - Sending to '+@adminAddress+': '+@HtmlBody
				EXEC msdb.dbo.sp_send_dbmail
					@profile_name = 'DoNotReply-ILSharedLearning',
					@recipients=@adminAddress,
					@subject=@Subject,
					@body=@HtmlBody,
					@body_format='HTML'
			END ELSE BEGIN
				EXEC msdb.dbo.sp_send_dbmail
					@profile_name='DoNotReply-ILSharedLearning',
					@recipients=@HoldEmail,
					@subject=@Subject,
					@body=@HtmlBody,
					@body_format='HTML'
			END

			SET @HtmlBody = @HtmlBodyTemplate
			SET	@HtmlBody = REPLACE(@HtmlBody,'@FullName',IsNull(@FullName,''))
			SET @HoldEmail = @Email
			SET @HoldUserId = @UserId
			SET @Data = ''
			
			SET @EmailsSent = @EmailsSent + 1
			IF @EmailsSent % @BatchSize = 0 BEGIN
				WAITFOR DELAY '00:01:00'
				EXEC msdb.dbo.sysmail_delete_mailitems_sp @sent_status='sent'
			END
		END
		
		-- Do @ContentId control break processing
		IF @ContentId <> @HoldContentId OR @DoContentBreak = 'True' BEGIN
			SET @DoContentBreak = 'False'
			SET @Data = @Data+@ContentTemplate
			SET @Data = REPLACE(@Data,'@ContentName',IsNull(@ContentTitle,''))
			SET @Data = REPLACE(@Data,'@ContentId',IsNull(@ContentId,''))
			SET @HoldContentId = @ContentId
		END

		-- Do processing
		SET @Data = @Data+@ResourceTemplate
		SET @Data = REPLACE(@Data,'@Description',IsNull(@Description,''))
		SET @Data = REPLACE(@Data,'@LastUpdated',IsNull(@LastUpdated,''))
		
		FETCH NEXT FROM dataCursor INTO @UserId, @FullName, @Email, @ContentId, @LastUpdated, @ContentTitle, @Description
	END
	CLOSE dataCursor
	DEALLOCATE dataCursor
	PRINT '** completed loop **'

	if len(IsNull(@Data,'')) > 10 begin
		PRINT '** send last email **'

		SET @HtmlBody = REPLACE(@HtmlBody,'@UpdateList',IsNull(@Data,''))
		IF @debug > 11 BEGIN
			PRINT 'Skipping Email for  <'+@HoldEmail+'>: '+@HtmlBody
		END ELSE IF @debug > 9 BEGIN
			PRINT 'Skipping Email for '+@HoldEmail+'> - Sending to '+@adminAddress+': '+@HtmlBody
			EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'DoNotReply-ILSharedLearning',
				@recipients=@adminAddress,
				@subject=@Subject,
				@body=@HtmlBody,
				@body_format='HTML'
		END ELSE BEGIN
			EXEC msdb.dbo.sp_send_dbmail
				@profile_name='DoNotReply-ILSharedLearning',
				@recipients=@HoldEmail,
				@subject=@Subject,
				@body=@HtmlBody,
				@body_format='HTML'
		END
	end

	-- Cleanup emails already sent
	IF @debug < 10 
		WAITFOR DELAY '00:01:00'

	EXEC msdb.dbo.sysmail_delete_mailitems_sp @sent_status='sent'
	
	-- Update System.Process record if applicable
	IF @debug < 10 BEGIN
		UPDATE [System.Process]
		SET LastRunDate = @LastRunDate
		WHERE Code = @code
	END	
END
