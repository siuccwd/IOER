USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[ActivityLogInsert]    Script Date: 04/27/2013 17:35:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ActivityLogInsert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ActivityLogInsert]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--- Insert Procedure for ActivityLog---

Create PROCEDURE [dbo].[ActivityLogInsert]
        @ActivityType varchar(25), 
        @Activity     varchar(75), 
        @Event        varchar(75), 
        @Comment      varchar(500) 
        ,@TargetUserId      int
        ,@ActivityObjectId  int 
        ,@ActionByUserId    int 
        ,@Integer2			int
		,@RelatedImageUrl varchar(200)
		,@RelatedTargetUrl varchar(200)
As
If @ActivityType = ''   SET @ActivityType = 'audit' 
If @Activity  = ''      SET @Activity  = 'Unknown'  
If @Event = ''          SET @Event = NULL 
If @Comment = ''        SET @Comment = NULL 
If @TargetUserId = 0        SET @TargetUserId = NULL 
If @ActivityObjectId = 0    SET @ActivityObjectId = NULL 
If @ActionByUserId = 0		SET @ActionByUserId = NULL 
If @Integer2 = 0			SET @Integer2 = NULL 
If @RelatedImageUrl = ''	SET @RelatedImageUrl = NULL 
If @RelatedTargetUrl = ''	SET @RelatedTargetUrl = NULL 

INSERT INTO ActivityLog
(
    CreatedDate, 
    ActivityType, 
    Activity, 
    Event, 
    Comment, 
    TargetUserId 
    ,ActivityObjectId 
    ,ActionByUserId 
    ,Int2
	,RelatedImageUrl
	,RelatedTargetUrl
)
Values (

    getdate(), 
    @ActivityType, 
    @Activity, 
    @Event, 
    @Comment 
    ,@TargetUserId 
    ,@ActivityObjectId
    ,@ActionByUserId 
    ,@Integer2
	,@RelatedImageUrl
	,@RelatedTargetUrl
)
 
select SCOPE_IDENTITY() As Id

GO

grant execute on [ActivityLogInsert] to public
go
