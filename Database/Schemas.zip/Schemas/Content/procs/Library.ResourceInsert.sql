
--- Insert Procedure for [Library.Resource] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.ResourceInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.ResourceInsert]
Go
/*
select top 200 * from [resource.version_summary]



[Library.ResourceInsert] 0, 89, 447237, '', 2

*/
/*
need to handle insert by code (for views, published, etc
If @LibrarySectionId is 0, and have a code, would need to look up by code and createdById
  - would have to handle creating of the section for the first time.
  - might be cleaner to handle server side
  
- we may want to handle my published differently anyway - or allow to delete?
  - if persisting under Resource.PublishedBy, no need to persist specifically, just allow display
- we could allow null section id - useful for quick adds
=========================================================
Modifications
14/02/03 mparsons -added code to update favoriteCount on the resource table
			******* be sure to change the absolute reference to the resource table if added to another database
*/
CREATE PROCEDURE [Library.ResourceInsert]
            @LibraryId int, 
            @LibrarySectionId int, 
            @ResourceIntId int, 
            @Comment varchar(500), 
            @CreatedById int
As
If @ResourceIntId = 0   SET @ResourceIntId = NULL 
If @LibrarySectionId = 0   SET @LibrarySectionId = NULL 
If @LibraryId = 0   SET @LibraryId = NULL 
If @Comment = ''   SET @Comment = NULL 
If @CreatedById = 0   SET @CreatedById = NULL 

If (@LibrarySectionId is null AND @LibraryId is null) OR @ResourceIntId is null begin
  print '[Library.ResourceInsert] Error: Incomplete parameters were provided'
	RAISERROR('[Library.ResourceInsert] Error: incomplete parameters were provided. Require Source @ResourceIntId, and @sectionId or @LibraryId', 18, 1)    
	RETURN -1 
  end
declare @sectionId int
,@availableSectionsCount int
,@newLibResId	int
,@setSectionAsDefault bit

set @setSectionAsDefault= 0

  
If @LibrarySectionId is null begin
    print '@LibrarySectionId not include, get default'
   select @LibrarySectionId = isnull(Id,0) from [Library.Section] where LibraryId = @LibraryId and IsDefaultSection = 1
   if @LibrarySectionId is null or @LibrarySectionId = 0 begin
      print 'default section not found, get min updateable'
      select @LibrarySectionId = isnull(min(Id),0) from [Library.Section] where LibraryId = @LibraryId and AreContentsReadOnly = 0
      if @LibrarySectionId is null or @LibrarySectionId = 0 begin
        print 'no available updateable sections, creating'
        --create
        INSERT INTO [dbo].[Library.Section]
           ([LibraryId]
           ,[SectionTypeId]
           ,[Description]
           ,[ParentId]
           ,[IsDefaultSection]
           ,[AreContentsReadOnly]
           ,[Created]
           ,[CreatedById]
           ,[LastUpdated]
           ,[LastUpdatedById])
         VALUES
               (@LibraryId, 
               3, 
               'Default section', 
               null, 
               1, 
               0, 
               getdate(), @CreatedById, 
               getdate(), @CreatedById 
                )
        set @LibrarySectionId = SCOPE_IDENTITY()
        end  --insert 
     else begin
        -- set as default
        UPDATE [dbo].[Library.Section]    
          SET [IsDefaultSection] = 1
        WHERE id = @LibrarySectionId
        end --min updateable found
      end --= default not found
      
   end --get default
   
--check for dups
if exists(SELECT [ResourceIntId] FROM [dbo].[Library.Resource] 
    where [ResourceIntId]= @ResourceIntId and LibrarySectionId = @LibrarySectionId) begin
    print '[Library.ResourceInsert] Error: resource already exists in collection'
    RAISERROR('[Library.ResourceInsert] Error: resource already exists in collection', 18, 1)    
    RETURN -1 
    end   
    
INSERT INTO [Library.Resource] (

    LibrarySectionId, 
    ResourceIntId, 
    Comment, 
    Created, 
    CreatedById
)
Values (

    @LibrarySectionId, 
    @ResourceIntId, 
    @Comment, 
    getdate(), 
    @CreatedById
)
 
select @newLibResId = SCOPE_IDENTITY() 
	
	--UPDATE [Isle_IOER].[dbo].[Resource]
	--SET FavoriteCount = FavoriteCount + 1
	--WHERE Id = @ResourceIntId

select @newLibResId  as Id
GO
grant execute on [Library.ResourceInsert] to public
Go