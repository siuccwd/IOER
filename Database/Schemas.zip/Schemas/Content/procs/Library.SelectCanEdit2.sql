USE [IsleContent]
GO
/****** Object:  StoredProcedure [dbo].[Library.SelectCanEdit2]    Script Date: 9/10/2014 9:47:32 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
[Library.SelectCanEdit2] 22,0
*/

/*
Select all libraries/collections where user has edit access. Includes:
- personal
- libraries where has curate access
- collections where has curate access
- org libraries with implicit access
- members of multiple orgs are not implemented as yet (thru org.member)
Modifications
14-02-10 mparsons - add optional lib parm to reduce the recordset and allow easy check of access to a specific library
-----------------------------------------------------------------------------
14-06-29 mparsons - start new version that provides for finer control
*/
Alter PROCEDURE [dbo].[Library.SelectCanEdit2]
  @UserId int
  ,@LibraryId	int
  --,@BaseMemberId int
As
if @LibraryId = 0	set @LibraryId = NULL

declare @BaseMemberId int, @OrgLibAdminId int
set @BaseMemberId = 3	--editor
set @OrgLibAdminId = 4 -- libAdmin
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	LibraryId int NOT NULL,
	Title varchar(100),
	AccessReason varchar(100),
	LibraryTypeId int ,
	LibraryOrgId int ,
	PublicAccessLevel int ,
	OrgAccessLevel int ,
	MemberTypeId int ,
	HasExplicitAccess bit,
	NeedsApproval bit
)
--=== explicit first ======================================================================
--personal library
INSERT INTO #tempWorkTable (LibraryId, Title, AccessReason, LibraryTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, HasExplicitAccess, NeedsApproval)
SELECT distinct
	base.[Id]	
	,base.[Title], 'Is Personal Lib'	
	,base.LibraryTypeId, isnull(base.OrgId,0), base.PublicAccessLevel, base.OrgAccessLevel
	,4		--admin	
	,1
	,0
  FROM [dbo].[Library] base
  where base.IsActive = 1 
  And (base.Id = @LibraryId OR @LibraryId is null)
  And (base.LibraryTypeId = 1 And base.CreatedById = @UserId)
	
--member library -------------------------
-- not sure but am treating contributors as do need approval
INSERT INTO #tempWorkTable (LibraryId, Title, AccessReason, LibraryTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, HasExplicitAccess, NeedsApproval)
SELECT distinct
	base.[Id]	
	,base.[Title], 'Is Lib Mbr'	
	,base.LibraryTypeId, isnull(base.OrgId,0), base.PublicAccessLevel, base.OrgAccessLevel
	,mbr.MemberTypeId
	,1
	,0	--case when mbr.MemberTypeId > @BaseMemberId then 0
  FROM [dbo].[Library] base
  inner join [Library.Member] mbr on base.id = mbr.LibraryId
  
  where base.IsActive = 1 
  And (base.Id = @LibraryId OR @LibraryId is null)
  and base.Id not in (select LibraryId from #tempWorkTable)
  And (mbr.UserId = @UserId AND mbr.MemberTypeId >= @BaseMemberId)


--=== implicit access ======================================================================
-- org mbrs
-- check for org mbr with lib admin (not overall admin as we have a specific role for lib admin????)
INSERT INTO #tempWorkTable (LibraryId, Title, AccessReason, LibraryTypeId, LibraryOrgId, PublicAccessLevel, OrgAccessLevel,MemberTypeId, HasExplicitAccess, NeedsApproval)
SELECT distinct
	base.[Id]	
	,base.[Title], 'Is Org Lib Admin'	
	,base.LibraryTypeId, isnull(base.OrgId,0), base.PublicAccessLevel, base.OrgAccessLevel
	,4		--admin	
	,1
	,0	--case when mbr.MemberTypeId > @BaseMemberId then 0
  FROM [dbo].[Library] base
 inner Join [dbo].[Gateway.Org_MemberSummary] org on base.OrgId = org.[OrgId]
 
  where base.IsActive = 1 and base.orgId is not null
  And (base.Id = @LibraryId OR @LibraryId is null)
  and base.Id not in (select LibraryId from #tempWorkTable)
  And (org.UserId = @UserId AND org.[OrgMemberTypeId] = @OrgLibAdminId)
  
--==== return ==========================================================
  select distinct
  	base.[Id]
	,base.[Title]
	,base.[Title] + ' ( ' + lt.Title + ' )' As FormattedTitle
	,AccessReason
	,base.Description
	,MemberTypeId, HasExplicitAccess 
	,NeedsApproval 
	,base.LibraryTypeId, lt.Title as LibraryType
	,isnull(base.OrgId,0) As OrgId
    ,isnull(org.Name, '') As Organization
	,case when base.PublicAccessLevel > 1 then 1 else 0 end As IsPublic
	,base.IsActive
	,base.PublicAccessLevel
	,base.OrgAccessLevel
	,base.ImageUrl
	,base.Created, base.CreatedById
	,base.LastUpdated, base.LastUpdatedById
	--to remove
	,IsDiscoverable

  from #tempWorkTable work
  inner join Library		base	on work.LibraryId = base.Id
  inner join [Library.Type] lt		on base.LibraryTypeId = lt.Id
  left join  [Gateway.OrgSummary] org on base.OrgId = org.Id
  Order by Title
  --================================
  GO
grant execute on [Library.SelectCanEdit2] to public 
Go
