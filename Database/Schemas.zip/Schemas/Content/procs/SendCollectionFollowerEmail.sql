USE [IsleContent]
GO
/****** Object:  StoredProcedure [dbo].[SendLibraryFollowerEmail]    Script Date: 3/18/2014 4:03:13 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jerome Grimmer
-- Create date: 3/19/2014
-- Description:	Sends email notifications of resources recently added to followed collections
--
-- Debug levels:
-- 10 = Send email to admin address instead of actual recipient.
-- 11 = Same as 10 plus skip the update of the System.Process record
-- 12 = Send *NO* e-mail and skip update of the System.Process record
-- =============================================
ALTER PROCEDURE [dbo].[SendLibraryCollectionFollowerEmail]
	@code varchar(50),
	@subscriptionTypeId int,
	@debug int = 1,
	@adminAddress varchar(50) = 'jgrimmer@siuccwd.com'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Get last run date
	DECLARE @sysprocId int, @sysprocLastRun datetime
	SELECT @sysprocId = Id, @sysprocLastRun = LastRunDate
	FROM [System.Process]
	WHERE Code = @code
	DECLARE @LastRunDate datetime
	SET @LastRunDate = GETDATE()
	
	-- Get email notice
	DECLARE @Subject varchar(100), @HtmlBodyTemplate nvarchar(max)
	SELECT @Subject = [Subject], @HtmlBodyTemplate = HtmlBody
	FROM EmailNotice
	WHERE NoticeCode = 'CollectionsNotification'
	
	DECLARE @HtmlBody nvarchar(max), @Data nvarchar(max), @LibraryTemplate nvarchar(100), @CollectionTemplate nvarchar(100), @ResourceTemplate nvarchar(500)
	SET @LibraryTemplate = '<h1>Library: @LibraryName</h1>'
	SET @CollectionTemplate = '<h2>Collection: @CollectionName</h2>'
	SET @ResourceTemplate = '<a href="http://ioer.ilsharedlearning.org/Resource/@ResourceIntId/@ResourceTitle">@ResourceTitle</a><br />@Description<br /><br />'

	DECLARE @UserId int, @FullName varchar(101), @Email varchar(100), @LibraryId int, @LibraryTitle varchar(200),
		@CollectionId int, @CollectionTitle varchar(100),
		@ResourceIntId int, @ResourceTitle varchar(300), @ResourceDescription varchar(max),
		@HoldUserId int, @HoldEmail varchar(100), @HoldLibraryId int, @HoldCollectionId int,
		@FirstTimeThru bit, @DoLibraryBreak bit, @DoCollectionBreak bit, @EmailsSent int, @BatchSize int
	SET @FirstTimeThru = 'True'
	SET @DoLibraryBreak = 'False'
	SET @DoCollectionBreak = 'False'
	SET @EmailsSent = 0
	SET @BatchSize = 2000
		
	-- Loop through subscribers
	PRINT 'Looping through subscribers'
	DECLARE dataCursor CURSOR FOR
		SELECT MIN(libsub.UserId) AS UserId, FullName, Email, als.Id AS LibraryId, als.Title AS LibraryTitle,
			libsec.Id AS CollectionId, libsec.Title AS CollectionTitle,
			libres.ResourceIntId, libres.Title AS ResourceTitle, libres.[Description]
		FROM [Library.SectionSubscription] libsub
		INNER JOIN Isle_IOER.dbo.[Patron_Summary] patsum	ON libsub.UserId = patsum.Id
		INNER JOIN Isle_IOER.dbo.[Library.Section] libsec	ON libsub.SectionId = libsec.Id
		INNER JOIN Isle_IOER.dbo.[ActiveLibrarySummary] als ON libsec.LibraryId = als.Id
		INNER JOIN Isle_IOER.dbo.[Library.Resource] libres	ON libsec.Id = libres.LibrarySectionId
		INNER JOIN Isle_IOER.dbo.[Resource.Version] vers	ON libres.ResourceIntId = vers.ResourceIntId
		LEFT JOIN ISLE_IOER.dbo.[Resource.Link] rlink		ON libres.ResourceIntId = rlink.ResourceIntId
		WHERE als.LastUpdated >= @sysprocLastRun AND libres.Created >= @sysprocLastRun 
		AND patsum.Email NOT IN (SELECT [E-mail Address] FROM BouncedEmails WHERE [Bounce Type] = 'hard') 
		AND rlink.IsDeleted <> 'True' AND vers.IsActive = 'True'
		AND libsub.SubscriptionTypeId = @subscriptionTypeId
		GROUP BY FullName, Email, als.Id, als.Title, libsec.Id, libsec.Title, libres.ResourceIntId, libres.Title, libres.Description
		ORDER BY UserId, als.Title, als.Id, libsec.Title, libsec.Id, libres.Title
	OPEN dataCursor
	FETCH NEXT FROM dataCursor INTO @UserId, @FullName, @Email, @LibraryId, @LibraryTitle,
		@CollectionId, @CollectionTitle, @ResourceIntId, @ResourceTitle, @ResourceDescription
	
	WHILE @@FETCH_STATUS = 0 BEGIN
		-- Do First Record special processing
		IF @FirstTimeThru = 'True' BEGIN
			SET @HtmlBody = @HtmlBodyTemplate
			SET	@HtmlBody = REPLACE(@HtmlBody,'@FullName',IsNull(@FullName,''))
			SET @HoldEmail = @Email
			SET @HoldUserId = @UserId
			SET @Data = @LibraryTemplate+@CollectionTemplate
			SET @Data = REPLACE(@Data,'@LibraryName',IsNull(@LibraryTitle,''))
			SET @Data = REPLACE(@Data,'@CollectionName',IsNull(@CollectionTitle,''))
			SET @HoldUserId = @UserId
			SET @HoldLibraryId = @LibraryId
			SET @HoldCollectionId = @CollectionId
			SET @FirstTimeThru = 'False'
		END
		
		-- Do @UserId control break processing
		IF @UserId <> @HoldUserId BEGIN
			SET @DoLibraryBreak = 'True'
			SET @HtmlBody = REPLACE(@HtmlBody,'@ResourceList',IsNull(@Data,''))
			IF @debug > 11 BEGIN
				PRINT 'Skipping Email for  <'+@HoldEmail+'>: '+@HtmlBody
			END ELSE IF @debug > 9 BEGIN
				PRINT 'Skipping Email for '+@HoldEmail+'> - Sending to '+@adminAddress+': '+@HtmlBody
				EXEC msdb.dbo.sp_send_dbmail
					@profile_name = 'DoNotReply-ILSharedLearning',
					@recipients=@adminAddress,
					@subject=@Subject,
					@body=@HtmlBody,
					@body_format='HTML'
			END ELSE BEGIN
				EXEC msdb.dbo.sp_send_dbmail
					@profile_name='DoNotReply-ILSharedLearning',
					@recipients=@HoldEmail,
					@subject=@Subject,
					@body=@HtmlBody,
					@body_format='HTML'
			END
			SET @HtmlBody = @HtmlBodyTemplate
			SET	@HtmlBody = REPLACE(@HtmlBody,'@FullName',IsNull(@FullName,''))
			SET @HoldEmail = @Email
			SET @HoldUserId = @UserId
			SET @Data = ''
			
			SET @EmailsSent = @EmailsSent + 1
			IF @EmailsSent % @BatchSize = 0 BEGIN
				WAITFOR DELAY '00:01:00'
				EXEC msdb.dbo.sysmail_delete_mailitems_sp @sent_status='sent'
			END
		END
		
		-- Do @LibraryId control break processing
		IF @LibraryId <> @HoldLibraryId OR @DoLibraryBreak = 'True' BEGIN
			SET @DoLibraryBreak = 'False'
			SET @DoCollectionBreak = 'True'
			SET @Data = @Data+@LibraryTemplate
			SET @Data = REPLACE(@Data,'@LibraryName',IsNull(@LibraryTitle,''))
			SET @HoldLibraryId = @LibraryId
		END
		
		-- Do @CollectionId control break processing
		IF @CollectionId <> @HoldCollectionId OR @DoCollectionBreak = 'True' BEGIN
			SET @DoCollectionBreak = 'False'
			SET @Data = @Data+@CollectionTemplate
			SET @Data = REPLACE(@Data,'@CollectionName',IsNull(@CollectionTitle,''))
			SET @HoldCollectionId = @CollectionId
		END
		
		-- Do Resource processing
		SET @Data = @Data+@ResourceTemplate
		SET @Data = REPLACE(@Data,'@ResourceIntId',IsNull(@ResourceIntId,''))
		SET @Data = REPLACE(@Data,'@ResourceTitle',IsNull(@ResourceTitle,''))
		SET @Data = REPLACE(@Data,'@Description',IsNull(@ResourceDescription,''))
		
		FETCH NEXT FROM dataCursor INTO @UserId, @FullName, @Email, @LibraryId, @LibraryTitle,
			@CollectionId, @CollectionTitle, @ResourceIntId, @ResourceTitle, @ResourceDescription
	END
	CLOSE dataCursor
	DEALLOCATE dataCursor
	SET @HtmlBody = REPLACE(@HtmlBody,'@ResourceList',IsNull(@Data,''))
	IF @debug > 11 BEGIN
		PRINT 'Skipping Email for  <'+@HoldEmail+'>: '+@HtmlBody
	END ELSE IF @debug > 9 BEGIN
		PRINT 'Skipping Email for '+@HoldEmail+'> - Sending to '+@adminAddress+': '+@HtmlBody
		EXEC msdb.dbo.sp_send_dbmail
			@profile_name = 'DoNotReply-ILSharedLearning',
			@recipients=@adminAddress,
			@subject=@Subject,
			@body=@HtmlBody,
			@body_format='HTML'
	END ELSE BEGIN
		EXEC msdb.dbo.sp_send_dbmail
			@profile_name='DoNotReply-ILSharedLearning',
			@recipients=@HoldEmail,
			@subject=@Subject,
			@body=@HtmlBody,
			@body_format='HTML'
	END

	-- Cleanup emails already sent
	WAITFOR DELAY '00:01:00'
	EXEC msdb.dbo.sysmail_delete_mailitems_sp @sent_status='sent'
	
	-- Update System.Process record if applicable
	IF @debug < 11 BEGIN
		UPDATE [System.Process]
		SET LastRunDate = @LastRunDate
		WHERE Code = @code
	END	
END
