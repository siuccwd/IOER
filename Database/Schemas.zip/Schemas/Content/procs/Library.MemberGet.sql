use IsleContent
go
 
 
 
--- Get Single Procedure for [Library.Member] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.MemberGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.MemberGet]
Go

/*

[Library.MemberGet] 1, 0, 0

[Library.MemberGet] 0, 61, 2

[Library.MemberGet] 0, 61, 29

*/
CREATE PROCEDURE [Library.MemberGet]
    @Id int,
	@LibraryId int,
	@UserId int
As


If @Id = 0 And ( @LibraryId = 0 or @UserId = 0 ) begin
  RAISERROR('[Library.MemberGet] - invalid request. Require @Id, OR @LibraryId AND @UserId', 18, 1)  
  return -1
  end

if @Id = 0 set @Id = null
if @LibraryId = 0 set @LibraryId = null
if @UserId = 0 set @UserId = null


SELECT 
    base.Id, 
    base.LibraryId, 
    base.UserId, usr.SortName,
    base.MemberTypeId, 
   -- RowId, 
   	case when isnull(orgMbr.OrgId,0) = lib.OrgId OR isnull(usr.OrganizationId,0) = lib.OrgId then 1 else 0 end as IsAnOrgMbr,
	isnull(orgMbr.OrgMemberTypeId, 0) As [OrgMemberTypeId],
	isnull(orgMbr.OrgMemberType, '') As [OrgMemberType],

    base.Created, base.CreatedById, 
    base.LastUpdated, base.LastUpdatedById
FROM [Library.Member] base
Inner Join [LR.PatronOrgSummary] usr on base.UserId = usr.UserId
inner join [Codes.LibraryMemberType] lmt on base.MemberTypeId = lmt.Id
INNER JOIN dbo.Library lib ON base.LibraryId = lib.Id
Left Join [Gateway.Org_MemberSummary] orgMbr on lib.OrgId = orgMbr.OrgId AND orgMbr.UserId = base.UserId

WHERE 
	(base.Id = @Id or @Id is null)
AND (base.LibraryId = @LibraryId or @LibraryId is null)
AND	(base.UserId = @UserId or @UserId is null)
GO
grant execute on [Library.MemberGet] to Public
Go
 
 