
 
--- Insert Procedure for [Content.Reference] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Content.ReferenceInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Content.ReferenceInsert]
Go
CREATE PROCEDURE [Content.ReferenceInsert]
            @ParentId int, 
            @Title varchar(200), 
            @Author varchar(100), 
            @Publisher varchar(100), 
            @ISBN varchar(50), 
            @ReferenceUrl varchar(200), 
            @AdditionalInfo varchar(500), 
            @CreatedById int
As

If @Title = ''   SET @Title = NULL 
If @Author = ''   SET @Author = NULL 
If @Publisher = ''   SET @Publisher = NULL 
If @ISBN = ''   SET @ISBN = NULL 
If @ReferenceUrl = ''   SET @ReferenceUrl = NULL 
If @AdditionalInfo = ''   SET @AdditionalInfo = NULL 
If @CreatedById = 0   SET @CreatedById = NULL 

INSERT INTO [Content.Reference] (

    ParentId, 
    Title, 
    Author, 
    Publisher, 
    ISBN, 
    ReferenceUrl, 
    AdditionalInfo
    Created, 
    CreatedById, 
    LastUpdatedById
)
Values (

    @ParentId, 
    @Title, 
    @Author, 
    @Publisher, 
    @ISBN, 
    @ReferenceUrl, 
    @AdditionalInfo,
    getdate(), 
    @CreatedById, 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Content.ReferenceInsert] to public
Go
 