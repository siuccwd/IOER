USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersionUpdate]    Script Date: 04/01/2013 00:14:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DocumentVersionUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DocumentVersionUpdate]
GO

USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersionUpdate]    Script Date: 04/01/2013 00:14:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
/ContentDocs/1/2/WIAWorksProposedDropDownMenu.pdf
USE [IsleContent]
GO
--==================== prototype creating filePath
SELECT        TOP (200)  Title, FilePath, Url
,LEN(Url) - CHARINDEX('/', REVERSE(Url)) + 1
,'C:\IOER' + replace(SUBSTRING(url, 0, LEN(Url) - CHARINDEX('/', REVERSE(Url)) + 1), '/', '\') as NewPath
,  LastUpdated, LastUpdatedById
FROM            [Document.Version]
WHERE        
--(FilePath LIKE 'c:\ioer\content%')
(url LIKE '/contentDoc%')
and LastUpdated <= '2014-11-05 12:31:14.223'
ORDER BY LastUpdated DESC




Update [Document.Version]
Set FilePath = 'C:\IOER' + replace(SUBSTRING(url, 0, LEN(Url) - CHARINDEX('/', REVERSE(Url)) + 1), '/', '\')
WHERE        
	(url LIKE '/contentDoc%')
and LastUpdated <= '2014-11-05 12:31:14.223'

*/
--- Update Procedure for Document.Version---
CREATE PROCEDURE [dbo].[DocumentVersionUpdate]
		@RowId uniqueidentifier,
        @Title varchar(200), 
        @Summary varchar(500), 
        @Status varchar(25), 
        @FileName varchar(150), 
        @FileDate datetime, 
        @MimeType varchar(150), 
        @Bytes bigint, 
        @Data varbinary(MAX),
        @URL varchar(150),   
        @LastUpdatedById int,
		@FilePath varchar(150)

As
If @Summary = ''			SET @Summary = 'TBD' 
If @Status = ''				SET @Status = 'updated' 
If @FileDate < '1990-01-01'			SET @FileDate = getdate() 
If @URL = ''				  SET @URL = NULL
If @FilePath = ''				  SET @FilePath = NULL

UPDATE [Document.Version]
SET 
    Title = @Title, 
    Summary = @Summary, 
    Status = @Status, 
    FileName = @FileName, 
    FileDate = @FileDate, 
    MimeType = @MimeType, 
    Bytes = @Bytes, 
    Data = @Data, 
    URL = @URL,
    LastUpdated = getdate(), 
    LastUpdatedById = @LastUpdatedById
	,FilePath = @FilePath
WHERE RowId = @RowId

GO


