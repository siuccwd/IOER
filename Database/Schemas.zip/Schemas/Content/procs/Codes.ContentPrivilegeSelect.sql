 
--- Get Procedure for [Codes.ContentPrivilege] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Codes.ContentPrivilegeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Codes.ContentPrivilegeSelect]
Go
CREATE PROCEDURE [Codes.ContentPrivilegeSelect]
As
SELECT 
    Id, 
    Title, 
    Description, 
    IsActive, 
    Created
FROM [Codes.ContentPrivilege]
where IsActive = 1
order by SortOrder

GO
grant execute on [Codes.ContentPrivilegeSelect] to public 
Go
 