
--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SelectWhichContainResource]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SelectWhichContainResource]
Go
/*
[Library.SelectWhichContainResource] 21632
*/
CREATE PROCEDURE [Library.SelectWhichContainResource]
  @ResourceIntId int
As

SELECT 
    base.Id, 
    base.Title, 
	base.[Description],
	res.ResourceIntId,
    base.LibraryTypeId, 
    lt.Title as LibraryType,
    base.IsDiscoverable, 
    base.IsPublic
		,base.PublicAccessLevel
	,base.OrgAccessLevel,
    base.ImageUrl,
	base.IsActive,
	    base.Created, base.CreatedById, 
    base.LastUpdated, base.LastUpdatedById
    
FROM [Library] base
inner join [Library.Type] lt on base.LibraryTypeId = lt.Id
inner join [Library.SectionResourceSummary] res on base.id = res.libraryId
where     (res.ResourceIntId = @ResourceIntId)

Order by ResourceIntId,lt.Title, base.Title

GO
grant execute on [Library.SelectWhichContainResource] to public 
Go