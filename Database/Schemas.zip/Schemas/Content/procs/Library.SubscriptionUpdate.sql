use IsleContent
go
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SubscriptionUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SubscriptionUpdate]
Go
--- Update Procedure for [Library.Subscription] ---
CREATE PROCEDURE [Library.SubscriptionUpdate]
        @Id int,
        @SubscriptionTypeId int
        
As

If @SubscriptionTypeId = 0    SET @SubscriptionTypeId = NULL 

UPDATE [Library.Subscription] 
SET 
    SubscriptionTypeId = @SubscriptionTypeId, 
    LastUpdated = getdate()
WHERE Id = @Id
GO
grant execute on [Library.SubscriptionUpdate] to public
Go