USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersionInsert]    Script Date: 04/01/2013 00:14:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DocumentVersionInsert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DocumentVersionInsert]
GO

USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersionInsert]    Script Date: 04/01/2013 00:14:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[DocumentVersionInsert]
            @Title varchar(200), 
            @Summary varchar(500), 
            @Status varchar(25), 
            @FileName varchar(150), 
            @FileDate datetime, 
            @MimeType varchar(150), 
            @Bytes bigint, 
            @Data varbinary(MAX), 
            @URL varchar(150), 
            @CreatedById int,
			@FilePath varchar(150)
As

If @Summary = ''			SET @Summary = 'TBD' 
If @Status = ''				SET @Status = 'initial' 
If @FileDate < '1990-01-01'			SET @FileDate = getdate() 
If @URL = ''				  SET @URL = NULL
If @FilePath = ''				  SET @FilePath = NULL

declare @newId uniqueidentifier
set @newId = newId()

INSERT INTO [Document.Version](
		RowId,
    Title, 
    Summary, 
    [Status], 
    [FileName], 
    FileDate, 
    MimeType, 
    Bytes, 
    Data, 
    URL,
    Created, 
    CreatedById, 
    LastUpdated, 
    LastUpdatedById,
	FilePath
)
Values (
		@newId,
    @Title, 
    @Summary, 
    @Status, 
    @FileName, 
    @FileDate, 
    @MimeType, 
    @Bytes, 
    @Data, 
    @URL,
    getdate(), 
    @CreatedById, 
    getdate(), 
    @CreatedById,
	@FilePath
)
 
select @newId As RowId

GO


