USE [IsleContent]
GO
/*
USE [IsleContent]
GO

SELECT [LibraryId]
      ,[Library]
      ,[LibraryResourceCount]
  FROM [dbo].[Library.ResourceCount]
--where libraryId = 25
order by 3 desc


*/
Create  VIEW [dbo].[Library.ResourceCount] AS

SELECT [LibraryId], Library
      ,sum(NbrResources) As LibraryResourceCount
  FROM [dbo].[LibraryCollection.ResourceCount]
  group by LibraryId, Library
  --order by 3 desc
  
GO
grant select on [Library.ResourceCount] to public
go


