
if exists (select * from dbo.sysobjects where id = object_id(N'[Content.ReferenceUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Content.ReferenceUpdate]
Go
--- Update Procedure for [Content.Reference] ---
CREATE PROCEDURE [Content.ReferenceUpdate]
        @Id int,
        @Title varchar(200), 
        @Author varchar(100), 
        @Publisher varchar(100), 
        @ISBN varchar(50), 
        @ReferenceUrl varchar(200), 
        @AdditionalInfo varchar(500), 
        @LastUpdatedById int

As

If @Title = ''   SET @Title = NULL 
If @Author = ''   SET @Author = NULL 
If @Publisher = ''   SET @Publisher = NULL 
If @ISBN = ''   SET @ISBN = NULL 
If @ReferenceUrl = ''   SET @ReferenceUrl = NULL 
If @AdditionalInfo = ''   SET @AdditionalInfo = NULL 
If @LastUpdatedById = 0   SET @LastUpdatedById = NULL 

UPDATE [Content.Reference] 
SET 
    Title = @Title, 
    Author = @Author, 
    Publisher = @Publisher, 
    ISBN = @ISBN, 
    ReferenceUrl = @ReferenceUrl, 
    AdditionalInfo = @AdditionalInfo, 
    LastUpdated = getdate(), 
    LastUpdatedById = @LastUpdatedById
WHERE Id = @Id
GO
grant execute on [Content.ReferenceUpdate] to public
Go
 
 