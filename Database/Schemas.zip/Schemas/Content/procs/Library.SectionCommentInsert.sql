
--- Insert Procedure for [Library.SectionComment] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionCommentInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionCommentInsert]
Go
CREATE PROCEDURE [Library.SectionCommentInsert]
            @SectionId int, 
            @Comment varchar(1000), 
            @CreatedById int
As
If @CreatedById = 0   SET @CreatedById = NULL 
INSERT INTO [Library.SectionComment] (

    SectionId, 
    Comment, 
    CreatedById
)
Values (

    @SectionId, 
    @Comment, 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.SectionCommentInsert] to public
Go
 