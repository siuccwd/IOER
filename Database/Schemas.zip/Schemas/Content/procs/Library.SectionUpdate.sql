USE IsleContent
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionUpdate]
Go

/* 
==================================================================
--- Update Procedure for [Library.Section] ---
Modifications
13-05-28 mparsons - added @LibraryId to allow for easy reset of IsDefault 
14-02-05 mparsons - added Access levels. planning to remove IsPublic
==================================================================
*/
CREATE PROCEDURE [Library.SectionUpdate]
        @Id int, 
        @LibraryId int, 
        @Title varchar(100),
        @Description varchar(500), 
        @IsDefaultSection bit, 
        @PublicAccessLevel int, 
		@OrgAccessLevel int, 
        @AreContentsReadOnly bit, 
        @LastUpdatedById int,
		@ImageUrl varchar(200)

As
If @Title = ''   SET @Title = 'Missing - TBD' 
If @Description = ''   SET @Description = NULL 
If @ImageUrl = ''		SET @ImageUrl = NULL 
If @LastUpdatedById = 0   SET @LastUpdatedById = NULL 


declare @IsPublic bit
-- temp check during transition
if  @PublicAccessLevel = 0 begin
	set @IsPublic= 0
	end
	else begin
	set @IsPublic= 1
	if @OrgAccessLevel = 0
		set @OrgAccessLevel= 2
	end

if @IsDefaultSection = 1 begin
  --unset any existing
  update [Library.Section] set IsDefaultSection = 0 
  WHERE LibraryId = @LibraryId 
  end

UPDATE [Library.Section] 
SET 
    Title = @Title, 
    Description = @Description, 
    IsDefaultSection = @IsDefaultSection,  
	PublicAccessLevel = @PublicAccessLevel, 
	OrgAccessLevel = @OrgAccessLevel, 
    IsPublic = @IsPublic,  
    AreContentsReadOnly = @AreContentsReadOnly,  
	ImageUrl= @ImageUrl,
    LastUpdated = getdate(), 
    LastUpdatedById = @LastUpdatedById
WHERE Id = @Id
GO
grant execute on [Library.SectionUpdate] to public
Go
 