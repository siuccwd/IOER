

use IsleContent
go
 
--- Insert Procedure for [Library.Subscription] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SubscriptionInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SubscriptionInsert]
Go
CREATE PROCEDURE [Library.SubscriptionInsert]
            @LibraryId int, 
            @UserId int, 
            @SubscriptionTypeId int
			--, @MemberTypeId int
As

If @SubscriptionTypeId = 0   SET @SubscriptionTypeId = NULL 
--If @MemberTypeId = 0   SET @MemberTypeId = NULL 

INSERT INTO [Library.Subscription] (

    LibraryId, 
    UserId, 
    SubscriptionTypeId
  --,  PrivilegeId
)
Values (

    @LibraryId, 
    @UserId, 
    @SubscriptionTypeId
   --, @MemberTypeId
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.SubscriptionInsert] to public
Go
 