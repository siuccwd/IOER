
use IsleContent
go
if exists (select * from dbo.sysobjects where id = object_id(N'[LibrarySearch_SelectUsedValuesForFilter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure LibrarySearch_SelectUsedValuesForFilter
Go

/*
SELECT [Id] FROM dbo.[Codes.GroupType] codes 
WHERE IsActive = 1 AND codes.Id in (
	select distinct res.GroupTypeId from [dbo].[Resource.GroupType]  lres 
	INNER JOIN [dbo].[Library.Section] lsec ON lres.LibrarySectionId = lsec.Id 
	inner join dbo.[Resource.GroupType] res on lres.ResourceIntId = res.ResourceIntId 
	where 
		lsec.LibraryId	= 1OR	lsec.Id			= 0	)
-- ===========================================================================================
[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.AccessRights]', '[Resource.AccessRights] ', 'AccessRightsId',1,0

[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.CareerCluster]', '[Resource.CareerCluster] ', 'CareerClusterId',0,1

[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.EducationalUse]', '[Resource.EducationalUse] ', 'EducationalUseId',0,96

[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.GradeLevel]', '[Resource.GradeLevel] ', 'GradeLevelId',1,0

[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.GroupType]', '[Resource.GroupType] ', 'GroupTypeId',0,96

[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.GroupType]', '[Resource.GroupType] ', 'GroupTypeId',22,0


[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.IntendedAudience]', '[Resource.IntendedAudience] ', 'IntendedAudienceId',1,0

[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.ResourceFormat]', '[Resource.ResourceFormat] ', 'ResourceFormatId',0,96

[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.ResourceType]', '[Resource.ResourceType] ', 'ResourceTypeId'	,1,0
[LibrarySearch_SelectUsedValuesForFilter] 'dbo.[Codes.ResourceType]', '[Resource.ResourceType] ', 'ResourceTypeId'	,0,96


*/
Create PROCEDURE [dbo].[LibrarySearch_SelectUsedValuesForFilter]
		@CodeTable			varchar(50)
		,@ResourceChildTable	varchar(50)
		,@FKey				varchar(50)
		,@LibraryId			int
		,@LibrarySectionId  int

As
declare @Sql varchar(500)
SET NOCOUNT ON;
--caller must set square brackets if needed
set @sql = 'SELECT [Id], Title FROM ' + @CodeTable + ' codes 
WHERE IsActive = 1 AND codes.Id in (
	select distinct res.' + @FKey + ' 
	from [dbo].' + @ResourceChildTable + ' res 
	inner join dbo.[Library.Resource] lres on res.ResourceIntId = lres.ResourceIntId 
	INNER JOIN [dbo].[Library.Section] lsec ON lres.LibrarySectionId = lsec.Id 
	where 
		lsec.LibraryId	= ' + convert(varchar,@LibraryId) + ' 
	OR	lsec.Id			= ' + convert(varchar,@LibrarySectionId) + '	)
	Order by 2'
	
	print @sql
	exec(@sql)
go 
grant execute on [LibrarySearch_SelectUsedValuesForFilter] to public
go