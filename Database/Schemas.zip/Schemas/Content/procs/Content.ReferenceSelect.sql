
--- Get Procedure for [Content.Reference] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Content.ReferenceSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Content.ReferenceSelect]
Go
CREATE PROCEDURE [Content.ReferenceSelect]
  @ParentId int
As
SELECT 
    Id, 
    ParentId, 
    Title, 
    Author, 
    Publisher, 
    ISBN, 
    ReferenceUrl, AdditionalInfo,
    Created, 
    CreatedById, 
    LastUpdated, 
    LastUpdatedById
FROM [Content.Reference]
WHERE ParentId = @ParentId
Order by Title, Id
GO
grant execute on [Content.ReferenceSelect] to public 
Go