use IsleContent
go

--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[LibraryMember_Search]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [LibraryMember_Search]
Go
/*

-- ===========================================================

DECLARE @RC int,@Filter varchar(500), @StartPageIndex int, @PageSize int, @totalRows int,@SortOrder varchar(100)
set @SortOrder = '' 
set @Filter = ' LibraryId = 43 '
--set @Filter = ''                 
set @StartPageIndex = 1
set @PageSize = 4

exec [LibraryMember_Search] @Filter, @SortOrder, @StartPageIndex  ,@PageSize  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/

/* =================================================
= LibraryMember_Search
=		@StartPageIndex - starting page number. If interface is at 20 when next page is requested, this would be set to 21?
=		@PageSize - number of records on a page
=		@totalRows OUTPUT - total available rows. Used by interface to build a custom pager
= ------------------------------------------------------
= Modifications
= 14-02-04 mparsons - Created 
-- ================================================= */
Create PROCEDURE [dbo].LibraryMember_Search
		@Filter				    varchar(500)
		,@SortOrder	      varchar(500)
		,@StartPageIndex  int
		,@PageSize		    int
		,@TotalRows			  int OUTPUT
AS 
DECLARE 
@first_id			int
,@startRow		int
,@debugLevel	int
,@SQL             varchar(5000)
,@OrderBy         varchar(100)

	SET NOCOUNT ON;

-- ==========================================================
Set @debugLevel = 4
if len(@SortOrder) > 0
	set @OrderBy = ' Order by ' + @SortOrder
else 
  set @OrderBy = ' Order by Library, SortName '
--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

 
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	Id int NOT NULL,
	LibraryId int,
	UserId int
)
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end
 
set @SQL = 'SELECT [Id] ,[LibraryId],[UserId]   FROM [dbo].[Library.MemberSummary] 	  '  
	  + @Filter

if charindex( 'order by', lower(@Filter) ) = 0 
	set @SQL = 	@SQL + @OrderBy
if @debugLevel > 3 begin
  print '@SQL len: '  +  convert(varchar,len(@SQL))
	print @SQL
	end
	
INSERT INTO #tempWorkTable (Id, LibraryId, UserId)
exec (@sql)
   SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Show the StartPageIndex
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

SELECT     Distinct
		RowNumber,
		lib.[Id]
      ,lib.[LibraryId]
      ,[Library]
      ,lib.[UserId]
      ,[FullName]
      ,[SortName]
	  ,[FullName] AS MemberName
      ,[SortName] As MemberSortName
      ,[Email]
      ,[MemberTypeId]
      ,[MemberType]
	  ,Organization, OrganizationId
	  ,IsAnOrgMbr, OrgMemberTypeId, OrgMemberType
      ,CONVERT(varchar(10), lib.Created, 120) As Created
      ,[CreatedById]
	  ,CONVERT(varchar(10), lib.[LastUpdated], 120) As [LastUpdated]
      ,[LastUpdatedById]
  
From #tempWorkTable temp
    Inner Join [dbo].[Library.MemberSummary] lib on temp.Id = lib.Id

WHERE RowNumber > @first_id 
order by RowNumber		

SET ROWCOUNT 0
Go
grant execute on LibraryMember_Search to public 
Go