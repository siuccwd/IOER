  
USE [IsleContent]
GO 
--- Delete Procedure for [Library.Invitation] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Library.InvitationDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.InvitationDelete]
GO
CREATE PROCEDURE [Library.InvitationDelete]
        @RowId uniqueidentifier
As
DELETE FROM [Library.Invitation]
WHERE RowId = @RowId
GO
grant execute on [Library.InvitationDelete]  to public
Go