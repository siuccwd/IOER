 
--- Get Procedure for [Codes.ContentStatus] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Codes.ContentStatusSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Codes.ContentStatusSelect]
Go
CREATE PROCEDURE [Codes.ContentStatusSelect]
As
SELECT 
    Id, 
    Title, 
    Created
FROM [Codes.ContentStatus]
Order by Title

GO
grant execute on [Codes.ContentStatusSelect] to public 
Go
 