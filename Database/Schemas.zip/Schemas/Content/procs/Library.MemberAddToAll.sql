USE [IsleContent]
GO
 
--- Insert Procedure for [Library.MemberAddToAll] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.MemberAddToAll]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.MemberAddToAll]
Go
/*
USE [IsleContent]
GO

SELECT [UserId]
      ,[UserName]
      ,[FirstName]
      ,[LastName]
      ,[FullName]
      ,[SortName]
      ,[Email]
      ,[PublishingRole]
      ,[JobTitle]
      ,[RoleProfile]
      ,[OrganizationId]
      ,[Organization]
  FROM [dbo].[LR.PatronOrgSummary]


  

[Library.MemberAddToAll] 0, 166, 4, 2
*/
CREATE PROCEDURE [Library.MemberAddToAll]
            @LibraryId		int, 
            @UserId			int,   
			@MemberTypeId	int,
            @CreatedById	int

As
if @UserId = 0	set @UserId = NULL
if @MemberTypeId < 1	set @MemberTypeId= 1
if @CreatedById = 0	set @CreatedById = NULL

if @UserId is null begin
	print '[Library.MemberAddToAll] Error: Incomplete parameters were provided'
	RAISERROR('[Library.MemberAddToAll] Error: incomplete parameters were provided. Require: @@UserId ', 18, 1)    
	RETURN -1 
	end
/*
declare         
@UserId			int,   
@MemberTypeId	int,
@CreatedById	int    
set @UserId= 2
set @MemberTypeId= 4
set @CreatedById= 2
*/

INSERT INTO [dbo].[Library.Member]
           ([LibraryId]
           ,[UserId]
           ,[MemberTypeId]
           ,[CreatedById]
           ,[LastUpdatedById])

SELECT distinct base.[Id]
      ,@UserId As UserId
      ,@MemberTypeId
      ,@CreatedById
	  ,@CreatedById
  FROM [dbo].[Library] base
  where base.CreatedById <> @UserId
    and (base.Id not in 
		(select libraryId from  [library.member]  where userId = @UserId)
	)
  
  --

GO
grant execute on [Library.MemberAddToAll] to public
Go




