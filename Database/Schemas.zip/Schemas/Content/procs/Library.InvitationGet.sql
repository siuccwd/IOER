
USE [IsleContent]
GO 
--- Get Single Procedure for [Library.Invitation] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.InvitationGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.InvitationGet]
Go
CREATE PROCEDURE [Library.InvitationGet]
	@Id int,
    @RowId varchar(36)
As
if @Id = 0 set @Id = NULL
if @RowId = '' OR @RowId = '00000000-0000-0000-0000-000000000000'  set @RowId = NULL

if @Id is null AND @RowId is null begin
	print '[Library.InvitationGet] Error: Incomplete parameters were provided'
	RAISERROR('[Library.InvitationGet] Error: incomplete parameters were provided. Require: @Id OR @RowId ', 18, 1)    
	RETURN -1 
	end

SELECT    Id, 
	LibraryId, 
    RowId, 
    InvitationType, 
    PassCode, 
    TargetEmail, 
    TargetUserId, 
    Subject, 
    MessageContent, 
    EmailNoticeCode, 
    Response, 
    ResponseDate, 
    ExpiryDate, 
    IsActive, 
    DeleteOnResponse, 
    Created, 
    CreatedById, 
    LastUpdated, 
    LastUpdatedById
FROM [Library.Invitation]
WHERE 
	(@Id = Id or Id is null)
And	(RowId = @RowId or @RowId is null)
GO
grant execute on [Library.InvitationGet] to Public
Go
 