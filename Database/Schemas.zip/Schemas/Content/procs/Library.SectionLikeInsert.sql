
--- Insert Procedure for [Library.SectionLike] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionLikeInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionLikeInsert]
Go

CREATE PROCEDURE [Library.SectionLikeInsert]
            @SectionId int, 
            @IsLike bit, 
            @CreatedById int
As

If @CreatedById = 0   SET @CreatedById = NULL 
INSERT INTO [Library.SectionLike] (

    SectionId, 
    IsLike, 
    CreatedById
)
Values (

    @SectionId, 
    @IsLike, 
    @CreatedById
)
 
select SCOPE_IDENTITY() as Id
GO
grant execute on [Library.SectionLikeInsert] to public
Go