USE IsleContent
GO
--- Get Procedure for [Library.Section] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSelect]
Go
/*
[Library.SectionSelect]  1, 1

*/
CREATE PROCEDURE [Library.SectionSelect]
   @LibraryId int,
   @ShowingAll int
As
If @LibraryId = 0   SET @LibraryId = NULL 
Declare @IsPublic bit
if @ShowingAll = 0 set @IsPublic = 0
else if @ShowingAll = 1 set @IsPublic = 1
else set @IsPublic = NULL

SELECT     
    base.Id, 
    LibraryId, 
	lib.Title As Library,
	lib.Title As LibraryTitle,
    base.Title,
    case when resCount.Records is null then base.Title + ' (0)'
    else base.Title + ' (' + convert(varchar,resCount.Records) + ')' end As FormattedTitle,
    
    case when resCount.Records is null then 0
    else resCount.Records end As SectionResourceCount,
    SectionTypeId, lst.Title As SectionType ,
    base.Description, 
    ParentId, 
    base.IsDefaultSection,base.IsPublic,
	base.PublicAccessLevel,
	base.OrgAccessLevel,
    base.AreContentsReadOnly, 
    base.ImageUrl, Lib.ImageUrl As LibraryImageUrl,
    base.Created, base.CreatedById, 
    base.LastUpdated, base.LastUpdatedById
    
FROM [Library.Section] base
Inner join [Library] lib on base.LibraryId = lib.Id
Inner join [Library.SectionType] lst on base.SectionTypeId = lst.Id
left join (Select LibrarySectionId, count(*) As Records from [Library.SectionResourceSummary] group by LibrarySectionId) resCount on  base.Id = resCount.LibrarySectionId

WHERE  
    (base.LibraryId = @LibraryId or @LibraryId is null)
AND (base.IsPublic = @IsPublic or @IsPublic is null)

order by lib.Title, base.Title

GO
grant execute on [Library.SectionSelect] to public 
Go
 