USE [IsleContent]
GO

/****** Object:  StoredProcedure [dbo].[Content.SetAsFeaturedItem]    Script Date: 10/29/2014 9:35:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
select cc.ParentId, base.Id, base.Title, base.TypeId, base.SortOrder
from [Content] base
inner join [Content.Connector] cc on base.Id = cc.ChildId 
WHERE   (base.TypeId = 40) and cc.ParentId = 2232



[Content.SetAsFeaturedItem] 2232, 2553

[Content.SetAsFeaturedItem] 2232, 2555

*/


-- ====================================================================
--- Set content item as featured - set sortOrder to zero (and remove any existing zeroes)
--mods

-- ====================================================================
Alter PROCEDURE [dbo].[Content.SetAsFeaturedItem]
        @ParentId int,
        @ContentId int

As


if @ParentId = 0 OR @ContentId = 0 begin
  print '[Content.SetAsFeaturedItem] Error: Incomplete parameters were provided'
	RAISERROR('[Content.SetAsFeaturedItem] Error: incomplete parameters were provided. Require Source @ParentId AND @ContentId)', 18, 1)    
	RETURN -1 
  end

--reset existing
UPDATE [Content]
SET SortOrder = 10

--		select base.Id, base.Title, base.TypeId, base.SortOrder, cc.ParentId
from [Content] base
inner join [Content.Connector] cc on base.Id = cc.ChildId 
WHERE base.SortOrder = -1
and cc.ParentId = @ParentId



UPDATE [Content]
SET SortOrder = -1
WHERE Id = @ContentId


GO

grant execute on [Content.SetAsFeaturedItem] to public
go
