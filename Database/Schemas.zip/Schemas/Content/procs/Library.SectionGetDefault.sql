USE IsleContent
GO
--- Get Single Procedure for [Library.Section] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionGetDefault]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionGetDefault]
Go

/*
-- could use a search instead

[Library.SectionGetDefault] 1

*/
CREATE PROCEDURE [Library.SectionGetDefault]
    @LibraryId int
    --,@CreatedById int
As
If @LibraryId = 0   SET @LibraryId = NULL 
--If @CreatedById = 0   SET @CreatedById = NULL 

SELECT     
    base.Id, 
    LibraryId, lib.Title As LibraryTitle,
    base.Title,
    SectionTypeId, lst.Title As SectionType ,
    base.Description, 
    ParentId, 
    base.IsDefaultSection, base.IsPublic,
	base.PublicAccessLevel,
	base.OrgAccessLevel,
    base.AreContentsReadOnly, 
    base.ImageUrl, Lib.ImageUrl As LibraryImageUrl,
    base.Created, 
    base.CreatedById, 
    base.LastUpdated, 
    base.LastUpdatedById
FROM [Library.Section] base
Inner join [Library] lib on base.LibraryId = lib.Id
Inner join [Library.SectionType] lst on base.SectionTypeId = lst.Id

WHERE LibraryId = @LibraryId
--And CreatedById = @CreatedById
And base.IsDefaultSection= 1

GO
grant execute on [Library.SectionGetDefault] to Public
Go
 
 