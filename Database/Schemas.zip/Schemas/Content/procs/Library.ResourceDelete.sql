use IsleContent
go

--- Delete Procedure for [Library.Resource] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Library.ResourceDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.ResourceDelete]
GO

/*
[Library.ResourceDelete] 0, 0,0
[Library.ResourceDelete] 0, 1,0
[Library.ResourceDelete] 0, 0,1

[Library.ResourceDelete] 178, 0,0

[Library.ResourceDelete] 0, 79,447822

*/
CREATE PROCEDURE [Library.ResourceDelete]
        @LibraryResourceId int,
		@SourceLibrarySectionId int,
		@ResourceIntId int

As
If @LibraryResourceId = 0		SET @LibraryResourceId = NULL 
If @SourceLibrarySectionId = 0  SET @SourceLibrarySectionId = NULL 
If @ResourceIntId = 0			SET @ResourceIntId = NULL 

if @LibraryResourceId is null AND (@SourceLibrarySectionId is null OR @ResourceIntId is null) begin
  print '[Library.ResourceDelete] Error: Incomplete parameters were provided'
	RAISERROR('[Library.ResourceDelete] Error: incomplete parameters were provided. Require Source @LibraryResourceId, or  (@SourceLibrarySectionId AND @ResourceIntId)', 18, 1)    
	RETURN -1 
  end

DELETE FROM [Library.Resource]
where 
	(Id = @LibraryResourceId OR @LibraryResourceId is null)
AND (ResourceIntId = @ResourceIntId OR @ResourceIntId is null)
AND (LibrarySectionId = @SourceLibrarySectionId OR @SourceLibrarySectionId is null)

GO
grant execute on [Library.ResourceDelete]  to public
Go
