use IsleContent
go

--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SectionSearch]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SectionSearch]
Go
/*

-- ===========================================================

DECLARE @RC int,@Filter varchar(500), @StartPageIndex int, @PageSize int, @totalRows int,@SortOrder varchar(100)
set @SortOrder = '' 
set @Filter = ' ResourceLastAddedDate > ''2013-06-01'' '

set @Filter = ' base.Id in (Select LibrarySectionId from [Library.SectionMember] where userid = 2 ) '  

set @Filter = ' lib.Id in (Select LibraryId from [Library.Member] where userid = 2 ) '  

--set @Filter = ' base.Id in (Select SectionId from [Library.SectionSubscription] where userid = 2 ) '           
--set @Filter = ' '

set @StartPageIndex = 1
set @PageSize = 15

exec [Library.SectionSearch] @Filter, @SortOrder, @StartPageIndex  ,@PageSize  ,@totalRows OUTPUT

select 'total rows = ' + convert(varchar,@totalRows)


*/

/* ==========================================================================================
= Library collection search
=		@StartPageIndex - starting page number. If interface is at 20 when next page is requested, this would be set to 21?
=		@PageSize - number of records on a page
=		@totalRows OUTPUT - total available rows. Used by interface to build a custom pager
= ------------------------------------------------------
= Modifications
= 14-02-24 mparsons - Created 
-- ========================================================================================= */
Create PROCEDURE [dbo].[Library.SectionSearch]
	@Filter				varchar(500)
	,@SortOrder			varchar(500)
	,@StartPageIndex	int
	,@PageSize			int
	,@TotalRows			int OUTPUT
AS 
DECLARE 
	@first_id			int
	,@startRow		int
	,@debugLevel	int
	,@SQL             varchar(5000)
	,@OrderBy         varchar(100)

	SET NOCOUNT ON;

-- ==========================================================
Set @debugLevel = 4
if len(@SortOrder) > 0
	set @OrderBy = ' Order by ' + @SortOrder
else 
  set @OrderBy = ' Order by lib.Title '
--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

 
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	Id int NOT NULL,
	Title varchar(100),
	TotalResources int
)
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end
 
set @SQL = 'SELECT base.Id, base.Title, isnull(lrt.TotalResources,0) As TotalResources FROM [Library.Section]  base
		Inner Join [Library] lib on base.LibraryId = lib.Id
	  Left Join [LR.PatronOrgSummary] owner on lib.CreatedById = owner.Userid
	  Left join [Gateway.OrgSummary] org on lib.OrgId = org.id
	  Left Join [Library.SectionType] sect on base.SectionTypeId = sect.Id 
	  Left Join ( SELECT LibrarySectionId, max([ResourceCreated]) ResourceLastAddedDate  FROM [dbo].[Library.SectionResourceSummary] group by LibrarySectionId) 
				As SectionLastActivity  on base.Id = SectionLastActivity.LibrarySectionId
	  left join (SELECT LibrarySectionId, count(*) As TotalResources
		  FROM [Library.SectionResourceSummary] group by LibrarySectionId) 
		  As lrt on base.id = lrt.LibrarySectionId
	  '  
	  + @Filter

if charindex( 'order by', lower(@Filter) ) = 0 
	set @SQL = 	@SQL + @OrderBy
if @debugLevel > 3 begin
  print '@SQL len: '  +  convert(varchar,len(@SQL))
	print @SQL
	end
	
INSERT INTO #tempWorkTable (Id, Title, TotalResources)
exec (@sql)
   SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Show the StartPageIndex
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

SELECT     Distinct
	RowNumber,
	--==================================================================================================
    lib.Id As LibraryId,     lib.Title as LibraryTitle,     lib.Description As LibraryDescription, 
    LibraryTypeId, libt.Title as LibraryType,
	case when lib.PublicAccessLevel > 1 then 'Public'
      else 'Private' end as LibraryViewType,
    case when isnull(lib.ImageUrl,'') = '' then 'defaultUrl' else lib.ImageUrl end as LibraryImageUrl, 
    lib.OrgId,
	case when isnull(lib.OrgId,0) > 0 then org.Name 
      when isnull(creator.OrganizationId,0) > 0 then creator.Organization 
      else 'Personal' end as Organization,
	--==================================================================================================
	coll.Id, coll.Id As SectionId, coll.Title,     coll.Description, 
    SectionTypeId, sect.Title as SectionType,
    coll.IsDefaultSection,
	coll.PublicAccessLevel,
	coll.OrgAccessLevel,
	coll.AreContentsReadOnly,
    case when coll.PublicAccessLevel > 1 then 'Public'
      else 'Private' end as ViewType,
    case when isnull(coll.ImageUrl,'') = '' then 'defaultUrl' else coll.ImageUrl end as ImageUrl, 
    
    isnull(lrt.TotalResources,0) As TotalResources,
    coll.Created, coll.CreatedById, coll.LastUpdated, coll.LastUpdatedById
    
	,case 
		when creator.userid is not null Then creator.FullName
		else '' End As FullName
	,case 
		when creator.userid is not null Then creator.SortName
		else '' End As SortName    
  ,ResourceLastAddedDate

From #tempWorkTable temp
	Inner join [Library.Section] coll		on temp.Id = coll.Id
	Left Join [Library.SectionType] sect	on coll.SectionTypeId = sect.Id 
    Inner Join [Library] lib				on coll.LibraryId = lib.Id
    Inner Join [Library.Type] libt			on lib.LibraryTypeId = libt.Id
    Left Join [LR.PatronOrgSummary] creator on lib.CreatedById = creator.Userid
	Left join [Gateway.OrgSummary] org		on lib.OrgId = org.id
    Left Join ( SELECT libraryId, max([ResourceCreated]) ResourceLastAddedDate  FROM [dbo].[Library.SectionResourceSummary] group by libraryId) As LibLastActivity  on lib.Id = LibLastActivity.libraryId

	left join (SELECT LibraryId, count(*) As TotalResources
		  FROM [Library.SectionResourceSummary] group by LibraryId) 
		  As lrt on lib.id = lrt.LibraryId
    
WHERE RowNumber > @first_id 
order by RowNumber		

SET ROWCOUNT 0
Go
grant execute on [Library.SectionSearch] to public 
Go