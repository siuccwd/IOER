USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersionGet]    Script Date: 04/01/2013 00:13:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DocumentVersionGet]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DocumentVersionGet]
GO

USE IsleContent
GO

/****** Object:  StoredProcedure [dbo].[DocumentVersionGet]    Script Date: 04/01/2013 00:13:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[DocumentVersionGet]
    @RowId uniqueidentifier
As
SELECT     
		RowId, 
    Title, 
    Summary, 
    Status, 
    FileName, FilePath, 
    FileDate, 
    MimeType, 
    Bytes, 
    Data, 
		URL,
    Created, CreatedById, 
    LastUpdated, LastUpdatedById
FROM [Document.Version]
WHERE RowId = @RowId

GO
grant execute on [DocumentVersionGet] to public
go


