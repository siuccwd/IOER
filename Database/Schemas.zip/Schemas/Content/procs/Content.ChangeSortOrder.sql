USE [IsleContent]
GO

/****** Object:  StoredProcedure [dbo].[Content.ChangeSortOrder]    Script Date: 10/29/2014 9:35:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
select cc.ParentId, base.Id, base.Title, base.TypeId, base.SortOrder
from [Content] base
inner join [Content.Connector] cc on base.Id = cc.ChildId 
WHERE   (base.TypeId = 40) and cc.ParentId = 2232



[Content.ChangeSortOrder] 2554


*/


-- ====================================================================
--- Remove content item as featured - set sortOrder to 10
--mods

-- ====================================================================
Alter PROCEDURE [dbo].[Content.ChangeSortOrder]
        @ContentId int,
		@SortOrder int = 10

As


if @SortOrder < 0 OR @ContentId = 0 begin
  print '[Content.ChangeSortOrder] Error: Incomplete parameters were provided'
	RAISERROR('[Content.ChangeSortOrder] Error: incomplete parameters were provided. Require Source @SortOrder (GE -1) AND @ContentId)', 18, 1)    
	RETURN -1 
  end

UPDATE [Content]
SET SortOrder = @SortOrder
WHERE Id = @ContentId


GO

grant execute on [Content.ChangeSortOrder] to public
go
