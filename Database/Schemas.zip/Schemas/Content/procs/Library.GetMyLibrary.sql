USE [IsleContent]
GO
 
--- Get Single Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.GetMyLibrary]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.GetMyLibrary]
Go
/*

[Library.GetMyLibrary] 2

*/
--get personal library
CREATE PROCEDURE [Library.GetMyLibrary]
    @CreatedById int
As
SELECT     
    base.Id, 
    base.Title, 
    base.Description, 
    LibraryTypeId, 
    lt.Title as LibraryType,
    IsDiscoverable, 
        0 as OrgId,
    'Personal' As Organization,
    IsPublic, IsActive,
		base.PublicAccessLevel,
	base.OrgAccessLevel,
    base.ImageUrl, 
    base.Created, base.CreatedById, 
    base.LastUpdated, base.LastUpdatedById
    
FROM [Library] base
inner join [Library.Type] lt on base.LibraryTypeId = lt.Id
WHERE base.CreatedById = @CreatedById
And lt.Id = 1
GO
grant execute on [Library.GetMyLibrary] to Public
Go
 