 use IsleContent
 go
 
--- Get Procedure for [Library.Member] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.MemberSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.MemberSelect]
Go
CREATE PROCEDURE [Library.MemberSelect]
	@LibraryId int
As

SELECT 
    base.Id, 
    base.LibraryId, 
    base.UserId, usr.SortName,
    base.MemberTypeId, 
   -- RowId, 
    base.Created, base.CreatedById, 
    base.LastUpdated, base.LastUpdatedById
FROM [Library.Member] base
Inner Join [LR.PatronOrgSummary] usr on base.UserId = usr.UserId
inner join [Codes.LibraryMemberType] lmt on base.MemberTypeId = lmt.Id
where LibraryId = @LibraryId

GO
grant execute on [Library.MemberSelect] to public 
Go
 