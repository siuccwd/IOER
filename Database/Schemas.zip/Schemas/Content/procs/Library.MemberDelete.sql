use IsleContent
go
 
 
--- Delete Procedure for [Library.Member] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Library.MemberDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.MemberDelete]
GO
CREATE PROCEDURE [Library.MemberDelete]
        @Id int
As
DELETE FROM [Library.Member]
WHERE Id = @Id
GO
grant execute on [Library.MemberDelete]  to public
Go