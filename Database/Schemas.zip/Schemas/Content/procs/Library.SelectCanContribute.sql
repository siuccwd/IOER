USE [IsleContent]
GO

--- Get Procedure for [Library] ---
if exists (select * from dbo.sysobjects where id = object_id(N'[Library.SelectCanContribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
Drop Procedure [Library.SelectCanContribute]
Go
/*

[Library.SelectCanContribute] 2, 0
go
[Library.SelectCanContribute] 2, 43



[Library.SelectCanContribute] 92, 43

*/

/*
Select all libraries/collections where user has contribute access. Includes:
- personal
- libraries where has curate access
- collections where has curate access
- org libraries with implicit access
- members of multiple orgs are not implemented as yet (thru org.member)
Modifications

*/
CREATE PROCEDURE [Library.SelectCanContribute]
  @UserId		int
  ,@LibraryId	int
  --,@BaseMemberId int
As
declare @BaseMemberId int
set @BaseMemberId = 2	--contributor

if @LibraryId = 0	set @LibraryId = NULL

SELECT distinct
	base.[Id]
	,base.[Title]
	,base.Description
	,base.LibraryTypeId, lt.Title as LibraryType
	,IsDiscoverable
	,isnull(base.OrgId,0) As OrgId
    ,isnull(orgLibs.Organization, '') As Organization
	,case when base.PublicAccessLevel > 1 then 1 else 0 end As IsPublic
	,base.IsActive
	,base.PublicAccessLevel
	,base.OrgAccessLevel
	,base.ImageUrl
	,base.Created, base.CreatedById
    ,base.LastUpdated, base.LastUpdatedById,
    base.RowId
	--adding following will result in dups
	--,case when isnull(mbr.MemberTypeId,0) = 0 then 0
	--	else mbr.MemberTypeId end As MemberTypeId

  FROM [dbo].[Library] base
  inner join [Library.Type]			lt	on base.LibraryTypeId = lt.Id
  inner join [Library.Section]		ls	on base.id = ls.LibraryId
  left join [Library.SectionMember] lsm on ls.id = lsm.LibrarySectionId
  left join [Library.Member]		mbr on base.id = mbr.LibraryId
  --all orgs with libraries where user is associated
  left Join (
	Select distinct pos.OrgId ,pos.UserId, pos.Organization
	from [dbo].[Gateway.Org_MemberSummary] pos
	inner join Library orgLib on pos.OrgId = orgLib.OrgId
	) orgLibs on base.OrgId = orgLibs.OrgId
where 
	[IsActive]= 1
And (base.Id = @LibraryId OR @LibraryId is null)
And (
	(base.[CreatedById]= @UserId and LibraryTypeId = 1)
	OR
	(base.PublicAccessLevel >= 3)
	OR
	(mbr.UserId = @UserId AND mbr.MemberTypeId >= @BaseMemberId)
	OR
	(lsm.UserId = @UserId AND lsm.MemberTypeId >= @BaseMemberId)
	OR
	(orgLibs.UserId = @UserId AND base.OrgAccessLevel >= 3)
)
Order by base.Title 

GO
grant execute on [Library.SelectCanContribute] to public 
Go