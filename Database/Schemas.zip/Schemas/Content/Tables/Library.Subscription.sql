USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.Subscription]    Script Date: 06/13/2013 18:46:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Library.Subscription](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[SubscriptionTypeId] [int] NULL,
	[PrivilegeId] [int] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Library.Subscription] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Library.Subscription]  WITH CHECK ADD  CONSTRAINT [FK_Library.Subscription_Codes.SubscriptionType] FOREIGN KEY([SubscriptionTypeId])
REFERENCES [dbo].[Codes.SubscriptionType] ([Id])
GO

ALTER TABLE [dbo].[Library.Subscription] CHECK CONSTRAINT [FK_Library.Subscription_Codes.SubscriptionType]
GO

ALTER TABLE [dbo].[Library.Subscription]  WITH CHECK ADD  CONSTRAINT [FK_Library.Subscription_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Library.Subscription] CHECK CONSTRAINT [FK_Library.Subscription_Library]
GO

ALTER TABLE [dbo].[Library.Subscription] ADD  CONSTRAINT [DF_Library.Subscription_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.Subscription] ADD  CONSTRAINT [DF_Library.Subscription_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


