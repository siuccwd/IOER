USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.Like]    Script Date: 9/21/2014 11:30:52 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Content.Like](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ContentId] [int] NULL,
	[IsLike] [bit] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Content.Like] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Content.Like]    Script Date: 9/21/2014 11:30:52 AM ******/
CREATE CLUSTERED INDEX [IX_Content.Like] ON [dbo].[Content.Like]
(
	[ContentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Content.Like] ADD  CONSTRAINT [DF_Content.Like_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content.Like]  WITH CHECK ADD  CONSTRAINT [FK_Content.Like_Content] FOREIGN KEY([ContentId])
REFERENCES [dbo].[Content] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Content.Like] CHECK CONSTRAINT [FK_Content.Like_Content]
GO

