USE [IsleContent]
GO

ALTER TABLE [dbo].[Community.PostItem] DROP CONSTRAINT [FK_Community.PostItem_Community.Posting]
GO

ALTER TABLE [dbo].[Community.PostItem] DROP CONSTRAINT [FK_Community.PostItem_Community]
GO

ALTER TABLE [dbo].[Community.PostItem] DROP CONSTRAINT [DF_Community.PostItem_Created]
GO

/****** Object:  Table [dbo].[Community.PostItem]    Script Date: 3/13/2014 1:10:02 PM ******/
DROP TABLE [dbo].[Community.PostItem]
GO

/****** Object:  Table [dbo].[Community.PostItem]    Script Date: 3/13/2014 1:10:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Community.PostItem](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CommunityId] [int] NOT NULL,
	[PostingId] [int] NULL,
	[CreatedById] [int] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Community.PostItem] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_Community.PostItem] UNIQUE CLUSTERED 
(
	[CommunityId] ASC,
	[PostingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Community.PostItem] ADD  CONSTRAINT [DF_Community.PostItem_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Community.PostItem]  WITH CHECK ADD  CONSTRAINT [FK_Community.PostItem_Community] FOREIGN KEY([CommunityId])
REFERENCES [dbo].[Community] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Community.PostItem] CHECK CONSTRAINT [FK_Community.PostItem_Community]
GO

ALTER TABLE [dbo].[Community.PostItem]  WITH CHECK ADD  CONSTRAINT [FK_Community.PostItem_Community.Posting] FOREIGN KEY([PostingId])
REFERENCES [dbo].[Community.Posting] ([Id])
ON UPDATE SET DEFAULT
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Community.PostItem] CHECK CONSTRAINT [FK_Community.PostItem_Community.Posting]
GO

