USE [IsleContent]
GO

/****** Object:  Table [dbo].[ContentFile]    Script Date: 1/28/2014 5:45:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ContentFile](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Description] [varchar](max) NULL,
	[ResourceUrl] [varchar](200) NOT NULL,
	[OrgId] [int] NULL,
	[ResourceVersionId] [int] NULL,
	[IsActive] [bit] NOT NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NOT NULL,
	[LastUpdatedById] [int] NULL,
	[DocumentRowId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ContentFile] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ContentFile] ADD  CONSTRAINT [DF_ContentFile_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[ContentFile] ADD  CONSTRAINT [DF_ContentFile_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[ContentFile] ADD  CONSTRAINT [DF_ContentFile_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

