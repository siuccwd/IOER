USE [IsleContent]
GO

ALTER TABLE [dbo].[Community.Member] DROP CONSTRAINT [FK_Community.Member_Community]
GO

ALTER TABLE [dbo].[Community.Member] DROP CONSTRAINT [FK_Community.Member_Codes.LibraryMemberType]
GO

ALTER TABLE [dbo].[Community.Member] DROP CONSTRAINT [DF_Community.Member_Created]
GO

/****** Object:  Index [IX_Community.Member]    Script Date: 3/13/2014 1:10:40 PM ******/
DROP INDEX [IX_Community.Member] ON [dbo].[Community.Member]
GO

/****** Object:  Table [dbo].[Community.Member]    Script Date: 3/13/2014 1:10:40 PM ******/
DROP TABLE [dbo].[Community.Member]
GO

/****** Object:  Table [dbo].[Community.Member]    Script Date: 3/13/2014 1:10:40 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Community.Member](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CommunityId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[MemberTypeId] [int] NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Community.Member] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Community.Member]    Script Date: 3/13/2014 1:10:40 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Community.Member] ON [dbo].[Community.Member]
(
	[CommunityId] ASC,
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Community.Member] ADD  CONSTRAINT [DF_Community.Member_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Community.Member]  WITH CHECK ADD  CONSTRAINT [FK_Community.Member_Codes.LibraryMemberType] FOREIGN KEY([MemberTypeId])
REFERENCES [dbo].[Codes.LibraryMemberType] ([Id])
GO

ALTER TABLE [dbo].[Community.Member] CHECK CONSTRAINT [FK_Community.Member_Codes.LibraryMemberType]
GO

ALTER TABLE [dbo].[Community.Member]  WITH CHECK ADD  CONSTRAINT [FK_Community.Member_Community] FOREIGN KEY([CommunityId])
REFERENCES [dbo].[Community] ([Id])
GO

ALTER TABLE [dbo].[Community.Member] CHECK CONSTRAINT [FK_Community.Member_Community]
GO

