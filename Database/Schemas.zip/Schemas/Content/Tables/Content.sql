USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content]    Script Date: 03/20/2013 16:15:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Content](
	[Id] [int] IDENTITY(1,1000) NOT NULL,
	[TypeId] [int] NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Summary] [varchar](max) NULL,
	[Description] [varchar](max) NULL,
	[StatusId] [int] NULL,
	[PrivilegeTypeId] [int] NULL,
	[IsActive] [bit] NULL,
	[IsPublished] [bit] NULL,
	[OrganizationId] [uniqueidentifier] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
	[Approved] [datetime] NULL,
	[ApprovedById] [int] NULL,
	[ParentRowId] [uniqueidentifier] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Table_1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'FK to AppItemType table' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content', @level2type=N'COLUMN',@level2name=N'TypeId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Track last user to update an org' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content', @level2type=N'COLUMN',@level2name=N'LastUpdatedById'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Track last user to update an org' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content', @level2type=N'COLUMN',@level2name=N'Approved'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Track last user to update an org' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content', @level2type=N'COLUMN',@level2name=N'ApprovedById'
GO

ALTER TABLE [dbo].[Content]  WITH CHECK ADD  CONSTRAINT [FK_Content_Codes.ContentPrivilege] FOREIGN KEY([PrivilegeTypeId])
REFERENCES [dbo].[Codes.ContentPrivilege] ([Id])
GO

ALTER TABLE [dbo].[Content] CHECK CONSTRAINT [FK_Content_Codes.ContentPrivilege]
GO

ALTER TABLE [dbo].[Content]  WITH CHECK ADD  CONSTRAINT [FK_Content_Codes.ContentStatus] FOREIGN KEY([StatusId])
REFERENCES [dbo].[Codes.ContentStatus] ([Id])
GO

ALTER TABLE [dbo].[Content] CHECK CONSTRAINT [FK_Content_Codes.ContentStatus]
GO

ALTER TABLE [dbo].[Content] ADD  CONSTRAINT [DF_Table_1_StatusId]  DEFAULT ((1)) FOR [StatusId]
GO

ALTER TABLE [dbo].[Content] ADD  CONSTRAINT [DF_Table_1_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Content] ADD  CONSTRAINT [DF_Table_1_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content] ADD  CONSTRAINT [DF_Table_1_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Content] ADD  CONSTRAINT [DF_Table_1_Approved]  DEFAULT (getdate()) FOR [Approved]
GO

ALTER TABLE [dbo].[Content] ADD  CONSTRAINT [DF_Table_1_RowId]  DEFAULT (newid()) FOR [RowId]
GO


