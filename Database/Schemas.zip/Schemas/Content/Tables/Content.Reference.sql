USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.Reference]    Script Date: 03/21/2013 11:17:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Content.Reference](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ParentId] [int] NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Author] [varchar](100) NOT NULL,
	[Publisher] [varchar](100) NOT NULL,
	[ISBN] [varchar](50) NULL,
	[ReferenceUrl] [varchar](200) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Content.Reference] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'FK to AppItemType table' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content.Reference', @level2type=N'COLUMN',@level2name=N'ParentId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Track last user to update an org' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content.Reference', @level2type=N'COLUMN',@level2name=N'LastUpdatedById'
GO

ALTER TABLE [dbo].[Content.Reference] ADD  CONSTRAINT [DF_Content.Reference_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content.Reference] ADD  CONSTRAINT [DF_Content.Reference_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


