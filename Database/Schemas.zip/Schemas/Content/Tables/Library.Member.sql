USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.Member]    Script Date: 1/28/2014 10:54:17 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Library.Member](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[MemberTypeId] [int] NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NOT NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Library.Member] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_Library.Member_LibUser] UNIQUE NONCLUSTERED 
(
	[LibraryId] ASC,
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Library.Member] ADD  CONSTRAINT [DF_Library.Member_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Library.Member] ADD  CONSTRAINT [DF_Library.Member_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.Member] ADD  CONSTRAINT [DF_Library.Member_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Library.Member]  WITH CHECK ADD  CONSTRAINT [FK_Library.Member_Codes.LibraryMemberType] FOREIGN KEY([MemberTypeId])
REFERENCES [dbo].[Codes.LibraryMemberType] ([Id])
GO

ALTER TABLE [dbo].[Library.Member] CHECK CONSTRAINT [FK_Library.Member_Codes.LibraryMemberType]
GO

ALTER TABLE [dbo].[Library.Member]  WITH CHECK ADD  CONSTRAINT [FK_Library.Member_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Library.Member] CHECK CONSTRAINT [FK_Library.Member_Library]
GO

