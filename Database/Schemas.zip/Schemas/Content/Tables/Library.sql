USE IsleContent
GO

/****** Object:  Table [dbo].[Library]    Script Date: 05/16/2013 16:50:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
--  drop  TABLE [dbo].[Library]

CREATE TABLE [dbo].[Library](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Description] [varchar](500) NULL,
	[LibraryTypeId] [int] NULL,
	[IsDiscoverable] [bit] NULL,
	[IsPublic] [bit] NULL,
	[OrgId] [int] NULL,
	[IsActive] [bit] NULL,
	[ImageUrl] [varchar](200) NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Library] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Library]  WITH CHECK ADD  CONSTRAINT [FK_Library_Library.Type] FOREIGN KEY([LibraryTypeId])
REFERENCES [dbo].[Library.Type] ([Id])
GO

ALTER TABLE [dbo].[Library] CHECK CONSTRAINT [FK_Library_Library.Type]
GO

--ALTER TABLE [dbo].[Library]  WITH CHECK ADD  CONSTRAINT [FK_Library_Patron] FOREIGN KEY([CreatedById])
--REFERENCES [dbo].[Patron] ([Id])
--GO

--ALTER TABLE [dbo].[Library] CHECK CONSTRAINT [FK_Library_Patron]
--GO

ALTER TABLE [dbo].[Library] ADD  CONSTRAINT [DF_Library_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Library] ADD  CONSTRAINT [DF_Library_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library] ADD  CONSTRAINT [DF_Library_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Library] ADD  CONSTRAINT [DF_Library_RowId]  DEFAULT (newid()) FOR [RowId]
GO


