USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.History]    Script Date: 05/01/2013 16:05:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Content.History](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ContentId] [int] NOT NULL,
	[Action] [varchar](75) NOT NULL,
	[Description] [varchar](max) NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NOT NULL,
 CONSTRAINT [PK_Content.History] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Content.History]  WITH CHECK ADD  CONSTRAINT [FK_Content.History_Content] FOREIGN KEY([ContentId])
REFERENCES [dbo].[Content] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Content.History] CHECK CONSTRAINT [FK_Content.History_Content]
GO

ALTER TABLE [dbo].[Content.History] ADD  CONSTRAINT [DF_Content.History_Content.History]  DEFAULT ('Project Action') FOR [Action]
GO

ALTER TABLE [dbo].[Content.History] ADD  CONSTRAINT [DF_Content.History_Created]  DEFAULT (getdate()) FOR [Created]
GO

