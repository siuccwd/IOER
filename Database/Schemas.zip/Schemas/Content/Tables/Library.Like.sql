USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.Like]    Script Date: 3/28/2014 2:53:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Library.Like](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NOT NULL,
	[IsLike] [bit] NOT NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NOT NULL,
 CONSTRAINT [PK_Library.Like_1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Library.Like]    Script Date: 3/28/2014 2:53:31 PM ******/
CREATE NONCLUSTERED INDEX [IX_Library.Like] ON [dbo].[Library.Like]
(
	[LibraryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_Library.Like_LibIdUserId]    Script Date: 3/28/2014 2:53:31 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Library.Like_LibIdUserId] ON [dbo].[Library.Like]
(
	[LibraryId] ASC,
	[CreatedById] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Library.Like] ADD  CONSTRAINT [DF_Library.Like_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.Like]  WITH CHECK ADD  CONSTRAINT [FK_Library.Like_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Library.Like] CHECK CONSTRAINT [FK_Library.Like_Library]
GO

