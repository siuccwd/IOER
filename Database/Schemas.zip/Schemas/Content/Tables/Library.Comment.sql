USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.Comment]    Script Date: 1/15/2014 11:31:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Library.Comment](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NULL,
	[Comment] [varchar](1000) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Library.Comment] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Library.Comment] ADD  CONSTRAINT [DF_Library.Comment_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.Comment]  WITH CHECK ADD  CONSTRAINT [FK_Library.Comment_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([Id])
GO

ALTER TABLE [dbo].[Library.Comment] CHECK CONSTRAINT [FK_Library.Comment_Library]
GO


