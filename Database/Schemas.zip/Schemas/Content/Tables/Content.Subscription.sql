USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.Subscription]    Script Date: 9/16/2014 11:55:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Content.Subscription](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ContentId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[SubscriptionTypeId] [int] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Content.Subscription] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Content.Subscription] ADD  CONSTRAINT [DF_Content.Subscription_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content.Subscription] ADD  CONSTRAINT [DF_Content.Subscription_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Content.Subscription]  WITH CHECK ADD  CONSTRAINT [FK_Content.Subscription_Codes.SubscriptionType] FOREIGN KEY([SubscriptionTypeId])
REFERENCES [dbo].[Codes.SubscriptionType] ([Id])
GO

ALTER TABLE [dbo].[Content.Subscription] CHECK CONSTRAINT [FK_Content.Subscription_Codes.SubscriptionType]
GO

ALTER TABLE [dbo].[Content.Subscription]  WITH CHECK ADD  CONSTRAINT [FK_Content.Subscription_Content] FOREIGN KEY([ContentId])
REFERENCES [dbo].[Content] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Content.Subscription] CHECK CONSTRAINT [FK_Content.Subscription_Content]
GO


