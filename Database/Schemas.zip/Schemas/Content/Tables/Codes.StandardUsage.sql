USE [IsleContent]
GO

/****** Object:  Table [dbo].[Codes.StandardUsage]    Script Date: 9/21/2014 2:42:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.StandardUsage](
	[Id] [int] NOT NULL,
	[Title] [varchar](50) NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Codes.StandardUsage] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


