USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.Invitation]    Script Date: 2/13/2014 9:06:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Library.Invitation](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[InvitationType] [varchar](50) NULL,
	[PassCode] [varchar](50) NULL,
	[TargetEmail] [varchar](150) NULL,
	[TargetUserId] [int] NULL,
	[Subject] [varchar](100) NULL,
	[MessageContent] [varchar](max) NULL,
	[EmailNoticeCode] [varchar](50) NULL,
	[Response] [varchar](50) NULL,
	[ResponseDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[IsActive] [bit] NULL,
	[DeleteOnResponse] [bit] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NOT NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
	[LibMemberTypeId] [int] NULL,
	[StartingUrl] [varchar](200) NULL,
 CONSTRAINT [PK_Library.Invitation] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Library.Invitation] ADD  CONSTRAINT [DF_Library.Invitation_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Library.Invitation] ADD  CONSTRAINT [DF_Library.Invitation_Type]  DEFAULT ('Individual') FOR [InvitationType]
GO

ALTER TABLE [dbo].[Library.Invitation] ADD  CONSTRAINT [DF_Library.Invitation_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Library.Invitation] ADD  CONSTRAINT [DF_Library.Invitation_DeleteOnResponse]  DEFAULT ((0)) FOR [DeleteOnResponse]
GO

ALTER TABLE [dbo].[Library.Invitation] ADD  CONSTRAINT [DF_Table_1_DateSent]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.Invitation] ADD  CONSTRAINT [DF_Library.Invitation_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Library.Invitation]  WITH CHECK ADD  CONSTRAINT [FK_Library.Invitation_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([Id])
GO

ALTER TABLE [dbo].[Library.Invitation] CHECK CONSTRAINT [FK_Library.Invitation_Library]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Individual or Library' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Library.Invitation', @level2type=N'COLUMN',@level2name=N'InvitationType'
GO

