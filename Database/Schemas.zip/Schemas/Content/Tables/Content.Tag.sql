USE IsleContent
GO

/****** Object:  Table [dbo].[Content.Tag]    Script Date: 9/16/2014 11:52:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Content.Tag](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ContentId] [int] NOT NULL,
	[TagValueId] [int] NOT NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Content.Tag] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Content.Tag] ADD  CONSTRAINT [DF_Content.Tag_Created]  DEFAULT (getdate()) FOR [Created]
GO


ALTER TABLE [dbo].[Content.Tag]  WITH CHECK ADD  CONSTRAINT [FK_Content.Tag_Content] FOREIGN KEY([ContentId])
REFERENCES [dbo].[Content] ([Id])
GO

ALTER TABLE [dbo].[Content.Tag] CHECK CONSTRAINT [FK_Content.Tag_Content]
GO


