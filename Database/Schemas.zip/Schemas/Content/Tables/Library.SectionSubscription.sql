USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.SectionSubscription]    Script Date: 06/13/2013 18:44:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Library.SectionSubscription](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SectionId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[SubscriptionTypeId] [int] NULL,
	[PrivilegeId] [int] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Library.SectionSubscription] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Library.SectionSubscription] ADD  CONSTRAINT [DF_Library.SectionSubscription_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.SectionSubscription] ADD  CONSTRAINT [DF_Library.SectionSubscription_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


