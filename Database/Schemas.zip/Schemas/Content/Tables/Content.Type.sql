USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.Type]    Script Date: 03/20/2013 16:16:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[Content.Type](
	[Id] [int] NOT NULL,
	[Title] [varchar](50) NOT NULL,
	[Description] [varchar](200) NOT NULL,
	[HasApproval] [bit] NULL,
	[MaxVersions] [smallint] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Content.Type] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK, but set by creator' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content.Type', @level2type=N'COLUMN',@level2name=N'Id'
GO

ALTER TABLE [dbo].[Content.Type] ADD  CONSTRAINT [DF_Content.Type_HasApproval]  DEFAULT ((0)) FOR [HasApproval]
GO

ALTER TABLE [dbo].[Content.Type] ADD  CONSTRAINT [DF_Content.Type_MaxVersions]  DEFAULT ((1)) FOR [MaxVersions]
GO

ALTER TABLE [dbo].[Content.Type] ADD  CONSTRAINT [DF_Content.Type_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Content.Type] ADD  CONSTRAINT [DF_Content.Type_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content.Type] ADD  CONSTRAINT [DF_Content.Type_RowId]  DEFAULT (newid()) FOR [RowId]
GO


