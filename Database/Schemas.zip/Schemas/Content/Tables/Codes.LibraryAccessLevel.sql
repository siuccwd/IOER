USE [IsleContent]
GO

/****** Object:  Table [dbo].[Codes.LibraryAccessLevel]    Script Date: 2/5/2014 10:24:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.LibraryAccessLevel](
	[Id] [int] NOT NULL,
	[Title] [varchar](50) NULL,
	IsActive bit,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Codes.LibraryAccessLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.LibraryAccessLevel] ADD  CONSTRAINT [DF_Codes.LibraryAccessLevel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Codes.LibraryAccessLevel] ADD  CONSTRAINT [DF_Codes.LibraryAccessLevel_IsActive]  DEFAULT (1) FOR [IsActive]
GO

