USE IsleContent
GO


/****** Object:  Table [dbo].[EmailNotice]    Script Date: 1/28/2014 10:34:20 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[EmailNotice](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](75) NOT NULL,
	[Category] [varchar](50) NOT NULL,
	[NoticeCode] [varchar](50) NOT NULL,
	[Description] [varchar](500) NULL,
	[Filter] [varchar](max) NULL,
	[isActive] [bit] NOT NULL,
	[LanguageCode] [varchar](10) NULL,
	[FromEmail] [nvarchar](100) NULL,
	[CcEmail] [nvarchar](500) NULL,
	[BccEmail] [nvarchar](100) NULL,
	[Subject] [nvarchar](100) NOT NULL,
	[HtmlBody] [nvarchar](max) NOT NULL,
	[TextBody] [nvarchar](max) NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NOT NULL,
	[LastUpdatedById] [int] NULL,
	[LastUpdatedBy] [varchar](50) NULL,
	[CreatedBy] [varchar](50) NULL,
 CONSTRAINT [PK_EmailNotice] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[EmailNotice] ADD  CONSTRAINT [DF_EmailNotice_Category]  DEFAULT ('General') FOR [Category]
GO

ALTER TABLE [dbo].[EmailNotice] ADD  CONSTRAINT [DF_EmailNotice_isActive]  DEFAULT ((1)) FOR [isActive]
GO

ALTER TABLE [dbo].[EmailNotice] ADD  CONSTRAINT [DF_EmailNotice_langCode]  DEFAULT ('en') FOR [LanguageCode]
GO

ALTER TABLE [dbo].[EmailNotice] ADD  CONSTRAINT [DF_EmailNotice_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[EmailNotice] ADD  CONSTRAINT [DF_EmailNotice_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_ColumnHidden', @value=N'False' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice', @level2type=N'COLUMN',@level2name=N'id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_ColumnOrder', @value=0 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice', @level2type=N'COLUMN',@level2name=N'id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_ColumnWidth', @value=-1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice', @level2type=N'COLUMN',@level2name=N'id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Track last user to update an org' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice', @level2type=N'COLUMN',@level2name=N'LastUpdatedBy'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Track user who created the org' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice', @level2type=N'COLUMN',@level2name=N'CreatedBy'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DefaultView', @value=0x02 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Filter', @value=NULL , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_OrderBy', @value=NULL , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_OrderByOn', @value=N'False' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Orientation', @value=NULL , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_RowHeight', @value=1455 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_TableMaxRecords', @value=10000 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'EmailNotice'
GO

