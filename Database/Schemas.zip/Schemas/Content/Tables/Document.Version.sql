USE IsleContent
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Document.Version_RowId]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Document.Version] DROP CONSTRAINT [DF_Document.Version_RowId]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Document.Version_Status]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Document.Version] DROP CONSTRAINT [DF_Document.Version_Status]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Document.Version_Created]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Document.Version] DROP CONSTRAINT [DF_Document.Version_Created]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Document.Version_LastUpdated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Document.Version] DROP CONSTRAINT [DF_Document.Version_LastUpdated]
END

GO

USE IsleContent
GO

/****** Object:  Table [dbo].[Document.Version]    Script Date: 04/01/2013 00:09:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Document.Version]') AND type in (N'U'))
DROP TABLE [dbo].[Document.Version]
GO

USE IsleContent
GO

/****** Object:  Table [dbo].[Document.Version]    Script Date: 04/01/2013 00:09:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Document.Version](
	[RowId] [uniqueidentifier] NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Summary] [varchar](500) NULL,
	[Status] [varchar](25) NULL,
	[FileName] [varchar](150) NULL,
	[FileDate] [datetime] NULL,
	[MimeType] [varchar](150) NULL,
	[Bytes] [bigint] NULL,
	[Data] [varbinary](max) NOT NULL,
	[Url] [varchar](150) NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NOT NULL,
	[LastUpdated] [datetime] NOT NULL,
	[LastUpdatedById] [int] NOT NULL,
 CONSTRAINT [PK_Document.Version] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'do we need to distinguish between upload date and actual last mod date of the file?' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Document.Version', @level2type=N'COLUMN',@level2name=N'FileDate'
GO

ALTER TABLE [dbo].[Document.Version] ADD  CONSTRAINT [DF_Document.Version_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Document.Version] ADD  CONSTRAINT [DF_Document.Version_Status]  DEFAULT ('Pending') FOR [Status]
GO

ALTER TABLE [dbo].[Document.Version] ADD  CONSTRAINT [DF_Document.Version_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Document.Version] ADD  CONSTRAINT [DF_Document.Version_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

