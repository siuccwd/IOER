USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.Resource]    Script Date: 2/6/2014 5:07:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Library.Resource](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibrarySectionId] [int] NOT NULL,
	[ResourceIntId] [int] NOT NULL,
	[IsActive] [bit] NULL,
	[Comment] [varchar](500) NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Library.Resource] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Library.Resource] ADD  CONSTRAINT [DF_Library.Resource_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Library.Resource] ADD  CONSTRAINT [DF_Library.Resource_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.Resource]  WITH CHECK ADD  CONSTRAINT [FK_Library.Resource_Library.Section] FOREIGN KEY([LibrarySectionId])
REFERENCES [dbo].[Library.Section] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Library.Resource] CHECK CONSTRAINT [FK_Library.Resource_Library.Section]
GO
