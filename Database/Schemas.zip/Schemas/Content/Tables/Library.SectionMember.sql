USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.SectionMember]    Script Date: 1/28/2014 10:53:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Library.SectionMember](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibrarySectionId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[MemberTypeId] [int] NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[Created] [datetime] NOT NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NOT NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Library.SectionMember] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_Library.SectionMember_LibUser] UNIQUE NONCLUSTERED 
(
	[LibrarySectionId] ASC,
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Library.SectionMember] ADD  CONSTRAINT [DF_Library.SectionMember_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Library.SectionMember] ADD  CONSTRAINT [DF_Library.SectionMember_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.SectionMember] ADD  CONSTRAINT [DF_Library.SectionMember_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Library.SectionMember]  WITH CHECK ADD  CONSTRAINT [FK_Library.SectionMember_Codes.LibraryMemberType] FOREIGN KEY([MemberTypeId])
REFERENCES [dbo].[Codes.LibraryMemberType] ([Id])
GO

ALTER TABLE [dbo].[Library.SectionMember] CHECK CONSTRAINT [FK_Library.SectionMember_Codes.LibraryMemberType]
GO

ALTER TABLE [dbo].[Library.SectionMember]  WITH CHECK ADD  CONSTRAINT [FK_Library.SectionMember_Library.Section] FOREIGN KEY([LibrarySectionId])
REFERENCES [dbo].[Library.Section] ([Id])
GO

ALTER TABLE [dbo].[Library.SectionMember] CHECK CONSTRAINT [FK_Library.SectionMember_Library.Section]
GO

