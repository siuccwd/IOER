USE IsleContent
GO

/****** Object:  Table [dbo].[Library.Section]    Script Date: 05/16/2013 16:57:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Library.Section](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NOT NULL,
	[SectionTypeId] [int] NOT NULL,
	[Title] [varchar](100) NULL,
	[Description] [varchar](500) NULL,
	[ParentId] [int] NULL,
	[IsDefaultSection] [bit] NULL,
	[IsPublic] [bit] NULL,
	[AreContentsReadOnly] [bit] NULL,
	[ImageUrl] [varchar](200) NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Library.Section] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Library.Section]  WITH CHECK ADD  CONSTRAINT [FK_Library.Section_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Library.Section] CHECK CONSTRAINT [FK_Library.Section_Library]
GO

ALTER TABLE [dbo].[Library.Section]  WITH CHECK ADD  CONSTRAINT [FK_Library.Section_Library.SectionType] FOREIGN KEY([SectionTypeId])
REFERENCES [dbo].[Library.SectionType] ([Id])
GO

ALTER TABLE [dbo].[Library.Section] CHECK CONSTRAINT [FK_Library.Section_Library.SectionType]
GO

--ALTER TABLE [dbo].[Library.Section]  WITH CHECK ADD  CONSTRAINT [FK_Library.Section_Patron] FOREIGN KEY([CreatedById])
--REFERENCES [dbo].[Patron] ([Id])
--GO

--ALTER TABLE [dbo].[Library.Section] CHECK CONSTRAINT [FK_Library.Section_Patron]
--GO

ALTER TABLE [dbo].[Library.Section] ADD  CONSTRAINT [DF_Library.Section_SectionTypeId]  DEFAULT ((3)) FOR [SectionTypeId]
GO

ALTER TABLE [dbo].[Library.Section] ADD  CONSTRAINT [DF_Library.Section_IsDefaultSection]  DEFAULT ((0)) FOR [IsDefaultSection]
GO

ALTER TABLE [dbo].[Library.Section] ADD  CONSTRAINT [DF_Library.Section_IsPublic]  DEFAULT ((1)) FOR [IsPublic]
GO

ALTER TABLE [dbo].[Library.Section] ADD  CONSTRAINT [DF_Library.Section_AreContentsReadOnly]  DEFAULT ((0)) FOR [AreContentsReadOnly]
GO

ALTER TABLE [dbo].[Library.Section] ADD  CONSTRAINT [DF_Library.Section_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.Section] ADD  CONSTRAINT [DF_Library.Section_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


