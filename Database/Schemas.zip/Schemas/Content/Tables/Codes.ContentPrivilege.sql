USE [IsleContent]
GO

/****** Object:  Table [dbo].[Codes.ContentPrivilege]    Script Date: 03/20/2013 16:15:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.ContentPrivilege](
	[Id] [int] NOT NULL,
	[Title] [varchar](50) NULL,
	[Description] [varchar](200) NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Codes.ContentPrivilege] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.ContentPrivilege] ADD  CONSTRAINT [DF_Codes.ContentPrivilege_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Codes.ContentPrivilege] ADD  CONSTRAINT [DF_Codes.ContentPrivilege_Created]  DEFAULT (getdate()) FOR [Created]
GO


