USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.Standard]    Script Date: 9/28/2014 10:32:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Content.Standard](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ContentId] [int] NOT NULL,
	[StandardId] [int] NOT NULL,
	[AlignmentTypeCodeId] [int] NULL,
	[UsageTypeId] [int] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Content.StandardAlignment] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Content.Standard] ADD  CONSTRAINT [DF_Content.Standard_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content.Standard] ADD  CONSTRAINT [DF_Content.Standard_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Content.Standard]  WITH CHECK ADD  CONSTRAINT [FK_Content.Standard_Content] FOREIGN KEY([ContentId])
REFERENCES [dbo].[Content] ([Id])
GO

ALTER TABLE [dbo].[Content.Standard] CHECK CONSTRAINT [FK_Content.Standard_Content]
GO

