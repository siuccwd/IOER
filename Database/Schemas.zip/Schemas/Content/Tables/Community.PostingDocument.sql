USE [IsleContent]
GO

ALTER TABLE [dbo].[Community.PostingDocument] DROP CONSTRAINT [FK_Community.PostingDocument_Document.Version]
GO

ALTER TABLE [dbo].[Community.PostingDocument] DROP CONSTRAINT [FK_Community.PostingDocument_Community.Posting]
GO

ALTER TABLE [dbo].[Community.PostingDocument] DROP CONSTRAINT [DF_Community.PostingDocument_Created]
GO

/****** Object:  Index [IX_Community.PostingDocument]    Script Date: 3/13/2014 1:11:08 PM ******/
DROP INDEX [IX_Community.PostingDocument] ON [dbo].[Community.PostingDocument]
GO

/****** Object:  Table [dbo].[Community.PostingDocument]    Script Date: 3/13/2014 1:11:08 PM ******/
DROP TABLE [dbo].[Community.PostingDocument]
GO

/****** Object:  Table [dbo].[Community.PostingDocument]    Script Date: 3/13/2014 1:11:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Community.PostingDocument](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PostingId] [int] NULL,
	[DocumentId] [uniqueidentifier] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Community.PostingDocument] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Community.PostingDocument]    Script Date: 3/13/2014 1:11:08 PM ******/
CREATE NONCLUSTERED INDEX [IX_Community.PostingDocument] ON [dbo].[Community.PostingDocument]
(
	[PostingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Community.PostingDocument] ADD  CONSTRAINT [DF_Community.PostingDocument_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Community.PostingDocument]  WITH CHECK ADD  CONSTRAINT [FK_Community.PostingDocument_Community.Posting] FOREIGN KEY([PostingId])
REFERENCES [dbo].[Community.Posting] ([Id])
GO

ALTER TABLE [dbo].[Community.PostingDocument] CHECK CONSTRAINT [FK_Community.PostingDocument_Community.Posting]
GO

ALTER TABLE [dbo].[Community.PostingDocument]  WITH CHECK ADD  CONSTRAINT [FK_Community.PostingDocument_Document.Version] FOREIGN KEY([DocumentId])
REFERENCES [dbo].[Document.Version] ([RowId])
GO

ALTER TABLE [dbo].[Community.PostingDocument] CHECK CONSTRAINT [FK_Community.PostingDocument_Document.Version]
GO

