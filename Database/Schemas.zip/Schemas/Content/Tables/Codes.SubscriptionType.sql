USE [IsleContent]
GO

/****** Object:  Table [dbo].[Codes.SubscriptionType]    Script Date: 06/17/2013 11:01:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Codes.SubscriptionType](
	[Id] [int] NOT NULL,
	[Title] [varchar](50) NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Codes.SubscriptionType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Codes.SubscriptionType] ADD  CONSTRAINT [DF_Codes.SubscriptionType_Created]  DEFAULT (getdate()) FOR [Created]
GO

