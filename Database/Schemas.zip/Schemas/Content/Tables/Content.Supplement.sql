USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.Supplement]    Script Date: 03/20/2013 16:16:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Content.Supplement](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ParentId] [int] NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Description] [varchar](max) NULL,
	[ResourceUrl] [varchar](200) NULL,
	[PrivilegeTypeId] [int] NULL,
	[IsActive] [bit] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Content.Supplement] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'FK to AppItemType table' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content.Supplement', @level2type=N'COLUMN',@level2name=N'ParentId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Track last user to update an org' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Content.Supplement', @level2type=N'COLUMN',@level2name=N'LastUpdatedById'
GO

ALTER TABLE [dbo].[Content.Supplement] ADD  CONSTRAINT [DF_Content.Supplement_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Content.Supplement] ADD  CONSTRAINT [DF_Content.Supplement_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content.Supplement] ADD  CONSTRAINT [DF_Content.Supplement_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


