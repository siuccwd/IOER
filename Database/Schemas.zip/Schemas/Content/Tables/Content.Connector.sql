USE [IsleContent]
GO

/****** Object:  Table [dbo].[Content.Connector]    Script Date: 3/19/2014 4:21:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Content.Connector](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ParentId] [int] NOT NULL,
	[ChildId] [int] NOT NULL,
	[SortOrder] [int] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Content.Connector] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Content.Connector]    Script Date: 3/19/2014 4:21:35 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Content.Connector] ON [dbo].[Content.Connector]
(
	[ParentId] ASC,
	[ChildId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Content.Connector] ADD  CONSTRAINT [DF_Content.Connector_SortOrder]  DEFAULT ((10)) FOR [SortOrder]
GO

ALTER TABLE [dbo].[Content.Connector] ADD  CONSTRAINT [DF_Content.Connector_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Content.Connector]  WITH CHECK ADD  CONSTRAINT [FK_Content.Connector_Content] FOREIGN KEY([ParentId])
REFERENCES [dbo].[Content] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Content.Connector] CHECK CONSTRAINT [FK_Content.Connector_Content]
GO

ALTER TABLE [dbo].[Content.Connector]  WITH CHECK ADD  CONSTRAINT [FK_Content.Connector_Content1] FOREIGN KEY([ChildId])
REFERENCES [dbo].[Content] ([Id])
GO

ALTER TABLE [dbo].[Content.Connector] CHECK CONSTRAINT [FK_Content.Connector_Content1]
GO

