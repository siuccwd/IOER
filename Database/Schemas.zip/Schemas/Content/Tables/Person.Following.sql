USE [IsleContent]
GO

/****** Object:  Table [dbo].[Person.Following]    Script Date: 2/24/2014 12:52:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Person.Following](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FollowingUserId] [int] NOT NULL,
	[FollowedByUserId] [int] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Person.Following] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Person.Following_ByUserId]    Script Date: 2/24/2014 12:52:10 PM ******/
CREATE NONCLUSTERED INDEX [IX_Person.Following_ByUserId] ON [dbo].[Person.Following]
(
	[FollowedByUserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_Person.Following_FollowingUserId]    Script Date: 2/24/2014 12:52:10 PM ******/
CREATE NONCLUSTERED INDEX [IX_Person.Following_FollowingUserId] ON [dbo].[Person.Following]
(
	[FollowingUserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_Person.Following_Unq_FUId_FByUId]    Script Date: 2/24/2014 12:52:10 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Person.Following_Unq_FUId_FByUId] ON [dbo].[Person.Following]
(
	[FollowingUserId] ASC,
	[FollowedByUserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Person.Following] ADD  CONSTRAINT [DF_Person.Following_Created]  DEFAULT (getdate()) FOR [Created]
GO

