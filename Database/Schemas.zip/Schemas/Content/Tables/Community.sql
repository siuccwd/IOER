USE [IsleContent]
GO

ALTER TABLE [dbo].[Community] DROP CONSTRAINT [DF_Community_Created1]
GO

ALTER TABLE [dbo].[Community] DROP CONSTRAINT [DF_Community_Created]
GO

/****** Object:  Table [dbo].[Community]    Script Date: 3/13/2014 1:09:21 PM ******/
DROP TABLE [dbo].[Community]
GO

/****** Object:  Table [dbo].[Community]    Script Date: 3/13/2014 1:09:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Community](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[ImageUrl] [varchar](200) NULL,
	[ContactId] [int] NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[LastUpdated] [datetime] NULL,
	[LastUpdatedById] [int] NULL,
 CONSTRAINT [PK_Community] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Community] ADD  CONSTRAINT [DF_Community_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Community] ADD  CONSTRAINT [DF_Community_Created1]  DEFAULT (getdate()) FOR [LastUpdated]
GO

