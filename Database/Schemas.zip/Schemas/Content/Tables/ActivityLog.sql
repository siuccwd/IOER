USE [IsleContent]
GO

/****** Object:  Table [dbo].[ActivityLog]    Script Date: 1/15/2015 3:55:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ActivityLog](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CreatedDate] [datetime] NULL,
	[ActivityType] [varchar](25) NOT NULL,
	[Activity] [varchar](100) NOT NULL,
	[Event] [varchar](100) NOT NULL,
	[Comment] [varchar](1000) NULL,
	[TargetUserId] [int] NULL,
	[ActionByUserId] [int] NULL,
	[ActivityObjectId] [int] NULL,
	[Int2] [int] NULL,
	[RelatedImageUrl] [varchar](200) NULL,
	[RelatedTargetUrl] [varchar](200) NULL,
 CONSTRAINT [PK_ActivityLog] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Index [IX_ActivityLog_ActionByUserId]    Script Date: 1/15/2015 3:55:55 PM ******/
CREATE NONCLUSTERED INDEX [IX_ActivityLog_ActionByUserId] ON [dbo].[ActivityLog]
(
	[ActionByUserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

SET ANSI_PADDING ON

GO

/****** Object:  Index [IX_ActivityLog_Activities]    Script Date: 1/15/2015 3:55:55 PM ******/
CREATE NONCLUSTERED INDEX [IX_ActivityLog_Activities] ON [dbo].[ActivityLog]
(
	[ActivityType] ASC,
	[Activity] ASC,
	[Event] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_ActivityLog_Created]    Script Date: 1/15/2015 3:55:55 PM ******/
CREATE NONCLUSTERED INDEX [IX_ActivityLog_Created] ON [dbo].[ActivityLog]
(
	[CreatedDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ActivityLog] ADD  CONSTRAINT [DF_ActivityLog_CreatedDate]  DEFAULT (getdate()) FOR [CreatedDate]
GO

ALTER TABLE [dbo].[ActivityLog] ADD  CONSTRAINT [DF_ActivityLog_Type]  DEFAULT ('audit') FOR [ActivityType]
GO


