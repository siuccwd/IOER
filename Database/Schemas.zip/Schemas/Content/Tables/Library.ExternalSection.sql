USE [IsleContent]
GO

/****** Object:  Table [dbo].[Library.ExternalSection]    Script Date: 3/9/2014 4:56:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Library.ExternalSection](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NOT NULL,
	[ExternalSectionId] [int] NOT NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
	[RowId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Library.ExternalSection] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Library.ExternalSection] ADD  CONSTRAINT [DF_Library.ExternalSection_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Library.ExternalSection] ADD  CONSTRAINT [DF_Library.ExternalSection_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Library.ExternalSection]  WITH CHECK ADD  CONSTRAINT [FK_Library.ExternalSection_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Library.ExternalSection] CHECK CONSTRAINT [FK_Library.ExternalSection_Library]
GO

ALTER TABLE [dbo].[Library.ExternalSection]  WITH CHECK ADD  CONSTRAINT [FK_Table_1_Library.Section_ExtSectionId] FOREIGN KEY([ExternalSectionId])
REFERENCES [dbo].[Library.Section] ([Id])
GO

ALTER TABLE [dbo].[Library.ExternalSection] CHECK CONSTRAINT [FK_Table_1_Library.Section_ExtSectionId]
GO


