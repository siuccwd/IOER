USE [IsleContent]
GO

ALTER TABLE [dbo].[Community.Posting] DROP CONSTRAINT [FK_Community.Posting_Community.Posting]
GO

ALTER TABLE [dbo].[Community.Posting] DROP CONSTRAINT [FK_Community.Posting_Codes.PostingType]
GO

ALTER TABLE [dbo].[Community.Posting] DROP CONSTRAINT [DF_Community.Posting_Created]
GO

ALTER TABLE [dbo].[Community.Posting] DROP CONSTRAINT [DF_Community.Posting_PostingStatus]
GO

ALTER TABLE [dbo].[Community.Posting] DROP CONSTRAINT [DF_Community.Posting_PostingTypeId]
GO

/****** Object:  Table [dbo].[Community.Posting]    Script Date: 3/13/2014 1:10:22 PM ******/
DROP TABLE [dbo].[Community.Posting]
GO

/****** Object:  Table [dbo].[Community.Posting]    Script Date: 3/13/2014 1:10:22 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Community.Posting](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Message] [nvarchar](max) NULL,
	[PostingTypeId] [int] NULL,
	[PostingStatus] [varchar](25) NULL,
	[CreatedById] [int] NOT NULL,
	[Created] [datetime] NULL,
	[RelatedPostingId] [int] NULL,
 CONSTRAINT [PK_Community.Posting] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Community.Posting] ADD  CONSTRAINT [DF_Community.Posting_PostingTypeId]  DEFAULT ((1)) FOR [PostingTypeId]
GO

ALTER TABLE [dbo].[Community.Posting] ADD  CONSTRAINT [DF_Community.Posting_PostingStatus]  DEFAULT ('Open') FOR [PostingStatus]
GO

ALTER TABLE [dbo].[Community.Posting] ADD  CONSTRAINT [DF_Community.Posting_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Community.Posting]  WITH CHECK ADD  CONSTRAINT [FK_Community.Posting_Codes.PostingType] FOREIGN KEY([PostingTypeId])
REFERENCES [dbo].[Codes.PostingType] ([Id])
GO

ALTER TABLE [dbo].[Community.Posting] CHECK CONSTRAINT [FK_Community.Posting_Codes.PostingType]
GO

ALTER TABLE [dbo].[Community.Posting]  WITH CHECK ADD  CONSTRAINT [FK_Community.Posting_Community.Posting] FOREIGN KEY([RelatedPostingId])
REFERENCES [dbo].[Community.Posting] ([Id])
GO

ALTER TABLE [dbo].[Community.Posting] CHECK CONSTRAINT [FK_Community.Posting_Community.Posting]
GO

